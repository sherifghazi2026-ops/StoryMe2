#!/bin/bash

for file in $(grep -l "< style={styles.container}>" src/ --include="*.js"); do
  echo "إصلاح: $file"
  # استبدال < style={styles.container}> بـ <SafeAreaView style={styles.container}>
  sed -i 's/< style={styles.container}>/<SafeAreaView style={styles.container}>/g' "$file"
  # استبدال </ style> بـ </SafeAreaView>
  sed -i 's/<\/ style>/<\/SafeAreaView>/g' "$file"
  # استبدال </style> بـ </SafeAreaView> (حالات أخرى)
  sed -i 's/<\/style>/<\/SafeAreaView>/g' "$file"
done

echo "✅ تم إصلاح جميع الملفات"
