# هنضيف استخراج user_id من AsyncStorage مباشرة
sed -i 's/user_id: userData?.id || null,/user_id: userData?.id || userData?.$id || null,/' ~/Z1/src/screens/customer/CartScreen.js

# ولو برضو null، نستخرجه من AsyncStorage
sed -i 's/const sendOrder = async () => {/const sendOrder = async () => {\n    const storedUser = await AsyncStorage.getItem("userData");\n    const parsedUser = storedUser ? JSON.parse(storedUser) : null;\n    const userId = userData?.id || userData?.$id || parsedUser?.id || parsedUser?.$id || null;/' ~/Z1/src/screens/customer/CartScreen.js

# ونستخدم userId المتغير ده
sed -i 's/user_id: userData?.id || userData?.$id || null,/user_id: userId,/' ~/Z1/src/screens/customer/CartScreen.js
