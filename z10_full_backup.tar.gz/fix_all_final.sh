#!/bin/bash

echo "🔧 بدء إصلاح جميع الملفات..."

# 1. إصلاح الملفات التي تحتوي على < style={styles.container}>
for file in $(grep -l "< style={styles.container}>" src/ --include="*.js" 2>/dev/null); do
  echo "   إصلاح: $file"
  sed -i 's/< style={styles.container}>/<SafeAreaView style={styles.container}>/g' "$file"
done

# 2. إصلاح الملفات التي تحتوي على </ style> أو </style>
for file in $(grep -l "</ style>\|</style>" src/ --include="*.js" 2>/dev/null); do
  echo "   إصلاح: $file"
  sed -i 's/<\/ style>/<\/SafeAreaView>/g' "$file"
  sed -i 's/<\/style>/<\/SafeAreaView>/g' "$file"
done

# 3. إضافة استيراد SafeAreaView للملفات التي تحتوي على SafeAreaView ولكن بدون استيراد
for file in $(grep -l "SafeAreaView" src/ --include="*.js" 2>/dev/null); do
  if ! grep -q "react-native-safe-area-context" "$file"; then
    echo "   إضافة استيراد لـ: $file"
    sed -i '1a import { SafeAreaView } from "react-native-safe-area-context";' "$file"
  fi
done

# 4. إزالة الاستيراد القديم من react-native إذا كان موجوداً
for file in $(grep -l "SafeAreaView" src/ --include="*.js" 2>/dev/null); do
  if grep -q "SafeAreaView" "$file" | grep -q "react-native" | grep -v "react-native-safe-area-context"; then
    echo "   تنظيف: $file"
    sed -i 's/import { SafeAreaView } from "react-native";//g' "$file"
    sed -i "s/import { SafeAreaView } from 'react-native';//g" "$file"
    sed -i 's/import { \([^}]*\)SafeAreaView\([^}]*\) } from "react-native";/import { \1\2 } from "react-native";/g' "$file"
    sed -i "s/import { \([^}]*\)SafeAreaView\([^}]*\) } from 'react-native';/import { \1\2 } from 'react-native';/g" "$file"
  fi
done

# 5. تنظيف الفواصل الزائدة
for file in $(find src -name "*.js" 2>/dev/null); do
  sed -i 's/import { ,/import { /g' "$file"
  sed -i 's/import {  ,/import { /g' "$file"
  sed -i 's/, ,/,/g' "$file"
  sed -i 's/,,/,/g' "$file"
  sed -i 's/import { } from "react-native";//g' "$file"
  sed -i "s/import { } from 'react-native';//g" "$file"
done

echo "✅ تم إصلاح جميع الملفات"
