# إصلاح زر المودال بناءً على حالة تسجيل الدخول
# يستبدل الزر الثابت بزر ديناميكي

sed -i '/<TouchableOpacity style={\[styles.successButton, styles.saveButton\]} onPress={handleRegister}>/,/<\/TouchableOpacity>/c\
{isLoggedIn ? (\
  <TouchableOpacity style={[styles.successButton, styles.trackButton]} onPress={() => { setShowSuccessModal(false); navigation.navigate('\''MyOrdersMain'\''); }}>\
    <Text style={styles.saveButtonText}>تتبع طلبي</Text>\
  </TouchableOpacity>\
) : (\
  <TouchableOpacity style={[styles.successButton, styles.saveButton]} onPress={handleRegister}>\
    <Text style={styles.saveButtonText}>حفظ بياناتي واستكمال التسجيل</Text>\
  </TouchableOpacity>\
)}' ~/Z1/src/screens/customer/CartScreen.js

echo "✅ تم تعديل المودال"
