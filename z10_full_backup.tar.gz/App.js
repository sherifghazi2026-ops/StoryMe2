import 'react-native-gesture-handler';
import React, { useState, useEffect, useRef } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity, LogBox, Platform, AppState, Image, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import * as KeepAwake from 'expo-keep-awake';

const { deactivateKeepAwake, activateKeepAwakeAsync } = KeepAwake;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: true,
    priority: Notifications.AndroidNotificationPriority.MAX,
  }),
});

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'InteractionManager has been deprecated',
  'reading dataString is deprecated',
  'shouldShowAlert is deprecated',
  'Call to function.*ExpoKeepAwake.*rejected',
  'InteractionManager',
  'Possible Unhandled Promise Rejection',
]);

import { CartProvider } from './src/context/CartContext';
import { TermsProvider } from './src/context/TermsContext';
import { loadFonts, fontFamily } from './src/utils/fonts';
import { loadSounds, cleanup, useSoundEffect } from './src/utils/SoundHelper';
import { initializeCoreServices } from './src/services/servicesService';
import { setSoundHandlers } from './src/services/orderService';
import { addNotificationListener, initializeNotifications } from './src/services/notificationService';
import { registerForPushNotificationsAsync } from './src/services/pushNotificationService';
import { supabase } from './src/lib/supabaseClient';
import OrderAlertBar from './src/components/OrderAlertBar';

import SplashScreen from './src/screens/SplashScreen';
import HomeScreen from './src/screens/HomeScreen';
import LoginScreen from './src/screens/auth/LoginScreen';
import MerchantRegisterScreen from './src/screens/auth/MerchantRegisterScreen';
import ServiceProviderScreen from './src/screens/ServiceProviderScreen';
import CompleteProfileScreen from './src/screens/CompleteProfileScreen';
import CompleteRegistrationScreen from './src/screens/CompleteRegistrationScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import MyOrdersScreen from './src/screens/MyOrdersScreen';
import TermsScreen from './src/screens/TermsScreen';
import OrderTrackingScreen from './src/screens/customer/OrderTrackingScreen';
import ServiceScreen from './src/screens/ServiceScreen';
import UnifiedServiceScreen from './src/screens/UnifiedServiceScreen';
import MerchantsListScreen from './src/screens/MerchantsListScreen';
import MerchantProductsScreen from './src/screens/MerchantProductsScreen';
import CartScreen from './src/screens/customer/CartScreen';
import FulfillmentScreen from './src/screens/customer/FulfillmentScreen';
import RateOrderScreen from './src/screens/customer/RateOrderScreen';
import ProductDetailsScreen from './src/screens/customer/ProductDetailsScreen';
import AddReviewScreen from './src/screens/customer/AddReviewScreen';
import DishDetailsScreen from './src/screens/customer/DishDetailsScreen';
import CustomerItemsServiceScreen from './src/screens/customer/ServiceItemsScreen';
import ProductsServiceScreen from './src/screens/ProductsServiceScreen';
import MerchantDashboard from './src/screens/merchant/MerchantDashboard';
import MerchantOrdersScreen from './src/screens/merchant/MerchantOrdersScreen';
import OrderDetailsScreen from './src/screens/merchant/OrderDetailsScreen';
import MyProductsScreen from './src/screens/merchant/MyProductsScreen';
import AddProductScreen from './src/screens/merchant/AddProductScreen';
import AddOfferScreen from './src/screens/merchant/AddOfferScreen';
import EditMerchantScreen from './src/screens/merchant/EditMerchantScreen';
import DriverDashboard from './src/screens/driver/DriverDashboard';
import DriverDeliveriesScreen from './src/screens/driver/DriverDeliveriesScreen';
import DriverLoginScreen from './src/screens/auth/DriverLoginScreen';
import AdminHomeScreen from './src/screens/admin/AdminHomeScreen';
import UserManagement from './src/screens/admin/UserManagement';
import UserEditScreen from './src/screens/admin/UserEditScreen';
import AdminOrdersScreen from './src/screens/admin/AdminOrdersScreen';
import AddUserScreen from './src/screens/admin/AddUserScreen';
import ServicesManagementScreen from './src/screens/admin/ServicesManagementScreen';
import AddServiceScreen from './src/screens/admin/AddServiceScreen';
import AdminAssistantsScreen from './src/screens/admin/AdminAssistantsScreen';
import EditServiceScreen from './src/screens/admin/EditServiceScreen';
import ManageOffersScreen from './src/screens/admin/ManageOffersScreen';
import ManagePlacesScreen from './src/screens/admin/ManagePlacesScreen';
import ReviewProductsScreen from './src/screens/admin/ReviewProductsScreen';
import ItemsServiceScreen from './src/screens/admin/ItemsServiceScreen';
import ManageAllProductsScreen from './src/screens/admin/ManageAllProductsScreen';
import ManageMerchantProductsScreen from './src/screens/admin/ManageMerchantProductsScreen';
import AdminMerchantsListScreen from './src/screens/admin/AdminMerchantsListScreen';
import AdminMerchantProductsScreen from './src/screens/admin/AdminMerchantProductsScreen';
import AdminProductsReviewScreen from './src/screens/admin/AdminProductsReviewScreen';
import AdminProductsServicesScreen from './src/screens/admin/AdminProductsServicesScreen';
import ManageProductCategoriesScreen from './src/screens/admin/ManageProductCategoriesScreen';
import ManageServiceCategoriesScreen from './src/screens/admin/ManageServiceCategoriesScreen';
import ManageRegionsScreen from './src/screens/admin/ManageRegionsScreen';
import SettingsScreen from './src/screens/admin/SettingsScreen';
import SettingsAppearanceScreen from './src/screens/admin/SettingsAppearanceScreen';
import SettingsSplashScreen from './src/screens/admin/SettingsSplashScreen';
import SettingsSoundsScreen from './src/screens/admin/SettingsSoundsScreen';
import SettingsWaitingScreen from './src/screens/admin/SettingsWaitingScreen';
import SettingsBottomTabsScreen from './src/screens/admin/SettingsBottomTabsScreen';
import UnifiedVerificationScreen from './src/screens/admin/UnifiedVerificationScreen';
import ManageTrackingStepsScreen from './src/screens/admin/ManageTrackingStepsScreen';
import ManageProductsScreen from './src/screens/admin/ManageProductsScreen';
import FullServiceManager from './src/screens/admin/FullServiceManager';
import MerchantFullServiceManager from './src/screens/merchant/MerchantFullServiceManager';
import ShopManagementScreen from './src/screens/admin/ShopManagementScreen';
import TemplateProductsScreen from './src/screens/admin/TemplateProductsScreen';
import OffersScreen from './src/screens/OffersScreen';
import EshopScreen from './src/screens/EshopScreen';
import FullServiceFieldScreen from './src/screens/FullServiceFieldScreen';
import FullServiceFlow from './src/screens/FullServiceFlow';
import LoadingScreen from './src/screens/LoadingScreen';
import OfflineScreen from './src/screens/OfflineScreen';
import CustomerAuthScreen from './src/screens/CustomerAuthScreen';

const AiMainModal = ({ navigation }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFF' }}>
    <Ionicons name="flash" size={80} color="#8B5CF6" />
    <Text style={{ fontSize: 20, fontWeight: 'bold', marginTop: 20, fontFamily: fontFamily.arabic }}>خدمات الذكاء الاصطناعي</Text>
    <Text style={{ fontSize: 14, color: '#6B7280', marginTop: 10, textAlign: 'center', paddingHorizontal: 20, fontFamily: fontFamily.arabic }}>هذه الخدمة قيد التطوير حالياً</Text>
    <TouchableOpacity style={{ marginTop: 30, backgroundColor: '#8B5CF6', paddingHorizontal: 30, paddingVertical: 12, borderRadius: 8 }} onPress={() => navigation.goBack()}>
      <Text style={{ color: '#FFF', fontSize: 16, fontFamily: fontFamily.arabic }}>رجوع</Text>
    </TouchableOpacity>
  </View>
);

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function CustomerStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="ServiceScreen" component={ServiceScreen} />
      <Stack.Screen name="MerchantsListScreen" component={MerchantsListScreen} />
      <Stack.Screen name="ProductDetailsScreen" component={ProductDetailsScreen} />
      <Stack.Screen name="DishDetails" component={DishDetailsScreen} />
      <Stack.Screen name="Cart" component={CartScreen} />
      <Stack.Screen name="FulfillmentScreen" component={FulfillmentScreen} />
      <Stack.Screen name="RateOrderScreen" component={RateOrderScreen} />
      <Stack.Screen name="ServiceItemsScreen" component={CustomerItemsServiceScreen} />
      <Stack.Screen name="ProductsServiceScreen" component={ProductsServiceScreen} />
      <Stack.Screen name="FullServiceFlow" component={FullServiceFlow} />
      <Stack.Screen name="FullServiceFieldScreen" component={FullServiceFieldScreen} />
    </Stack.Navigator>
  );
}

function MyOrdersStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MyOrdersMain" component={MyOrdersScreen} />
      <Stack.Screen name="OrderTrackingScreen" component={OrderTrackingScreen} />
      <Stack.Screen name="RateOrderScreen" component={RateOrderScreen} />
    </Stack.Navigator>
  );
}

function OffersStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="OffersMain" component={OffersScreen} />
    </Stack.Navigator>
  );
}

function EshopStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="EshopMain" component={EshopScreen} />
      <Stack.Screen name="ProductDetailsScreen" component={ProductDetailsScreen} />
      <Stack.Screen name="AddReview" component={AddReviewScreen} />
      <Stack.Screen name="Cart" component={CartScreen} />
      <Stack.Screen name="FulfillmentScreen" component={FulfillmentScreen} />
    </Stack.Navigator>
  );
}

function MainTabs() {
  const [primaryColor, setPrimaryColor] = useState("#4F46E5");
  const [tabs, setTabs] = useState({
    tab1: { label: 'طلب', icon: 'cart' },
    tab2: { label: 'عروض', icon: 'pricetag' },
    tab3: { label: 'متجر Zid', icon: 'storefront' },
    tab4: { label: 'طلباتي', icon: 'list' },
  });

  const applySettings = (s) => {
    if (s.primary_color) setPrimaryColor(s.primary_color);
    setTabs({
      tab1: { label: s.tab1_label || 'طلب', icon: s.tab1_icon || 'cart', image: s.tab1_image || '' },
      tab2: { label: s.tab2_label || 'عروض', icon: s.tab2_icon || 'pricetag', image: s.tab2_image || '' },
      tab3: { label: s.tab3_label || 'متجر Zid', icon: s.tab3_icon || 'storefront', image: s.tab3_image || '' },
      tab4: { label: s.tab4_label || 'طلباتي', icon: s.tab4_icon || 'list', image: s.tab4_image || '' },
    });
  };

  useEffect(() => {
    supabase.from('app_settings').select('*').eq('id', 1).single().then(({ data }) => {
      if (data) {
        applySettings(data);
        AsyncStorage.setItem('appSettings', JSON.stringify(data));
      }
    }).catch(() => {});
  }, []);

  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        const tabImages = [tabs.tab1, tabs.tab2, tabs.tab3, tabs.tab4];
        const tabNames = [tabs.tab1.label, tabs.tab2.label, tabs.tab3.label, tabs.tab4.label];
        const idx = tabNames.indexOf(route.name);
        if (idx >= 0 && tabImages[idx]?.image) {
          return <Image source={{ uri: tabImages[idx].image }} style={{ width: 24, height: 24, borderRadius: 6 }} />;
        }
        let iconName;
        if (route.name === tabs.tab1.label) iconName = focused ? tabs.tab1.icon : tabs.tab1.icon + '-outline';
        else if (route.name === tabs.tab2.label) iconName = focused ? tabs.tab2.icon : tabs.tab2.icon + '-outline';
        else if (route.name === tabs.tab3.label) iconName = focused ? tabs.tab3.icon : tabs.tab3.icon + '-outline';
        else if (route.name === tabs.tab4.label) iconName = focused ? tabs.tab4.icon : tabs.tab4.icon + '-outline';
        return <Ionicons name={iconName} size={size} color={color} />;
      },
      tabBarActiveTintColor: primaryColor,
      tabBarInactiveTintColor: '#6B7280',
      tabBarStyle: {
        backgroundColor: '#FFF',
        borderTopColor: '#E5E7EB',
        borderTopWidth: 1,
        elevation: 8,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -2 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        paddingBottom: 5,
        height: 60,
      },
      tabBarLabelStyle: {
        fontSize: 12,
        fontWeight: '500',
        fontFamily: fontFamily.arabic,
        marginBottom: 5,
      },
      headerShown: false,
    })}>
      <Tab.Screen name={tabs.tab1.label} component={CustomerStack} />
      <Tab.Screen name={tabs.tab2.label} component={OffersStack} />
      <Tab.Screen name={tabs.tab3.label} component={EshopStack} />
      <Tab.Screen name={tabs.tab4.label} component={MyOrdersStack} />
    </Tab.Navigator>
  );
}

function RootStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="Loading">
      <Stack.Screen name="Loading" component={LoadingScreen} />
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen name="LoginScreen" component={LoginScreen} />
      <Stack.Screen name="CustomerAuth" component={CustomerAuthScreen} />
      <Stack.Screen name="UnifiedServiceScreen" component={UnifiedServiceScreen} />
      <Stack.Screen name="MerchantProductsScreen" component={MerchantProductsScreen} />
      <Stack.Screen name="Cart" component={CartScreen} />
      <Stack.Screen name="FulfillmentScreen" component={FulfillmentScreen} />
      <Stack.Screen name="MerchantRegister" component={MerchantRegisterScreen} />
      <Stack.Screen name="ServiceProvider" component={ServiceProviderScreen} />
      <Stack.Screen name="DriverLogin" component={DriverLoginScreen} />
      <Stack.Screen name="CompleteProfile" component={CompleteProfileScreen} />
      <Stack.Screen name="CompleteRegistrationScreen" component={CompleteRegistrationScreen} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="TermsScreen" component={TermsScreen} />
      <Stack.Screen name="MerchantDashboard" component={MerchantDashboard} />
      <Stack.Screen name="MerchantOrdersScreen" component={MerchantOrdersScreen} />
      <Stack.Screen name="MyOrdersScreen" component={MyOrdersScreen} />
      <Stack.Screen name="OrderDetailsScreen" component={OrderDetailsScreen} />
      <Stack.Screen name="MyProductsScreen" component={MyProductsScreen} />
      <Stack.Screen name="AddProductScreen" component={AddProductScreen} />
      <Stack.Screen name="AddOfferScreen" component={AddOfferScreen} />
      <Stack.Screen name="EditMerchantScreen" component={EditMerchantScreen} />
      <Stack.Screen name="DriverDashboard" component={DriverDashboard} />
      <Stack.Screen name="DriverDeliveries" component={DriverDeliveriesScreen} />
      <Stack.Screen name="AdminHome" component={AdminHomeScreen} />
      <Stack.Screen name="UserManagement" component={UserManagement} />
      <Stack.Screen name="UserEditScreen" component={UserEditScreen} />
      <Stack.Screen name="AdminOrders" component={AdminOrdersScreen} />
      <Stack.Screen name="AddUser" component={AddUserScreen} />
      <Stack.Screen name="ServicesManagement" component={ServicesManagementScreen} />
      <Stack.Screen name="AddService" component={AddServiceScreen} />
      <Stack.Screen name="EditService" component={EditServiceScreen} />
      <Stack.Screen name="AdminAssistants" component={AdminAssistantsScreen} />
      <Stack.Screen name="ManagePlacesScreen" component={ManagePlacesScreen} />
      <Stack.Screen name="ReviewProductsScreen" component={ReviewProductsScreen} />
      <Stack.Screen name="ItemsServiceScreen" component={ItemsServiceScreen} />
      <Stack.Screen name="ManageAllProductsScreen" component={ManageAllProductsScreen} />
      <Stack.Screen name="ManageMerchantProductsScreen" component={ManageMerchantProductsScreen} />
      <Stack.Screen name="AdminMerchantsListScreen" component={AdminMerchantsListScreen} />
      <Stack.Screen name="AdminMerchantProductsScreen" component={AdminMerchantProductsScreen} />
      <Stack.Screen name="AdminProductsReviewScreen" component={AdminProductsReviewScreen} />
      <Stack.Screen name="AdminProductsServicesScreen" component={AdminProductsServicesScreen} />
      <Stack.Screen name="ManageProductCategoriesScreen" component={ManageProductCategoriesScreen} />
      <Stack.Screen name="ManageServiceCategoriesScreen" component={ManageServiceCategoriesScreen} />
      <Stack.Screen name="ManageRegionsScreen" component={ManageRegionsScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="SettingsAppearance" component={SettingsAppearanceScreen} />
      <Stack.Screen name="SettingsSplash" component={SettingsSplashScreen} />
      <Stack.Screen name="SettingsSounds" component={SettingsSoundsScreen} />
      <Stack.Screen name="SettingsWaiting" component={SettingsWaitingScreen} />
      <Stack.Screen name="SettingsBottomTabs" component={SettingsBottomTabsScreen} />
      <Stack.Screen name="UnifiedVerificationScreen" component={UnifiedVerificationScreen} />
      <Stack.Screen name="ManageTrackingStepsScreen" component={ManageTrackingStepsScreen} />
      <Stack.Screen name="ManageProductsScreen" component={ManageProductsScreen} />
      <Stack.Screen name="FullServiceManager" component={FullServiceManager} />
      <Stack.Screen name="MerchantFullServiceManager" component={MerchantFullServiceManager} />
      <Stack.Screen name="ShopManagement" component={ShopManagementScreen} />
      <Stack.Screen name="TemplateProductsScreen" component={TemplateProductsScreen} />
      <Stack.Screen name="ManageOffersScreen" component={ManageOffersScreen} />
      <Stack.Screen name="AiMainModal" component={AiMainModal} />
      <Stack.Screen name="OfflineScreen" component={OfflineScreen} />
      <Stack.Screen name="OrderTrackingScreen" component={OrderTrackingScreen} />
      <Stack.Screen name="RateOrderScreen" component={RateOrderScreen} />
      <Stack.Screen name="OffersScreen" component={OffersScreen} />
    </Stack.Navigator>
  );
}

const cacheAppSettings = async () => {
  try {
    const { data } = await supabase.from('app_settings').select('*').eq('id', 1).single();
    if (data) {
      await AsyncStorage.setItem('appSettings', JSON.stringify(data));
      console.log('✅ تم تحميل إعدادات التطبيق');
    }
  } catch (error) {
    console.log('⚠️ فشل تحميل الإعدادات:', error.message);
  }
};

export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);
  const navigationRef = useRef();
  const [alertData, setAlertData] = useState(null);
  const soundEffects = useSoundEffect();
  const notificationListenerRef = useRef(null);

  useEffect(() => {
    global.showOrderAlert = (data) => setAlertData(data);
    return () => { global.showOrderAlert = null; };
  }, []);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'active') {
        activateKeepAwakeAsync?.()?.catch(() => {});
      } else {
        deactivateKeepAwake?.()?.catch(() => {});
        if (soundEffects && soundEffects.stopNotificationSound) {
          soundEffects.stopNotificationSound();
        }
      }
    });
    return () => subscription.remove();
  }, [soundEffects]);

  useEffect(() => {
    const setupNotifications = async () => {
      await initializeNotifications();
      await registerForPushNotificationsAsync();
    };
    setupNotifications();
  }, []);

  useEffect(() => {
    async function prepare() {
      try {
        console.log('🚀 بدء تحميل التطبيق...');
        await loadFonts();
        console.log('📦 جاري تحميل Sounds...');
        await loadSounds().catch(e => console.error('❌ خطأ في loadSounds:', e));
        console.log('📦 جاري تهيئة Core Services...');
        await initializeCoreServices().catch(e => console.error('❌ خطأ في initializeCoreServices:', e));
        console.log('📦 جاري تحميل App Settings...');
        await cacheAppSettings();
        console.log('✅ اكتمل تحميل التطبيق بنجاح');
      } catch (error) {
        console.error('❌ خطأ عام في prepare():', error);
      } finally {
        setAppIsReady(true);
      }
    }
    prepare();
    notificationListenerRef.current = addNotificationListener(navigationRef);
    return () => {
      cleanup();
      if (notificationListenerRef.current) notificationListenerRef.current();
    };
  }, []);

  useEffect(() => {
    if (soundEffects) {
      setSoundHandlers(soundEffects.playSendSound, soundEffects.startNotificationSound);
    }
  }, [soundEffects]);

  const handleAcceptOrder = async () => {
    if (alertData?.orderId) {
      const { acceptOrder } = require("./src/services/orderService");
      const userDataStr = await AsyncStorage.getItem("userData");
      const user = userDataStr ? JSON.parse(userDataStr) : null;
      const result = await acceptOrder(alertData.orderId, alertData.merchantId, alertData.merchantName, user?.phone);
      if (result.success) {
        setAlertData(null);
        soundEffects.stopNotificationSound();
        navigationRef.current?.navigate("MerchantOrdersScreen");
      } else {
        Alert.alert('خطأ', result.error || 'فشل قبول الطلب');
      }
    }
  };

  const handleRejectOrder = async () => {
    if (alertData?.orderId) {
      const { updateOrderStatus, ORDER_STATUS } = require("./src/services/orderService");
      await updateOrderStatus(alertData.orderId, ORDER_STATUS.CANCELLED, { cancellation_reason: "رفض بواسطة التاجر" });
      setAlertData(null);
      soundEffects.stopNotificationSound();
    }
  };

  if (!appIsReady) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4F46E5" />
        <Text style={[styles.loadingText, { fontFamily: fontFamily.arabic }]}>
          جاري تحميل التطبيق...
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <TermsProvider>
        <CartProvider>
          <NavigationContainer ref={navigationRef}>
            <RootStack />
          </NavigationContainer>
        </CartProvider>
      </TermsProvider>
      <OrderAlertBar
        visible={!!alertData}
        data={alertData}
        onAccept={handleAcceptOrder}
        onReject={handleRejectOrder}
        onDismiss={() => {
          setAlertData(null);
          soundEffects.stopNotificationSound();
        }}
      />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  loadingText: {
    marginTop: 12,
    color: '#6B7280',
    fontSize: 14,
  },
});
// trigger build Thu May 21 23:56:57 EEST 2026
