const fs = require('fs');
let content = fs.readFileSync('src/screens/customer/FulfillmentScreen.js', 'utf8');

content = content.replace(
  'const analyzeCart = async () => {',
  `const analyzeCart = async () => {
    if (!allItems || allItems.length === 0) { setLoading(false); return; }
    if (!allItems.some(item => item.id || item.cartItemId)) { setLoading(false); return; }`
);

fs.writeFileSync('src/screens/customer/FulfillmentScreen.js', content);
console.log('تم');
