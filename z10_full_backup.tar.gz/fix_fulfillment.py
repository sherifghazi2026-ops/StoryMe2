import re

with open('src/screens/customer/FulfillmentScreen.js', 'r') as f:
    content = f.read()

old = """  const loadSettings = async () => {
    try {
      const { data } = await supabase.from('app_settings').select('key, value').in('key', ['waiting_image_url', 'waiting_header_url', 'top_bar_image_url']);
      if (data) {
        data.forEach(item => {
          if (item.key === 'waiting_image_url') setWaitingImage(item.value || null);
          if (item.key === 'waiting_header_url') setWaitingHeader(item.value || null);
          if (item.key === 'top_bar_image_url') setTopBarImage(item.value || null);
        });
      }
    } catch (e) {}
  };"""

new = """  const loadSettings = async () => {
    try {
      const { data } = await supabase.from('app_settings').select('*').eq('id', 1).single();
      if (data) {
        setWaitingImage(data.waiting_image_url || null);
        setWaitingHeader(data.waiting_header_url || null);
        setTopBarImage(data.top_bar_image_url || null);
      }
    } catch (e) {}
  };"""

content = content.replace(old, new)

with open('src/screens/customer/FulfillmentScreen.js', 'w') as f:
    f.write(content)

print("تم التعديل")
