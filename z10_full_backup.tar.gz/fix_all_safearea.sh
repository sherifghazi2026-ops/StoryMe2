#!/bin/bash

for file in $(grep -r "SafeAreaView" src/ --include="*.js" | grep -v "react-native-safe-area-context" | cut -d: -f1 | sort -u); do
  echo "تعديل: $file"
  
  # إزالة SafeAreaView من الاستيرادات الموجودة
  sed -i 's/SafeAreaView,//g' "$file"
  sed -i 's/, SafeAreaView//g' "$file"
  sed -i 's/SafeAreaView//g' "$file"
  
  # إضافة الاستيراد الجديد إذا لم يكن موجوداً
  if ! grep -q "react-native-safe-area-context" "$file"; then
    # البحث عن سطر الاستيراد من react-native وإضافة الاستيراد بعده
    sed -i '/^import.*from "react-native"/a import { SafeAreaView } from "react-native-safe-area-context";' "$file"
    sed -i "/^import.*from 'react-native'/a import { SafeAreaView } from 'react-native-safe-area-context';" "$file"
  fi
  
  # تنظيف الفواصل الزائدة
  sed -i 's/import { ,/import { /g' "$file"
  sed -i 's/import {  ,/import { /g' "$file"
  sed -i 's/, ,/,/g' "$file"
  sed -i 's/,,/,/g' "$file"
  
  # إزالة الاستيرادات الفارغة
  sed -i 's/import { } from "react-native";//g' "$file"
  sed -i "s/import { } from 'react-native';//g" "$file"
done

echo "✅ تم تعديل جميع الملفات"
