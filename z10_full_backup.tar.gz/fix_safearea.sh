#!/bin/bash

# البحث عن جميع ملفات js التي تحتوي على SafeAreaView من react-native
for file in $(grep -r "SafeAreaView" src/ --include="*.js" | grep -v "react-native-safe-area-context" | cut -d: -f1 | sort -u); do
  echo "تعديل: $file"
  
  # استبدال الاستيراد المنفرد
  sed -i 's/import { SafeAreaView } from "react-native";/import { SafeAreaView } from "react-native-safe-area-context";/g' "$file"
  sed -i "s/import { SafeAreaView } from 'react-native';/import { SafeAreaView } from 'react-native-safe-area-context';/g" "$file"
  
  # استبدال الاستيرادات المتعددة (الحالة الأكثر شيوعاً)
  sed -i 's/import { \([^}]*\)SafeAreaView\([^}]*\) } from "react-native";/import { \1\2 } from "react-native";\nimport { SafeAreaView } from "react-native-safe-area-context";/g' "$file"
  sed -i "s/import { \([^}]*\)SafeAreaView\([^}]*\) } from 'react-native';/import { \1\2 } from 'react-native';\nimport { SafeAreaView } from 'react-native-safe-area-context';/g" "$file"
  
  # إزالة الفواصل الزائدة الناتجة عن التعديل السابق
  sed -i 's/import { ,/import { /g' "$file"
  sed -i 's/import {  ,/import { /g' "$file"
  sed -i 's/, ,/,/g' "$file"
  sed -i 's/,,/,/g' "$file"
  
  # تنظيف الاستيرادات الفارغة
  sed -i 's/import { } from "react-native";//g' "$file"
  sed -i "s/import { } from 'react-native';//g" "$file"
  
  # إزالة الأسطر الفارغة المتكررة
  sed -i '/^$/N;/^\n$/D' "$file"
done

echo "✅ تم تعديل جميع الملفات"
