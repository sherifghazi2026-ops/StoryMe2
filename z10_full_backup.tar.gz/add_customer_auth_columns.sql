-- إضافة أعمدة التحكم في شاشة تسجيل الدخول
ALTER TABLE app_settings
ADD COLUMN IF NOT EXISTS customer_auth_opacity TEXT DEFAULT '1.0',
ADD COLUMN IF NOT EXISTS customer_auth_background_url TEXT;
