import React, { useEffect } from 'react';
import { useAudioPlayer } from 'expo-audio';

export default function NotificationSound({ soundUrl, shouldPlay = false }) {
  const player = useAudioPlayer(soundUrl);

  useEffect(() => {
    if (shouldPlay) {
      player.play();
    }
  }, [shouldPlay]);

  return null; // هذا المكون لا يعرض أي شيء
}

// مثال للاستخدام:
// <NotificationSound
//   soundUrl="https://your-supabase-url/storage/v1/object/public/sounds/notification.mp3"
//   shouldPlay={true}
// />
