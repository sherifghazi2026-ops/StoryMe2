import React, { useState, useEffect, useMemo, useRef } from 'react';
import Mongez from './Mongez';
import { useCart } from '../context/CartContext';
import { getAssistantsForScreen } from '../services/assistantService';

export default function DynamicMongez({ screen, navigation, contextData = {} }) {
  const { cartItems } = useCart();
  const [hasAssistant, setHasAssistant] = useState(false);
  const [loading, setLoading] = useState(true);
  const loggedRef = useRef(false);

  useEffect(() => {
    const checkAssistant = async () => {
      try {
        let serviceId = null;
        
        // دعم service و products_service
        if ((screen === 'service' || screen === 'products_service') && contextData?.serviceId) {
          serviceId = contextData.serviceId;
        }

        if (!loggedRef.current) {
          console.log(`🔍 التحقق من وجود مساعد للشاشة: ${screen} ${serviceId ? `(خدمة: ${serviceId})` : ''}`);
        }

        // جلب المساعد للشاشة المطلوبة
        let result = await getAssistantsForScreen(screen, serviceId);
        
        // إذا كانت الشاشة products_service ولم نجد مساعد، نحاول البحث عن مساعد service
        if (screen === 'products_service' && (!result.success || result.data.length === 0)) {
          if (!loggedRef.current) console.log(`🔄 لم نجد مساعد لـ products_service، نحاول البحث في service...`);
          result = await getAssistantsForScreen('service', serviceId);
        }

        if (!loggedRef.current) {
          console.log(`📊 نتيجة التحقق:`, result);
        }

        if (result.success && result.data && result.data.length > 0) {
          if (!loggedRef.current) console.log(`✅ يوجد مساعد للشاشة ${screen}:`, result.data[0].name);
          setHasAssistant(true);
        } else {
          if (!loggedRef.current) console.log(`⚠️ لا يوجد مساعد للشاشة ${screen}`);
          setHasAssistant(false);
        }
        loggedRef.current = true;
      } catch (error) {
        if (!loggedRef.current) console.error('❌ خطأ في التحقق من المساعد:', error);
        setHasAssistant(false);
        loggedRef.current = true;
      } finally {
        setLoading(false);
      }
    };

    checkAssistant();
  }, [screen, contextData?.serviceId]);

  const fullContext = useMemo(() => {
    const baseContext = { ...contextData };
    if (cartItems && cartItems.length > 0) {
      baseContext.cartItems = cartItems;
    }
    return baseContext;
  }, [screen, contextData, cartItems]);

  if (loading) return null;
  if (!hasAssistant) return null;

  return (
    <Mongez screen={screen} navigation={navigation} contextData={fullContext} />
  );
}
