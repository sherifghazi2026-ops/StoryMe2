import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, Vibration } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { fontFamily } from '../utils/fonts';

const { width } = Dimensions.get('window');

export default function OrderAlertBar({ visible, orderData, onAccept, onReject, onDismiss }) {
  const [timeLeft, setTimeLeft] = useState(30);

  useEffect(() => {
    if (visible) {
      setTimeLeft(30);
      Vibration.vibrate([500, 500, 500]);
    }
  }, [visible]);

  useEffect(() => {
    if (!visible) return;
    if (timeLeft <= 0) {
      onDismiss?.();
      return;
    }
    const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, visible]);

  if (!visible || !orderData) return null;

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Ionicons name="notifications" size={24} color="#FFFFFF" />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.title}>طلب جديد!</Text>
          <Text style={styles.subtitle}>
            رقم الطلب: #{orderData?.orderId?.slice(0, 8)}...
          </Text>
          <Text style={styles.customerName}>
            العميل: {orderData?.customerName || 'غير معروف'}
          </Text>
          <Text style={styles.timer}>⏰ {timeLeft} ثانية</Text>
        </View>
        <View style={styles.buttons}>
          <TouchableOpacity style={[styles.button, styles.acceptButton]} onPress={onAccept}>
            <Ionicons name="checkmark-circle" size={28} color="#FFFFFF" />
            <Text style={styles.buttonText}>قبول</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.rejectButton]} onPress={onReject}>
            <Ionicons name="close-circle" size={28} color="#FFFFFF" />
            <Text style={styles.buttonText}>رفض</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 50,
    left: 10,
    right: 10,
    backgroundColor: '#4F46E5',
    borderRadius: 16,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    zIndex: 9999,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: fontFamily.arabic,
  },
  subtitle: {
    fontSize: 13,
    color: '#E0E7FF',
    fontFamily: fontFamily.arabic,
    marginTop: 2,
  },
  customerName: {
    fontSize: 12,
    color: '#C7D2FE',
    fontFamily: fontFamily.arabic,
    marginTop: 1,
  },
  timer: {
    fontSize: 12,
    color: '#FCA5A5',
    fontFamily: fontFamily.arabic,
    marginTop: 4,
  },
  buttons: {
    flexDirection: 'row',
    marginLeft: 8,
    gap: 8,
  },
  button: {
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    minWidth: 60,
  },
  acceptButton: {
    backgroundColor: '#10B981',
  },
  rejectButton: {
    backgroundColor: '#EF4444',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: 'bold',
    marginTop: 2,
    fontFamily: fontFamily.arabic,
  },
});
