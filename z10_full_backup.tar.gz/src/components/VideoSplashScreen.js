import React, { useEffect } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { VideoView, useVideoPlayer } from 'expo-video';
import * as SplashScreen from 'expo-splash-screen';

const { width, height } = Dimensions.get('window');

const VideoSplashScreen = ({ videoUrl, onFinish }) => {
  const player = useVideoPlayer(videoUrl, (playerInstance) => {
    playerInstance.loop = false;
    playerInstance.play();
  });

  useEffect(() => {
    if (!player) return;

    const checkVideoEnd = () => {
      if (!player.playing && player.currentTime > 0) {
        SplashScreen.hideAsync();
        if (onFinish) onFinish();
      }
    };

    const interval = setInterval(checkVideoEnd, 200);
    return () => clearInterval(interval);
  }, [player, onFinish]);

  return (
    <View style={styles.container}>
      <VideoView
        player={player}
        style={styles.video}
        contentFit="cover"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  video: { width, height },
});

export default VideoSplashScreen;
