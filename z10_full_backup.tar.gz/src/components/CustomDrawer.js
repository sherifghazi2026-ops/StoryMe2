import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Alert, ScrollView, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';

const appIcon = require('../../assets/icons/Zidicon.png');

export default function CustomDrawer({ isLoggedIn, userData, onClose, navigation }) {
  const [isFullService, setIsFullService] = useState(false);

  useEffect(() => { checkMerchantType(); }, [userData]);

  const checkMerchantType = async () => {
    if (userData?.role === 'merchant' && userData?.merchant_type) {
      const { data: service } = await supabase
        .from('services')
        .select('type')
        .eq('id', userData.merchant_type)
        .single();
      if (service?.type === 'full_service') {
        setIsFullService(true);
      }
    }
  };

  const handleLogout = async () => {
    Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'خروج', onPress: async () => {
          await AsyncStorage.removeItem('userData');
          await AsyncStorage.removeItem('userToken');
          await AsyncStorage.removeItem('userPhone');
          await AsyncStorage.removeItem('userRole');
          onClose();
          navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
        }
      }
    ]);
  };

  const handleVisitorLogin = async () => {
    await AsyncStorage.setItem('userRole', 'visitor');
    onClose();
    navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
  };

  const handleContact = () => { Linking.openURL('https://wa.me/201223369908'); };
  const handleShare = () => { Linking.openURL('https://wa.me/?text=حمل%20تطبيق%20Zid%20-%20Zid%20App'); };
  const handleRate = () => { Alert.alert('⭐ تقييم التطبيق', 'تقييم التطبيق سيكون متاحاً قريباً على المتجر'); };

  const getInitials = (name) => {
    if (!name) return '👤';
    const nameParts = name.trim().split(' ');
    return nameParts.length >= 2 ? `${nameParts[0].charAt(0)}${nameParts[1].charAt(0)}`.toUpperCase() : name.charAt(0).toUpperCase();
  };

  const getAvatarColor = (name) => {
    if (!name) return '#4F46E5';
    const colors = ['#4F46E5', '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899', '#14B8A6'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) { hash = ((hash << 5) - hash) + name.charCodeAt(i); hash |= 0; }
    return colors[Math.abs(hash) % colors.length];
  };

  const getAvatarImage = () => {
    if (userData?.avatar_url) return <Image source={{ uri: userData.avatar_url }} style={styles.avatarImage} />;
    return (
      <View style={[styles.avatarPlaceholder, { backgroundColor: getAvatarColor(userData?.name) }]}>
        <Text style={styles.avatarInitials}>{getInitials(userData?.name)}</Text>
      </View>
    );
  };

  const getRoleText = (role) => {
    switch(role) {
      case 'merchant': return 'تاجر';
      case 'driver': return 'مندوب';
      case 'admin': return 'مدير النظام';
      default: return '';
    }
  };

  const guestMenuItems = [
    { icon: 'log-in-outline', title: 'تسجيل الدخول', screen: 'CustomerAuth', color: '#4F46E5' },
    { icon: 'share-social-outline', title: 'شارك التطبيق', action: handleShare, color: '#3B82F6' },
    { icon: 'star-outline', title: 'قيم التطبيق', action: handleRate, color: '#F59E0B' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'person-outline', title: 'الدخول كزائر', action: handleVisitorLogin, color: '#9CA3AF' },
  ];

  const customerMenuItems = [
    { icon: 'home-outline', title: 'الرئيسية', screen: 'MainTabs', color: '#4F46E5' },
    { icon: 'cart-outline', title: 'طلباتي السابقة', screen: 'MyOrdersScreen', color: '#F59E0B' },
    { icon: 'person-outline', title: 'الملف الشخصي', screen: 'Profile', color: '#4F46E5' },
    { icon: 'share-social-outline', title: 'شارك التطبيق', action: handleShare, color: '#3B82F6' },
    { icon: 'star-outline', title: 'قيم التطبيق', action: handleRate, color: '#F59E0B' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'log-out-outline', title: 'تسجيل الخروج', action: handleLogout, color: '#EF4444' },
  ];

  const merchantMenuItems = [
    { icon: 'home-outline', title: 'الرئيسية', screen: 'MerchantDashboard', color: '#4F46E5' },
    { icon: 'cube-outline', title: 'منتجاتي', screen: 'MyProductsScreen', color: '#8B5CF6' },
    { icon: 'apps-outline', title: 'إدارة الخدمات', screen: 'MerchantFullServiceManager', color: '#8B5CF6' },
    { icon: 'person-outline', title: 'الملف الشخصي', screen: 'Profile', color: '#4F46E5' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'log-out-outline', title: 'تسجيل الخروج', action: handleLogout, color: '#EF4444' },
  ];

  const fullServiceMerchantItems = [
    { icon: 'home-outline', title: 'الرئيسية', screen: 'MerchantDashboard', color: '#4F46E5' },
    { icon: 'apps-outline', title: 'إدارة الخدمات', screen: 'MerchantFullServiceManager', color: '#8B5CF6' },
    { icon: 'cart-outline', title: 'الطلبات', screen: 'MerchantOrdersScreen', color: '#F59E0B' },
    { icon: 'person-outline', title: 'الملف الشخصي', screen: 'Profile', color: '#4F46E5' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'log-out-outline', title: 'تسجيل الخروج', action: handleLogout, color: '#EF4444' },
  ];

  const driverMenuItems = [
    { icon: 'home-outline', title: 'الرئيسية', screen: 'DriverDashboard', color: '#4F46E5' },
    { icon: 'bicycle-outline', title: 'التوصيلات', screen: 'DriverDeliveries', color: '#10B981' },
    { icon: 'person-outline', title: 'الملف الشخصي', screen: 'Profile', color: '#4F46E5' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'log-out-outline', title: 'تسجيل الخروج', action: handleLogout, color: '#EF4444' },
  ];

  const adminMenuItems = [
    { icon: 'home-outline', title: 'الرئيسية', screen: 'AdminHome', color: '#4F46E5' },
    { icon: 'people-outline', title: 'المستخدمين', screen: 'UserManagement', color: '#F59E0B' },
    { icon: 'cart-outline', title: 'الطلبات', screen: 'AdminOrders', color: '#10B981' },
    { icon: 'business-outline', title: 'الأماكن', screen: 'ManagePlacesScreen', color: '#8B5CF6' },
    { icon: 'person-add-outline', title: 'إضافة مستخدم', screen: 'AddUser', color: '#3B82F6' },
    { icon: 'share-social-outline', title: 'شارك التطبيق', action: handleShare, color: '#3B82F6' },
    { icon: 'logo-whatsapp', title: 'تواصل معنا', action: handleContact, color: '#25D366' },
    { icon: 'log-out-outline', title: 'تسجيل الخروج', action: handleLogout, color: '#EF4444' },
  ];

  let menuItems = guestMenuItems;
  if (isLoggedIn) {
    if (userData?.role === 'customer') menuItems = customerMenuItems;
    else if (userData?.role === 'merchant') menuItems = isFullService ? fullServiceMerchantItems : merchantMenuItems;
    else if (userData?.role === 'driver') menuItems = driverMenuItems;
    else if (userData?.role === 'admin') menuItems = adminMenuItems;
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>{getAvatarImage()}</View>
        <View style={styles.userInfo}>
          {isLoggedIn ? (
            <>
              <Text style={styles.userName}>{userData?.name || userData?.full_name || 'مستخدم'}</Text>
              <Text style={styles.userRole}>{getRoleText(userData?.role)}</Text>
            </>
          ) : (
            <>
              <Text style={styles.userName}>زائر</Text>
              <Text style={styles.userRole}>مرحباً بك</Text>
            </>
          )}
        </View>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}><Ionicons name="close" size={24} color="#FFF" /></TouchableOpacity>
      </View>
      <ScrollView style={styles.menuList}>
        {menuItems.map((item, index) => (
          <TouchableOpacity key={index} style={styles.menuItem} onPress={() => {
            if (item.action) item.action();
            else if (item.screen) { onClose(); navigation.navigate(item.screen); }
          }}>
            <Ionicons name={item.icon} size={24} color={item.color} />
            <Text style={[styles.menuText, { color: item.color }]}>{item.title}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.footer}>
        <Text style={styles.footerText}>Zid © 2026</Text>
        <Text style={styles.footerVersion}>الإصدار 1.0.0</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { backgroundColor: '#4F46E5', padding: 20, paddingTop: 40, flexDirection: 'row', alignItems: 'center', borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  avatarContainer: { marginRight: 15 },
  avatarImage: { width: 62, height: 62, borderRadius: 31, borderWidth: 3, borderColor: '#FFFFFF' },
  avatarPlaceholder: { width: 62, height: 62, borderRadius: 31, justifyContent: 'center', alignItems: 'center', borderWidth: 3, borderColor: '#FFFFFF' },
  avatarInitials: { color: '#FFFFFF', fontSize: 24, fontWeight: 'bold' },
  userInfo: { flex: 1 },
  userName: { fontSize: 18, fontWeight: 'bold', color: '#FFF' },
  userRole: { fontSize: 12, color: '#FFD700', marginTop: 2 },
  closeButton: { padding: 5 },
  menuList: { flex: 1, paddingTop: 20 },
  menuItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  menuText: { fontSize: 16, marginLeft: 15, flex: 1 },
  footer: { padding: 20, borderTopWidth: 1, borderTopColor: '#E5E7EB', alignItems: 'center' },
  footerText: { fontSize: 12, color: '#9CA3AF' },
  footerVersion: { fontSize: 10, color: '#D1D5DB', marginTop: 4 },
});
