import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Modal, TextInput, ScrollView,
  ActivityIndicator, Animated, Dimensions, Platform, StatusBar, Image,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import groqService from '../services/groqService';
import { getAssistantsForScreen, fetchAssistantData } from '../services/assistantService';
import { getServiceContext } from '../services/contextService';
import { useCart } from '../context/CartContext';
import { fontFamily } from '../utils/fonts';

const { width } = Dimensions.get('window');
const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 50 : StatusBar.currentHeight || 24;

const CONFIRM_KEYWORDS = ['تمام', 'ايوه', 'نعم', 'موافق', 'ضيف', 'أضف', 'حطه', 'هات', 'جيب', 'اكيد', 'ماشي', 'خلاص', 'يلا'];
const CART_QUERY_KEYWORDS = ['السله', 'السلة', 'السبت', 'عربيتي', 'العربه', 'الطلبات', 'طلباتي'];
const REMOVE_KEYWORDS = ['شيل', 'امسح', 'احذف', 'الغي', 'ازاله', 'مسح', 'مش عايز', 'مش عاوزه', 'مش محتاج', 'مش محتاجه', 'بلاش', 'كفايه', 'كفاية', 'خلع', 'طلع', 'سيب', 'ابعد', 'ارمى', 'ارمي', 'مش ضروري', 'ملهوش لزوم'];
// استفسار عن المنتجات المتاحة
const PRODUCTS_QUERY_KEYWORDS = ['عندك منتجات', 'منتجاتك', 'عندك ايه', 'ايه المتاح', 'ايه المنتجات', 'المنتجات المتاحة', 'ايه اللي عندك'];

// أرقام عربية
const ARABIC_NUMBERS = {
  'واحد': 1, 'اتنين': 2, 'تلاته': 3, 'اربعه': 4, 'خمسه': 5,
  'سته': 6, 'سبعه': 7, 'تمان': 8, 'تسعه': 9, 'عشره': 10,
  'حداشر': 11, 'اتناشر': 12
};

export default function Mongez({ screen, navigation, contextData = {} }) {
  const [visible, setVisible] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [assistant, setAssistant] = useState(null);
  const [context, setContext] = useState(null);
  const [dynamicData, setDynamicData] = useState(null);
  const [slideAnim] = useState(new Animated.Value(width));
  const scrollViewRef = useRef();
  const textInputRef = useRef(null);
  const [customIcon, setCustomIcon] = useState(null);
  const { cartItems, addToCart, updateQuantity, removeFromCart } = useCart();
  const [toastMsg, setToastMsg] = useState('');
  const toastOpacity = useRef(new Animated.Value(0)).current;
  const [welcomed, setWelcomed] = useState(false);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    if (!welcomed) { loadAssistant(); setWelcomed(true); }
    loadContext();
    AsyncStorage.getItem('userData').then(data => { if (data) { const u = JSON.parse(data); setUserName(u.full_name || u.name || ''); } });
    AsyncStorage.getItem("appSettings").then(s => {
      if (s) { const settings = JSON.parse(s); if (settings.assistant_icon_url) setCustomIcon(settings.assistant_icon_url); }
    });
  }, [screen, contextData]);

  useEffect(() => { if (assistant && assistant.data_table) loadDynamicData(); }, [assistant]);

  const showToast = (message) => {
    setToastMsg(message);
    toastOpacity.setValue(1);
    Animated.timing(toastOpacity, { toValue: 0, duration: 4000, useNativeDriver: true }).start(() => setToastMsg(''));
  };

  const loadAssistant = async () => {
    try {
      const result = await getAssistantsForScreen(screen, contextData?.serviceId);
      if (result.success && result.data && result.data.length > 0) {
        setAssistant(result.data[0]);
        const wm = result.data[0].welcome_message || 'أهلاً! أنا مُنجز. كيف أقدر أساعدك؟';
        setMessages([{ id: Date.now(), text: wm, sender: 'assistant', timestamp: new Date() }]);
      }
    } catch (error) { console.error('خطأ:', error); }
  };

  const loadContext = async () => {
    try {
      const result = await getServiceContext(screen, contextData);
      if (result.success && result.data) setContext(result.data);
    } catch (error) { console.error('خطأ:', error); }
  };

  const loadDynamicData = async () => {
    if (!assistant?.data_table) return;
    const result = await fetchAssistantData(assistant.data_table, assistant.data_columns || 'id, name, price, merchant_id, service_id, image_url', assistant.data_filter, assistant.data_limit || 50);
    if (result.success && result.data.length > 0) {
      const filtered = result.data.filter(p => p.count > 1);
      setDynamicData({ summary: filtered.map(p => `${p.name} (${p.price}ج)`).join('، '), products: filtered });
    }
  };

  const openChat = () => { setVisible(true); Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 65, friction: 11 }).start(); };
  const closeChat = () => { Animated.timing(slideAnim, { toValue: width, duration: 300, useNativeDriver: true }).start(() => setVisible(false)); };

  const getCartSummary = () => {
    if (!cartItems || cartItems.length === 0) return 'السلة فاضية حالياً.';
    return cartItems.map(i => `${i.quantity}x ${i.name}`).join('، ');
  };

  const findProduct = (name) => {
    const products = dynamicData?.products || [];
    const clean = name.toLowerCase().trim();
    return products.find(p => p.name?.toLowerCase().includes(clean) || clean.includes(p.name?.toLowerCase()));
  };

  const extractQuantity = (text) => {
    const hindi = text.match(/[٠-٩]+/);
    if (hindi) { const map = { '٠':0,'١':1,'٢':2,'٣':3,'٤':4,'٥':5,'٦':6,'٧':7,'٨':8,'٩':9 }; return parseInt(hindi[0].replace(/[٠-٩]/g, c => map[c])); }
    const latin = text.match(/(\d+)/);
    if (latin) return parseInt(latin[1]);
    for (const [word, num] of Object.entries(ARABIC_NUMBERS)) { if (text.includes(word)) return num; }
    if (text.match(/ين$/) || text.match(/تين$/)) return 2;
    return 1;
  };

  const addProductToCart = (productName, quantity = 1) => {
    const found = findProduct(productName);
    if (found) {
      const existing = cartItems.find(i => i.name?.toLowerCase() === found.name?.toLowerCase());
      if (existing) { updateQuantity(existing.id || existing.cartItemId, quantity); showToast(`✅ تم تحديث "${found.name}" (+${quantity})`); return `✅ تم تحديث كمية "${found.name}" (+${quantity}) في السلة 🛒`; }
      addToCart({ id: found.id, cartItemId: found.id, name: found.name, price: found.price, quantity, image_url: found.image_url || '', merchant_id: found.merchant_id, serviceType: found.service_id, serviceName: found.name, isUnified: true });
      showToast(`✅ تم إضافة "${found.name}" إلى السلة`);
      return `✅ تم إضافة "${found.name}" إلى السلة بنجاح 🛒`;
    }
    return null;
  };

  const removeProductFromCart = (productName) => {
    const item = cartItems.find(i => { const pn = (i.name || '').toLowerCase(); const qn = productName.toLowerCase().trim(); return pn.includes(qn) || qn.includes(pn); });
    if (item) { removeFromCart(item.id || item.cartItemId); showToast(`🗑️ تم حذف "${item.name}" من السلة`); return `🗑️ تم حذف "${item.name}" من السلة`; }
    return null;
  };

  const findProductInText = (text) => {
    const products = dynamicData?.products || [];
    for (const p of products) { if (text.includes(p.name)) { return { productName: p.name, quantity: extractQuantity(text) }; } }
    return null;
  };

  const isConfirmMessage = (text) => CONFIRM_KEYWORDS.some(kw => text.toLowerCase().trim() === kw);
  const isCartQuery = (text) => CART_QUERY_KEYWORDS.some(kw => text.toLowerCase().includes(kw));
  const isProductsQuery = (text) => PRODUCTS_QUERY_KEYWORDS.some(kw => text.toLowerCase().includes(kw));
  const isRemoveIntent = (text) => REMOVE_KEYWORDS.some(kw => text.toLowerCase().includes(kw));

  const sendMessage = async () => {
    if (!inputText.trim() || loading) return;
    const msgText = inputText.trim();
    const userMessage = { id: Date.now(), text: msgText, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setTimeout(() => textInputRef.current?.focus(), 100);
    setLoading(true);

    // ✅ استفسار عن المنتجات - اعرض المتاح بدون عرض "تحب أضيف"
    if (isProductsQuery(msgText)) {
      const summary = dynamicData?.summary || context?.summary || 'لا توجد منتجات حالياً.';
      setMessages(prev => [...prev, { id: Date.now() + 1, text: `📋 ${summary}`, sender: 'assistant', timestamp: new Date() }]);
      setLoading(false);
      return;
    }

    // ✅ إضافة مباشرة لو الرسالة فيها منتج مع أمر (عايز، ضيف، هات، الخ)
    const addKeywords = ['عايز', 'عاوزه', 'عاوز', 'نبي', 'هات', 'جيب', 'ضيف', 'أضف', 'حط', 'اشتري'];
    const isAddIntent = addKeywords.some(kw => msgText.toLowerCase().includes(kw));
    if (isAddIntent) {
      const foundInMsg = findProductInText(msgText);
      if (foundInMsg) {
        const result = addProductToCart(foundInMsg.productName, foundInMsg.quantity);
        if (result) { setMessages(prev => [...prev, { id: Date.now() + 1, text: result, sender: 'assistant', timestamp: new Date() }]); setLoading(false); return; }
      }
    }

    // السلة
    if (isCartQuery(msgText)) {
      const summary = getCartSummary();
      setMessages(prev => [...prev, { id: Date.now() + 1, text: `🛒 ${summary}`, sender: 'assistant', timestamp: new Date() }]);
      setLoading(false);
      return;
    }

    // حذف
    if (isRemoveIntent(msgText)) {
      const item = cartItems.find(i => msgText.toLowerCase().includes((i.name || '').toLowerCase()));
      if (item) { const result = removeProductFromCart(item.name); setMessages(prev => [...prev, { id: Date.now() + 1, text: result, sender: 'assistant', timestamp: new Date() }]); }
      else { setMessages(prev => [...prev, { id: Date.now() + 1, text: 'مش لاقي المنتج ده في السلة.', sender: 'assistant', timestamp: new Date() }]); }
      setLoading(false);
      return;
    }

    // تأكيد "تمام" - دور بس في آخر رسالة مساعد فيها "أضيف" أو "تطلبه"
    if (isConfirmMessage(msgText)) {
      const allMessages = [...messages, userMessage];
      for (let i = allMessages.length - 2; i >= 0; i--) {
        const msg = allMessages[i];
        if (msg.sender === 'assistant' && (msg.text.includes('أضيف') || msg.text.includes('تطلبه'))) {
          const found = findProductInText(msg.text);
          if (found) {
            const result = addProductToCart(found.productName, found.quantity);
            if (result) { setMessages(prev => [...prev, { id: Date.now() + 1, text: result, sender: 'assistant', timestamp: new Date() }]); setLoading(false); return; }
          }
        }
      }
      setMessages(prev => [...prev, { id: Date.now() + 1, text: 'معندناش حاجة نضيفها دلوقتي.', sender: 'assistant', timestamp: new Date() }]);
      setLoading(false);
      return;
    }

    // Groq
    try {
      const model = assistant?.model || 'llama-3.3-70b-versatile';
      let systemPrompt = assistant?.system_prompt || 'أنت مساعد مبيعات ذكي. رد بالعامية المصرية.';
      if (userName) { systemPrompt = `العميل الحالي اسمه: ${userName}. ${systemPrompt}`; }
      const fullPrompt = (dynamicData?.summary || context?.summary || '') ? `المنتجات المتاحة:\n${dynamicData?.summary || context?.summary}\n\nالعميل: ${msgText}` : msgText;
      const response = await groqService.ask(fullPrompt, { model, systemPrompt });
      setMessages(prev => [...prev, { id: Date.now() + 1, text: response.text, sender: 'assistant', timestamp: new Date() }]);
    } catch (error) {
      setMessages(prev => [...prev, { id: Date.now(), text: 'يا فندم حصل ضغط خفيف، جرب تاني...', sender: 'assistant', timestamp: new Date() }]);
    } finally { setLoading(false); }
  };

  if (!assistant && messages.length === 0) return null;
  const assistantColor = assistant?.color || '#4F46E5';

  return (
    <>
      <TouchableOpacity style={[styles.floatingButton, customIcon ? styles.floatingButtonImage : { backgroundColor: assistantColor }]} onPress={openChat} activeOpacity={0.8}>
        {customIcon ? <Image source={{ uri: customIcon }} style={styles.floatingImage} resizeMode="contain" /> : <Ionicons name="chatbubble-ellipses" size={28} color="#FFF" />}
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="none" onRequestClose={closeChat}>
        <StatusBar barStyle="light-content" backgroundColor="#000" />
        <View style={styles.modalOverlay}>
          <Animated.View style={[styles.chatContainer, { transform: [{ translateX: slideAnim }] }]}>
            <View style={[styles.chatHeader, { backgroundColor: assistantColor, paddingTop: STATUSBAR_HEIGHT }]}>
              <TouchableOpacity onPress={closeChat} style={styles.closeButton}><Ionicons name="close" size={24} color="#FFF" /></TouchableOpacity>
              <Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>{assistant?.name || 'مُنجز الذكي'}</Text>
              <View style={{ width: 40 }} />
            </View>

            <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
              <ScrollView 
                ref={scrollViewRef} 
                style={styles.messagesContainer} 
                contentContainerStyle={{ padding: 14, paddingBottom: 20 }} 
                onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })} 
                keyboardShouldPersistTaps="handled" 
                showsVerticalScrollIndicator={false}
              >
                {messages.map(msg => (
                  <View key={msg.id} style={[styles.messageRow, msg.sender === 'user' ? styles.userRow : styles.assistantRow]}>
                    {msg.sender !== 'user' && (
                      <View style={[styles.avatarContainer, customIcon && styles.avatarContainerImage]}>
                        {customIcon ? <Image source={{ uri: customIcon }} style={styles.avatarImage} resizeMode="contain" /> : <Ionicons name="chatbubble" size={20} color={assistantColor} />}
                      </View>
                    )}
                    <View style={[styles.messageBubble, msg.sender === 'user' ? styles.userBubble : styles.assistantBubble]}>
                      <Text style={[styles.messageText, msg.sender === 'user' ? styles.userText : styles.assistantText, { fontFamily: fontFamily.arabic, textAlign: 'right' }]}>{msg.text}</Text>
                      <Text style={styles.timeText}>{msg.timestamp?.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</Text>
                    </View>
                  </View>
                ))}
                {loading && (
                  <View key="loading" style={styles.loadingRow}>
                    <View style={[styles.avatarContainer, customIcon && styles.avatarContainerImage]}>
                      {customIcon ? <Image source={{ uri: customIcon }} style={styles.avatarImage} resizeMode="contain" /> : <Ionicons name="chatbubble" size={20} color={assistantColor} />}
                    </View>
                    <View style={[styles.messageBubble, styles.assistantBubble]}><ActivityIndicator size="small" color={assistantColor} /></View>
                  </View>
                )}
              </ScrollView>

              <View style={styles.inputContainer}>
                <TextInput ref={textInputRef} style={[styles.input, { fontFamily: fontFamily.arabic, textAlign: 'right' }]} value={inputText} onChangeText={setInputText} placeholder="اكتب رسالتك..." placeholderTextColor="#9CA3AF" multiline editable={!loading} />
                <TouchableOpacity style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]} onPress={sendMessage} disabled={!inputText.trim() || loading}>
                  <Ionicons name="send" size={20} color={inputText.trim() ? assistantColor : '#9CA3AF'} />
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>

            {toastMsg !== '' && (
              <Animated.View style={[styles.toastContainer, { opacity: toastOpacity, top: STATUSBAR_HEIGHT + 10 }]}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.toastText}>{toastMsg}</Text>
              </Animated.View>
            )}
          </Animated.View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  floatingButton: { position: 'absolute', bottom: 35, right: 20, width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', elevation: 30, zIndex: 999999 },
  floatingButtonImage: { backgroundColor: 'transparent', borderRadius: 0, elevation: 0 },
  floatingImage: { width: 60, height: 60 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' },
  chatContainer: { flex: 1, width: width, backgroundColor: '#FFF' },
  chatHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingBottom: 10 },
  closeButton: { padding: 4 },
  headerTitle: { fontSize: 17, fontWeight: 'bold', color: '#FFF' },
  messagesContainer: { flex: 1, backgroundColor: '#F9FAFB' },
  messageRow: { flexDirection: 'row', marginBottom: 12, alignItems: 'flex-end' },
  userRow: { justifyContent: 'flex-end' },
  assistantRow: { justifyContent: 'flex-start' },
  avatarContainer: { width: 30, height: 30, borderRadius: 15, backgroundColor: '#EEF2FF', justifyContent: 'center', alignItems: 'center', marginRight: 8 },
  avatarContainerImage: { backgroundColor: 'transparent', borderRadius: 0 },
  avatarImage: { width: 30, height: 30 },
  messageBubble: { maxWidth: '78%', padding: 12, borderRadius: 16 },
  userBubble: { backgroundColor: '#4F46E5' },
  assistantBubble: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E5E7EB' },
  messageText: { fontSize: 14, lineHeight: 22 },
  userText: { color: '#FFF' },
  assistantText: { color: '#1F2937' },
  timeText: { fontSize: 9, color: '#9CA3AF', marginTop: 4, alignSelf: 'flex-end' },
  loadingRow: { flexDirection: 'row', marginBottom: 12, alignItems: 'center' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', padding: 10, borderTopWidth: 1, borderTopColor: '#E5E7EB', backgroundColor: '#FFF', paddingBottom: Platform.OS === 'ios' ? 25 : 10 },
  input: { flex: 1, backgroundColor: '#F3F4F6', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, maxHeight: 100, marginRight: 8, color: '#1F2937' },
  sendButton: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  sendButtonDisabled: { opacity: 0.4 },
  toastContainer: { position: 'absolute', left: 20, right: 20, backgroundColor: '#ECFDF5', borderWidth: 1, borderColor: '#10B981', borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10, zIndex: 9999, elevation: 10 },
  toastText: { flex: 1, fontSize: 14, fontWeight: '600', color: '#065F46', fontFamily: fontFamily.arabic, textAlign: 'right' },
});
