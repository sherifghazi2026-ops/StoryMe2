import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';

export const getServiceContext = async (screen, contextData = {}) => {
  try {
    let summary = '';
    let data = {};

    // 🌟 شاشة المتجر: عرض المنتجات المتاحة
    if (screen === 'eshop') {
      const products = contextData?.products || [];
      if (products.length > 0) {
        const productsList = products.slice(0, 15).map(p => `${p.name} (${p.price}ج)`).join('، ');
        summary = `المنتجات المتاحة في المتجر (${products.length} منتج): ${productsList}${products.length > 15 ? ` و ${products.length - 15} منتج آخر` : ''}.`;
        data.products = products;
      } else {
        summary = 'المتجر لا يحتوي على منتجات حالياً.';
      }
      if (contextData?.cartCount > 0) {
        summary += `\nالعميل لديه ${contextData.cartCount} منتجات في السلة.`;
      }
    }

    // الشاشة الرئيسية
    else if (screen === 'home') {
      const { data: services } = await supabase.from(TABLES.SERVICES).select('name, type, category').eq('is_active', true).limit(10);
      if (services && services.length > 0) {
        const servicesList = services.map(s => s.name).join('، ');
        summary = `الخدمات المتاحة في التطبيق: ${servicesList}. يمكن للمستخدم طلب أي من هذه الخدمات.`;
        data = { services };
      }
    }

    // شاشة الخدمة
    else if (screen === 'service' && contextData?.serviceId) {
      const { data: service } = await supabase.from(TABLES.SERVICES).select('*').eq('id', contextData.serviceId).single();
      if (service) {
        summary = `الخدمة الحالية: ${service.name}`;
        if (service.type === 'items' || service.type === 'products') {
          const { data: merchants } = await supabase.from(TABLES.PROFILES).select('full_name, merchant_type, place_name, id').eq('role', 'merchant').eq('merchant_type', service.id).eq('active', true).limit(10);
          if (merchants && merchants.length > 0) {
            const merchantsList = merchants.map(m => m.place_name || m.full_name).join('، ');
            summary += `\nالتجار المتاحون: ${merchantsList}.`;
            data.merchants = merchants;
          }
          if (contextData?.merchantId) {
            const { data: products } = await supabase.from(TABLES.PRODUCTS).select('name, price, description').eq('merchant_id', contextData.merchantId).eq('status', 'approved').eq('is_available', true).limit(20);
            if (products && products.length > 0) {
              const productsList = products.slice(0, 10).map(p => `${p.name} (${p.price}ج)`).join('، ');
              summary += `\nمنتجات التاجر: ${productsList}.`;
              data.products = products;
            }
          }
        } else if (service.type === 'items_service') {
          const collectionName = service.items_collection || `${service.id}_items`;
          const { data: items } = await supabase.from(collectionName).select('name, iron_price, clean_price, price').eq('is_active', true).limit(20);
          if (items && items.length > 0) {
            const itemsList = items.slice(0, 5).map(i => i.name).join('، ');
            summary += `\nالأصناف المتاحة: ${itemsList}.`;
            data.items = items;
          }
        }
        data.service = service;
      }
    }

    // شاشة السلة
    else if (screen === 'cart' && contextData?.cartItems) {
      if (contextData.cartItems && contextData.cartItems.length > 0) {
        const total = contextData.cartItems.reduce((sum, i) => sum + (i.price * (i.quantity || 1)), 0);
        const itemsList = contextData.cartItems.map(i => `${i.name} x${i.quantity || 1}`).join('، ');
        summary = `السلة تحتوي على: ${itemsList}. الإجمالي: ${total} ج.`;
        data.cart = contextData.cartItems;
      } else {
        summary = 'السلة فارغة.';
      }
    }

    // شاشة الطلبات
    else if (screen === 'orders' && contextData?.customerPhone) {
      const { data: orders } = await supabase.from(TABLES.ORDERS).select('id, status, total_price, created_at').eq('customer_phone', contextData.customerPhone).order('created_at', { ascending: false }).limit(5);
      if (orders && orders.length > 0) {
        const statusMap = { 'pending': 'معلق', 'accepted': 'تم القبول', 'preparing': 'جاري التجهيز', 'on_the_way': 'جاري التوصيل', 'delivered': 'تم التوصيل' };
        const ordersList = orders.map(o => `طلب ${o.id.slice(-6)}: ${statusMap[o.status] || o.status}`).join('\n');
        summary = `آخر طلباتك:\n${ordersList}`;
        data.orders = orders;
      } else {
        summary = 'لا توجد طلبات سابقة.';
      }
    }

    if (!summary) summary = 'لا توجد معلومات إضافية عن هذه الصفحة.';

    console.log('📊 السياق المجمع:', summary.substring(0, 300));
    return { success: true, data: { summary, ...data } };

  } catch (error) {
    console.error('❌ خطأ في جلب السياق:', error);
    return { success: false, error: error.message, data: { summary: 'عذراً، لا يمكن جلب معلومات الخدمة حالياً.' } };
  }
};
