import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { startNotificationSound, stopNotificationSound } from '../utils/SoundHelper';

export const handleNotificationPress = async (data, navigationRef) => {
  await stopNotificationSound();

  if (!navigationRef?.current) return;

  const { screen, orderId, order_id, type } = data || {};
  const finalOrderId = orderId || order_id;

  let userRole = 'customer';
  try {
    const userDataStr = await AsyncStorage.getItem('userData');
    if (userDataStr) {
      const user = JSON.parse(userDataStr);
      userRole = user.role || 'customer';
    }
  } catch (e) {}

  try {
    if (finalOrderId && userRole === 'merchant') {
      navigationRef.current.navigate('MerchantOrdersScreen');
    } else if (finalOrderId) {
      navigationRef.current.navigate('OrderTrackingScreen', { orderId: finalOrderId });
    } else {
      navigationRef.current.navigate(screen || 'MainTabs');
    }
  } catch (error) {
    console.log('Navigation error:', error);
  }
};

export const addNotificationListener = (navigationRef) => {
  console.log('👂 بدء الاستماع للإشعارات');

  const receivedListener = Notifications.addNotificationReceivedListener(notification => {
    const data = notification.request.content.data || {};
    const title = notification.request.content.title || '';
    console.log('📬 إشعار:', title, '| النوع:', data.type);

    // ✅ تشغيل الصوت حسب نوع الإشعار
    if (data.type === 'new_order' || title.includes('طلب جديد')) {
      // للتاجر: يتكرر لحد القبول أو 55 ثانية
      startNotificationSound('merchant');
    } else if (data.type === 'order_confirmed' || title.includes('تم استلام')) {
      // للعميل: مرة واحدة فقط
      startNotificationSound('customer');
    }

    // إظهار البار المنبثق للتاجر
    if (data.type === 'new_order') {
      AsyncStorage.getItem('userData').then(str => {
        if (str) {
          const user = JSON.parse(str);
          if (user.role === 'merchant' && global.showOrderAlert) {
            global.showOrderAlert({
              orderId: data.orderId,
              customerName: data.customerName || 'عميل',
              serviceName: data.serviceName || 'خدمة',
              total: data.total || 0,
              merchantId: data.merchantId || '',
              merchantName: data.merchantName || '',
            });
          }
        }
      });
    }
  });

  const responseListener = Notifications.addNotificationResponseReceivedListener(response => {
    let data = response.notification.request.content.data || {};
    if (!data || Object.keys(data).length === 0) {
      try { data = JSON.parse(response.notification.request.content.dataString || '{}'); } catch (e) {}
    }
    handleNotificationPress(data, navigationRef);
  });

  Notifications.getLastNotificationResponseAsync().then(response => {
    if (response) {
      let data = response.notification.request.content.data || {};
      if (!data || Object.keys(data).length === 0) {
        try { data = JSON.parse(response.notification.request.content.dataString || '{}'); } catch (e) {}
      }
      setTimeout(() => handleNotificationPress(data, navigationRef), 1000);
    }
  });

  return () => {
    receivedListener.remove();
    responseListener.remove();
  };
};

export const initializeNotifications = async () => {
  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.log('❌ لم يتم منح صلاحية الإشعارات');
      return false;
    }

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('orders', {
        name: 'الطلبات',
        description: 'إشعارات الطلبات الجديدة',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#4F46E5',
        sound: 'notification.mp3',
        bypassDnd: true,
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
    }

    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
        shouldShowBanner: true,
        shouldShowList: true,
        priority: Notifications.AndroidNotificationPriority.MAX,
      }),
    });

    console.log('✅ تم تهيئة الإشعارات بنجاح');
    return true;
  } catch (error) {
    console.error('❌ خطأ في تهيئة الإشعارات:', error);
    return false;
  }
};

export default {
  addNotificationListener,
  initializeNotifications,
  handleNotificationPress,
};
