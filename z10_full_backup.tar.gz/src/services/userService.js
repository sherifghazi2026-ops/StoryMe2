import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';

export const toggleUserStatus = async (userId, isActive) => {
  try {
    const { error } = await supabase
      .from(TABLES.PROFILES)
      .update({ is_active: !isActive, updated_at: new Date().toISOString() })
      .eq('id', userId);
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const deleteUser = async (userId) => {
  try {
    // 1. حذف من merchants
    const { error: merchantError } = await supabase
      .from('merchants')
      .delete()
      .eq('user_id', userId);
    if (merchantError) console.log('⚠️ خطأ في حذف التاجر:', merchantError.message);

    // 2. حذف المنتجات المرتبطة
    const { error: productsError } = await supabase
      .from(TABLES.PRODUCTS)
      .delete()
      .eq('merchant_id', userId);
    if (productsError) console.log('⚠️ خطأ في حذف المنتجات:', productsError.message);

    // 3. حذف الطلبات المرتبطة
    const { error: ordersError } = await supabase
      .from(TABLES.ORDERS)
      .delete()
      .or(`merchant_id.eq.${userId},driver_id.eq.${userId},customer_phone.eq.${userId}`);
    if (ordersError) console.log('⚠️ خطأ في حذف الطلبات:', ordersError.message);

    // 4. حذف التقييمات المرتبطة
    const { error: reviewsError } = await supabase
      .from('reviews')
      .delete()
      .or(`provider_id.eq.${userId},customer_id.eq.${userId}`);
    if (reviewsError) console.log('⚠️ خطأ في حذف التقييمات:', reviewsError.message);

    // 5. حذف التوكن
    const { error: tokenError } = await supabase
      .from('user_tokens')
      .delete()
      .eq('user_id', userId);
    if (tokenError) console.log('⚠️ خطأ في حذف التوكن:', tokenError.message);

    // 6. حذف من places (تحديث الأماكن)
    const { error: placesError } = await supabase
      .from('places')
      .update({ merchant_id: null, merchant_name: null })
      .eq('merchant_id', userId);
    if (placesError) console.log('⚠️ خطأ في تحديث الأماكن:', placesError.message);

    // 7. حذف الملف الشخصي
    const { error: profileError } = await supabase
      .from(TABLES.PROFILES)
      .delete()
      .eq('id', userId);
    if (profileError) throw profileError;

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
