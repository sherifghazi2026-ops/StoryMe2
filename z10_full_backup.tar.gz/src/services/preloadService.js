import { Asset } from 'expo-asset';
import * as FileSystem from 'expo-file-system';
import { supabase } from '../lib/supabaseClient';

// قائمة الملفات المحلية المطلوب تحميلها مسبقاً
const localAssets = [
  require('../../assets/icons/ZidiconSP.png'),
  require('../../assets/icon.png'),
  require('../../assets/splash.png'),
  require('../../assets/favicon.png'),
];

// تحميل الملفات المحلية
export const preloadLocalAssets = async () => {
  try {
    console.log('📦 بدء تحميل الملفات المحلية...');
    const cacheImages = localAssets.map(asset => Asset.fromModule(asset).downloadAsync());
    await Promise.all(cacheImages);
    console.log('✅ تم تحميل الملفات المحلية');
    return true;
  } catch (error) {
    console.error('❌ خطأ في تحميل الملفات المحلية:', error);
    return false;
  }
};

// تحميل الصور عن بعد (GIF)
export const preloadRemoteImages = async (urls) => {
  try {
    const validUrls = urls.filter(url => url && url.startsWith('http'));
    if (validUrls.length === 0) return true;
    
    console.log(`📦 بدء تحميل ${validUrls.length} صورة عن بعد...`);
    const promises = validUrls.map(url => 
      Asset.fromURI(url).downloadAsync().catch(e => console.log(`فشل تحميل: ${url}`))
    );
    await Promise.all(promises);
    console.log('✅ تم تحميل الصور عن بعد');
    return true;
  } catch (error) {
    console.error('❌ خطأ في تحميل الصور عن بعد:', error);
    return false;
  }
};

// تحميل الأصوات
export const preloadSounds = async (soundUrls) => {
  try {
    const validUrls = soundUrls.filter(url => url && url.startsWith('http'));
    if (validUrls.length === 0) return true;
    
    console.log(`🔊 بدء تحميل ${validUrls.length} ملف صوتي...`);
    const promises = validUrls.map(async (url) => {
      const filename = url.split('/').pop();
      const filePath = `${FileSystem.documentDirectory}sounds/${filename}`;
      const dirInfo = await FileSystem.getInfoAsync(`${FileSystem.documentDirectory}sounds`);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(`${FileSystem.documentDirectory}sounds`, { intermediates: true });
      }
      const download = FileSystem.createDownloadResumable(url, filePath);
      await download.downloadAsync();
      return filePath;
    });
    await Promise.all(promises);
    console.log('✅ تم تحميل الملفات الصوتية');
    return true;
  } catch (error) {
    console.error('❌ خطأ في تحميل الملفات الصوتية:', error);
    return false;
  }
};

// التحقق من وجود اتصال إنترنت
export const checkInternet = async () => {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    await fetch('https://www.google.com', { method: 'HEAD', signal: controller.signal });
    clearTimeout(timeout);
    return true;
  } catch (error) {
    return false;
  }
};
