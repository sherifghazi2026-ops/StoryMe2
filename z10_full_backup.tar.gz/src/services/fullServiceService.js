import { supabase } from '../lib/supabaseClient';

export const getFullServices = async () => {
  const { data, error } = await supabase
    .from('full_services')
    .select('*')
    .order('created_at', { ascending: true });
  if (error) { console.error('خطأ full_services:', error); return []; }
  return data || [];
};

export const createFullService = async (service) => {
  const { data, error } = await supabase
    .from('full_services')
    .insert([service])
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const getSubServices = async (fullServiceId) => {
  if (!fullServiceId || fullServiceId === 'undefined') {
    console.error('❌ getSubServices: fullServiceId is undefined');
    return [];
  }
  console.log('🔍 getSubServices called with:', fullServiceId);

  // ✅ Normalize: إذا كان fullServiceId هو service_id (نصي) وليس UUID
  let query;
  if (typeof fullServiceId === 'string' && fullServiceId.length < 36) {
    // هو service_id (مثل 'travel') - نجيب الـ UUID من full_services
    const { data: fullService } = await supabase
      .from('full_services')
      .select('id')
      .eq('service_id', fullServiceId)
      .single();
    
    if (!fullService) {
      console.log('⚠️ لم يتم العثور على full_service بـ service_id:', fullServiceId);
      // نجرب البحث مباشرة بـ id
      query = supabase.from('sub_services').select('*').eq('full_service_id', fullServiceId).order('sort_order', { ascending: true });
    } else {
      query = supabase.from('sub_services').select('*').eq('full_service_id', fullService.id).order('sort_order', { ascending: true });
    }
  } else {
    // هو UUID مباشرة
    query = supabase.from('sub_services').select('*').eq('full_service_id', fullServiceId).order('sort_order', { ascending: true });
  }

  const { data, error } = await query;
  if (error) {
    console.error('خطأ في جلب الخدمات الفرعية:', error);
    return [];
  }
  console.log('✅ تم جلب الخدمات الفرعية:', data?.length || 0);
  return data || [];
};

export const createSubService = async (subService) => {
  const { data, error } = await supabase
    .from('sub_services')
    .insert([subService])
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const updateSubService = async (id, updates) => {
  const { data, error } = await supabase
    .from('sub_services')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const deleteSubService = async (id) => {
  const { error } = await supabase
    .from('sub_services')
    .delete()
    .eq('id', id);
  if (error) throw error;
  return true;
};

export const toggleSubServiceActive = async (id, is_active) => {
  const { error } = await supabase
    .from('sub_services')
    .update({ is_active })
    .eq('id', id);
  if (error) throw error;
  return true;
};

export const toggleSubServiceTitle = async (id, show_title) => {
  const { error } = await supabase
    .from('sub_services')
    .update({ show_title })
    .eq('id', id);
  if (error) throw error;
  return true;
};

export const getServiceFields = async (subServiceId) => {
  console.log('🔍 getServiceFields called with:', subServiceId);
  let subServiceName = null;
  try {
    const { data: subData } = await supabase
      .from('sub_services')
      .select('name')
      .eq('id', subServiceId)
      .single();
    if (subData) subServiceName = subData.name;
  } catch (e) {}
  if (subServiceName) {
    console.log(`🔍 البحث عن حقول لـ service_id = "${subServiceName}"`);
    const { data, error } = await supabase
      .from('service_fields')
      .select('*')
      .eq('service_id', subServiceName)
      .order('sort_order', { ascending: true });
    if (!error && data && data.length > 0) {
      console.log(`✅ تم جلب ${data.length} حقل لـ ${subServiceName}`);
      return data;
    }
  }
  const { data, error } = await supabase
    .from('service_fields')
    .select('*')
    .eq('sub_service_id', subServiceId)
    .order('sort_order', { ascending: true });
  if (error) {
    console.error('خطأ في جلب الحقول:', error);
    return [];
  }
  console.log(`✅ تم جلب ${data?.length || 0} حقل`);
  return data || [];
};

export const createServiceField = async (field) => {
  const { data, error } = await supabase
    .from('service_fields')
    .insert([field])
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const updateServiceField = async (id, updates) => {
  const { data, error } = await supabase
    .from('service_fields')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const deleteServiceField = async (id) => {
  const { error } = await supabase
    .from('service_fields')
    .delete()
    .eq('id', id);
  if (error) throw error;
  return true;
};

export const getServiceFieldsByServiceId = async (serviceName) => {
  console.log('🔍 getServiceFieldsByServiceId:', serviceName);
  const { data, error } = await supabase
    .from('service_fields')
    .select('*')
    .eq('service_id', serviceName)
    .order('sort_order', { ascending: true });
  if (error) return [];
  console.log(`✅ getServiceFieldsByServiceId: ${data?.length || 0} حقول`);
  return data || [];
};
