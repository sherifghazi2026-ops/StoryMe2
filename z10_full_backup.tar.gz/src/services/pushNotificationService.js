import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { supabase } from '../lib/supabaseClient';
import AsyncStorage from '@react-native-async-storage/async-storage';

export async function registerForPushNotificationsAsync() {
  try {
    const userDataStr = await AsyncStorage.getItem('userData');
    console.log('🔍 userDataStr:', userDataStr ? 'موجود' : 'مش موجود');
    
    if (!userDataStr) {
      console.log('❌ مفيش userData - المستخدم مش مسجل دخول');
      return null;
    }
    
    const user = JSON.parse(userDataStr);
    const userId = user.id || user.$id;
    console.log('👤 userId:', userId);
    
    if (!userId) {
      console.log('❌ مفيش userId');
      return null;
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    console.log('📋 صلاحية الإشعارات:', existingStatus);
    
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
      console.log('📋 الصلاحية بعد الطلب:', finalStatus);
    }
    
    if (finalStatus !== 'granted') {
      console.log('❌ الصلاحية مش ممنوحة');
      return null;
    }

    const tokenData = await Notifications.getExpoPushTokenAsync({
      projectId: '269d52f2-14ab-478f-8c83-3bda7816fe99',
    });
    const token = tokenData.data;
    console.log('🎫 التوكن:', token);

    // حذف أي توكن قديم بنفس القيمة أو نفس المستخدم
    await supabase.from('user_tokens').delete().eq('expo_push_token', token);
    await supabase.from('user_tokens').delete().eq('user_id', userId);

    // تسجيل التوكن الجديد
    const { error } = await supabase.from('user_tokens').upsert({
      user_id: userId,
      expo_push_token: token,
      platform: Platform.OS,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id' });

    if (error) {
      console.log('❌ خطأ في تسجيل التوكن في Supabase:', error.message);
    } else {
      console.log('✅ Push Token registered in Supabase');
    }

    await AsyncStorage.setItem('expoPushToken', token);
    console.log('✅ Push Token registered:', token);
    return token;
  } catch (error) {
    console.log('❌ فشل تسجيل التوكن:', error.message);
    return null;
  }
}

export async function unregisterPushNotifications() {
  try {
    const token = await AsyncStorage.getItem('expoPushToken');
    const userDataStr = await AsyncStorage.getItem('userData');
    if (token && userDataStr) {
      const user = JSON.parse(userDataStr);
      await supabase.from('user_tokens').delete().eq('user_id', user.id || user.$id).eq('expo_push_token', token);
    }
    await AsyncStorage.removeItem('expoPushToken');
  } catch (error) {}
}

export async function sendNewOrderToMerchant(expoPushToken, data) {
  return sendPushNotification(expoPushToken,
    `🔔 طلب جديد!`,
    `${data.customerName} يطلب ${data.serviceName}\n#${data.orderId?.slice(-6)}\n\n📍 ${data.address || 'غير محدد'} | 💰 ${data.total} ج.م\n⚡ اضغط للرد فوراً`,
    { orderId: data.orderId, order_id: data.orderId, screen: 'MerchantOrdersScreen', type: 'new_order' },
    'notification'
  );
}

export async function sendOrderConfirmationToCustomer(expoPushToken, data) {
  return sendPushNotification(expoPushToken,
    `👋 مرحباً ${data.customerName}!`,
    `تم استلام طلبك رقم #${data.orderId?.slice(-6)} بنجاح\nجاري تجهيز ${data.serviceName} الخاص بك\n\n💰 ${data.total} ج.م | 📍 ${data.address || 'غير محدد'}`,
    { orderId: data.orderId, order_id: data.orderId, screen: 'OrderTrackingScreen', type: 'order_confirmed' },
    'usernotification'
  );
}

export async function sendProductApproved(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `✅ تمت الموافقة على منتجك`, `"${data.productName}" متاح الآن للعملاء\n\n💰 ${data.price} ج.م | 📦 ${data.category || ''}`, { screen: 'MerchantDashboard', type: 'product_approved' });
}

export async function sendProductRejected(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `❌ تم رفض منتجك`, `"${data.productName}" لم يتم قبوله\n\n📝 السبب: ${data.reason || 'غير محدد'}\nيمكنك تعديله وإعادة الإرسال`, { screen: 'MerchantDashboard', type: 'product_rejected' });
}

export async function sendBioApproved(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `✅ تم اعتماد نبذتك التعريفية`, `ملفك الشخصي مكتمل الآن\n\n👁️ سيظهر للعملاء مما يزيد فرص الطلبات`, { screen: 'MerchantDashboard', type: 'bio_approved' });
}

export async function sendBioRejected(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `❌ تم رفض النبذة التعريفية`, `📝 السبب: ${data.reason || 'غير محدد'}\nيمكنك تعديلها من الملف الشخصي`, { screen: 'MerchantDashboard', type: 'bio_rejected' });
}

export async function sendPortfolioApproved(expoPushToken) {
  return sendPushNotification(expoPushToken, `🖼️ تم اعتماد معرض أعمالك`, `صور أعمالك ظاهرة الآن للعملاء\n\n➕ أضف المزيد لزيادة ثقة العملاء`, { screen: 'MerchantDashboard', type: 'portfolio_approved' });
}

export async function sendPortfolioRejected(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `❌ تم رفض صور معرض الأعمال`, `📝 السبب: ${data.reason || 'غير محدد'}\nيمكنك تعديلها من الملف الشخصي`, { screen: 'MerchantDashboard', type: 'portfolio_rejected' });
}

export async function sendOfferApproved(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `🎯 تم تفعيل عرضك`, `"${data.offerTitle}" نشط الآن\n\n🔥 سيظهر للعملاء في قسم العروض`, { screen: 'MerchantDashboard', type: 'offer_approved' });
}

export async function sendOfferRejected(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `❌ تم رفض عرضك`, `"${data.offerTitle}" لم يتم قبوله\n\n📝 السبب: ${data.reason || 'غير محدد'}`, { screen: 'MerchantDashboard', type: 'offer_rejected' });
}

export async function sendNewProductToAdmin(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `📦 منتج جديد للمراجعة`, `"${data.productName}" | ${data.price} ج.م\nمن: ${data.merchantName} | ${data.category || ''}\n\n⏳ بانتظار المراجعة`, { screen: 'ReviewProductsScreen', productId: data.productId, type: 'new_product_review' });
}

export async function sendMerchantContentToAdmin(expoPushToken, data) {
  return sendPushNotification(expoPushToken, `📝 محتوى جديد للمراجعة`, `${data.merchantName}\nالنوع: ${data.contentType}\n\n⏳ بانتظار الموافقة`, { screen: 'ManageMerchantContent', type: 'new_content_review' });
}

export async function sendPushNotification(expoPushToken, title, body, data = {}, sound = 'notification') {
  if (!expoPushToken) return;
  const message = {
    to: expoPushToken,
    sound: sound,
    title: title,
    body: body,
    data: data,
    priority: 'high',
    channelId: data.type === 'order_confirmed' ? 'customer_orders' : 'orders',
  };
  try {
    const response = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Accept-encoding': 'gzip, deflate', 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
    });
    const result = await response.json();
    console.log('📤 إشعار:', title);
    return result;
  } catch (error) { return null; }
}

export async function sendNotificationToUser(userId, title, body, data = {}) {
  try {
    const { data: tokens } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', userId);
    if (tokens) for (const token of tokens) await sendPushNotification(token.expo_push_token, title, body, data);
  } catch (error) {}
}
