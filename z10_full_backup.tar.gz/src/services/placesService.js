import { supabase } from '../lib/supabaseClient';
import { uploadServiceImage } from './uploadService';

/**
 * جلب جميع الأماكن
 */
export const getAllPlaces = async () => {
  try {
    console.log('🔍 جلب جميع الأماكن...');
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    const formattedPlaces = (data || []).map(place => ({
      id: place.id,
      name: place.name,
      address: place.address,
      image_url: place.image_url,
      type: place.type,
      merchant_id: place.merchant_id,
      merchant_name: place.merchant_name,
      delivery_fee: place.delivery_fee || 10,
      phone: place.phone,
      is_active: place.is_active,
      created_at: place.created_at,
    }));
    
    console.log(`✅ تم جلب ${formattedPlaces.length} مكان`);
    return { success: true, data: formattedPlaces };
  } catch (error) {
    console.error('❌ خطأ في جلب الأماكن:', error);
    return { success: false, error: error.message, data: [] };
  }
};

/**
 * جلب الأماكن حسب النوع
 */
export const getPlacesByType = async (type) => {
  try {
    console.log('🔍 جلب الأماكن للنوع:', type);
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .eq('type', type)
      .eq('is_active', true)
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    const formattedPlaces = (data || []).map(place => ({
      id: place.id,
      name: place.name,
      address: place.address,
      image_url: place.image_url,
      type: place.type,
      merchant_id: place.merchant_id,
      merchant_name: place.merchant_name,
      delivery_fee: place.delivery_fee || 10,
      phone: place.phone,
      is_active: place.is_active,
    }));
    
    console.log(`✅ تم جلب ${formattedPlaces.length} مكان`);
    return { success: true, data: formattedPlaces };
  } catch (error) {
    console.error('❌ خطأ في جلب الأماكن:', error);
    return { success: false, error: error.message, data: [] };
  }
};

/**
 * جلب مكان حسب المعرف
 */
export const getPlaceById = async (placeId) => {
  try {
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .eq('id', placeId)
      .single();
    
    if (error) throw error;
    
    return { 
      success: true, 
      data: {
        id: data.id,
        name: data.name,
        address: data.address,
        image_url: data.image_url,
        type: data.type,
        merchant_id: data.merchant_id,
        merchant_name: data.merchant_name,
        delivery_fee: data.delivery_fee || 10,
        phone: data.phone,
      }
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

/**
 * إنشاء مكان جديد
 */
export const createPlace = async (placeData) => {
  try {
    const newPlace = {
      name: placeData.name,
      type: placeData.type,
      address: placeData.address || '',
      image_url: placeData.image_url || null,
      phone: placeData.phone || '',
      merchant_id: placeData.merchant_id || null,
      merchant_name: placeData.merchant_name || null,
      delivery_fee: placeData.delivery_fee || 10,
      is_active: placeData.is_active !== false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    
    const { data, error } = await supabase
      .from('places')
      .insert([newPlace])
      .select('*')
      .single();
    
    if (error) throw error;
    
    console.log('✅ تم إنشاء مكان جديد:', data.name);
    return { success: true, data: { id: data.id, ...data } };
  } catch (error) {
    console.error('❌ فشل إنشاء المكان:', error);
    return { success: false, error: error.message };
  }
};

/**
 * تحديث مكان
 */
export const updatePlace = async (placeId, placeData) => {
  try {
    const updateData = {
      name: placeData.name,
      type: placeData.type,
      address: placeData.address,
      phone: placeData.phone,
      merchant_id: placeData.merchant_id,
      merchant_name: placeData.merchant_name,
      delivery_fee: placeData.delivery_fee,
      is_active: placeData.is_active,
      updated_at: new Date().toISOString(),
    };
    
    // ✅ فقط أضف image_url إذا كان موجوداً
    if (placeData.image_url !== undefined) {
      updateData.image_url = placeData.image_url;
    }
    
    const { data, error } = await supabase
      .from('places')
      .update(updateData)
      .eq('id', placeId)
      .select('*')
      .single();
    
    if (error) throw error;
    
    console.log('✅ تم تحديث المكان:', data.name);
    return { success: true, data: { id: data.id, ...data } };
  } catch (error) {
    console.error('❌ فشل تحديث المكان:', error);
    return { success: false, error: error.message };
  }
};

/**
 * حذف مكان
 */
export const deletePlace = async (placeId) => {
  try {
    const { error } = await supabase
      .from('places')
      .delete()
      .eq('id', placeId);
    
    if (error) throw error;
    
    console.log('✅ تم حذف المكان');
    return { success: true };
  } catch (error) {
    console.error('❌ فشل حذف المكان:', error);
    return { success: false, error: error.message };
  }
};

/**
 * حذف مكان مع المنتجات المرتبطة به
 */
export const deletePlaceWithProducts = async (placeId) => {
  try {
    // 1. حذف المنتجات المرتبطة بالمكان
    const { error: productsError } = await supabase
      .from('products')
      .delete()
      .eq('place_id', placeId);
    
    if (productsError) {
      console.warn('⚠️ خطأ في حذف المنتجات:', productsError.message);
    }
    
    // 2. حذف المكان
    const { error } = await supabase
      .from('places')
      .delete()
      .eq('id', placeId);
    
    if (error) throw error;
    
    console.log('✅ تم حذف المكان والمنتجات المرتبطة');
    return { success: true };
  } catch (error) {
    console.error('❌ فشل حذف المكان:', error);
    return { success: false, error: error.message };
  }
};

/**
 * رفع صورة للمكان - يتم رفع الصورة فقط وإرجاع الرابط
 * @param {string} imageUri - رابط الصورة المحلية
 * @returns {object} نتيجة الرفع مع رابط الصورة
 */
export const uploadPlaceImageOnly = async (imageUri) => {
  try {
    const uploadResult = await uploadServiceImage(imageUri);
    if (!uploadResult.success) {
      throw new Error(uploadResult.error);
    }
    console.log('✅ تم رفع الصورة بنجاح:', uploadResult.fileUrl);
    return { success: true, imageUrl: uploadResult.fileUrl };
  } catch (error) {
    console.error('❌ فشل رفع الصورة:', error);
    return { success: false, error: error.message };
  }
};

/**
 * تحديث صورة المكان - يرفع الصورة ثم يحدث المكان
 */
export const updatePlaceImage = async (placeId, imageUri) => {
  try {
    // 1. رفع الصورة
    const uploadResult = await uploadServiceImage(imageUri);
    if (!uploadResult.success) {
      throw new Error(uploadResult.error);
    }
    
    // 2. تحديث المكان برابط الصورة
    const { data, error } = await supabase
      .from('places')
      .update({ 
        image_url: uploadResult.fileUrl, 
        updated_at: new Date().toISOString() 
      })
      .eq('id', placeId)
      .select('*')
      .single();
    
    if (error) throw error;
    
    console.log('✅ تم تحديث صورة المكان:', data.name);
    return { success: true, data: { id: data.id, ...data }, imageUrl: uploadResult.fileUrl };
  } catch (error) {
    console.error('❌ فشل تحديث صورة المكان:', error);
    return { success: false, error: error.message };
  }
};

/**
 * تغيير حالة المكان (نشط/غير نشط)
 */
export const togglePlaceStatus = async (placeId, isActive) => {
  try {
    const { data, error } = await supabase
      .from('places')
      .update({ is_active: isActive, updated_at: new Date().toISOString() })
      .eq('id', placeId)
      .select('*')
      .single();
    
    if (error) throw error;
    
    console.log(`✅ تم ${isActive ? 'تفعيل' : 'تعطيل'} المكان:`, data.name);
    return { success: true, data: { id: data.id, ...data } };
  } catch (error) {
    console.error('❌ فشل تغيير حالة المكان:', error);
    return { success: false, error: error.message };
  }
};
