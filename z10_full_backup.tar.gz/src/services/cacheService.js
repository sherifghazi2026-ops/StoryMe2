import * as FileSystem from 'expo-file-system/legacy';
import * as Crypto from 'expo-crypto';

const CACHE_DIR = `${FileSystem.cacheDirectory}zid_cache/`;
const METADATA_DIR = `${CACHE_DIR}metadata/`;

const downloadQueue = new Map();

/** توليد اسم ملف ثابت مع الحفاظ على الامتداد */
const getFileName = async (url, type = 'file') => {
  if (!url) return null;
  const hash = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    url,
    { encoding: Crypto.CryptoEncoding.HEX }
  );
  // استخراج الامتداد الأصلي
  const extension = url.split('.').pop().split('?')[0];
  const ext = extension.match(/gif|mp3|mp4|png|jpg|jpeg/) ? `.${extension}` : '';
  return `${type}_${hash}${ext}`;
};

// التأكد من المجلدات
const ensureCacheDir = async () => {
  for (const dir of [CACHE_DIR, METADATA_DIR]) {
    const info = await FileSystem.getInfoAsync(dir);
    if (!info.exists) {
      await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
    }
  }
};

/** الدالة العامة (الأساسية) */
export const cacheFile = async (url, options = {}) => {
  if (!url) return null;

  const { type = 'file', forceRefresh = false } = options;

  try {
    await ensureCacheDir();
    
    const fileName = await getFileName(url, type);
    const filePath = `${CACHE_DIR}${fileName}`;

    // التحقق من وجود الملف
    const fileInfo = await FileSystem.getInfoAsync(filePath);
    if (fileInfo.exists && !forceRefresh) {
      console.log(`✅ من الكاش: ${fileName}`);
      return filePath;
    }

    // منع التحميل المتزامن
    if (downloadQueue.has(fileName)) {
      console.log(`⏳ انتظار: ${fileName}`);
      return await downloadQueue.get(fileName);
    }

    console.log(`⬇️ تحميل: ${fileName}`);

    const downloadPromise = FileSystem.downloadAsync(url, filePath, { cache: false })
      .then(result => {
        if (result.status === 200) {
          console.log(`✅ تم التحميل: ${fileName}`);
          return filePath;
        }
        throw new Error(`Status ${result.status}`);
      })
      .catch(err => {
        console.error(`❌ فشل تحميل ${fileName}:`, err.message);
        return null;
      });

    downloadQueue.set(fileName, downloadPromise);
    const result = await downloadPromise;
    downloadQueue.delete(fileName);

    return result;

  } catch (error) {
    console.error(`❌ فشل تحميل ${url}:`, error.message);
    return null;
  }
};

/** دالة مخصصة للـ GIF */
export const cacheGif = (url) => cacheFile(url, { type: 'gif' });

/** مسح الكاش بالكامل */
export const clearCache = async () => {
  try {
    await FileSystem.deleteAsync(CACHE_DIR, { idempotent: true });
    console.log('🧹 تم مسح الكاش');
  } catch (e) {
    console.error('فشل مسح الكاش:', e);
  }
};

/** الحصول على حجم الكاش */
export const getCacheSize = async () => {
  try {
    const info = await FileSystem.getInfoAsync(CACHE_DIR);
    if (!info.exists) return 0;
    const files = await FileSystem.readDirectoryAsync(CACHE_DIR);
    let total = 0;
    for (const file of files) {
      const fileInfo = await FileSystem.getInfoAsync(`${CACHE_DIR}${file}`);
      if (fileInfo.exists) total += fileInfo.size;
    }
    return total;
  } catch {
    return 0;
  }
};

export default { cacheFile, cacheGif, clearCache, getCacheSize };
