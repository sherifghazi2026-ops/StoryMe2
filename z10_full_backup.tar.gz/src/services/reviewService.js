import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';

const REVIEWS_TABLE = 'reviews';

export const getProviderReviews = async (providerId) => {
  try {
    // ✅ providerId = merchant.id (وليس user.id)
    const { data, error } = await supabase
      .from(REVIEWS_TABLE)
      .select('*, profiles:customer_id(full_name, avatar_url)')
      .eq('provider_id', providerId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) {
    return { success: false, error: error.message, data: [] };
  }
};

export const getProviderAverageRating = async (providerId) => {
  try {
    const { data, error } = await supabase
      .from(REVIEWS_TABLE)
      .select('rating')
      .eq('provider_id', providerId);

    if (error) throw error;

    if (!data || data.length === 0) {
      return { success: true, average: 0, count: 0 };
    }

    const sum = data.reduce((acc, r) => acc + r.rating, 0);
    const average = sum / data.length;
    return { success: true, average, count: data.length };
  } catch (error) {
    return { success: false, error: error.message, average: 0, count: 0 };
  }
};

export const updateProviderRating = async (providerId) => {
  try {
    const { average, count } = await getProviderAverageRating(providerId);
    await supabase
      .from(TABLES.PROFILES)
      .update({
        avg_rating: average,
        reviews_count: count,
        updated_at: new Date().toISOString()
      })
      .eq('id', providerId);
  } catch (error) {
    console.log('⚠️ فشل تحديث متوسط التقييم:', error.message);
  }
};

export const deleteReview = async (reviewId) => {
  try {
    const { error } = await supabase.from(REVIEWS_TABLE).delete().eq('id', reviewId);
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
