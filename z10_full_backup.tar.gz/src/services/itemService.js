import { supabase } from '../lib/supabaseClient';

// ✅ استخدام جدول واحد موحد لجميع الأصناف
const ITEMS_TABLE = 'service_items';

export const getItems = async (serviceId) => {
  try {
    console.log(`🔍 جلب الأصناف للخدمة: ${serviceId}`);
    const { data, error } = await supabase
      .from(ITEMS_TABLE)
      .select('*')
      .eq('service_id', serviceId)
      .order('name', { ascending: true });

    if (error) throw error;

    const formattedData = (data || []).map(item => ({
      $id: item.id,
      ...item,
      created_at: item.created_at,
    }));

    return { success: true, data: formattedData };
  } catch (error) {
    console.error('❌ خطأ في جلب الأصناف:', error);
    return { success: false, error: error.message, data: [] };
  }
};

export const addItem = async (serviceId, itemData) => {
  try {
    if (!itemData.name) return { success: false, error: 'اسم الصنف مطلوب' };

    const newItem = {
      name: itemData.name,
      is_active: itemData.is_active !== false,
      created_at: new Date().toISOString(),
      prices: itemData.prices || null,
      image_url: itemData.image_url || null,
      service_id: serviceId,
    };

    const { data, error } = await supabase
      .from(ITEMS_TABLE)
      .insert([newItem])
      .select('*')
      .single();

    if (error) throw error;
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    console.error('❌ خطأ في إضافة الصنف:', error);
    return { success: false, error: error.message };
  }
};

export const updateItem = async (itemId, itemData) => {
  try {
    const updateData = {
      ...itemData,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from(ITEMS_TABLE)
      .update(updateData)
      .eq('id', itemId)
      .select('*')
      .single();

    if (error) throw error;
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const deleteItem = async (itemId) => {
  try {
    const { error } = await supabase.from(ITEMS_TABLE).delete().eq('id', itemId);
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const toggleItemStatus = async (itemId, is_active) => {
  try {
    const { data, error } = await supabase
      .from(ITEMS_TABLE)
      .update({
        is_active: is_active,
        updated_at: new Date().toISOString(),
      })
      .eq('id', itemId)
      .select('*')
      .single();

    if (error) throw error;
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getActiveItems = async (serviceId) => {
  try {
    if (!serviceId) return { success: false, error: 'معرّف الخدمة مطلوب', data: [] };

    const { data, error } = await supabase
      .from(ITEMS_TABLE)
      .select('*')
      .eq('service_id', serviceId)
      .eq('is_active', true)
      .order('name', { ascending: true });

    if (error) throw error;

    const formattedData = (data || []).map(item => ({
      $id: item.id,
      ...item,
      created_at: item.created_at,
    }));

    return { success: true, data: formattedData };
  } catch (error) {
    console.error('❌ خطأ في جلب الأصناف النشطة:', error);
    return { success: false, error: error.message, data: [] };
  }
};

// ✅ دالة مساعدة للحفاظ على التوافق مع الكود القديم (تأخذ collectionName وتستخدم serviceId)
export const getItemsByCollection = async (collectionName, serviceId = null) => {
  // إذا تم تمرير serviceId، نستخدمه مباشرة
  if (serviceId) {
    return getItems(serviceId);
  }
  // محاولة استخراج serviceId من collectionName (مثلاً bakery_items -> bakery)
  if (collectionName && collectionName.endsWith('_items')) {
    const extractedServiceId = collectionName.replace('_items', '');
    return getItems(extractedServiceId);
  }
  return { success: false, error: 'لا يمكن تحديد الخدمة', data: [] };
};
