import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';
import { sendPushNotification } from './pushNotificationService';
import { stopNotificationSound } from '../utils/SoundHelper';
import { playSendSound } from '../utils/SoundHelper';

export const ORDER_STATUS = {
  PENDING: 'pending', ACCEPTED: 'accepted', PREPARING: 'preparing',
  READY: 'ready', DRIVER_ASSIGNED: 'driver_assigned',
  ON_THE_WAY: 'on_the_way', DELIVERED: 'delivered', CANCELLED: 'cancelled',
};

let globalPlayNotificationSound = null;
let globalPlaySendSound = null;

export const setSoundHandlers = (playSend, playNotification) => {
  globalPlaySendSound = playSend;
  globalPlayNotificationSound = playNotification;
};

export const stopAllSounds = () => {
  stopNotificationSound();
};

let lastOrderIds = new Set();
let notificationInterval = null;
let isPlaying = false;

export const startNotificationCheck = (merchantId) => {
  if (notificationInterval) clearInterval(notificationInterval);
  notificationInterval = setInterval(async () => {
    const result = await getOrders({ status: ORDER_STATUS.PENDING });
    if (result.success && result.data.length > 0) {
      const newOrders = result.data.filter(o => !lastOrderIds.has(o.id));
      if (newOrders.length > 0) {
        newOrders.forEach(o => lastOrderIds.add(o.id));
        if (!isPlaying && globalPlayNotificationSound) {
          isPlaying = true;
          globalPlayNotificationSound();
        }
      }
    }
  }, 5000);
  return () => { clearInterval(notificationInterval); stopAllSounds(); };
};

export const stopOrderNotificationSound = () => {
  stopAllSounds();
};

export const getOrders = async (filters = {}) => {
  try {
    let query = supabase.from(TABLES.ORDERS).select('*');
    if (filters.customerPhone) query = query.eq('customer_phone', filters.customerPhone);
    if (filters.status) {
      if (Array.isArray(filters.status)) query = query.in('status', filters.status);
      else query = query.eq('status', filters.status);
    }
    if (filters.merchantId) query = query.eq('merchant_id', String(filters.merchantId));
    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) { return { success: false, error: error.message }; }
};

export const getMerchantOrders = async (merchantId) => {
  try {
    const { data: pendingOrders } = await supabase.from(TABLES.ORDERS).select('*').eq('service_type', (await supabase.from('merchants').select('service_type').eq('id', merchantId).single()).data?.service_type).eq('status', ORDER_STATUS.PENDING).order('created_at', { ascending: false });
    const { data: myOrders } = await supabase.from(TABLES.ORDERS).select('*').eq('merchant_id', String(merchantId)).neq('status', ORDER_STATUS.PENDING).order('created_at', { ascending: false });
    return { success: true, data: [...(pendingOrders || []), ...(myOrders || [])] };
  } catch (error) { return { success: false, error: error.message }; }
};

export const acceptOrder = async (orderId, merchantId, merchantName, merchantPhone) => {
  try {
    const updateData = {
      status: ORDER_STATUS.ACCEPTED, merchant_id: String(merchantId), merchant_name: merchantName,
      merchant_place: merchantPhone, updated_at: new Date().toISOString()
    };
    const { data, error } = await supabase.from(TABLES.ORDERS).update(updateData).eq('id', orderId).select('*').single();
    if (error) throw error;
    stopAllSounds();
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) { return { success: false, error: error.message }; }
};

// ✅ رسالة العميل الجديدة
export const sendCustomerNotification = async (customerUserId, customerName, orderId, serviceName) => {
  try {
    if (!customerUserId || !orderId) return;
    const { data: tokenData } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', customerUserId).maybeSingle();
    if (tokenData?.expo_push_token) {
      await sendPushNotification(tokenData.expo_push_token,
        "🛒 طلبك قيد المراجعة",
        "أهلاً " + customerName + "،\nطلب " + (serviceName || "الخدمة") + " قيد المراجعة من قبل مقدمي الخدمة.\nسيصلك إشعار فور القبول.",
        { orderId: orderId, order_id: orderId, screen: "OrderTrackingScreen", type: "order_confirmed" }
      );
    }
  } catch (error) {}
};

export const sendOrderNotifications = async (orderDataWithId) => {
  try {
    const orderData = orderDataWithId;
    let customerUserId = orderData.user_id;
    if (!customerUserId && orderData.customer_phone) {
      const { data: profile } = await supabase.from('profiles').select('id').eq('phone', orderData.customer_phone).maybeSingle();
      if (profile?.id) customerUserId = profile.id;
    }
    if (orderData.merchant_id) {
      const { data: tokens } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', orderData.merchant_id);
      if (tokens) for (const t of tokens) {
        await sendPushNotification(t.expo_push_token,
          "🔔 طلب جديد!",
          `${orderData.customer_name} يطلب ${orderData.service_name}\n#${orderData.id?.slice(-6)}\n\n📍 ${orderData.customer_address || 'غير محدد'} | 💰 ${orderData.final_total} ج.م\n⚡ اضغط للرد فوراً`,
          { orderId: orderData.id, order_id: orderData.id, screen: 'MerchantOrdersScreen', type: 'new_order' }
        );
      }
    }
    if (customerUserId) await sendCustomerNotification(customerUserId, orderData.customer_name, orderData.id, orderData.service_name);
  } catch (error) {}
};

export const createOrder = async (orderData) => {
  try {
    const cleanOrder = {
      customer_name: orderData.customer_name || orderData.customerName,
      customer_phone: orderData.customer_phone || orderData.customerPhone || orderData.userPhone,
      customer_address: orderData.customer_address || orderData.customerAddress || '',
      service_type: orderData.service_type || orderData.serviceType,
      service_name: orderData.service_name || orderData.serviceName || orderData.merchant_name,
      merchant_id: orderData.merchant_id || null,
      merchant_name: orderData.merchant_name || orderData.merchantName || null,
      items: orderData.items || [],
      total_price: orderData.total_price || 0,
      delivery_fee: orderData.delivery_fee || 0,
      final_total: orderData.final_total || 0,
      notes: orderData.notes || '',
      payment_method: orderData.payment_method || 'cash_on_delivery',
      status: orderData.status || 'pending',
      is_guest: orderData.is_guest || false,
      guest_phone: orderData.guest_phone || null,
      user_id: orderData.user_id || null,
    };

    const { data, error } = await supabase.from(TABLES.ORDERS).insert([cleanOrder]).select('*').single();
    if (error) throw error;
    stopAllSounds();
    if (data.customer_phone) {
      const { data: customer } = await supabase.from('profiles').select('id').eq('phone', data.customer_phone).maybeSingle();
      if (customer?.id) await sendCustomerNotification(customer.id, data.customer_name, data.id, data.service_name);
    }
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) { return { success: false, error: error.message }; }
};

export const cancelOrder = async (orderId, reason = '') => {
  try {
    const { data, error } = await supabase.from(TABLES.ORDERS).update({
      status: ORDER_STATUS.CANCELLED, cancellation_reason: reason, cancelled_at: new Date().toISOString(), updated_at: new Date().toISOString()
    }).eq('id', orderId).select('*').single();
    if (error) throw error;
    stopAllSounds();
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) { return { success: false, error: error.message }; }
};

export const updateOrderStatus = async (orderId, status, additionalData = {}) => {
  try {
    const updateData = { status, updated_at: new Date().toISOString(), ...additionalData };
    if (status === ORDER_STATUS.DELIVERED) updateData.delivered_at = new Date().toISOString();
    const { data, error } = await supabase.from(TABLES.ORDERS).update(updateData).eq('id', orderId).select('*').single();
    if (error) throw error;
    if (status === ORDER_STATUS.CANCELLED || status === ORDER_STATUS.DELIVERED) stopAllSounds();
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) { return { success: false, error: error.message }; }
};

export const setOrderPrice = async (orderId, totalPrice, deliveryFee, platformFee = 0) => {
  return updateOrderStatus(orderId, ORDER_STATUS.READY, { total_price: Number(totalPrice), delivery_fee: Number(deliveryFee), platform_fee: Number(platformFee), final_total: Number(totalPrice) + Number(deliveryFee) + Number(platformFee) });
};

export const assignDriver = async (orderId, driverId, driverName, driverPhone) => {
  const result = await updateOrderStatus(orderId, ORDER_STATUS.DRIVER_ASSIGNED, { driver_id: String(driverId), driver_name: driverName, driver_phone: driverPhone });
  if (result.success) {
    const { sendNotificationToUser } = await import('./pushNotificationService');
    await sendNotificationToUser(driverId, '🚀 طلب توصيل جديد', 'تم تعيينك لتوصيل طلب جديد. تحقق من التطبيق.', { screen: 'DriverDashboard', type: 'new_delivery' });
  }
  return result;
};

export const startDelivery = async (orderId) => {
  return updateOrderStatus(orderId, ORDER_STATUS.ON_THE_WAY, { delivery_started_at: new Date().toISOString(), updated_at: new Date().toISOString() });
};

export const completeDelivery = async (orderId) => {
  return updateOrderStatus(orderId, ORDER_STATUS.DELIVERED, { delivered_at: new Date().toISOString(), updated_at: new Date().toISOString() });
};

export const sendSystemNotification = async (title, body, data = {}) => {
  try { await Notifications.scheduleNotificationAsync({ content: { title, body, sound: 'notification.mp3', data }, trigger: null }); } catch (e) {}
};

export default {
  getOrders, getMerchantOrders, acceptOrder, createOrder, cancelOrder,
  updateOrderStatus, setOrderPrice, assignDriver, startDelivery, completeDelivery,
  sendCustomerNotification, sendOrderNotifications, setSoundHandlers, stopAllSounds,
  startNotificationCheck, stopOrderNotificationSound, ORDER_STATUS
};
