import { supabase } from '../lib/supabaseClient';

export const getShopSettings = async () => {
  try {
    const { data, error } = await supabase.from('shop_settings').select('*').eq('id', 1).single();
    if (error || !data) {
      return { id: 1, is_active: true, maintenance_message: 'المتجر قيد التجهيز', banner_title: 'عروض خاصة', banner_subtitle: 'خصومات ولفترة محدودة', free_shipping: true, free_shipping_min_order: 200 };
    }
    return data;
  } catch (e) {
    return { is_active: true, maintenance_message: 'المتجر قيد التجهيز' };
  }
};

export const updateShopSettings = async (settings) => {
  try {
    const { data: current } = await supabase.from('shop_settings').select('*').eq('id', 1).single();
    const updates = { ...(current || {}), ...settings };
    const { error } = await supabase.from('shop_settings').update(updates).eq('id', 1);
    if (error) throw error;
    return { success: true };
  } catch (e) {
    return { success: false };
  }
};

export const getShopProducts = async (category = '') => {
  try {
    let query = supabase.from('shop_products').select('*').eq('is_active', true).order('created_at', { ascending: false });
    if (category) query = query.eq('category', category);
    const { data, error } = await query;
    if (error) return { success: true, data: [] };
    return { success: true, data: data || [] };
  } catch (e) {
    return { success: true, data: [] };
  }
};

export const getFeaturedProducts = async () => {
  try {
    const { data } = await supabase.from('shop_products').select('*').eq('is_active', true).eq('is_featured', true).limit(6);
    return { success: true, data: data || [] };
  } catch (e) {
    return { success: true, data: [] };
  }
};

export const createShopProduct = async (product) => {
  const { data, error } = await supabase.from('shop_products').insert([{
    name: product.name,
    price: product.price,
    category: product.category || 'عام',
    description: product.description || '',
    image_url: product.image_url || '',
    is_active: true,
    is_featured: product.is_featured || false,
    created_at: new Date().toISOString(),
  }]).select().single();
  if (error) return { success: false, error: error.message };
    // إرسال إشعار لكل الأدمنز
    const { data: admins } = await supabase.from("profiles").select("id").eq("role", "admin");
    if (admins) {
      for (const admin of admins) {
        const { data: tokens } = await supabase.from("user_tokens").select("expo_push_token").eq("user_id", admin.id);
        if (tokens) {
          for (const token of tokens) {
            fetch("https://exp.host/--/api/v2/push/send", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                to: token.expo_push_token,
                title: "🛒 طلب متجر جديد",
                body: `${orderData.name} طلب من المتجر بقيمة ${orderData.total} ج`,
                data: { screen: "ShopManagement", type: "new_shop_order" },
                priority: "high",
              }),
            }).catch(() => {});
          }
        }
      }
    }
  return { success: true, data };
};

export const createShopOrder = async (orderData) => {
  try {
    const { data, error } = await supabase.from('orders').insert([{
      customer_name: orderData.name,
      customer_phone: orderData.phone,
      customer_address: orderData.address,
      service_type: 'eshop',
      service_name: 'متجر Zid',
      items: orderData.items,
      total_price: orderData.total + (orderData.shipping || 0),
      delivery_fee: orderData.shipping || 0,
      final_total: orderData.total + (orderData.shipping || 0),
      status: 'pending',
      notes: orderData.notes || '',
      is_guest: !orderData.userId,
      user_id: orderData.userId || null,
      guest_phone: !orderData.userId ? orderData.phone : null,
      created_at: new Date().toISOString(),
    }]).select().single();
    if (error) throw error;
    // إرسال إشعار لكل الأدمنز
    const { data: admins } = await supabase.from("profiles").select("id").eq("role", "admin");
    if (admins) {
      for (const admin of admins) {
        const { data: tokens } = await supabase.from("user_tokens").select("expo_push_token").eq("user_id", admin.id);
        if (tokens) {
          for (const token of tokens) {
            fetch("https://exp.host/--/api/v2/push/send", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                to: token.expo_push_token,
                title: "🛒 طلب متجر جديد",
                body: `${orderData.name} طلب من المتجر بقيمة ${orderData.total} ج`,
                data: { screen: "ShopManagement", type: "new_shop_order" },
                priority: "high",
              }),
            }).catch(() => {});
          }
        }
      }
    }
    return { success: true, data };
  } catch (e) {
    return { success: false, error: e.message };
  }
};
