import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';

const PRODUCTS = TABLES.PRODUCTS;

const getUnifiedProducts = async (merchantId) => {
  try {
    const { data: prices } = await supabase
      .from('merchant_product_prices')
      .select('template_product_id, price, is_available')
      .eq('merchant_id', merchantId);

    if (!prices || prices.length === 0) return [];

    const ids = prices.map(p => p.template_product_id);
    const { data: templates } = await supabase
      .from('template_products')
      .select('*')
      .in('id', ids);

    if (!templates) return [];

    return templates.map(t => {
      const p = prices.find(x => x.template_product_id === t.id);
      return {
        ...t,
        price: p?.price || 0,
        id: t.id,
        is_unified: true,
        status: 'approved',
        is_available: p?.is_available !== false
      };
    });
  } catch (error) {
    console.error('getUnifiedProducts error:', error);
    return [];
  }
};

const getUserIdFromMerchantId = async (merchantId) => {
  const { data: merchants } = await supabase.from('merchants').select('user_id').eq('id', merchantId).limit(1);
  return merchants && merchants.length > 0 ? merchants[0].user_id : null;
};

export const getMerchantProductsByService = async (merchantId, serviceId) => {
  try {
    const userId = await getUserIdFromMerchantId(merchantId);
    console.log('🔍 getMerchantProductsByService - merchantId:', merchantId, 'userId:', userId);

    let productsQuery = supabase.from(PRODUCTS).select('*');
    if (userId) productsQuery = productsQuery.eq('merchant_id', userId);
    if (serviceId) productsQuery = productsQuery.eq('service_id', serviceId);

    const { data, error } = await productsQuery;
    if (error) throw error;
    console.log('📦 products found:', data?.length || 0);

    const unified = await getUnifiedProducts(merchantId);
    console.log('📦 unified found:', unified.length);

    const all = [...(data || []), ...unified];
    return { success: true, data: all };
  } catch (error) {
    return { success: false, error: error.message, data: [] };
  }
};

export const getMerchantProducts = async (merchantId) => {
  try {
    const userId = await getUserIdFromMerchantId(merchantId);
    let query = supabase.from(PRODUCTS).select('*').order('created_at', { ascending: false });
    if (userId) query = query.eq('merchant_id', userId);
    const { data, error } = await query;
    if (error) throw error;
    const unified = await getUnifiedProducts(merchantId);
    const all = [...(data || []), ...unified];
    return { success: true, data: all };
  } catch (error) {
    return { success: false, error: error.message, data: [] };
  }
};

export const addProduct = async (productData) => {
  try {
    if (productData.is_unified && productData.template_product_id) {
      const { error } = await supabase.from('merchant_product_prices').upsert({
        merchant_id: productData.merchant_id,
        template_product_id: productData.template_product_id,
        price: parseFloat(productData.price),
      }, { onConflict: 'merchant_id,template_product_id' });
      if (error) throw error;
      return { success: true, data: null, message: 'تم حفظ المنتج الموحد' };
    }
    const newProduct = {
      name: productData.name, description: productData.description || '',
      price: parseFloat(productData.price), image_url: productData.image_url || '',
      is_available: true, status: 'pending',
      merchant_id: productData.merchant_id, merchant_name: productData.merchant_name,
      service_id: productData.service_id, category_id: productData.category_id || null,
      created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
    };
    const { data, error } = await supabase.from(PRODUCTS).insert([newProduct]).select('*').single();
    if (error) throw error;
    await notifyAdminsNewProduct(data);
    return { success: true, data };
  } catch (error) {
    console.error('❌ addProduct error:', error);
    return { success: false, error: error.message };
  }
};

const notifyAdminsNewProduct = async (product) => {
  try {
    const { data: admins } = await supabase.from('profiles').select('id').eq('role', 'admin');
    if (admins && admins.length > 0) {
      for (const admin of admins) {
        const { data: tokens } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', admin.id);
        if (tokens) {
          for (const token of tokens) {
            if (token.expo_push_token) {
              await fetch('https://exp.host/--/api/v2/push/send', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ to: token.expo_push_token, sound: 'default', title: '📦 منتج جديد للمراجعة', body: `${product.name} - ${product.price}ج من ${product.merchant_name || 'تاجر'}`, data: { screen: 'ReviewProductsScreen', productId: product.id, type: 'new_product_review' } }),
              });
            }
          }
        }
      }
    }
  } catch (error) {}
};

export const approveProduct = async (productId) => {
  try {
    const { data, error } = await supabase.from(PRODUCTS).update({ status: 'approved', updated_at: new Date().toISOString() }).eq('id', productId).select('*').single();
    if (error) throw error;
    return { success: true, data };
  } catch (error) { return { success: false, error: error.message }; }
};

export const rejectProduct = async (productId, reason = '') => {
  try {
    const { data, error } = await supabase.from(PRODUCTS).update({ status: 'rejected', rejection_reason: reason, updated_at: new Date().toISOString() }).eq('id', productId).select('*').single();
    if (error) throw error;
    return { success: true, data };
  } catch (error) { return { success: false, error: error.message }; }
};

export const getProductsByService = async (serviceId) => {
  try {
    const { data, error } = await supabase.from(PRODUCTS).select('*').eq('service_id', serviceId).eq('status', 'approved').eq('is_available', true);
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) { return { success: false, error: error.message, data: [] }; }
};

export const getAllProducts = async () => {
  try {
    const { data, error } = await supabase.from(PRODUCTS).select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) { return { success: false, error: error.message, data: [] }; }
};

export const getPendingProducts = async () => {
  try {
    const { data, error } = await supabase.from(PRODUCTS).select('*').eq('status', 'pending').order('created_at', { ascending: false });
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) { return { success: false, error: error.message, data: [] }; }
};

export const deleteProduct = async (productId) => {
  try { await supabase.from(PRODUCTS).delete().eq('id', productId); return { success: true }; }
  catch (error) { return { success: false, error: error.message }; }
};
