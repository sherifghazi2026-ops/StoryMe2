// Helper لتوحيد طريقة إرسال الإشعارات من أي مكان في التطبيق
import { sendPushNotification, sendNewOrderNotification, sendOrderUpdateNotification, sendNotificationToUser } from './pushNotificationService';
import { supabase } from '../lib/supabaseClient';

// إرسال إشعار لصاحب الطلب
export async function notifyCustomer(orderId, customerUserId, data) {
  try {
    const { data: tokens } = await supabase
      .from('user_tokens')
      .select('expo_push_token')
      .eq('user_id', customerUserId);

    if (tokens && tokens.length > 0) {
      for (const token of tokens) {
        await sendOrderUpdateNotification(token.expo_push_token, {
          orderId,
          customerName: data.customerName,
          status: data.status,
        });
      }
    }
  } catch (error) {
    console.error('❌ فشل إرسال إشعار للعميل:', error);
  }
}

// إرسال إشعار للتاجر
export async function notifyMerchant(merchantUserId, orderData) {
  try {
    const { data: tokens } = await supabase
      .from('user_tokens')
      .select('expo_push_token')
      .eq('user_id', merchantUserId);

    if (tokens && tokens.length > 0) {
      for (const token of tokens) {
        await sendNewOrderNotification(token.expo_push_token, orderData);
      }
    }
  } catch (error) {
    console.error('❌ فشل إرسال إشعار للتاجر:', error);
  }
}

// إرسال إشعار للمشرف
export async function notifyAdmin(orderData) {
  try {
    const { data: admins } = await supabase
      .from('profiles')
      .select('id')
      .eq('role', 'admin');

    if (admins) {
      for (const admin of admins) {
        const { data: tokens } = await supabase
          .from('user_tokens')
          .select('expo_push_token')
          .eq('user_id', admin.id);

        if (tokens) {
          for (const token of tokens) {
            await sendNewOrderNotification(token.expo_push_token, {
              ...orderData,
              screen: 'AdminHome',
            });
          }
        }
      }
    }
  } catch (error) {
    console.error('❌ فشل إرسال إشعار للمشرف:', error);
  }
}

// دالة موحدة لإرسال الإشعارات عند إنشاء طلب جديد
export async function broadcastNewOrder(orderId, orderDetails) {
  const {
    customerUserId,
    merchantUserId,
    customerName,
    serviceType,
  } = orderDetails;

  const orderData = {
    orderId,
    customerName,
    serviceType,
  };

  // إرسال للتاجر
  if (merchantUserId) {
    await notifyMerchant(merchantUserId, orderData);
  }

  // إرسال للمشرفين
  await notifyAdmin(orderData);
  
  console.log('✅ تم بث إشعارات الطلب الجديد:', orderId);
}
