import { File } from 'expo-file-system/next';
import { Platform } from 'react-native';

const IMAGEKIT_PRIVATE_KEY = 'private_EWamixKcyYNZI2xJmmO0iQBN53k=';
const IMAGEKIT_PUBLIC_KEY = 'public_gRNWZVl/bFOQ7VfIDOm6J/Mwzrc=';
const IMAGEKIT_URL_ENDPOINT = 'https://ik.imagekit.io/vzuah6tku/';

// الحد الأقصى لحجم الملف (25 ميجابايت)
const MAX_FILE_SIZE = 25 * 1024 * 1024;

const sanitizeFolderName = (name) => {
  if (!name || typeof name !== 'string') {
    return 'unknown';
  }
  let clean = name.toLowerCase();
  clean = clean.replace(/[َُِّْ]/g, '');
  clean = clean.replace(/[^\w\u0621-\u064A\s-]/g, '');
  clean = clean.replace(/[\s-]+/g, '_');
  clean = clean.replace(/^_+|_+$/g, '');
  if (!clean || clean.length === 0) {
    clean = `user_${Date.now()}`;
  }
  return clean;
};

// دالة للتحقق من صحة الملف
const validateFile = async (uri) => {
  try {
    if (!uri) {
      return { valid: false, error: 'uri غير موجود' };
    }
    
    const file = new File(uri);
    const exists = await file.exists;
    if (!exists) {
      return { valid: false, error: 'الملف غير موجود على الجهاز' };
    }
    
    const fileInfo = await file.info();
    
    if (fileInfo.size && fileInfo.size > MAX_FILE_SIZE) {
      return { valid: false, error: `حجم الملف كبير جداً (الحد الأقصى ${MAX_FILE_SIZE / (1024 * 1024)} ميجابايت)` };
    }

    return { valid: true, fileInfo };
  } catch (error) {
    console.error('❌ خطأ في التحقق من الملف:', error);
    return { valid: false, error: error.message };
  }
};

export const uploadToImageKit = async (uri, fileName, folderType = 'general', userName = 'common') => {
  try {
    if (!uri) {
      throw new Error('uri غير موجود');
    }

    console.log(`📤 بدء رفع إلى ImageKit:`, { fileName, folderType, userName });

    const validation = await validateFile(uri);
    if (!validation.valid) {
      throw new Error(`الملف غير صالح: ${validation.error}`);
    }
    console.log('✅ الملف صالح، الحجم:', validation.fileInfo.size);
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch('https://www.google.com', {
        method: 'HEAD',
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) throw new Error('لا يوجد اتصال بالإنترنت');
      console.log('✅ اتصال الإنترنت نشط');
    } catch (netError) {
      console.warn('⚠️ تحذير: لا يمكن التحقق من الاتصال:', netError.message);
    }
    
    const cleanUserName = sanitizeFolderName(userName);
    let baseFolder = '/zayedid';

    if (folderType === 'voice') {
      baseFolder += '/voices';
    } else if (folderType === 'service') {
      baseFolder += '/services';
    } else if (folderType === 'general') {
      baseFolder += '/pictures';
    } else if (userName !== 'common' && cleanUserName !== 'unknown') {
      baseFolder += `/users/${cleanUserName}`;
      switch (folderType) {
        case 'profile':
          baseFolder += '/profile';
          break;
        case 'cover':
          baseFolder += '/cover';
          break;
        case 'dish':
          baseFolder += '/dishes';
          break;
        case 'video':
          baseFolder += '/videos';
          break;
        default:
          baseFolder += '/misc';
      }
    } else {
      baseFolder += '/misc';
    }

    console.log('📁 الرفع إلى مجلد:', baseFolder);

    let base64;
    try {
      const file = new File(uri);
      base64 = await file.base64();
      console.log(`✅ تم قراءة الملف بنجاح، حجم base64: ${base64.length} حرف`);
    } catch (readError) {
      console.error('❌ خطأ في قراءة الملف:', readError);
      throw new Error(`فشل في قراءة الملف: ${readError.message}`);
    }

    let mimeType = 'image/jpeg';
    const fileExt = fileName.split('.').pop().toLowerCase();
    
    if (fileExt === 'gif') {
      mimeType = 'image/gif';
    } else if (fileExt === 'mp4' || folderType === 'video') {
      mimeType = 'video/mp4';
    } else if (fileExt === 'png') {
      mimeType = 'image/png';
    } else if (['mp3', 'm4a', 'wav', 'aac'].includes(fileExt)) {
      mimeType = 'audio/mpeg';
    }

    const formData = new FormData();
    formData.append('file', `data:${mimeType};base64,${base64}`);
    formData.append('publicKey', IMAGEKIT_PUBLIC_KEY);
    formData.append('fileName', fileName);
    formData.append('useUniqueFileName', 'true');
    formData.append('folder', baseFolder);
    formData.append('tags', cleanUserName);
    formData.append('overwriteFile', 'false');
    
    console.log('📤 إرسال الطلب إلى ImageKit...');
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 ثانية للفيديو
    
    const response = await fetch('https://upload.imagekit.io/api/v1/files/upload', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'),
      },
      body: formData,
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    const data = await response.json();
    
    if (response.ok && data.url) {
      console.log('✅ ImageKit أعاد الرابط:', data.url);
      return {
        success: true,
        fileUrl: data.url,
        fileId: data.fileId,
        filePath: data.filePath,
      };
    } else {
      console.error('❌ فشل الرفع:', data);
      return {
        success: false,
        error: data.message || 'فشل الرفع إلى ImageKit',
        details: data
      };
    }
  } catch (error) {
    console.error('❌ خطأ في رفع الملف:', error);
    let errorMessage = 'فشل في رفع الملف';
    if (error.name === 'AbortError') {
      errorMessage = 'انتهت مهلة الرفع. تأكد من اتصالك بالإنترنت وحاول مجدداً.';
    } else if (error.message.includes('Network request failed')) {
      errorMessage = 'فشل الاتصال بخادم ImageKit. تحقق من اتصالك بالإنترنت.';
    } else if (error.message.includes('قراءة الملف')) {
      errorMessage = 'فشل في قراءة الملف. حاول مرة أخرى.';
    } else {
      errorMessage = error.message || 'خطأ غير متوقع في رفع الملف';
    }
    
    return { success: false, error: errorMessage };
  }
};

// دالة رفع صورة الخدمة
export const uploadServiceImage = async (imageUri) => {
  const fileName = `service_${Date.now()}.jpg`;
  return uploadToImageKit(imageUri, fileName, 'service', 'services');
};

// دالة رفع صورة المطعم
export const uploadRestaurantImage = async (imageUri, restaurantName, type = 'profile') => {
  const fileName = `${type}_${Date.now()}.jpg`;
  return uploadToImageKit(imageUri, fileName, type, restaurantName);
};

// دالة رفع PDF للمطعم
export const uploadRestaurantPDF = async (pdfUri, restaurantName) => {
  const fileName = `menu_${Date.now()}.pdf`;
  return uploadToImageKit(pdfUri, fileName, 'general', restaurantName);
};

// دوال الأطباق
export const uploadDishImage = (imageUri, userName) => {
  const fileName = `dish_${Date.now()}.jpg`;
  return uploadToImageKit(imageUri, fileName, 'dish', userName);
};

export const uploadDishVideo = (videoUri, userName) => {
  const fileName = `video_${Date.now()}.mp4`;
  return uploadToImageKit(videoUri, fileName, 'video', userName);
};

// دالة رفع الصور الشخصية
export const uploadProfileImage = (imageUri, userName) => {
  const fileName = `profile_${Date.now()}.jpg`;
  return uploadToImageKit(imageUri, fileName, 'profile', userName);
};

// دالة رفع الصوت
export const uploadVoiceFile = (audioUri) => {
  const fileName = `voice_${Date.now()}.m4a`;
  return uploadToImageKit(audioUri, fileName, 'voice');
};

// دالة عامة لرفع أي ملف
export const uploadAnyFile = async (fileUri, customFileName = null) => {
  try {
    if (!fileUri) throw new Error('uri غير موجود');
    
    const fileExt = fileUri.split('.').pop().toLowerCase();
    const fileName = customFileName || `file_${Date.now()}.${fileExt}`;
    
    console.log(`📤 رفع ملف: ${fileName} (نوع: ${fileExt})`);
    
    let folderType = 'general';
    if (fileExt === 'gif') folderType = 'general';
    else if (['mp3', 'wav', 'm4a', 'aac'].includes(fileExt)) folderType = 'voice';
    else if (['mp4', 'mov'].includes(fileExt)) folderType = 'video';
    
    return await uploadToImageKit(fileUri, fileName, folderType, 'splash');
  } catch (error) {
    console.error('❌ خطأ في رفع الملف:', error);
    return { success: false, error: error.message };
  }
};

// دالة رفع ملف GIF
export const uploadGifFile = async (gifUri) => {
  const fileName = `splash_${Date.now()}.gif`;
  return await uploadAnyFile(gifUri, fileName);
};

// دالة رفع فيديو (مخصصة للملفات الكبيرة)
export const uploadVideoFile = async (videoUri) => {
  try {
    if (!videoUri) throw new Error('uri غير موجود');
    
    console.log(`📤 رفع فيديو مباشر: ${videoUri}`);
    
    // قراءة الملف كـ Blob باستخدام fetch
    const response = await fetch(videoUri);
    const blob = await response.blob();
    
    // التحقق من الحجم
    if (blob.size > MAX_FILE_SIZE) {
      return { 
        success: false, 
        error: `حجم الفيديو كبير جداً (الحد الأقصى ${MAX_FILE_SIZE / (1024 * 1024)} ميجابايت)` 
      };
    }
    
    const fileName = `splash_video_${Date.now()}.mp4`;
    const folder = '/zayedid/videos';
    
    // استخدام FormData مباشرة (أسرع وأفضل من Base64)
    const formData = new FormData();
    formData.append('file', blob, fileName);
    formData.append('publicKey', IMAGEKIT_PUBLIC_KEY);
    formData.append('fileName', fileName);
    formData.append('useUniqueFileName', 'true');
    formData.append('folder', folder);
    formData.append('tags', 'splash_video');
    formData.append('overwriteFile', 'false');
    
    console.log('📤 إرسال الفيديو إلى ImageKit...');
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 120000); // 120 ثانية للفيديو
    
    const uploadResponse = await fetch('https://upload.imagekit.io/api/v1/files/upload', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'),
      },
      body: formData,
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    const data = await uploadResponse.json();
    
    if (uploadResponse.ok && data.url) {
      console.log('✅ تم رفع الفيديو بنجاح:', data.url);
      return { success: true, fileUrl: data.url };
    } else {
      console.error('❌ فشل رفع الفيديو:', data);
      return { success: false, error: data.message || 'فشل رفع الفيديو' };
    }
  } catch (error) {
    console.error('❌ خطأ في رفع الفيديو:', error);
    return { success: false, error: error.message };
  }
};

// دالة رفع ملف صوتي
export const uploadSoundFile = async (soundUri) => {
  const fileExt = soundUri.split('.').pop().toLowerCase();
  const fileName = `sound_${Date.now()}.${fileExt}`;
  return await uploadAnyFile(soundUri, fileName);
};

// دالة الحذف من ImageKit
export const deleteFromImageKit = async (fileUrl) => {
  try {
    const fileId = fileUrl.split('/').pop()?.split('?')[0];
    if (!fileId) return { success: false, error: 'لا يمكن استخراج معرف الملف' };

    const response = await fetch(`https://api.imagekit.io/v1/files/${fileId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'),
      },
    });

    if (response.ok) {
      return { success: true };
    } else {
      const data = await response.json();
      return { success: false, error: data.message };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
};
