import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';

export const ASSISTANT_SCREENS = {
  HOME: 'home',
  RESTAURANT: 'restaurant',
  HOME_CHEF: 'home_chef',
  OFFERS: 'offers',
  CART: 'cart',
  PROFILE: 'profile',
  ORDERS: 'orders',
  ADMIN: 'admin',
  SERVICE: 'service',
  ESHOP: 'eshop',
  PRODUCTS_SERVICE: 'products_service',
  MERCHANTS_LIST: 'merchants_list'
};

export const ASSISTANT_POSITIONS = {
  BOTTOM_RIGHT: 'bottom-right',
  BOTTOM_LEFT: 'bottom-left',
  BOTTOM_CENTER: 'bottom-center'
};

export const AVAILABLE_MODELS = [
  { label: 'Llama 3.1 8B (سريع)', value: 'llama-3.1-8b-instant' },
  { label: 'Llama 3.3 70B (ذكي)', value: 'llama-3.3-70b-versatile' },
  { label: 'GPT-OSS 20B (خفيف)', value: 'openai/gpt-oss-20b' },
  { label: 'GPT-OSS 120B (ممتاز)', value: 'openai/gpt-oss-120b' },
];

export const getAssistantsForScreen = async (screenName, serviceId = null) => {
  try {
    console.log('🔍 جلب المساعدين للشاشة:', screenName, serviceId);
    let query = supabase.from(TABLES.ASSISTANTS).select('*').eq('is_active', true).order('order', { ascending: true });

    if (screenName === 'service' && serviceId) {
      query = query.eq('service_id', serviceId);
    } else {
      query = query.eq('screen', screenName);
    }

    const { data, error } = await query;
    if (error) throw error;

    console.log(`✅ تم جلب ${data?.length || 0} مساعد للشاشة ${screenName}`);
    return { success: true, data: data || [] };
  } catch (error) {
    console.error('❌ خطأ في جلب المساعدين:', error);
    return { success: true, data: [] };
  }
};

export const getAllAssistants = async () => {
  try {
    console.log('🔍 جلب جميع المساعدين...');
    const { data, error } = await supabase.from(TABLES.ASSISTANTS).select('*').order('screen').order('order');
    if (error) {
      console.error('❌ خطأ في جلب جميع المساعدين:', error);
      throw error;
    }
    console.log(`✅ تم جلب ${data?.length || 0} مساعد`);
    return { success: true, data: data || [] };
  } catch (error) {
    console.error('❌ فشل جلب جميع المساعدين:', error);
    return { success: false, error: error.message, data: [] };
  }
};

export const createAssistant = async (assistantData) => {
  try {
    const newAssistant = {
      name: assistantData.name,
      screen: assistantData.screen,
      icon: assistantData.icon || 'chatbubble',
      color: assistantData.color || '#4F46E5',
      system_prompt: assistantData.systemPrompt || 'أنت مساعد ذكي اسمك "مُنجز". رد بالعامية المصرية.',
      welcome_message: assistantData.welcomeMessage || 'أهلاً! أنا مُنجز. كيف أقدر أساعدك؟',
      position: assistantData.position || 'bottom-right',
      is_active: assistantData.is_active !== undefined ? assistantData.is_active : true,
      order: assistantData.order || 0,
      service_id: assistantData.serviceId || null,
      service_name: assistantData.serviceName || null,
      model: assistantData.model || 'llama-3.3-70b-versatile',
      data_table: assistantData.data_table || null,
      data_columns: assistantData.data_columns || null,
      data_filter: assistantData.data_filter || null,
      data_limit: assistantData.data_limit || 50,
      service_display_name: assistantData.service_display_name || null,
      service_type_name: assistantData.service_type_name || null,
      service_description: assistantData.service_description || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from(TABLES.ASSISTANTS)
      .insert([newAssistant])
      .select('*')
      .single();

    if (error) throw error;
    console.log('✅ تم إنشاء مساعد جديد:', data);
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    console.error('❌ فشل إنشاء المساعد:', error);
    return { success: false, error: error.message };
  }
};

export const updateAssistant = async (assistantId, assistantData) => {
  try {
    const updateData = {
      name: assistantData.name,
      screen: assistantData.screen,
      icon: assistantData.icon,
      color: assistantData.color,
      system_prompt: assistantData.systemPrompt,
      welcome_message: assistantData.welcomeMessage,
      position: assistantData.position,
      is_active: assistantData.is_active,
      order: assistantData.order,
      service_id: assistantData.serviceId || null,
      service_name: assistantData.serviceName || null,
      model: assistantData.model,
      data_table: assistantData.data_table || null,
      data_columns: assistantData.data_columns || null,
      data_filter: assistantData.data_filter || null,
      data_limit: assistantData.data_limit || 50,
      service_display_name: assistantData.service_display_name || null,
      service_type_name: assistantData.service_type_name || null,
      service_description: assistantData.service_description || null,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from(TABLES.ASSISTANTS)
      .update(updateData)
      .eq('id', assistantId)
      .select('*')
      .single();

    if (error) throw error;
    console.log('✅ تم تحديث المساعد:', data);
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    console.error('❌ فشل تحديث المساعد:', error);
    return { success: false, error: error.message };
  }
};

export const deleteAssistant = async (assistantId) => {
  try {
    const { error } = await supabase.from(TABLES.ASSISTANTS).delete().eq('id', assistantId);
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const toggleAssistantStatus = async (assistantId, is_active) => {
  try {
    const { data, error } = await supabase
      .from(TABLES.ASSISTANTS)
      .update({ is_active, updated_at: new Date().toISOString() })
      .eq('id', assistantId)
      .select('*')
      .single();

    if (error) throw error;
    return { success: true, data: { $id: data.id, ...data } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// ========== دوال جديدة للبيانات الديناميكية من Supabase ==========
export const fetchAssistantData = async (tableName, columns = '*', filter = null, limit = 50) => {
    // لو الجدول all_merchant_products، نجيب المنتجات المشتركة فقط
    if (tableName === 'all_merchant_products' && filter) {
      const { data: allData } = await supabase.from(tableName).select(columns).limit(1000);
      if (allData) {
        const grouped = {};
        allData.forEach(p => {
          if (!grouped[p.name]) grouped[p.name] = { ...p, count: 1, id: p.id };
          else { grouped[p.name].count++; }
        });
        const shared = Object.values(grouped).filter(p => p.count > 1);
        console.log(`✅ تم فلترة ${shared.length} منتج مشترك من ${allData.length}`);
        return { success: true, data: shared };
      }
    }
  try {
    console.log('📦 جلب بيانات من جدول:', tableName);
    let query = supabase.from(tableName).select(columns);
    if (filter && filter.includes('::')) {
      const [key, op, val] = filter.split('::');
      if (key && op && val) query = query.filter(key, op, val);
    }
    const { data, error } = await query.limit(limit);
    if (error) throw error;
    console.log(`✅ تم جلب ${data?.length || 0} عنصر من ${tableName}`);
    return { success: true, data: data || [] };
  } catch (error) {
    console.error('❌ خطأ في جلب البيانات:', error);
    return { success: false, error: error.message, data: [] };
  }
};
