import { supabase } from '../lib/supabaseClient';

export const getMerchantsByType = async (serviceType, regionId = null) => {
  try {
    console.log(`🔍 جلب التجار لخدمة: ${serviceType}, المنطقة: ${regionId || 'الكل'}`);

    let query = supabase
      .from('profiles')
      .select('id, full_name, phone, image_url, place_name, merchant_type, is_verified, active, region_id')
      .eq('role', 'merchant')
      .eq('merchant_type', serviceType)
      .eq('is_verified', true);

    if (regionId) {
      query = query.eq('region_id', regionId);
    }

    let { data: profilesData, error: profilesError } = await query;

    if (!profilesError && profilesData && profilesData.length > 0) {
      const formatted = profilesData.map(item => ({
        id: item.id,
        name: item.full_name,
        phone: item.phone,
        image_url: item.image_url,
        place_name: item.place_name,
        service_type: item.merchant_type,
        region_id: item.region_id
      }));
      console.log(`✅ تم جلب ${formatted.length} تاجر من profiles لخدمة ${serviceType}`);
      return { success: true, data: formatted };
    }

    const { data: serviceData } = await supabase
      .from('services')
      .select('full_service_id')
      .eq('id', serviceType)
      .single();

    if (serviceData && serviceData.full_service_id) {
      const { data: fullService } = await supabase
        .from('full_services')
        .select('service_id')
        .eq('id', serviceData.full_service_id)
        .single();

      if (fullService && fullService.service_id) {
        console.log(`🔄 الخدمة ${serviceType} مرتبطة بخدمة شاملة ${fullService.service_id}`);

        let linkedQuery = supabase
          .from('profiles')
          .select('id, full_name, phone, image_url, place_name, merchant_type, region_id')
          .eq('role', 'merchant')
          .eq('merchant_type', fullService.service_id)
          .eq('is_verified', true);

        if (regionId) {
          linkedQuery = linkedQuery.eq('region_id', regionId);
        }

        const { data: linkedMerchants } = await linkedQuery;

        if (linkedMerchants && linkedMerchants.length > 0) {
          const formatted = linkedMerchants.map(item => ({
            id: item.id,
            name: item.full_name,
            phone: item.phone,
            image_url: item.image_url,
            place_name: item.place_name,
            service_type: item.merchant_type,
            region_id: item.region_id
          }));
          console.log(`✅ تم جلب ${formatted.length} تاجر من خلال الربط لخدمة ${serviceType}`);
          return { success: true, data: formatted };
        }
      }
    }

    let merchantQuery = supabase
      .from('merchants')
      .select('id, name, phone, image_url, place_name, service_type, is_active')
      .eq('service_type', serviceType)
      .eq('is_active', true);

    const { data: merchantsData, error: merchantsError } = await merchantQuery;

    if (!merchantsError && merchantsData && merchantsData.length > 0) {
      // للجدول merchants لا يوجد region_id مباشر، نحتاج لربطه مع profiles
      const merchantIds = merchantsData.map(m => m.id);
      let profilesForRegions = supabase
        .from('profiles')
        .select('id, region_id')
        .in('id', merchantIds);

      if (regionId) {
        profilesForRegions = profilesForRegions.eq('region_id', regionId);
      }

      const { data: profilesWithRegion } = await profilesForRegions;
      const allowedIds = profilesWithRegion?.map(p => p.id) || [];

      const filtered = merchantsData.filter(m => !regionId || allowedIds.includes(m.id));
      const formatted = filtered.map(item => ({
        id: item.id,
        name: item.name,
        phone: item.phone,
        image_url: item.image_url,
        place_name: item.place_name,
        service_type: item.service_type
      }));
      console.log(`✅ تم جلب ${formatted.length} تاجر من merchants لخدمة ${serviceType}`);
      return { success: true, data: formatted };
    }

    console.log(`⚠️ لا يوجد تجار لخدمة ${serviceType}`);
    return { success: true, data: [] };

  } catch (error) {
    console.error('خطأ في جلب التجار:', error);
    return { success: false, data: [], error: error.message };
  }
};

export const getMerchantById = async (merchantId) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', merchantId)
      .single();

    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
