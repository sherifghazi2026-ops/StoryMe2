import Groq from 'groq-sdk';

const GROQ_API_KEY = process.env.EXPO_PUBLIC_GROQ_API_KEY;
if (!GROQ_API_KEY) { console.error('❌ Groq API Key missing in .env'); }
const groq = new Groq({ apiKey: GROQ_API_KEY, dangerouslyAllowBrowser: true });

class GroqService {
  async ask(prompt, options = {}) {
    const { conversationHistory = [], model = 'llama-3.3-70b-versatile', systemPrompt = 'أنت مساعد اسمك "مُنجز". رد بالعامية المصرية.' } = options;
    try {
      const messages = [{ role: 'system', content: systemPrompt }];
      // آخر 5 رسايل للسياق
      conversationHistory.slice(-5).forEach(msg => {
        messages.push({ role: msg.sender === 'user' ? 'user' : 'assistant', content: msg.text });
      });
      messages.push({ role: 'user', content: prompt });
      const completion = await groq.chat.completions.create({ messages, model, temperature: 0.1, max_tokens: 400 });
      return { success: true, text: completion.choices[0]?.message?.content || 'آسف، ما فهمتش' };
    } catch (error) {
      return { success: false, text: 'يا فندم حصل ضغط خفيف، جرب تاني...' };
    }
  }

  async askWithTools(prompt, options = {}) {
    const { conversationHistory = [], model = 'llama-3.3-70b-versatile', systemPrompt, contextSummary = '' } = options;

    const tools = [{
      type: "function",
      function: {
        name: "add_to_cart",
        description: "إضافة منتج للسلة. استخدمها فقط بعد تأكيد العميل (تمام، ضيف، أيوه، موافق).",
        parameters: {
          type: "object",
          properties: {
            product_name: { type: "string", description: "اسم المنتج المتفق عليه من المحادثة" },
            quantity: { type: "number", description: "الكمية (افتراضي 1)" }
          },
          required: ["product_name"]
        }
      }
    }];

    try {
      const fullPrompt = contextSummary ? `المنتجات المتاحة:\n${contextSummary}\n\nطلب العميل: ${prompt}` : prompt;

      const messages = [
        { role: 'system', content: systemPrompt || 'أنت مساعد مبيعات ذكي.' },
        ...conversationHistory.slice(-5).map(msg => ({
          role: msg.sender === 'user' ? 'user' : 'assistant',
          content: msg.text
        })),
        { role: 'user', content: fullPrompt }
      ];

      const completion = await groq.chat.completions.create({
        messages, model, temperature: 0.1, max_tokens: 400, tools, tool_choice: "auto"
      });

      const responseMessage = completion.choices[0]?.message;
      const reply = responseMessage?.content || '';

      if (responseMessage?.tool_calls?.length > 0) {
        const toolCall = responseMessage.tool_calls[0];
        const args = JSON.parse(toolCall.function.arguments);
        return { success: true, text: reply, toolCall: { name: toolCall.function.name, args } };
      }

      return { success: true, text: reply || 'آسف، ما فهمتش' };
    } catch (error) {
      return this.ask(prompt, { conversationHistory, model, systemPrompt });
    }
  }
}

export default new GroqService();
