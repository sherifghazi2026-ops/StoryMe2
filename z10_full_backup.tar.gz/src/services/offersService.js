import { supabase } from '../lib/supabaseClient';
import { sendPushNotification } from './pushNotificationService';

export const OFFER_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  EXPIRED: 'expired',
};

export const getActiveOffers = async (serviceType) => {
  return getApprovedOffers(serviceType);
};

export const createOffer = async (offerData) => {
  try {
    const cleanData = {
      merchant_id: offerData.merchant_id || null,
      merchant_name: offerData.merchant_name || '',
      service_type: offerData.service_type || '',
      title: offerData.title || '',
      description: offerData.description || '',
      image_url: offerData.image_url || '',
      discount_percent: offerData.discount_percent || null,
      original_price: offerData.original_price || null,
      offer_price: offerData.offer_price || null,
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    
    console.log('📤 Sending to Supabase:', JSON.stringify(cleanData));
    
    const { data, error } = await supabase.from('offers').insert([cleanData]).select('*').single();
    
    if (error) {
      console.error('❌ Supabase error:', error);
      throw error;
    }
    
    console.log('✅ Offer created:', data);
    return { success: true, data };
  } catch (error) {
    console.error('❌ createOffer error:', error);
    return { success: false, error: error.message };
  }
};

export const getMerchantOffers = async (merchantId) => {
  try {
    const { data, error } = await supabase.from('offers').select('*').eq('merchant_id', merchantId).order('created_at', { ascending: false });
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) {
    return { success: false, error: error.message, data: [] };
  }
};

export const getApprovedOffers = async (serviceType) => {
  try {
    let query = supabase.from('offers').select('*').eq('status', OFFER_STATUS.APPROVED).order('created_at', { ascending: false });
    if (serviceType) query = query.eq('service_type', serviceType);
    const { data, error } = await query;
    if (error) throw error;
    return { success: true, data: data || [] };
  } catch (error) {
    return { success: false, error: error.message, data: [] };
  }
};

export const updateOfferStatus = async (offerId, status, adminNotes = '') => {
  try {
    const { error } = await supabase.from('offers').update({ status, admin_notes: adminNotes, updated_at: new Date().toISOString() }).eq('id', offerId);
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const notifyCustomersAboutOffer = async (offer) => {
  try {
    const { data: customers } = await supabase.from('user_tokens').select('expo_push_token').not('expo_push_token', 'is', null).limit(100);
    if (customers) {
      for (const customer of customers) {
        if (customer.expo_push_token) {
          await sendPushNotification(customer.expo_push_token, '🔥 عرض جديد!', offer.title + ' - ' + (offer.description || 'خصم مميز'), { screen: 'OffersScreen', offerId: offer.id, type: 'new_offer' });
        }
      }
    }
  } catch (error) {
    console.error('خطأ في إرسال إشعارات العروض:', error);
  }
};
