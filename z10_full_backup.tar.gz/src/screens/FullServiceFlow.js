import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  Alert, ActivityIndicator, Modal, Dimensions, Image
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getSubServices, getServiceFields, getServiceFieldsByServiceId } from '../services/fullServiceService';
import { createOrder } from '../services/orderService';
import { supabase } from '../lib/supabaseClient';

const { width } = Dimensions.get('window');
const COL_WIDTH = (width - 80) / 7;
const MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const WEEKDAYS = ['سبت','أحد','إثنين','ثلاثاء','أربعاء','خميس','جمعة'];

export default function FullServiceFlow({ navigation, route }) {
  const { fullServiceId, fullServiceName, merchantId, merchantName, merchantImage } = route.params;
  const [subServices, setSubServices] = useState([]);
  const [selectedSub, setSelectedSub] = useState(null);
  const [fields, setFields] = useState([]);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // ✅ حقول الزائر
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [guestAddress, setGuestAddress] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  // ✅ Modal نجاح للزائر
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [currentDateField, setCurrentDateField] = useState(null);
  const [selectedDay, setSelectedDay] = useState(1);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => { init(); }, []);

  const init = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setUserData(user);
      setIsLoggedIn(true);
    }
    await loadSubServices();
  };

  const loadSubServices = async () => {
    const allSubs = await getSubServices(fullServiceId);
    const { data: merchantSettings } = await supabase
      .from('merchant_sub_services')
      .select('*')
      .eq('merchant_id', merchantId);
    const settingsMap = {};
    (merchantSettings || []).forEach(s => { settingsMap[s.sub_service_id] = s; });
    const filteredSubs = (allSubs || []).filter(sub => {
      if (sub.is_active === false) return false;
      const setting = settingsMap[sub.id];
      if (setting && setting.show_title === false) return false;
      return true;
    });
    setSubServices(filteredSubs);
    setLoading(false);
  };

  const handleSelectSub = async (sub) => {
    setSelectedSub(sub);
    let data = await getServiceFields(sub.id);
    if (!data || data.length === 0) {
      data = await getServiceFieldsByServiceId(sub.name);
    }
    setFields(data || []);
    const initial = {};
    (data || []).forEach(f => { initial[f.field_name] = ''; });
    setFormData(initial);
  };

  const openDatePicker = (fieldName) => {
    setCurrentDateField(fieldName);
    const val = formData[fieldName];
    if (val) {
      const d = new Date(val);
      if (!isNaN(d.getTime())) {
        setSelectedDay(d.getDate());
        setSelectedMonth(d.getMonth());
        setSelectedYear(d.getFullYear());
      }
    }
    setShowDatePicker(true);
  };

  const confirmDate = () => {
    const d = new Date(selectedYear, selectedMonth, selectedDay);
    const formatted = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    setFormData(prev => ({...prev, [currentDateField]: formatted}));
    setShowDatePicker(false);
  };

  const jsDay = new Date(selectedYear, selectedMonth, 1).getDay();
  const firstDay = (jsDay + 1) % 7;
  const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
  const blanks = Array(firstDay).fill(null);
  const days = Array.from({length: daysInMonth}, (_, i) => i + 1);

  const handleSend = async () => {
    // ✅ تحقق من الزائر
    if (!isLoggedIn) {
      if (!guestName.trim()) { Alert.alert('تنبيه', 'يرجى إدخال الاسم'); return; }
      if (!guestPhone.trim() || guestPhone.length < 10) { Alert.alert('تنبيه', 'يرجى إدخال رقم هاتف صحيح'); return; }
      if (!guestAddress.trim()) { Alert.alert('تنبيه', 'يرجى إدخال العنوان'); return; }
      if (!termsAccepted) { Alert.alert('تنبيه', 'يجب الموافقة على شروط الاستخدام'); return; }
    }

    for (const f of fields) {
      if (f.is_required && !formData[f.field_name]?.trim()) {
        return Alert.alert('تنبيه', `حقل "${f.field_label}" مطلوب`);
      }
    }
    setSending(true);
    const items = fields
      .map(f => formData[f.field_name] ? `${f.field_label}: ${formData[f.field_name]}` : null)
      .filter(Boolean);
    const result = await createOrder({
      customer_name: isLoggedIn ? (userData?.full_name || 'عميل') : guestName.trim(),
      customer_phone: isLoggedIn ? (userData?.phone || '') : guestPhone.trim(),
      customer_address: isLoggedIn ? (userData?.address || '') : guestAddress.trim(),
      service_type: fullServiceId,
      sub_service_id: selectedSub?.id || null,
      service_name: selectedSub.name,
      merchant_id: merchantId,
      merchant_name: merchantName,
      items,
      description: items.join('\n'),
      is_guest: !isLoggedIn,
    });
    setSending(false);
    if (result.success) {
      if (!isLoggedIn) {
        setLastOrderId(result.data.id);
        setShowSuccessModal(true);
      } else {
        Alert.alert('✅ تم', 'تم إرسال طلبك بنجاح', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]);
      }
    } else {
      Alert.alert('خطأ', result.error);
    }
  };

  const handleRegister = () => {
    setShowSuccessModal(false);
    navigation.navigate('CustomerAuth', {
      prefillName: guestName,
      prefillPhone: guestPhone,
      fromGuestCheckout: true,
      pendingOrderId: lastOrderId
    });
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backCircle} onPress={() => selectedSub ? setSelectedSub(null) : navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color="#FFF" />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <View style={styles.merchantRow}>
            {merchantImage ? (
              <Image source={{ uri: merchantImage }} style={styles.merchantAvatar} />
            ) : (
              <View style={styles.merchantAvatarPlaceholder}>
                <Ionicons name="storefront-outline" size={16} color="#9CA3AF" />
              </View>
            )}
            <Text style={styles.headerTitle} numberOfLines={1}>{merchantName || fullServiceName}</Text>
          </View>
          {selectedSub && <Text style={styles.subServiceTitle} numberOfLines={1}>{selectedSub.name}</Text>}
        </View>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {!selectedSub ? (
          <>
            <Text style={styles.sectionTitle}>اختر الخدمة</Text>
            {subServices.map(sub => (
              <TouchableOpacity key={sub.id} style={styles.subCard} onPress={() => handleSelectSub(sub)} activeOpacity={0.9}>
                {sub.image_url ? (
                  <View style={styles.imageCard}>
                    <Image source={{ uri: sub.image_url }} style={styles.subImage} />
                    <View style={styles.imageOverlay} />
                    <Text style={styles.imageTitle}>{sub.name}</Text>
                    <View style={styles.arrowBadge}><Ionicons name="chevron-forward" size={20} color="#FFF" /></View>
                  </View>
                ) : (
                  <View style={styles.noImageCard}>
                    <View style={styles.iconContainer}><Ionicons name={sub.icon || 'document-text'} size={28} color="#8B5CF6" /></View>
                    <View style={{ flex: 1 }}><Text style={styles.subName}>{sub.name}</Text></View>
                    <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </>
        ) : (
          <>
            {/* ✅ بيانات الزائر */}
            {!isLoggedIn && (
              <View style={styles.guestCard}>
                <Text style={styles.guestTitle}>بيانات الطلب</Text>
                <TextInput style={styles.guestInput} placeholder="الاسم" value={guestName} onChangeText={setGuestName} />
                <TextInput style={styles.guestInput} placeholder="رقم الهاتف" value={guestPhone} onChangeText={setGuestPhone} keyboardType="phone-pad" />
                <TextInput style={styles.guestInput} placeholder="العنوان" value={guestAddress} onChangeText={setGuestAddress} />
              </View>
            )}

            {fields.filter(f => f.is_visible !== false).map(field => (
              <View key={field.id} style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>{field.field_label} {field.is_required && <Text style={{ color: '#EF4444' }}>*</Text>}</Text>
                {field.field_type === 'date' ? (
                  <TouchableOpacity style={styles.dateField} onPress={() => openDatePicker(field.field_name)}>
                    <Ionicons name="calendar-outline" size={20} color="#8B5CF6" />
                    <Text style={[styles.dateText, !formData[field.field_name] && { color: '#9CA3AF' }]}>{formData[field.field_name] || 'اختر التاريخ'}</Text>
                  </TouchableOpacity>
                ) : field.field_type === 'number' ? (
                  <View style={styles.numberField}>
                    <TouchableOpacity style={styles.numBtn} onPress={() => { const c = parseInt(formData[field.field_name] || '0') || 0; setFormData({...formData, [field.field_name]: String(Math.max(0, c - 1))}); }}><Ionicons name="remove" size={22} color="#8B5CF6" /></TouchableOpacity>
                    <View style={styles.numDisplay}><Text style={styles.numValue}>{formData[field.field_name] || '0'}</Text></View>
                    <TouchableOpacity style={styles.numBtn} onPress={() => { const c = parseInt(formData[field.field_name] || '0') || 0; setFormData({...formData, [field.field_name]: String(c + 1)}); }}><Ionicons name="add" size={22} color="#8B5CF6" /></TouchableOpacity>
                  </View>
                ) : field.field_type === 'select' ? (
                  <View style={styles.optionsGrid}>
                    {(field.field_options || []).map(opt => {
                      const isSelected = formData[field.field_name] === opt;
                      return (
                        <TouchableOpacity key={opt} style={[styles.optionBtn, isSelected && styles.optionBtnActive]} onPress={() => setFormData({...formData, [field.field_name]: opt})}>
                          <Text style={[styles.optionBtnText, isSelected && styles.optionBtnTextActive]}>{opt}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                ) : (
                  <TextInput style={styles.textInput} placeholder={field.placeholder || field.field_label} value={formData[field.field_name]} onChangeText={(v) => setFormData({...formData, [field.field_name]: v})} keyboardType={field.field_type === 'number' ? 'numeric' : 'default'} multiline={field.field_type === 'textarea'} textAlignVertical={field.field_type === 'textarea' ? 'top' : 'auto'} />
                )}
              </View>
            ))}

            {/* ✅ الشروط والأحكام للزائر */}
            {!isLoggedIn && (
              <TouchableOpacity style={[styles.termsCard, termsAccepted && styles.termsCardActive]} onPress={() => setTermsAccepted(!termsAccepted)}>
                <View style={[styles.checkbox, termsAccepted && styles.checkboxActive]}>{termsAccepted && <Ionicons name="checkmark" size={16} color="#FFF" />}</View>
                <Text style={styles.termsText}>أوافق على <Text style={styles.termsLink} onPress={() => { setTermsAccepted(true); navigation.navigate("TermsScreen"); }}>شروط وأحكام تطبيق Zid</Text></Text>
              </TouchableOpacity>
            )}

            <TouchableOpacity style={[styles.sendBtn, sending && { opacity: 0.6 }]} onPress={handleSend} disabled={sending}>
              {sending ? <ActivityIndicator color="#FFF" /> : <Text style={styles.sendText}>إرسال الطلب</Text>}
            </TouchableOpacity>
          </>
        )}
      </ScrollView>

      {/* ✅ Modal نجاح للتسجيل */}
      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.successModalOverlay}>
          <View style={styles.successModalContent}>
            <Ionicons name="checkmark-circle" size={60} color="#10B981" />
            <Text style={styles.successTitle}>✅ تم استلام طلبك!</Text>
            <Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text>
            <TouchableOpacity style={styles.registerBtn} onPress={handleRegister}>
              <Ionicons name="person-add" size={20} color="#FFF" />
              <Text style={styles.registerBtnText}>حفظ بياناتي واستكمال التسجيل</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.laterBtn} onPress={() => setShowSuccessModal(false)}>
              <Text style={styles.laterBtnText}>لاحقاً</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showDatePicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.dateModal}>
          <View style={styles.dateModalHeader}><TouchableOpacity onPress={() => setShowDatePicker(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity><Text style={styles.dateModalTitle}>اختر التاريخ</Text><TouchableOpacity onPress={confirmDate}><Text style={styles.doneText}>تم</Text></TouchableOpacity></View>
          <View style={styles.monthSelector}><TouchableOpacity onPress={() => { if (selectedMonth > 0) setSelectedMonth(selectedMonth - 1); else { setSelectedMonth(11); setSelectedYear(selectedYear - 1); } }}><Ionicons name="chevron-back" size={20} color="#8B5CF6" /></TouchableOpacity><Text style={styles.monthText}>{MONTHS[selectedMonth]} {selectedYear}</Text><TouchableOpacity onPress={() => { if (selectedMonth < 11) setSelectedMonth(selectedMonth + 1); else { setSelectedMonth(0); setSelectedYear(selectedYear + 1); } }}><Ionicons name="chevron-forward" size={20} color="#8B5CF6" /></TouchableOpacity></View>
          <View style={styles.weekRow}>{WEEKDAYS.map(d => <View key={d} style={styles.weekCell}><Text style={styles.weekDay}>{d}</Text></View>)}</View>
          <View style={styles.daysGrid}>{blanks.map((_, i) => <View key={`b${i}`} style={styles.dayCell} />)}{days.map(day => (<TouchableOpacity key={day} style={[styles.dayCell, selectedDay === day && styles.dayCellActive]} onPress={() => setSelectedDay(day)}><Text style={[styles.dayText, selectedDay === day && styles.dayTextActive]}>{day}</Text></TouchableOpacity>))}</View>
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  headerCenter: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  merchantRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  merchantAvatar: { width: 32, height: 32, borderRadius: 16 },
  merchantAvatarPlaceholder: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', maxWidth: '70%' },
  subServiceTitle: { fontSize: 13, color: '#6B7280', marginTop: 2, fontWeight: '500' },
  content: { padding: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16, color: '#1F2937' },
  subCard: { marginBottom: 14 },
  imageCard: { height: 120, borderRadius: 16, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', position: 'relative' },
  subImage: { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%', resizeMode: 'cover' },
  imageOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
  imageTitle: { fontSize: 22, fontWeight: '800', color: '#FFFFFF', textShadowColor: '#000000', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, textAlign: 'center', zIndex: 1 },
  arrowBadge: { position: 'absolute', top: 14, right: 14, width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center' },
  noImageCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  iconContainer: { width: 52, height: 52, borderRadius: 14, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  subName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  // ✅ بطاقة الزائر
  guestCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  guestTitle: { fontSize: 16, fontWeight: '700', color: '#1F2937', marginBottom: 12 },
  guestInput: { backgroundColor: '#F9FAFB', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1F2937', borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 10 },
  // الشروط والأحكام
  termsCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: '#FFF', borderWidth: 1.5, borderColor: '#E5E7EB', marginBottom: 16, gap: 10 },
  termsCardActive: { borderColor: '#8B5CF6', backgroundColor: '#F0F0FF' },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: '#D1D5DB', justifyContent: 'center', alignItems: 'center' },
  checkboxActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  termsText: { fontSize: 13, color: '#4B5563', flex: 1 },
  termsLink: { color: '#8B5CF6', fontWeight: '600' },
  // حقول
  textInput: { backgroundColor: '#FFF', borderRadius: 10, padding: 14, borderWidth: 1, borderColor: '#E5E7EB', fontSize: 14, color: '#1F2937' },
  fieldGroup: { marginBottom: 16 },
  fieldLabel: { fontSize: 15, fontWeight: '600', color: '#1F2937', marginBottom: 8 },
  dateField: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 10, padding: 14, borderWidth: 1, borderColor: '#E5E7EB', gap: 10 },
  dateText: { fontSize: 14, color: '#1F2937', flex: 1 },
  numberField: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 14, borderWidth: 1, borderColor: '#E5E7EB', gap: 20 },
  numBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  numDisplay: { minWidth: 50, alignItems: 'center' },
  numValue: { fontSize: 24, fontWeight: '700', color: '#8B5CF6' },
  optionsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10 },
  optionBtn: { minWidth: 100, paddingHorizontal: 20, paddingVertical: 14, borderRadius: 12, backgroundColor: '#F3F4F6', borderWidth: 1.5, borderColor: '#E5E7EB', justifyContent: 'center', alignItems: 'center' },
  optionBtnActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  optionBtnText: { fontSize: 14, fontWeight: '500', color: '#4B5563', textAlign: 'center' },
  optionBtnTextActive: { color: '#FFF', fontWeight: '700' },
  sendBtn: { backgroundColor: '#8B5CF6', padding: 16, borderRadius: 14, alignItems: 'center', marginTop: 10 },
  sendText: { color: '#FFF', fontSize: 17, fontWeight: '700' },
  // Modal نجاح
  successModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModalContent: { backgroundColor: '#FFF', borderRadius: 24, padding: 28, alignItems: 'center', width: '88%' },
  successTitle: { fontSize: 20, fontWeight: '800', color: '#1F2937', marginTop: 12 },
  successSubtext: { fontSize: 13, color: '#6B7280', marginTop: 14, textAlign: 'center', lineHeight: 20 },
  registerBtn: { flexDirection: 'row', backgroundColor: '#8B5CF6', padding: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 20, gap: 8 },
  registerBtnText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  laterBtn: { marginTop: 12, padding: 8 },
  laterBtnText: { color: '#9CA3AF', fontSize: 14 },
  // Calendar Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  dateModal: { backgroundColor: '#FFF', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 30 },
  dateModalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  dateModalTitle: { fontSize: 18, fontWeight: '700', color: '#1F2937' },
  cancelText: { fontSize: 15, color: '#EF4444' },
  doneText: { fontSize: 15, color: '#8B5CF6', fontWeight: '600' },
  monthSelector: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', marginBottom: 12 },
  monthText: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  weekRow: { flexDirection: 'row', marginBottom: 8 },
  weekCell: { width: COL_WIDTH, alignItems: 'center', paddingVertical: 4 },
  weekDay: { fontSize: 12, color: '#9CA3AF', fontWeight: '600' },
  daysGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: { width: COL_WIDTH, height: 42, justifyContent: 'center', alignItems: 'center', borderRadius: 21, marginBottom: 2 },
  dayCellActive: { backgroundColor: '#8B5CF6' },
  dayText: { fontSize: 15, color: '#1F2937', textAlign: 'center' },
  dayTextActive: { color: '#FFF', fontWeight: '700' },
});
