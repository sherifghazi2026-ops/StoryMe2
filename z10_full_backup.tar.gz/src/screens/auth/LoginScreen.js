import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, ActivityIndicator, ScrollView,
  Image, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { registerUserToken } from '../../services/orderService';
import { fontFamily } from '../../utils/fonts';

const MASTER_ADMIN_PASSWORD = 'Admin135792';
const MASTER_ADMIN_PHONE = '0000000000';

export default function LoginScreen({ navigation }) {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [regions, setRegions] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [globalIcon, setGlobalIcon] = useState('');
  const [showRegionPicker, setShowRegionPicker] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [fullName, setFullName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => { loadRegions(); fetchGlobalIcon(); }, []);

  const loadRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    setRegions(data || []);
    if (data && data.length > 0) setSelectedRegion(data[0].id);
  };

  const fetchGlobalIcon = async () => {
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'regions_icon').single();
    if (data?.value) setGlobalIcon(data.value);
  };

  const handleLogin = async () => {
    if ((phone === MASTER_ADMIN_PHONE || !phone.trim()) && password === MASTER_ADMIN_PASSWORD) {
      const masterAdmin = {
        id: '00000000-0000-0000-0000-000000000000', $id: '00000000-0000-0000-0000-000000000000',
        full_name: 'Master Admin', name: 'Master Admin', phone: MASTER_ADMIN_PHONE,
        role: 'admin', admin_level: 'super', active: true,
      };
      await AsyncStorage.setItem('userData', JSON.stringify(masterAdmin));
      await AsyncStorage.setItem('userRole', 'admin');
      await AsyncStorage.setItem('userId', masterAdmin.id);
      await AsyncStorage.setItem('masterAdminPassword', MASTER_ADMIN_PASSWORD);
      navigation.reset({ index: 0, routes: [{ name: 'AdminHome' }] });
      return;
    }

    if (!phone.trim() || !password.trim()) {
      Alert.alert('تنبيه', 'يرجى إدخال رقم الهاتف وكلمة المرور');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.from(TABLES.PROFILES).select('*').eq('phone', phone).eq('password', password).single();
      if (error || !data) { Alert.alert('خطأ', 'رقم الهاتف أو كلمة المرور غير صحيحة'); setLoading(false); return; }
      
      // إذا تم اختيار منطقة أثناء تسجيل الدخول، حدثها
      if (selectedRegion && selectedRegion !== data.region_id) {
        await supabase.from('profiles').update({ region_id: selectedRegion }).eq('id', data.id);
        data.region_id = selectedRegion;
      }
      
      const userDataToStore = {
        id: data.id, $id: data.id, full_name: data.full_name, name: data.full_name,
        phone: data.phone, role: data.role, admin_level: data.admin_level || 'basic',
        merchantType: data.merchant_type, merchant_type: data.merchant_type,
        active: data.active, profile_completed: data.profile_completed,
        region_id: data.region_id,
      };
      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await AsyncStorage.setItem('userRole', data.role);
      await AsyncStorage.setItem('userId', data.id);
      if (data.admin_level === 'super') await AsyncStorage.setItem('masterAdminPassword', MASTER_ADMIN_PASSWORD);

      if (data.role === 'merchant') navigation.reset({ index: 0, routes: [{ name: 'MerchantDashboard' }] });
      else if (data.role === 'driver') navigation.reset({ index: 0, routes: [{ name: 'DriverDashboard' }] });
      else if (data.role === 'admin') navigation.reset({ index: 0, routes: [{ name: 'AdminHome' }] });
      else navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
    } catch (error) { Alert.alert('خطأ', 'فشل تسجيل الدخول'); } finally { setLoading(false); }
  };

  const handleRegister = async () => {
    if (!fullName.trim()) { Alert.alert('تنبيه', 'الاسم مطلوب'); return; }
    if (!phone.trim() || phone.length < 11) { Alert.alert('تنبيه', 'رقم هاتف صحيح مطلوب'); return; }
    if (!selectedRegion) { Alert.alert('تنبيه', 'يرجى اختيار المنطقة'); return; }
    if (!password.trim() || password.length < 4) { Alert.alert('تنبيه', 'كلمة المرور 4 أحرف على الأقل'); return; }
    if (password !== confirmPassword) { Alert.alert('تنبيه', 'كلمة المرور غير متطابقة'); return; }

    setLoading(true);
    try {
      const { data: existing } = await supabase.from('profiles').select('phone').eq('phone', phone).single();
      if (existing) { Alert.alert('خطأ', 'رقم الهاتف مسجل مسبقاً'); setLoading(false); return; }

      const { error } = await supabase.from('profiles').insert([{
        full_name: fullName.trim(), phone, password, role: 'customer',
        region_id: selectedRegion, is_verified: true, active: true,
        created_at: new Date(), updated_at: new Date(),
      }]);
      if (error) throw error;

      Alert.alert('✅ تم', 'تم التسجيل بنجاح. يمكنك تسجيل الدخول الآن.');
      setIsRegistering(false);
    } catch (e) { Alert.alert('خطأ', e.message); } finally { setLoading(false); }
  };

  const regionName = regions.find(r => r.id === selectedRegion)?.name || 'اختر المنطقة';

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-forward" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>{isRegistering ? 'تسجيل عميل جديد' : 'تسجيل الدخول'}</Text>
        <View style={{ width: 28 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {isRegistering ? (
          <>
            <TextInput style={styles.input} placeholder="الاسم الكامل" value={fullName} onChangeText={setFullName} />
            <TextInput style={styles.input} placeholder="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            <TouchableOpacity style={styles.regionPickerBtn} onPress={() => setShowRegionPicker(true)}>
              <Text style={styles.regionPickerText}>{regionName}</Text>
              <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              {globalIcon ? (
                <Image source={{ uri: globalIcon }} style={styles.regionPickerIcon} />
              ) : (
                <Ionicons name="location-outline" size={20} color="#9CA3AF" />
              )}
            </TouchableOpacity>
            <View style={styles.passwordRow}>
              <TextInput style={[styles.input, { flex: 1, marginBottom: 0 }]} placeholder="كلمة المرور" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}><Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color="#9CA3AF" /></TouchableOpacity>
            </View>
            <TextInput style={styles.input} placeholder="تأكيد كلمة المرور" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry />
            <TouchableOpacity style={styles.loginButton} onPress={handleRegister} disabled={loading}>
              {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.loginButtonText}>تسجيل</Text>}
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsRegistering(false)}><Text style={styles.link}>لديك حساب؟ تسجيل الدخول</Text></TouchableOpacity>
          </>
        ) : (
          <>
            <TextInput style={styles.input} placeholder="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            <View style={styles.passwordRow}>
              <TextInput style={[styles.input, { flex: 1, marginBottom: 0 }]} placeholder="كلمة المرور" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}><Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color="#9CA3AF" /></TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.regionPickerBtn} onPress={() => setShowRegionPicker(true)}>
              <Text style={styles.regionPickerText}>{regionName}</Text>
              <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              {globalIcon ? (
                <Image source={{ uri: globalIcon }} style={styles.regionPickerIcon} />
              ) : (
                <Ionicons name="location-outline" size={20} color="#9CA3AF" />
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.loginButton} onPress={handleLogin} disabled={loading}>
              {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.loginButtonText}>دخول</Text>}
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsRegistering(true)}><Text style={styles.link}>تسجيل عميل جديد</Text></TouchableOpacity>
          </>
        )}
      </ScrollView>

      <Modal visible={showRegionPicker} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowRegionPicker(false)}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>اختر المنطقة</Text>
            {regions.map((region) => (
              <TouchableOpacity
                key={region.id}
                style={[styles.regionOption, selectedRegion === region.id && styles.regionOptionActive]}
                onPress={() => { setSelectedRegion(region.id); setShowRegionPicker(false); }}
              >
                <Text style={[styles.regionOptionText, selectedRegion === region.id && styles.regionOptionTextActive]}>{region.name}</Text>
                {selectedRegion === region.id && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  input: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 14, marginBottom: 16, fontSize: 16 },
  passwordRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 16 },
  regionPickerBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E5E7EB',
    borderRadius: 8, padding: 14, marginBottom: 16, gap: 8,
  },
  regionPickerIcon: { width: 22, height: 22, borderRadius: 6, resizeMode: 'cover' },
  regionPickerText: { flex: 1, fontSize: 16, color: '#1F2937', textAlign: 'right' },
  loginButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  loginButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  link: { color: '#4F46E5', fontSize: 14, textAlign: 'center', marginTop: 16 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  modalContent: { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 20, width: '100%', maxWidth: 340 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  regionOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, borderRadius: 12, marginBottom: 6, backgroundColor: '#F9FAFB' },
  regionOptionActive: { backgroundColor: '#EEF2FF' },
  regionOptionText: { fontSize: 15, color: '#6B7280', fontFamily: fontFamily.arabic },
  regionOptionTextActive: { color: '#4F46E5', fontWeight: '700' },
});
