import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput, Alert,
  ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { fontFamily } from '../../utils/fonts';

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export default function MerchantRegisterScreen({ navigation }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [regions, setRegions] = useState([]);
  const [serviceType, setServiceType] = useState('restaurant');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const SERVICE_TYPES = [
    { id: 'restaurant', label: 'مطعم', icon: 'restaurant' },
    { id: 'delivery', label: 'توصيل', icon: 'bicycle' },
    { id: 'thomascook', label: 'توماس كوك', icon: 'airplane' },
    { id: 'shop', label: 'متجر', icon: 'storefront' },
  ];

  useEffect(() => { fetchRegions(); }, []);

  const fetchRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    if (data) {
      setRegions(data);
      if (data.length > 0) setSelectedRegion(data[0].id);
    }
  };

  const handleRegister = async () => {
    if (!name.trim()) { Alert.alert('تنبيه', 'أدخل اسم المحل'); return; }
    if (!phone.trim() || phone.length < 10) { Alert.alert('تنبيه', 'أدخل رقم هاتف صحيح'); return; }
    if (!password || password.length < 4) { Alert.alert('تنبيه', 'كلمة المرور 4 أحرف على الأقل'); return; }
    if (password !== confirmPassword) { Alert.alert('تنبيه', 'كلمة المرور غير متطابقة'); return; }
    if (!selectedRegion) { Alert.alert('تنبيه', 'الرجاء اختيار منطقة الخدمة'); return; }

    setLoading(true);
    try {
      const { data: existing } = await supabase.from(TABLES.PROFILES).select('id').eq('phone', phone.trim()).limit(1);
      if (existing && existing.length > 0) { Alert.alert('خطأ', 'رقم الهاتف مسجل مسبقاً'); setLoading(false); return; }

      const newUserId = generateUUID();
      const newUser = {
        id: newUserId, full_name: name.trim(), phone: phone.trim(), password,
        role: 'merchant', merchant_type: serviceType, region_id: selectedRegion,
        active: true, profile_completed: false, is_verified: false,
        created_at: new Date().toISOString(), updated_at: new Date().toISOString()
      };
      
      const { error: insertError } = await supabase.from(TABLES.PROFILES).insert([newUser]);
      if (insertError) { Alert.alert('خطأ', insertError.message || 'فشل في إنشاء الحساب'); setLoading(false); return; }

      const { data: merchantData, error: merchantError } = await supabase
        .from('merchants').insert([{
          id: newUserId, user_id: newUserId, name: name.trim(),
          phone: phone.trim(), service_type: serviceType, is_active: true,
          created_at: new Date().toISOString(), updated_at: new Date().toISOString()
        }]);
      
      if (merchantError) console.warn('تحذير: فشل إضافة سجل التاجر:', merchantError.message);

      const userDataToStore = { id: newUserId, $id: newUserId, full_name: name.trim(), name: name.trim(), phone: phone.trim(), role: 'merchant', merchantType: serviceType, region_id: selectedRegion };
      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await AsyncStorage.setItem('userRole', 'merchant');
      await AsyncStorage.setItem('userPhone', phone.trim());
      await AsyncStorage.setItem('userName', name.trim());

      Alert.alert('تم التسجيل', 'تم إنشاء حساب التاجر بنجاح', [
        { text: 'متابعة', onPress: () => navigation.replace('CompleteRegistrationScreen') }
      ]);
    } catch (error) { Alert.alert('خطأ', error.message || 'فشل في إنشاء الحساب'); }
    finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Ionicons name="arrow-back" size={24} color="#1F2937" />
      </TouchableOpacity>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>تسجيل تاجر جديد</Text>
          <Text style={styles.subtitle}>أنشئ حسابك وابدأ في بيع منتجاتك</Text>

          <View style={styles.inputContainer}>
            <Ionicons name="storefront-outline" size={20} color="#9CA3AF" style={styles.inputIcon} />
            <TextInput style={styles.input} placeholder="اسم المحل / المتجر" placeholderTextColor="#9CA3AF" value={name} onChangeText={setName} />
          </View>
          <View style={styles.inputContainer}>
            <Ionicons name="call-outline" size={20} color="#9CA3AF" style={styles.inputIcon} />
            <TextInput style={styles.input} placeholder="رقم الهاتف" placeholderTextColor="#9CA3AF" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
          </View>
          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color="#9CA3AF" style={styles.inputIcon} />
            <TextInput style={[styles.input, { flex: 1 }]} placeholder="كلمة المرور" placeholderTextColor="#9CA3AF" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}><Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color="#9CA3AF" /></TouchableOpacity>
          </View>
          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color="#9CA3AF" style={styles.inputIcon} />
            <TextInput style={[styles.input, { flex: 1 }]} placeholder="تأكيد كلمة المرور" placeholderTextColor="#9CA3AF" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry={!showConfirmPassword} />
            <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}><Ionicons name={showConfirmPassword ? "eye-off" : "eye"} size={20} color="#9CA3AF" /></TouchableOpacity>
          </View>

          <Text style={styles.label}>نوع الخدمة</Text>
          <View style={styles.serviceTypesRow}>
            {SERVICE_TYPES.map((type) => (
              <TouchableOpacity key={type.id} style={[styles.serviceTypeItem, serviceType === type.id && styles.serviceTypeActive]} onPress={() => setServiceType(type.id)}>
                <Ionicons name={type.icon} size={22} color={serviceType === type.id ? '#FFF' : '#4F46E5'} />
                <Text style={[styles.serviceTypeText, serviceType === type.id && styles.serviceTypeTextActive]}>{type.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>منطقة الخدمة</Text>
          <View style={styles.pickerContainer}>
            <Ionicons name="map-outline" size={20} color="#9CA3AF" style={styles.inputIcon} />
            <Picker selectedValue={selectedRegion} onValueChange={setSelectedRegion} style={styles.picker} dropdownIconColor="#4F46E5">
              <Picker.Item label="اختر المنطقة..." value={null} color="#9CA3AF" />
              {regions.map((r) => (
                <Picker.Item key={r.id} label={r.name} value={r.id} />
              ))}
            </Picker>
          </View>

          <TouchableOpacity style={styles.registerButton} onPress={handleRegister} disabled={loading}>
            {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.registerButtonText}>إنشاء حساب التاجر</Text>}
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')} style={styles.loginLink}>
            <Text style={styles.loginLinkText}>لديك حساب بالفعل؟ سجل دخول</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  backButton: { padding: 16 },
  content: { padding: 24, paddingTop: 10 },
  title: { fontSize: 26, fontWeight: 'bold', color: '#1F2937', marginBottom: 8, fontFamily: fontFamily.arabic },
  subtitle: { fontSize: 14, color: '#6B7280', marginBottom: 24, fontFamily: fontFamily.arabic },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8, marginTop: 4, fontFamily: fontFamily.arabic },
  inputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, paddingHorizontal: 16, marginBottom: 14, height: 52 },
  inputIcon: { marginRight: 12 },
  input: { flex: 1, fontSize: 15, color: '#1F2937', textAlign: 'right' },
  pickerContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, paddingHorizontal: 16, marginBottom: 14, height: 52 },
  picker: { flex: 1, color: '#1F2937' },
  serviceTypesRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 16, gap: 8 },
  serviceTypeItem: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB', gap: 6 },
  serviceTypeActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  serviceTypeText: { fontSize: 13, color: '#4F46E5', fontFamily: fontFamily.arabic },
  serviceTypeTextActive: { color: '#FFF' },
  registerButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  registerButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600', fontFamily: fontFamily.arabic },
  loginLink: { alignItems: 'center', marginTop: 16 },
  loginLinkText: { color: '#4F46E5', fontSize: 14, fontFamily: fontFamily.arabic },
});
