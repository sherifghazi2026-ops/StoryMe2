import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, StyleSheet, TouchableOpacity, Text, TextInput, ScrollView, Image, Alert,
  ActivityIndicator, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { createOrder } from '../services/orderService';
import { uploadServiceImage } from '../services/uploadService';
import { getMerchantsByType } from '../services/merchantService';
import { playSendSound } from '../utils/SoundHelper';

export default function ServiceScreen({ navigation, route }) {
  const { serviceType, serviceName, serviceColor, serviceImage, serviceHeaderImage } = route.params;
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [address, setAddress] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState([]);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [sending, setSending] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [termsOpened, setTermsOpened] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    loadUserData(); loadSavedAddress();
    return () => { isMounted.current = false; };
  }, []);

  useFocusEffect(useCallback(() => {
    if (termsOpened) setTermsAccepted(true);
  }, [termsOpened]));

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) { const parsed = JSON.parse(data); setUserData(parsed); setIsLoggedIn(true); setGuestName(parsed.full_name || parsed.name || ''); setGuestPhone(parsed.phone || ''); }
  };

  const loadSavedAddress = async () => { const savedAddress = await AsyncStorage.getItem('zayed_address'); if (savedAddress) setAddress(savedAddress); };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('صلاحيات', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.7 });
    if (!result.canceled && result.assets?.length > 0) { setImages(prev => [...prev, result.assets[0].uri]); }
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') { Alert.alert('صلاحيات', 'يجب السماح بالوصول للكاميرا'); return; }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, quality: 0.7 });
    if (!result.canceled && result.assets?.length > 0) { setImages(prev => [...prev, result.assets[0].uri]); }
  };

  const removeImage = (index) => setImages(images.filter((_, i) => i !== index));

  const validateGuestInfo = () => {
    if (!isLoggedIn) {
      if (!guestName.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال الاسم'); return false; }
      if (!guestPhone.trim() || guestPhone.length < 10) { Alert.alert('تنبيه', 'الرجاء إدخال رقم هاتف صحيح'); return false; }
      if (!termsAccepted) { Alert.alert('تنبيه', 'يجب الموافقة على شروط الاستخدام'); return false; }
    }
    if (!address.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال العنوان'); return false; }
    return true;
  };

  const sendOrder = async () => {
    if (!validateGuestInfo()) return;
    setSending(true);
    try {
      const merchantsResult = await getMerchantsByType(serviceType);
      let merchantId = null, merchantName = null, merchantPhone = null;
      if (merchantsResult.success && merchantsResult.data.length) {
        const selected = merchantsResult.data[Math.floor(Math.random() * merchantsResult.data.length)];
        merchantId = selected.$id || selected.id; merchantName = selected.name || selected.full_name; merchantPhone = selected.phone || '';
      }
      const image_urls = [];
      if (images.length) { setUploadingImages(true); for (let i = 0; i < images.length; i++) { const res = await uploadServiceImage(images[i]); if (res.success) image_urls.push(res.fileUrl); } setUploadingImages(false); }
      const customerName = isLoggedIn ? (userData?.full_name || userData?.name || 'عميل') : guestName.trim();
      const customerPhone = isLoggedIn ? (userData?.phone || '') : guestPhone.trim();
      const orderData = { customer_name: customerName, customer_phone: customerPhone, customer_address: address, service_type: serviceType, service_name: serviceName, items: description ? [description] : [], description, image_urls, notes: '', merchantId, merchantName, merchantPhone, is_guest: !isLoggedIn, guest_phone: !isLoggedIn ? guestPhone : null };
      const result = await createOrder(orderData);
      if (result.success) { await AsyncStorage.setItem('zayed_address', address); await playSendSound(); setLastOrderId(result.data.id);
        if (!isLoggedIn) { setShowSuccessModal(true); } else { Alert.alert('✅ تم إرسال طلبك', 'تم إرسال طلبك بنجاح', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]); }
        setDescription(''); setImages([]);
      } else { Alert.alert('خطأ', result.error || 'فشل في إرسال الطلب'); }
    } catch (error) { Alert.alert('خطأ', 'فشل في إرسال الطلب'); } finally { setSending(false); setUploadingImages(false); }
  };

  const handleRegister = () => { setShowSuccessModal(false); navigation.navigate('CustomerAuth', { prefillName: guestName, prefillPhone: guestPhone, fromGuestCheckout: true, pendingOrderId: lastOrderId }); };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {serviceHeaderImage ? (
        <View style={styles.headerImageContainer}>
          <Image source={{ uri: serviceHeaderImage }} style={styles.headerImage} />
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <Text style={styles.headerImageTitle}>{serviceName}</Text>
        </View>
      ) : (
        <View style={[styles.header, { backgroundColor: serviceColor || '#4F46E5' }]}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <View style={styles.headerCenter}><Text style={styles.headerTitle}>{serviceName}</Text><Text style={styles.headerSubtitle}>اطلب خدمتك الآن</Text></View>
          <View style={{ width: 40 }} />
        </View>
      )}

      {/* ✅ KeyboardAvoidingView + ScrollView */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.guestCard}>
            <View style={styles.guestCardHeader}><Ionicons name={isLoggedIn ? "person-circle" : "person-outline"} size={24} color="#4F46E5" /><Text style={styles.guestCardTitle}>{isLoggedIn ? 'مرحباً بعودتك' : 'بيانات الطلب'}</Text></View>
            {!isLoggedIn ? (<><View style={styles.inputGroup}><Ionicons name="person-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="الاسم الكامل" placeholderTextColor="#9CA3AF" value={guestName} onChangeText={setGuestName} editable={!sending} /></View><View style={styles.inputGroup}><Ionicons name="call-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="رقم الهاتف" placeholderTextColor="#9CA3AF" value={guestPhone} onChangeText={setGuestPhone} keyboardType="phone-pad" editable={!sending} /></View></>) : (<View style={styles.loggedInInfo}><View style={styles.infoChip}><Ionicons name="person" size={14} color="#4F46E5" /><Text style={styles.infoChipText}>{userData?.full_name || userData?.name}</Text></View><View style={styles.infoChip}><Ionicons name="call" size={14} color="#4F46E5" /><Text style={styles.infoChipText}>{userData?.phone || 'غير متاح'}</Text></View></View>)}
            <View style={styles.inputGroup}><Ionicons name="location-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="العنوان التفصيلي" placeholderTextColor="#9CA3AF" value={address} onChangeText={setAddress} editable={!sending} /></View>
          </View>
          <View style={styles.sectionCard}><Text style={styles.sectionTitle}>📝 وصف الطلب</Text><TextInput style={styles.textArea} placeholder="اكتب تفاصيل طلبك هنا..." placeholderTextColor="#9CA3AF" value={description} onChangeText={setDescription} multiline numberOfLines={4} editable={!sending} /></View>
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>🖼️ صور توضيحية (اختياري)</Text>
            <View style={styles.imageButtonsRow}>
              <TouchableOpacity style={styles.imageButton} onPress={pickImage}><Ionicons name="images-outline" size={24} color="#4F46E5" /><Text style={styles.imageButtonText}>معرض الصور</Text></TouchableOpacity>
              <TouchableOpacity style={styles.imageButton} onPress={takePhoto}><Ionicons name="camera-outline" size={24} color="#4F46E5" /><Text style={styles.imageButtonText}>التقاط صورة</Text></TouchableOpacity>
            </View>
            {images.length > 0 && (
              <View style={styles.imagesPreviewRow}>
                {images.map((img, index) => (
                  <View key={index} style={styles.imagePreviewItem}>
                    <Image source={{ uri: img }} style={styles.previewImage} />
                    <TouchableOpacity style={styles.removeImageBtn} onPress={() => removeImage(index)}><Ionicons name="close-circle" size={24} color="#EF4444" /></TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
          {!isLoggedIn && (
            <TouchableOpacity style={[styles.termsCard, termsAccepted && styles.termsCardActive]} onPress={() => setTermsAccepted(!termsAccepted)} activeOpacity={0.8}>
              <View style={[styles.checkbox, termsAccepted && styles.checkboxActive]}>{termsAccepted && <Ionicons name="checkmark" size={16} color="#FFF" />}</View>
              <Text style={styles.termsText}>أوافق على <Text style={styles.termsLink} onPress={(e) => { e.stopPropagation(); setTermsOpened(true); navigation.navigate('TermsScreen'); }}>شروط وأحكام تطبيق Zid</Text></Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={[styles.sendButton, (!isLoggedIn && !termsAccepted) || sending ? styles.disabled : null]} onPress={sendOrder} disabled={(!isLoggedIn && !termsAccepted) || sending} activeOpacity={0.8}>
            {sending ? <ActivityIndicator color="#FFF" /> : <View style={styles.sendButtonContent}><Ionicons name="send" size={20} color="#FFF" /><Text style={styles.sendButtonText}>إرسال الطلب</Text></View>}
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={showSuccessModal} transparent animationType="fade"><View style={styles.modalOverlay}><View style={styles.successModal}><View style={styles.successIcon}><Ionicons name="checkmark-circle" size={60} color="#10B981" /></View><Text style={styles.successTitle}>✅ تم استلام طلبك!</Text><View style={styles.successDivider} /><Text style={styles.successText}>رقم الطلب: <Text style={styles.successOrderId}>#{lastOrderId?.slice(-6) || '......'}</Text></Text><Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text><TouchableOpacity style={styles.registerButton} onPress={handleRegister} activeOpacity={0.8}><Ionicons name="person-add" size={20} color="#FFF" /><Text style={styles.registerButtonText}>حفظ بياناتي واستكمال التسجيل</Text></TouchableOpacity><TouchableOpacity style={styles.laterButton} onPress={() => setShowSuccessModal(false)}><Text style={styles.laterButtonText}>لاحقاً</Text></TouchableOpacity></View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  headerImageContainer: { height: 160, position: "relative", justifyContent: "center", alignItems: "center" },
  headerImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  backButton: { position: 'absolute', top: 12, left: 12, zIndex: 10 },
  backButtonCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  headerImageTitle: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, textAlign: "center", textAlignVertical: "center", fontSize: 28, fontWeight: "900", color: "#FFF", textShadowColor: "#000", textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, paddingTop: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, elevation: 2 },
  headerCenter: { alignItems: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#FFF' },
  headerSubtitle: { fontSize: 11, color: 'rgba(255,255,255,0.8)', marginTop: 1 },
  content: { padding: 16, paddingBottom: 40 },
  guestCard: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E8ECF0', elevation: 1 },
  guestCardHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 16 },
  guestCardTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  inputGroup: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  inputIcon: { marginRight: 10, width: 20, textAlign: 'center' },
  modernInput: { flex: 1, color: '#000000', backgroundColor: '#F5F7FA', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, borderWidth: 1, borderColor: '#E8ECF0' },
  loggedInInfo: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  infoChip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EEF2FF', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  infoChipText: { fontSize: 13, color: '#4F46E5', fontWeight: '500' },
  sectionCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E8ECF0' },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#1F2937', marginBottom: 12 },
  textArea: { color: '#000000', backgroundColor: '#F5F7FA', borderWidth: 1, borderColor: '#E8ECF0', borderRadius: 12, padding: 14, fontSize: 14, minHeight: 100, textAlignVertical: 'top', lineHeight: 22 },
  imageButtonsRow: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  imageButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EEF2FF', padding: 14, borderRadius: 12, gap: 8 },
  imageButtonText: { color: '#4F46E5', fontSize: 14, fontWeight: '600' },
  imagesPreviewRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  imagePreviewItem: { position: 'relative' },
  previewImage: { width: 80, height: 80, borderRadius: 10 },
  removeImageBtn: { position: 'absolute', top: -8, right: -8, backgroundColor: '#FFF', borderRadius: 12 },
  termsCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: '#FFF', borderWidth: 1.5, borderColor: '#E5E7EB', marginBottom: 16, gap: 10 },
  termsCardActive: { borderColor: '#4F46E5', backgroundColor: '#EEF2FF' },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: '#D1D5DB', justifyContent: 'center', alignItems: 'center' },
  checkboxActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  termsText: { fontSize: 13, color: '#4B5563', flex: 1, lineHeight: 18 },
  termsLink: { color: '#4F46E5', fontWeight: '600' },
  sendButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 30, elevation: 2 },
  disabled: { opacity: 0.5, elevation: 0 },
  sendButtonContent: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sendButtonText: { color: '#FFF', fontSize: 17, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModal: { backgroundColor: '#FFF', borderRadius: 24, padding: 28, alignItems: 'center', width: '88%', elevation: 10 },
  successIcon: { marginBottom: 12 },
  successTitle: { fontSize: 20, fontWeight: '800', color: '#1F2937', marginTop: 8 },
  successDivider: { height: 1, width: 40, backgroundColor: '#E5E7EB', marginVertical: 14 },
  successText: { fontSize: 14, color: '#4B5563' },
  successOrderId: { fontWeight: '700', color: '#4F46E5', fontSize: 16 },
  successSubtext: { fontSize: 13, color: '#6B7280', marginTop: 14, textAlign: 'center', lineHeight: 20 },
  registerButton: { flexDirection: 'row', backgroundColor: '#4F46E5', padding: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 20, gap: 8 },
  registerButtonText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  laterButton: { marginTop: 12, padding: 8 },
  laterButtonText: { color: '#9CA3AF', fontSize: 14 },
});
