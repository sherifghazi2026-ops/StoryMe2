import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ActivityIndicator, Alert, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getProductsByService } from '../services/productService';
import { createOrder } from '../services/orderService';
import { supabase } from '../lib/supabaseClient';
import DynamicMongez from '../components/DynamicMongez';

export default function ProductsServiceScreen({ route, navigation }) {
  const { serviceId, serviceName, serviceHeaderImage } = route.params;
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [allProducts, setAllProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quantities, setQuantities] = useState({});
  const [userPhone, setUserPhone] = useState('');
  const [userName, setUserName] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);
  const [searchText, setSearchText] = useState('');

  useEffect(() => { init(); }, []);

  const init = async () => {
    await loadUserData();
    await loadSavedAddress();
    await loadCategories();
    await loadProducts();
  };

  const loadUserData = async () => {
    try {
      const data = await AsyncStorage.getItem('userData');
      if (data) {
        const user = JSON.parse(data);
        setUserName(user.full_name || user.name || '');
        setUserPhone(user.phone || '');
      }
    } catch (error) {}
  };

  const loadSavedAddress = async () => {
    try {
      const saved = await AsyncStorage.getItem('zayed_address');
      if (saved) setAddress(saved);
    } catch (error) {}
  };

  const loadCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .eq('service_type', serviceId)
        .order('sort_order');
      if (!error && data) setCategories(data);
    } catch (error) {}
  };

  const loadProducts = async () => {
    setLoading(true);
    try {
      const data = await getProductsByService(serviceId);
      setAllProducts(data || []);
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  };

  const updateQuantity = (productId, value) => {
    const qty = parseInt(value) || 0;
    setQuantities(prev => ({ ...prev, [productId]: qty }));
  };

  const getTotal = () => {
    let total = 0;
    for (const id in quantities) {
      const qty = quantities[id];
      if (qty > 0) {
        const product = allProducts.find(p => p.id === id);
        if (product) total += product.price * qty;
      }
    }
    return total;
  };

  const handleSendOrder = async () => {
    if (!userName.trim() || !userPhone.trim()) {
      Alert.alert('تنبيه', 'يرجى إدخال الاسم ورقم الهاتف');
      return;
    }
    if (!address.trim()) {
      Alert.alert('تنبيه', 'يرجى إدخال العنوان');
      return;
    }

    const items = [];
    for (const id in quantities) {
      const qty = quantities[id];
      if (qty > 0) {
        const product = allProducts.find(p => p.id === id);
        if (product) items.push({ ...product, quantity: qty });
      }
    }
    if (items.length === 0) {
      Alert.alert('تنبيه', 'لم تطلب أي منتج');
      return;
    }

    setSending(true);
    try {
      const orderData = {
        service_type: serviceId,
        service_name: serviceName,
        user_name: userName.trim(),
        user_phone: userPhone.trim(),
        address: address.trim(),
        items: items,
        notes: notes.trim(),
        total: getTotal(),
      };
      const result = await createOrder(orderData);
      if (result.success) {
        Alert.alert('✅ تم', 'تم إرسال طلبك بنجاح');
        setQuantities({});
        setNotes('');
        navigation.goBack();
      } else {
        Alert.alert('خطأ', result.error);
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ غير متوقع');
    }
    setSending(false);
  };

  const filteredProducts = allProducts.filter(p => {
    if (searchText.trim() && !p.name.includes(searchText.trim())) return false;
    if (selectedCategory && p.category_id !== selectedCategory) return false;
    return true;
  });

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#1F2937" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{serviceName || 'المنتجات'}</Text>
          <View style={{ width: 24 }} />
        </View>

        {serviceHeaderImage && (
          <Image source={{ uri: serviceHeaderImage }} style={styles.headerImage} resizeMode="cover" />
        )}

        <View style={styles.content}>
          {/* Guest info */}
          <View style={styles.guestCard}>
            <View style={styles.inputGroup}>
              <Ionicons name="person-outline" size={18} color="#9CA3AF" />
              <TextInput style={styles.input} placeholder="الاسم *" value={userName} onChangeText={setUserName} />
            </View>
            <View style={styles.inputGroup}>
              <Ionicons name="call-outline" size={18} color="#9CA3AF" />
              <TextInput style={styles.input} placeholder="رقم الهاتف *" value={userPhone} onChangeText={setUserPhone} keyboardType="phone-pad" />
            </View>
            <View style={styles.inputGroup}>
              <Ionicons name="location-outline" size={18} color="#9CA3AF" />
              <TextInput style={styles.input} placeholder="العنوان *" value={address} onChangeText={setAddress} />
            </View>
          </View>

          {/* Search */}
          <View style={styles.searchContainer}>
            <Ionicons name="search-outline" size={20} color="#8B5CF6" />
            <TextInput style={styles.searchInput} placeholder="ابحث عن منتج..." value={searchText} onChangeText={setSearchText} />
          </View>

          {/* Categories */}
          {categories.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesRow}>
              <TouchableOpacity style={[styles.categoryChip, !selectedCategory && { borderColor: '#8B5CF6', backgroundColor: '#F3E8FF' }]} onPress={() => setSelectedCategory(null)}>
                <Ionicons name="grid-outline" size={24} color={!selectedCategory ? '#8B5CF6' : '#9CA3AF'} />
                <Text style={[styles.categoryChipText, !selectedCategory && { color: '#8B5CF6' }]}>الكل</Text>
              </TouchableOpacity>
              {categories.map(cat => (
                <TouchableOpacity key={cat.id} style={[styles.categoryChip, selectedCategory === cat.id && { borderColor: '#8B5CF6', backgroundColor: '#F3E8FF' }]} onPress={() => setSelectedCategory(cat.id)}>
                  {cat.icon ? <Ionicons name={cat.icon} size={24} color={selectedCategory === cat.id ? '#8B5CF6' : '#9CA3AF'} /> : <Ionicons name="cube-outline" size={24} color={selectedCategory === cat.id ? '#8B5CF6' : '#9CA3AF'} />}
                  <Text style={[styles.categoryChipText, selectedCategory === cat.id && { color: '#8B5CF6' }]}>{cat.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}

          {/* Products */}
          {filteredProducts.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="cube-outline" size={50} color="#D1D5DB" />
              <Text style={styles.emptyText}>لا توجد منتجات</Text>
            </View>
          ) : (
            filteredProducts.map(product => (
              <View key={product.id} style={styles.productCard}>
                {product.image_url ? (
                  <Image source={{ uri: product.image_url }} style={styles.productImg} />
                ) : (
                  <View style={[styles.productImg, { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' }]}>
                    <Ionicons name="cube-outline" size={24} color="#9CA3AF" />
                  </View>
                )}
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{product.name}</Text>
                  <Text style={styles.productPrice}>{product.price} ج</Text>
                </View>
                <TextInput style={styles.qtyInput} placeholder="0" keyboardType="numeric" value={String(quantities[product.id] || '')} onChangeText={(v) => updateQuantity(product.id, v)} />
              </View>
            ))
          )}

          {filteredProducts.length > 0 && (
            <>
              <Text style={styles.totalText}>الإجمالي: {getTotal()} ج</Text>
              <View style={styles.inputGroup}>
                <Ionicons name="document-text-outline" size={18} color="#9CA3AF" />
                <TextInput style={styles.input} placeholder="ملاحظات" value={notes} onChangeText={setNotes} multiline />
              </View>
              <TouchableOpacity style={[styles.sendButton, sending && styles.disabled]} onPress={handleSendOrder} disabled={sending}>
                {sending ? <ActivityIndicator color="#FFF" /> : <Text style={styles.sendButtonText}>إرسال الطلب</Text>}
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
      
      {/* المساعد الذكي - يظهر في شاشة المنتجات */}
      <DynamicMongez 
        screen="products_service" 
        navigation={navigation} 
        contextData={{ 
          serviceId: serviceId,
          serviceName: serviceName,
          products: allProducts,
          categories: categories
        }} 
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerImage: { width: '100%', height: 120, resizeMode: 'cover' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  guestCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12 },
  inputGroup: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
  input: { flex: 1, backgroundColor: '#F5F7FA', borderRadius: 8, padding: 10, fontSize: 14 },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, paddingHorizontal: 14, marginBottom: 14, borderWidth: 1.5, borderColor: '#8B5CF6', height: 48 },
  searchInput: { flex: 1, fontSize: 15, color: '#1F2937', marginLeft: 10 },
  categoriesRow: { marginBottom: 12 },
  categoryChip: { alignItems: 'center', backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginRight: 10, width: 90, borderWidth: 1, borderColor: '#E5E7EB' },
  categoryChipText: { fontSize: 12, fontWeight: '600', color: '#1F2937', marginTop: 6, textAlign: 'center' },
  productCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', padding: 10, borderRadius: 10, marginBottom: 8, gap: 10 },
  productImg: { width: 50, height: 50, borderRadius: 8 },
  productInfo: { flex: 1 },
  productName: { fontSize: 15, fontWeight: '500' },
  productPrice: { fontSize: 13, color: '#F59E0B', marginTop: 2 },
  qtyInput: { width: 50, backgroundColor: '#F5F7FA', borderRadius: 6, padding: 8, textAlign: 'center', fontSize: 14, borderWidth: 1, borderColor: '#E5E7EB' },
  empty: { alignItems: 'center', padding: 30 },
  emptyText: { color: '#9CA3AF', marginTop: 8 },
  totalText: { fontSize: 18, fontWeight: '700', textAlign: 'right', marginVertical: 12 },
  sendButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 12 },
  disabled: { opacity: 0.6 },
  sendButtonText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
