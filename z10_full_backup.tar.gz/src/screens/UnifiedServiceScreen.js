import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList,
  ActivityIndicator, Animated, Dimensions, StatusBar, TextInput, Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabaseClient';
import { fontFamily } from '../utils/fonts';
import { useCart } from '../context/CartContext';
import DynamicMongez from '../components/DynamicMongez';

const { width } = Dimensions.get('window');
const CARD_SIZE = (width - 48) / 2;
const PRODUCT_CARD_WIDTH = (width - 48) / 2;

export default function UnifiedServiceScreen({ route, navigation }) {
  const { serviceId, serviceName, serviceColor, serviceHeaderImage } = route.params;
  const [activeTab, setActiveTab] = useState(0);
  const slideAnim = useState(new Animated.Value(0))[0];
  const [headerImage, setHeaderImage] = useState(serviceHeaderImage);
  const { cartItems } = useCart();
  const [allProducts, setAllProducts] = useState([]);

  useEffect(() => {
    if (!headerImage) loadServiceHeader();
    loadAllProducts();
  }, []);

  // إعادة تحميل المنتجات عند الرجوع للتبويب 0
  useEffect(() => {
    if (activeTab === 0) {
      loadAllProducts();
    }
  }, [activeTab]);

  const loadServiceHeader = async () => {
    try {
      const { data } = await supabase
        .from('services')
        .select('header_image, image_url')
        .eq('id', serviceId)
        .single();
      if (data?.header_image || data?.image_url) {
        setHeaderImage(data.header_image || data.image_url);
      }
    } catch (e) {}
  };

  const loadAllProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('all_merchant_products')
        .select('*')
        .eq('service_id', serviceId)
        .eq('is_available', true);

      if (!error && data) {
        const grouped = {};
        (data || []).forEach(p => {
          if (!grouped[p.name]) {
            grouped[p.name] = {
              id: p.id,
              name: p.name,
              description: p.description,
              image_url: p.image_url,
              category: p.category || '',
              merchants: [p.merchant_id],
              prices: [p.price],
              minPrice: p.price,
              maxPrice: p.price,
              merchantCount: 1,
              product_type: p.product_type
            };
          } else {
            grouped[p.name].merchants.push(p.merchant_id);
            grouped[p.name].prices.push(p.price);
            grouped[p.name].merchantCount++;
            if (p.price < grouped[p.name].minPrice) grouped[p.name].minPrice = p.price;
            if (p.price > grouped[p.name].maxPrice) grouped[p.name].maxPrice = p.price;
          }
        });

        const uniqueProducts = Object.values(grouped)
          .filter(p => p.merchantCount > 1)
          .map(p => ({
            id: p.id,
            name: p.name,
            price: p.minPrice,
            minPrice: p.minPrice,
            maxPrice: p.maxPrice,
            description: p.description,
            image_url: p.image_url,
            category: p.category,
            merchantCount: p.merchantCount,
            merchant_id: p.merchants[0],
            product_type: 'multi_merchant'
          }));

        setAllProducts(uniqueProducts);
        console.log(`✅ تم جلب ${uniqueProducts.length} منتج مشترك (من ${data.length} إجمالي)`);
      }
    } catch (e) {
      console.log('خطأ في جلب المنتجات:', e);
    }
  };

  const switchTab = (tabIndex) => {
    setActiveTab(tabIndex);
    Animated.timing(slideAnim, {
      toValue: tabIndex,
      duration: 250,
      useNativeDriver: true,
    }).start();
  };

  const indicatorPosition = slideAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, (width - 48) / 2],
  });

  const productsSummary = allProducts.map(p => `${p.name} (${p.price}ج)`).join('، ');

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <View style={styles.headerImageContainer}>
        {headerImage ? (
          <Image source={{ uri: headerImage }} style={styles.headerImage} resizeMode="cover" />
        ) : (
          <View style={[styles.headerImage, styles.placeholderHeader, { backgroundColor: (serviceColor || '#4F46E5') + '30' }]}>
            <Ionicons name="storefront-outline" size={60} color={serviceColor || '#4F46E5'} />
          </View>
        )}

        <View style={styles.headerOverlay}>
          <TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color="#FFF" />
          </TouchableOpacity>
          <Text style={styles.headerServiceName}>{serviceName}</Text>
          <TouchableOpacity style={styles.cartCircle} onPress={() => navigation.navigate("FulfillmentScreen", { cartItems: cartItems.filter(i => i.isUnified), serviceId, serviceName })}>
            <Ionicons name="cart-outline" size={22} color="#FFF" />
            {cartItems.length > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{cartItems.length}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.tabSwitcher}>
        <View style={styles.tabBackground}>
          <Animated.View style={[styles.tabIndicator, { transform: [{ translateX: indicatorPosition }] }]} />
          <TouchableOpacity style={styles.tab} onPress={() => switchTab(0)} activeOpacity={0.7}>
            <Ionicons name="apps" size={18} color={activeTab === 0 ? '#FFF' : '#4F46E5'} />
            <Text style={[styles.tabText, activeTab === 0 && styles.activeTabText]}>المنتجات الموحدة</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.tab} onPress={() => switchTab(1)} activeOpacity={0.7}>
            <Ionicons name="storefront" size={18} color={activeTab === 1 ? '#FFF' : '#4F46E5'} />
            <Text style={[styles.tabText, activeTab === 1 && styles.activeTabText]}>قوائم البائعين</Text>
          </TouchableOpacity>
        </View>
      </View>

      {activeTab === 0 ? (
        <UnifiedProductsTab
          serviceId={serviceId}
          serviceName={serviceName}
          externalProducts={allProducts}
        />
      ) : (
        <MerchantsListInline
          serviceId={serviceId}
          serviceName={serviceName}
          navigation={navigation}
        />
      )}

      <DynamicMongez
        screen="service"
        navigation={navigation}
        contextData={{
          serviceId: serviceId,
          serviceName: serviceName,
          products: allProducts,
          productsSummary: productsSummary
        }}
      />
    </SafeAreaView>
  );
}

function MerchantsListInline({ serviceId, serviceName, navigation }) {
  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadMerchants(); }, []);

  const loadMerchants = async () => {
    try {
      const { data, error } = await supabase
        .from('merchants')
        .select('*')
        .eq('service_type', serviceId)
        .eq('is_active', true);
      if (error) throw error;
      setMerchants(data || []);
    } catch (error) { console.log(error); } finally { setLoading(false); }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <ScrollView contentContainerStyle={styles.merchantsContainer}>
      <Text style={styles.sectionTitle}>{merchants.length} تاجر متوفر</Text>
      <View style={styles.grid}>
        {merchants.map((merchant, index) => (
          <TouchableOpacity
            key={merchant.id || index}
            style={styles.card}
            onPress={() => navigation.navigate('MerchantProductsScreen', {
              merchantId: merchant.id,
              merchantName: merchant.name,
              merchantPhone: merchant.phone,
              merchantImage: merchant.image_url,
              serviceType: serviceId,
              serviceName: serviceName,
            })}
          >
            <View style={styles.cardContent}>
              {merchant.image_url ? (
                <Image source={{ uri: merchant.image_url }} style={styles.merchantImage} />
              ) : (
                <View style={styles.placeholderIcon}>
                  <Ionicons name="storefront-outline" size={40} color="#6B7280" />
                </View>
              )}
              <Text style={styles.merchantName} numberOfLines={1}>{merchant.name}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

function UnifiedProductsTab({ serviceId, serviceName, externalProducts }) {
  const [products, setProducts] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { cartItems, addToCart, updateQuantity } = useCart();
  const [defaultMerchantId, setDefaultMerchantId] = useState(null);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const toastOpacity = useState(new Animated.Value(0))[0];

  const showToast = (message) => {
    setToastMessage(message);
    setToastVisible(true);
    Animated.sequence([
      Animated.timing(toastOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.delay(1200),
      Animated.timing(toastOpacity, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => setToastVisible(false));
  };

  useEffect(() => {
    loadDefaultMerchant();
  }, []);

  const loadDefaultMerchant = async () => {
    try {
      const { data, error } = await supabase
        .from('merchants')
        .select('id')
        .eq('service_type', serviceId)
        .eq('is_active', true)
        .limit(1)
        .single();
      if (!error && data?.id) setDefaultMerchantId(data.id);
    } catch (error) {}
  };

  useEffect(() => {
    if (externalProducts && externalProducts.length > 0) {
      setProducts(externalProducts);
      setFiltered(externalProducts);
      setLoading(false);
    } else {
      loadProducts();
    }
  }, [externalProducts]);

  useEffect(() => {
    if (!search.trim()) setFiltered(products);
    else setFiltered(products.filter(p => p.name.toLowerCase().includes(search.toLowerCase())));
  }, [search, products]);

  const loadProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('all_merchant_products')
        .select('*')
        .eq('service_id', serviceId)
        .eq('is_available', true);
      if (error) throw error;

      const grouped = {};
      (data || []).forEach(p => {
        if (!grouped[p.name]) {
          grouped[p.name] = {
            id: p.id, name: p.name, description: p.description, image_url: p.image_url,
            category: p.category || '', merchants: [p.merchant_id], prices: [p.price],
            minPrice: p.price, maxPrice: p.price, merchantCount: 1, product_type: p.product_type
          };
        } else {
          grouped[p.name].merchants.push(p.merchant_id);
          grouped[p.name].prices.push(p.price);
          grouped[p.name].merchantCount++;
          if (p.price < grouped[p.name].minPrice) grouped[p.name].minPrice = p.price;
          if (p.price > grouped[p.name].maxPrice) grouped[p.name].maxPrice = p.price;
        }
      });

      const uniqueProducts = Object.values(grouped)
        .filter(p => p.merchantCount > 1)
        .map(p => ({
          id: p.id, name: p.name, price: p.minPrice, minPrice: p.minPrice, maxPrice: p.maxPrice,
          description: p.description, image_url: p.image_url, category: p.category,
          merchantCount: p.merchantCount, merchant_id: p.merchants[0] || defaultMerchantId,
          product_type: 'multi_merchant'
        }));

      setProducts(uniqueProducts);
      setFiltered(uniqueProducts);
      console.log(`✅ تم جلب ${uniqueProducts.length} منتج مشترك`);
    } catch (error) {
      setProducts([]);
      setFiltered([]);
    } finally {
      setLoading(false);
    }
  };

  const getQty = (id) => cartItems.find(i => i.id === id)?.quantity || 0;

  const handleAdd = async (p) => {
    let merchantId = p.merchant_id;
    if (!merchantId && defaultMerchantId) merchantId = defaultMerchantId;
    if (!merchantId) {
      try {
        const { data: merchant } = await supabase
          .from('merchants').select('id').eq('service_type', serviceId).eq('is_active', true).limit(1).single();
        if (merchant?.id) merchantId = merchant.id;
        else { Alert.alert('تنبيه', 'لا يوجد مقدم خدمة متاح حالياً لهذا المنتج'); return; }
      } catch (error) { Alert.alert('تنبيه', 'حدث خطأ في إضافة المنتج'); return; }
    }

    const existing = cartItems.find(i => i.id === p.id);
    if (existing) {
      updateQuantity(p.id, 1);
    } else {
      addToCart({
        id: p.id, name: p.name, price: p.price, quantity: 1, image_url: p.image_url,
        merchant_id: merchantId, serviceType: serviceId, serviceName: serviceName, isUnified: true,
      });
    }
    console.log('🛒 تمت إضافة للسلة:', { id: p.id, name: p.name, price: p.price, merchant_id: merchantId, serviceType: serviceId });
    showToast(`تمت إضافة ${p.name} للسلة`);
  };

  const renderProduct = ({ item }) => {
    const qty = getQty(item.id);
    return (
      <View style={styles.productGridCard}>
        <View style={styles.cardTopSection}>
          <View style={styles.imageContainer}>
            {item.image_url ? (
              <Image source={{ uri: item.image_url }} style={styles.productImage} resizeMode="cover" />
            ) : (
              <View style={styles.productPlaceholder}>
                <Ionicons name="image-outline" size={32} color="#9CA3AF" />
              </View>
            )}
          </View>

          <View style={styles.productInfo}>
            <Text style={styles.productName} numberOfLines={1}>{item.name}</Text>
            {item.category ? (
              <Text style={styles.productCategory}>{item.category}</Text>
            ) : null}
            {item.merchantCount > 1 ? (
              <Text style={styles.priceRangeText}>{item.minPrice} - {item.maxPrice} ج</Text>
            ) : (
              <Text style={styles.productPrice}>{item.price} ج</Text>
            )}
            {item.merchantCount > 1 && (
              <Text style={styles.merchantCountText}>متوفر لدى {item.merchantCount} تاجر</Text>
            )}
          </View>
        </View>

        <View style={styles.cartActionContainer}>
          {qty > 0 ? (
            <View style={styles.quantityControl}>
              <TouchableOpacity style={styles.qtyButton} onPress={() => updateQuantity(item.id, -1)}>
                <Ionicons name="remove" size={18} color="#FFF" />
              </TouchableOpacity>
              <Text style={styles.qtyText}>{qty}</Text>
              <TouchableOpacity style={styles.qtyButton} onPress={() => handleAdd(item)}>
                <Ionicons name="add" size={18} color="#FFF" />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={styles.addButton} onPress={() => handleAdd(item)}>
              <Ionicons name="add" size={20} color="#FFF" />
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <View style={styles.productsWrapper}>
      {toastVisible && (
        <Animated.View style={[styles.toastContainer, { opacity: toastOpacity }]}>
          <Ionicons name="checkmark-circle" size={20} color="#10B981" />
          <Text style={styles.toastText}>{toastMessage}</Text>
        </Animated.View>
      )}

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={18} color="#9CA3AF" />
        <TextInput style={styles.searchInput} placeholder="ابحث عن منتج..." value={search} onChangeText={setSearch} textAlign="right" />
        {search !== '' && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color="#9CA3AF" />
          </TouchableOpacity>
        )}
      </View>

      {filtered.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="cube-outline" size={60} color="#E5E7EB" />
          <Text style={styles.emptyText}>لا توجد منتجات مشتركة متاحة</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          renderItem={renderProduct}
          keyExtractor={item => item.id}
          numColumns={2}
          contentContainerStyle={styles.productsContainer}
          columnWrapperStyle={styles.columnWrapper}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerImageContainer: { position: 'relative', height: 160 },
  headerImage: { width: '100%', height: '100%', position: 'absolute', top: 0, left: 0 },
  placeholderHeader: { justifyContent: 'center', alignItems: 'center' },
  headerOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.3)', flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 16, paddingTop: 40 },
  backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  cartCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', position: 'relative' },
  cartBadge: { position: 'absolute', top: -4, right: -4, backgroundColor: '#EF4444', borderRadius: 10, width: 20, height: 20, justifyContent: 'center', alignItems: 'center' },
  cartBadgeText: { color: '#FFF', fontSize: 11, fontWeight: '700' },
  headerServiceName: { fontSize: 22, fontWeight: '700', color: '#FFF', fontFamily: fontFamily.arabic, textAlign: 'center', flex: 1 },
  tabSwitcher: { paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tabBackground: { flexDirection: 'row', backgroundColor: '#F3F4F6', borderRadius: 12, padding: 3, position: 'relative', height: 42 },
  tabIndicator: { position: 'absolute', width: '50%', height: 36, backgroundColor: '#4F46E5', borderRadius: 10, top: 3, left: 3 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 10, zIndex: 1 },
  tabText: { fontSize: 14, fontWeight: '600', color: '#4F46E5', fontFamily: fontFamily.arabic },
  activeTabText: { color: '#FFF' },
  merchantsContainer: { padding: 16 },
  sectionTitle: { fontSize: 14, color: '#6B7280', marginBottom: 12, fontFamily: fontFamily.arabic },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  card: { width: CARD_SIZE, backgroundColor: '#FFF', borderRadius: 16, padding: 12, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 12, elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 4 },
  cardContent: { alignItems: 'center', gap: 8 },
  merchantImage: { width: 70, height: 70, borderRadius: 35, backgroundColor: '#F3F4F6' },
  placeholderIcon: { width: 70, height: 70, borderRadius: 35, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  merchantName: { fontSize: 14, fontWeight: '600', color: '#1F2937', textAlign: 'center', fontFamily: fontFamily.arabic },
  productsWrapper: { flex: 1 },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', margin: 16, marginBottom: 8, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', gap: 8 },
  searchInput: { flex: 1, paddingVertical: 10, fontSize: 14, fontFamily: fontFamily.arabic },
  productsContainer: { padding: 16, paddingTop: 8 },
  columnWrapper: { justifyContent: 'space-between', marginBottom: 12 },
  productGridCard: { width: PRODUCT_CARD_WIDTH, backgroundColor: '#FFF', borderRadius: 14, borderWidth: 1, borderColor: '#E5E7EB', overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.04, shadowRadius: 6, elevation: 2, flexDirection: 'column', justifyContent: 'space-between' },
  cardTopSection: { flex: 1 },
  imageContainer: { width: '100%', aspectRatio: 1, backgroundColor: '#F9FAFB' },
  productImage: { width: '100%', height: '100%' },
  productPlaceholder: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center', backgroundColor: '#F3F4F6' },
  productInfo: { padding: 10, gap: 3, alignItems: 'center' },
  productName: { fontSize: 13, fontWeight: '600', color: '#1F2937', textAlign: 'center', fontFamily: fontFamily.arabic, lineHeight: 18 },
  productCategory: { fontSize: 12, fontWeight: '700', color: '#92400E', textAlign: 'center', fontFamily: fontFamily.arabic, backgroundColor: '#FEF3C7', paddingHorizontal: 10, paddingVertical: 3, borderRadius: 8, overflow: 'hidden', marginTop: 2 },
  productPrice: { fontSize: 14, fontWeight: '700', color: '#10B981', textAlign: 'center' },
  priceRangeText: { fontSize: 12, fontWeight: '600', color: '#10B981', textAlign: 'center' },
  merchantCountText: { fontSize: 10, color: '#8B5CF6', textAlign: 'center' },
  cartActionContainer: { borderTopWidth: 1, borderTopColor: '#F3F4F6', padding: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FAFAFA', marginTop: 'auto' },
  addButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#4F46E5', justifyContent: 'center', alignItems: 'center' },
  quantityControl: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14 },
  qtyButton: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#4F46E5', justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 15, fontWeight: '700', color: '#1F2937', minWidth: 20, textAlign: 'center' },
  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 12, fontFamily: fontFamily.arabic },
  toastContainer: { position: 'absolute', top: 10, left: 20, right: 20, backgroundColor: '#ECFDF5', borderWidth: 1, borderColor: '#10B981', borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10, zIndex: 9999, elevation: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 8 },
  toastText: { flex: 1, fontSize: 14, fontWeight: '600', color: '#065F46', fontFamily: fontFamily.arabic, textAlign: 'right' },
});
