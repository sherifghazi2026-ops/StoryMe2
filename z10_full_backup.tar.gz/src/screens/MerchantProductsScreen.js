import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Image, ActivityIndicator, RefreshControl, Alert, Dimensions, TextInput, Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabaseClient';
import { getMerchantProductsByService } from '../services/productService';
import { getSubServices } from '../services/fullServiceService';
import { useCart } from '../context/CartContext';
import DynamicMongez from '../components/DynamicMongez';

const { width } = Dimensions.get('window');
const CARD_MARGIN = 16;
const CARD_WIDTH = (width - CARD_MARGIN * 3) / 2;

export default function MerchantProductsScreen({ navigation, route }) {
  const { merchantId, merchantName, merchantImage, serviceType, serviceName, placeId, placeName, placeImage, isFullService } = route.params;
  const { addToCart } = useCart();

  const [allProducts, setAllProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [fullSubServices, setFullSubServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchText, setSearchText] = useState('');

  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const toastOpacity = useRef(new Animated.Value(0)).current;
  const toastTranslateY = useRef(new Animated.Value(20)).current;

  const showToast = (message) => {
    setToastMessage(message);
    setToastVisible(true);
    Animated.parallel([
      Animated.timing(toastOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.timing(toastTranslateY, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start();
    setTimeout(() => {
      Animated.parallel([
        Animated.timing(toastOpacity, { toValue: 0, duration: 400, useNativeDriver: true }),
        Animated.timing(toastTranslateY, { toValue: 10, duration: 400, useNativeDriver: true }),
      ]).start(() => setToastVisible(false));
    }, 2000);
  };

  useFocusEffect(useCallback(() => {
    if (isFullService) { loadSubServices(); } else { loadAll(); }
  }, []));

  const loadAll = async () => {
    setLoading(true);
    await loadCategories();
    await loadProducts();
    setLoading(false);
    setRefreshing(false);
  };

  const loadCategories = async () => {
    const { data } = await supabase
      .from('product_categories')
      .select('*')
      .eq('service_id', serviceType)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    setCategories(data || []);
  };

  const loadSubServices = async () => {
    setLoading(true);
    const { data: fs } = await supabase.from('full_services').select('id').eq('service_id', serviceType).single();
    if (fs) {
      const subs = await getSubServices(fs.id);
      setFullSubServices(subs.filter(s => s.is_active !== false));
    }
    setLoading(false); setRefreshing(false);
  };

  const loadProducts = async () => {
    const result = await getMerchantProductsByService(merchantId, serviceType);
    if (result.success) setAllProducts(result.data);
  };

  const getFilteredByCategory = () => {
    if (!selectedCategory) return allProducts;
    return allProducts.filter(p => {
      return !p.category_id || (p.category_id === selectedCategory.id) || (p.category === selectedCategory.name);
    });
  };

  const availableProducts = getFilteredByCategory().filter(p => {
    if (p.is_available === false) return false;
    if (searchText.trim()) return p.name?.toLowerCase().includes(searchText.trim().toLowerCase());
    return true;
  });

  const unavailableProducts = getFilteredByCategory().filter(p => {
    if (p.is_available !== false) return false;
    if (searchText.trim()) return p.name?.toLowerCase().includes(searchText.trim().toLowerCase());
    return true;
  });

  const displayProducts = [...availableProducts, ...unavailableProducts];
  const showCategories = !selectedCategory && !searchText && categories.length > 0;
  const listData = showCategories ? categories : displayProducts;

  const handleAddToCart = (product) => {
    addToCart({
      id: product.id, name: product.name, price: product.price,
      image_url: product.image_url, description: product.description,
      merchantId, merchantName: merchantName || placeName,
      serviceType, deliveryFee: 10, quantity: 1
    });
    showToast(`تمت إضافة ${product.name} للسلة`);
  };

  const handleProductPress = (product) => {
    navigation.navigate('ProductDetailsScreen', { product, merchantId, merchantName: merchantName || placeName });
  };

  const handleSubServicePress = (sub) => {
    navigation.navigate("FullServiceFieldScreen", {
      subServiceImage: sub.image_url, serviceType, subServiceName: sub.name,
      merchantId, merchantName: merchantName || placeName,
      serviceHeaderImage: route.params.serviceHeaderImage,
    });
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  const displayName = placeName || merchantName;
  const displayImage = placeImage || merchantImage;
  const flatListKey = showCategories ? 'categories-view' : 'products-view';

  return (
    <SafeAreaView style={styles.container}>
      {/* ✅ Header: سهم رجوع | سطرين (تاجر + فئة) | سلة */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => selectedCategory || searchText ? (setSelectedCategory(null), setSearchText('')) : navigation.goBack()}>
          <View style={styles.backCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
        </TouchableOpacity>
        
        <View style={styles.headerCenter}>
          {/* السطر الأول: صورة + اسم التاجر */}
          <View style={styles.merchantRow}>
            {displayImage ? <Image source={{ uri: displayImage }} style={styles.merchantAvatar} /> : <View style={styles.merchantAvatarPlaceholder}><Ionicons name="storefront-outline" size={16} color="#9CA3AF" /></View>}
            <Text style={styles.headerTitle} numberOfLines={1}>{displayName}</Text>
          </View>
          {/* السطر الثاني: اسم الفئة في المنتصف */}
          {selectedCategory && (
            <Text style={styles.headerSubtitle} numberOfLines={1}>{selectedCategory.name}</Text>
          )}
        </View>
        
        <TouchableOpacity onPress={() => navigation.navigate('Cart')}><Ionicons name="cart" size={24} color="#4F46E5" /></TouchableOpacity>
      </View>

      {!isFullService && (
        <View style={styles.searchOuter}>
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={20} color="#9CA3AF" />
            <TextInput style={styles.searchInput} placeholder="ابحث عن منتج..." value={searchText} onChangeText={setSearchText} placeholderTextColor="#9CA3AF" />
            {searchText !== '' && (
              <TouchableOpacity onPress={() => setSearchText('')}>
                <Ionicons name="close-circle" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            )}
          </View>
        </View>
      )}

      {isFullService ? (
        <FlatList
          data={fullSubServices} keyExtractor={item => item.id} contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.subServiceCard} onPress={() => handleSubServicePress(item)} activeOpacity={0.9}>
              {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.subServiceBg} /> : <View style={[styles.subServiceBg, styles.subServicePlaceholder]}><Ionicons name="document-text" size={40} color="#8B5CF6" /></View>}
              <View style={styles.subServiceOverlay} /><View style={styles.subServiceTextContainer}><Text style={styles.subServiceName}>{item.name}</Text></View>
              <View style={styles.subServiceArrow}><Ionicons name="chevron-forward" size={22} color="#FFF" /></View>
            </TouchableOpacity>
          )}
          ListHeaderComponent={<Text style={styles.sectionTitle}>اختر الخدمة</Text>}
          ListEmptyComponent={<Text style={styles.emptyText}>لا توجد خدمات فرعية</Text>}
        />
      ) : (
        <FlatList
          key={flatListKey}
          data={listData}
          keyExtractor={item => item.id}
          numColumns={showCategories ? 1 : 2}
          columnWrapperStyle={!showCategories ? { justifyContent: 'space-between' } : undefined}
          contentContainerStyle={styles.list}
          refreshControl={!showCategories ? <RefreshControl refreshing={refreshing} onRefresh={loadAll} /> : undefined}
          ListEmptyComponent={<View style={styles.emptyContainer}><Ionicons name="cube-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد منتجات متاحة</Text></View>}
          renderItem={({ item }) => {
            if (showCategories) {
              return (
                <TouchableOpacity style={styles.categoryCard} onPress={() => setSelectedCategory(item)} activeOpacity={0.9}>
                  {item.image_url ? (
                    <View style={styles.categoryImageCard}><Image source={{ uri: item.image_url }} style={styles.categoryImage} /><View style={styles.categoryOverlay} /><Text style={styles.categoryImageText}>{item.name}</Text><View style={styles.categoryArrow}><Ionicons name="chevron-forward" size={20} color="#FFF" /></View></View>
                  ) : (
                    <View style={styles.categoryNoImage}><View style={styles.categoryIconCircle}><Ionicons name={item.icon || 'cube'} size={28} color="#8B5CF6" /></View><Text style={styles.categoryName}>{item.name}</Text><Ionicons name="chevron-forward" size={20} color="#9CA3AF" /></View>
                  )}
                </TouchableOpacity>
              );
            }
            return (
              <TouchableOpacity style={[styles.productCard, !item.is_available && styles.productCardHidden]} onPress={() => handleProductPress(item)} activeOpacity={0.7}>
                <View style={styles.imageContainer}>
                  {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.productImage} /> : <View style={[styles.productImage, styles.placeholderImage]}><Ionicons name="image-outline" size={30} color="#9CA3AF" /></View>}
                  {!item.is_available && <View style={styles.unavailableOverlay}><Text style={styles.unavailableText}>غير متوفر</Text></View>}
                </View>
                <View style={styles.productInfo}>
                  <Text style={styles.productName} numberOfLines={2}>{item.name}</Text>
                  {item.description && <Text style={styles.productDesc} numberOfLines={2}>{item.description}</Text>}
                  <View style={styles.priceRow}>
                    <Text style={styles.productPrice}>{item.price} ج</Text>
                    <TouchableOpacity style={styles.addButton} onPress={() => handleAddToCart(item)}>
                      <Ionicons name="add-circle" size={24} color="#4F46E5" />
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}

      {toastVisible && (
        <Animated.View style={[styles.toastWrapper, { opacity: toastOpacity, transform: [{ translateY: toastTranslateY }] }]}>
          <View style={styles.toastInner}>
            <Ionicons name="cart" size={20} color="#4F46E5" />
            <Text style={styles.toastText} numberOfLines={1}>{toastMessage}</Text>
          </View>
        </Animated.View>
      )}

      <DynamicMongez screen="service" navigation={navigation} contextData={{ serviceId: serviceType, serviceName, merchantId, merchantName, placeName, screen: "service", products: allProducts }} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerCenter: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  // السطر الأول: صورة + اسم التاجر
  merchantRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  merchantAvatar: { width: 28, height: 28, borderRadius: 14 },
  merchantAvatarPlaceholder: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
   backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  // السطر الثاني: اسم الفئة في المنتصف
  headerSubtitle: { fontSize: 13, color: '#6B7280', marginTop: 4 },
  searchOuter: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 4, backgroundColor: '#F9FAFB' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, paddingHorizontal: 14, borderWidth: 1.5, borderColor: '#E5E7EB', height: 48 },
  searchInput: { flex: 1, fontSize: 15, color: '#1F2937', marginLeft: 10 },
  list: { padding: CARD_MARGIN },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#1F2937', marginBottom: 16 },
  categoryCard: { marginBottom: 14 },
  categoryImageCard: { height: 120, borderRadius: 16, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', position: 'relative' },
  categoryImage: { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%', resizeMode: 'cover' },
  categoryOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
  categoryImageText: { fontSize: 22, fontWeight: '800', color: '#FFFFFF', textShadowColor: '#000000', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, textAlign: 'center', zIndex: 1 },
  categoryArrow: { position: 'absolute', top: 14, right: 14, width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center' },
  categoryNoImage: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  categoryIconCircle: { width: 52, height: 52, borderRadius: 14, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  categoryName: { flex: 1, fontSize: 16, fontWeight: '600', color: '#1F2937' },
  subServiceCard: { width: '100%', height: 130, borderRadius: 16, marginBottom: 14, overflow: 'hidden', elevation: 4 },
  subServiceBg: { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%', resizeMode: 'cover' },
  subServicePlaceholder: { backgroundColor: '#8B5CF620', justifyContent: 'center', alignItems: 'center' },
  subServiceOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
  subServiceTextContainer: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center' },
  subServiceName: { fontSize: 22, fontWeight: '800', color: '#FFFFFF', textShadowColor: '#000000', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, textAlign: 'center', letterSpacing: 1, paddingHorizontal: 20 },
  subServiceArrow: { position: 'absolute', right: 12, top: '50%', marginTop: -11, backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: 15, width: 30, height: 30, justifyContent: 'center', alignItems: 'center' },
  productCard: { width: CARD_WIDTH, backgroundColor: '#FFF', borderRadius: 16, marginBottom: CARD_MARGIN, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 3, overflow: 'hidden' },
  productCardHidden: { opacity: 0.6 },
  imageContainer: { position: 'relative', width: '100%', height: CARD_WIDTH * 0.9, borderTopLeftRadius: 16, borderTopRightRadius: 16, overflow: 'hidden' },
  productImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  placeholderImage: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  unavailableOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  unavailableText: { color: '#FFF', fontSize: 14, fontWeight: '700' },
  productInfo: { padding: 12 },
  productName: { fontSize: 14, fontWeight: '600', color: '#1F2937', lineHeight: 20, height: 40 },
  productDesc: { fontSize: 12, color: '#6B7280', marginTop: 4, lineHeight: 16, height: 32 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  productPrice: { fontSize: 16, fontWeight: 'bold', color: '#F59E0B' },
  addButton: { padding: 4 },
  emptyContainer: { alignItems: 'center', padding: 40, width: '100%' },
  emptyText: { fontSize: 16, color: '#6B7280', marginTop: 12 },
  toastWrapper: { position: 'absolute', bottom: 40, left: 0, right: 0, alignItems: 'center', justifyContent: 'center', zIndex: 9999 },
  toastInner: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 25, borderWidth: 1, borderColor: '#E5E7EB', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 6, maxWidth: '90%' },
  toastText: { color: '#374151', fontSize: 14, fontWeight: '600', marginLeft: 8 },
});
