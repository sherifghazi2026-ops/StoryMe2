import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Image,
  RefreshControl, Alert, Modal, TextInput, Platform, StatusBar, BackHandler,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CustomDrawer from '../components/CustomDrawer';
import { getOrders, ORDER_STATUS } from '../services/orderService';
import { getVisibleServicesForHome } from '../services/servicesService';
import { useFocusEffect } from '@react-navigation/native';
import { supabase } from '../lib/supabaseClient';
import { fontFamily } from '../utils/fonts';
import DynamicMongez from '../components/DynamicMongez';
import useInterval from '../hooks/useInterval';

const { width } = Dimensions.get('window');
const CARD_SIZE = (width - 48) / 2;
const appIcon = require('../../assets/icons/ZidiconSP.png');

const CURRENT_ORDER_STATUSES = [
  ORDER_STATUS.PENDING, ORDER_STATUS.ACCEPTED, ORDER_STATUS.PREPARING,
  ORDER_STATUS.READY, ORDER_STATUS.DRIVER_ASSIGNED, ORDER_STATUS.ON_THE_WAY, ORDER_STATUS.PICKUP
];

const getStatusText = (status) => {
  const t = {
    [ORDER_STATUS.PENDING]: 'معلق', [ORDER_STATUS.ACCEPTED]: 'تم القبول',
    [ORDER_STATUS.PREPARING]: 'قيد التجهيز', [ORDER_STATUS.READY]: 'جاهز',
    [ORDER_STATUS.DRIVER_ASSIGNED]: 'مندوب معين', [ORDER_STATUS.ON_THE_WAY]: 'جاري التوصيل',
    [ORDER_STATUS.PICKUP]: 'استلام', [ORDER_STATUS.DELIVERED]: 'تم التوصيل', [ORDER_STATUS.CANCELLED]: 'ملغي',
  };
  return t[status] || status;
};

const getStatusColor = (status) => {
  const c = {
    [ORDER_STATUS.PENDING]: '#F59E0B', [ORDER_STATUS.ACCEPTED]: '#3B82F6',
    [ORDER_STATUS.PREPARING]: '#8B5CF6', [ORDER_STATUS.READY]: '#10B981',
    [ORDER_STATUS.DRIVER_ASSIGNED]: '#6366F1', [ORDER_STATUS.ON_THE_WAY]: '#F59E0B',
    [ORDER_STATUS.PICKUP]: '#8B5CF6', [ORDER_STATUS.DELIVERED]: '#10B981', [ORDER_STATUS.CANCELLED]: '#EF4444',
  };
  return c[status] || '#6B7280';
};

const OrderIcon = ({ order, services, navigation }) => {
  const [trackingIcon, setTrackingIcon] = useState(null);
  useEffect(() => { if (services.length > 0) loadIcon(); }, [services]);
  const loadIcon = async () => {
    if (order.sub_service_id) {
      const { data: sub } = await supabase.from('sub_services').select('tracking_icon_url').eq('id', order.sub_service_id).single();
      if (sub?.tracking_icon_url) { setTrackingIcon(sub.tracking_icon_url); return; }
    }
    const service = services.find(s => s.id === order.service_type);
    if (service?.tracking_icon_url) { setTrackingIcon(service.tracking_icon_url); }
  };
  const orderId = order.id || order.$id;
  const statusColor = getStatusColor(order.status);
  return (
    <TouchableOpacity style={styles.orderIconCard} onPress={() => navigation.navigate('OrderTrackingScreen', { orderId })} activeOpacity={0.7}>
      <View style={styles.orderIconBadge}>
        {trackingIcon ? <Image source={{ uri: trackingIcon }} style={styles.orderCustomIcon} /> : <Ionicons name="receipt-outline" size={28} color={statusColor} />}
        <View style={[styles.orderStatusDot, { backgroundColor: statusColor }]} />
      </View>
      <Text style={styles.orderServiceName} numberOfLines={1}>{order.service_name || order.service_type}</Text>
      <Text style={[styles.orderStatusMini, { color: statusColor }]}>{getStatusText(order.status)}</Text>
    </TouchableOpacity>
  );
};

const HomeScreen = ({ navigation }) => {
  const [ready, setReady] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState(null);
  const [userPhone, setUserPhone] = useState('');
  const [currentOrders, setCurrentOrders] = useState([]);
  const [services, setServices] = useState([]);
  const [groupedServices, setGroupedServices] = useState({});
  const [categories, setCategories] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [adminModalVisible, setAdminModalVisible] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showCurrentOrders, setShowCurrentOrders] = useState(true);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [regions, setRegions] = useState([]);
  const [globalIcon, setGlobalIcon] = useState('');
  const [userRegionName, setUserRegionName] = useState('');
  const [tagline, setTagline] = useState('');
  const [appLogoUrl, setAppLogoUrl] = useState(null);
  const [primaryColor, setPrimaryColor] = useState("#4F46E5");
  const [backgroundColor, setBackgroundColor] = useState("#FFFFFF");
  const [headerColor, setHeaderColor] = useState("#FFFFFF");
  const [categoryTextColor, setCategoryTextColor] = useState("#1F2937");
  const [headerImageUrl, setHeaderImageUrl] = useState(null);
  const [backgroundImageUrl, setBackgroundImageUrl] = useState(null);
  const [bgOpacity, setBgOpacity] = useState(0.3);
  const [cardOpacity, setCardOpacity] = useState(1);
  const [showRateReminder, setShowRateReminder] = useState(false);
  const [unratedOrders, setUnratedOrders] = useState([]);

  useEffect(() => {
    AsyncStorage.getItem("appSettings").then(cached => {
      if (cached) {
        const s = JSON.parse(cached);
        if (s.primary_color) setPrimaryColor(s.primary_color);
        if (s.background_color) setBackgroundColor(s.background_color);
        if (s.header_color) setHeaderColor(s.header_color);
        if (s.bg_opacity) setBgOpacity(parseFloat(s.bg_opacity) || 0.3);
        if (s.card_opacity) setCardOpacity(parseFloat(s.card_opacity) || 1);
        if (s.header_image_url) setHeaderImageUrl(s.header_image_url);
        if (s.background_image_url) setBackgroundImageUrl(s.background_image_url);
      }
      setReady(true);
    });
  }, []);

  useFocusEffect(useCallback(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => true);
    checkLoginStatus(); fetchSettings();
    return () => subscription.remove();
  }, []));

  useEffect(() => { if (ready) initApp(); }, [ready]);
  const initApp = async () => { await checkLoginStatus(); await fetchRegions(); await checkLoginStatus(); fetchSettings(); await loadCategories(); await loadServices(); };

  useEffect(() => {
    const redirectUser = async () => {
      try {
        const userDataStr = await AsyncStorage.getItem('userData');
        if (userDataStr) {
          const user = JSON.parse(userDataStr);
          if (user.role === 'merchant' || user.role === 'driver') {
            navigation.replace(user.role === 'merchant' ? 'MerchantDashboard' : 'DriverDashboard');
            return;
          }
        }
      } catch (error) {}
    };
    if (isLoggedIn) redirectUser();
  }, [isLoggedIn, navigation]);

  useFocusEffect(useCallback(() => { if (isLoggedIn && userPhone) fetchCurrentOrders(); }, [isLoggedIn, userPhone]));
  useInterval(() => { if (isLoggedIn && userPhone) fetchCurrentOrders(); }, 5000);

  useEffect(() => {
    if (isLoggedIn && userPhone) checkUnratedOrders();
  }, [isLoggedIn, userPhone, currentOrders]);

  const checkUnratedOrders = async () => {
    try {
      const deliveredOrders = currentOrders.filter(o => o.status === ORDER_STATUS.DELIVERED || o.status === 'delivered');
      if (deliveredOrders.length === 0) return;
      const unrated = [];
      for (const order of deliveredOrders) {
        const { data: existingReview } = await supabase.from('shop_reviews').select('id').eq('order_id', order.id).maybeSingle();
        const rateShown = await AsyncStorage.getItem(`rate_reminder_${order.id}`);
        if (!existingReview && !rateShown) unrated.push(order);
      }
      if (unrated.length > 0) {
        setUnratedOrders(unrated);
        setShowRateReminder(true);
      }
    } catch (e) {}
  };

  const handleRateLater = async () => {
    for (const order of unratedOrders) {
      await AsyncStorage.setItem(`rate_reminder_${order.id}`, 'shown');
    }
    setShowRateReminder(false);
  };

  const handleRateNow = () => {
    setShowRateReminder(false);
    navigation.navigate('MyOrdersScreen');
  };

  const checkLoginStatus = async () => {
    const savedLogo = await AsyncStorage.getItem('appLogoUrl'); if (savedLogo) setAppLogoUrl(savedLogo);
    const data = await AsyncStorage.getItem('userData');
    const phone = await AsyncStorage.getItem('userPhone');
    if (data) {
      const parsed = JSON.parse(data); setUserData(parsed); setIsLoggedIn(true); setUserPhone(parsed.phone || phone);
      if (parsed.role === 'customer' && parsed.region_id) {
        setSelectedRegion(parsed.region_id);
        const { data: regionData } = await supabase.from('regions').select('name').eq('id', parsed.region_id).single();
        if (regionData) setUserRegionName(regionData.name);
      }
    }
    if (phone) setUserPhone(phone);
  };

  const fetchRegions = async () => { const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name'); if (data) setRegions(data); };

  const fetchSettings = async () => {
    const { data } = await supabase.from('app_settings').select('*').eq('id', 1).single();
    if (data) {
      if (data.regions_icon) setGlobalIcon(data.regions_icon);
      if (data.splash_text) setTagline(data.splash_text);
      if (data.primary_color) setPrimaryColor(data.primary_color);
      if (data.background_color) setBackgroundColor(data.background_color);
      if (data.category_text_color) setCategoryTextColor(data.category_text_color);
      if (data.header_color) setHeaderColor(data.header_color);
      if (data.bg_opacity) setBgOpacity(parseFloat(data.bg_opacity) || 0.3);
      if (data.card_opacity) setCardOpacity(parseFloat(data.card_opacity) || 1);
      if (data.header_image_url) setHeaderImageUrl(data.header_image_url);
      if (data.background_image_url) setBackgroundImageUrl(data.background_image_url);
      if (data.app_logo_url) { setAppLogoUrl(data.app_logo_url); AsyncStorage.setItem('appLogoUrl', data.app_logo_url); }
      await AsyncStorage.setItem('appSettings', JSON.stringify(data));
    }
  };

  const loadCategories = async () => { const { data } = await supabase.from('service_categories').select('*').eq('is_active', true).order('sort_order'); if (data) setCategories(data); };
  const loadServices = async () => {
    const result = await getVisibleServicesForHome();
    if (result.success) {
      const filtered = result.data.filter(s => !['mongez', 'assistant', 'vegetables', 'fruits'].includes(s.id));
      const sorted = filtered.sort((a, b) => (a.is_active && !b.is_active ? -1 : !a.is_active && b.is_active ? 1 : 0));
      setServices(sorted);
      const grouped = {}; sorted.forEach(s => { const cat = s.category || 'other'; if (!grouped[cat]) grouped[cat] = []; grouped[cat].push(s); });
      setGroupedServices(grouped);
    }
  };

  const fetchCurrentOrders = async () => {
    if (!isLoggedIn || !userPhone) return;
    const result = await getOrders({ customerPhone: userPhone, status: CURRENT_ORDER_STATUSES });
    if (result.success) setCurrentOrders(result.data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
    setRefreshing(false);
  };

  const onRefresh = () => { setRefreshing(true); loadServices(); checkLoginStatus(); fetchSettings(); if (isLoggedIn) fetchCurrentOrders(); };

  const navigateToService = (service) => {
    if (!service.is_active) { Alert.alert('تنبيه', service.maintenance_text || 'الخدمة غير متاحة'); return; }
    if (service.type === 'ai') { Alert.alert('AI', 'خدمة الذكاء الاصطناعي قيد التطوير'); return; }
    if (service.type === "full_service") { navigation.navigate("MerchantsListScreen", { serviceType: service.id, serviceName: service.name, isFullService: true, serviceHeaderImage: service.header_image, subServices: service.sub_services || [], regionId: selectedRegion }); return; }
    if (service.type === 'items_service') { navigation.navigate('ServiceItemsScreen', { serviceId: service.id, serviceName: service.name, subServices: service.sub_services || [], serviceHeaderImage: service.header_image, regionId: selectedRegion }); }
    else if (service.type === 'items' || service.type === 'products') { navigation.navigate('UnifiedServiceScreen', { serviceId: service.id, serviceName: service.name, serviceColor: service.color, serviceHeaderImage: service.header_image, regionId: selectedRegion }); }
    else { navigation.navigate('ServiceScreen', { serviceType: service.id, serviceName: service.name, serviceColor: service.color, serviceImage: service.image_url, serviceHeaderImage: service.header_image, regionId: selectedRegion }); }
  };

  const handleAdminAccess = () => { if (adminPassword === "admin2026") { setAdminModalVisible(false); setAdminPassword(''); navigation.navigate('AdminHome'); } else Alert.alert('خطأ', 'كلمة المرور غير صحيحة'); };
  const getCategoryInfo = (catId) => { const cat = categories.find(c => c.id === catId); return cat || { id: catId, name: catId, icon: 'apps-outline', image_url: null }; };
  const getServiceImage = (service) => service.image_url ? { uri: service.image_url } : null;

  const renderRegionInHeader = () => {
    if (!isLoggedIn || !userRegionName) return null;
    return (
      <View style={styles.headerRegionBadge}>
        {globalIcon ? <Image source={{ uri: globalIcon }} style={styles.headerRegionIcon} /> : <Ionicons name="location" size={10} color={primaryColor} />}
        <Text style={[styles.headerRegionText, { color: primaryColor }]} numberOfLines={1}>{userRegionName}</Text>
      </View>
    );
  };

  const renderAvatar = () => {
    if (!isLoggedIn || !userData) {
      return (
        <View style={styles.authButtonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('CustomerAuth')} style={styles.registerButton}>
            <Ionicons name="log-in-outline" size={20} color={primaryColor} />
            <Text style={[styles.registerText, { fontFamily: fontFamily.arabic, color: primaryColor }]}>دخول / تسجيل</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.profileButton}>
      {userData?.image_url ? <Image source={{ uri: userData.image_url }} style={[styles.profileImage, { borderColor: primaryColor }]} /> : <Ionicons name="person-circle-outline" size={32} color={primaryColor} />}
    </TouchableOpacity>;
  };

  const imageOpacity = bgOpacity;

  const renderServicesByCategory = () => {
    if (services.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Ionicons name="cloud-offline-outline" size={60} color="#E5E7EB" />
          <Text style={[styles.emptyText, { fontFamily: fontFamily.arabic }]}>تعذر تحميل الخدمات</Text>
          <TouchableOpacity style={[styles.retryButton, { backgroundColor: primaryColor }]} onPress={loadServices}><Text style={[styles.retryButtonText, { fontFamily: fontFamily.arabic }]}>🔄 حاول مرة أخرى</Text></TouchableOpacity>
        </View>
      );
    }
    const sortedCategories = Object.keys(groupedServices).sort((a, b) => { const ca = categories.find(c => c.id === a); const cb = categories.find(c => c.id === b); return (ca?.sort_order || 99) - (cb?.sort_order || 99); });
    return (
      <>{sortedCategories.map(category => {
        const categoryServices = groupedServices[category];
        if (!categoryServices?.length) return null;
        const catInfo = getCategoryInfo(category);
        return (
          <View key={category} style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={[styles.sectionIcon, !catInfo.image_url && { backgroundColor: '#F5F5F5' }]}>
                {catInfo.image_url ? <Image source={{ uri: catInfo.image_url }} style={styles.categoryImage} /> : <Ionicons name={catInfo.icon || 'apps-outline'} size={24} color="#6B7280" />}
              </View>
              <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic, color: categoryTextColor }]}>{catInfo.name}</Text>
            </View>
            <View style={styles.grid}>
              {categoryServices.map(service => {
                const key = service.$id || service.id;
                const serviceImage = getServiceImage(service);
                const is_active = service.is_active === true;
                return (
                  <TouchableOpacity 
                    key={key} 
                    style={[
                      styles.card, 
                      !is_active && styles.disabledCard,
                      { opacity: cardOpacity }
                    ]} 
                    onPress={() => navigateToService(service)} 
                    disabled={!is_active}>
                    {serviceImage ? <Image source={serviceImage} style={[styles.cardImage, !is_active && styles.disabledImage]} /> : <View style={[styles.cardImage, styles.placeholderImage, { backgroundColor: (service.color || '#6B7280') + '20' }]}><Ionicons name={service.icon || 'apps-outline'} size={40} color={service.color || '#6B7280'} /></View>}
                    <View style={[styles.overlay, !is_active && styles.disabledOverlay]}><Text style={[styles.cardTitle, { fontFamily: fontFamily.arabic }, !is_active && styles.disabledCardTitle]}>{service.name}</Text>{!is_active && <View style={styles.maintenanceBadge}><Text style={[styles.maintenanceText, { fontFamily: fontFamily.arabic }]}>{service.maintenance_text || 'قيد الصيانة'}</Text></View>}</View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        );
      })}</>
    );
  };

  if (!ready) return <View style={{ flex: 1, backgroundColor: '#FFFFFF' }} />;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor }]}>
      {backgroundImageUrl && <Image source={{ uri: backgroundImageUrl }} style={[styles.bgImage, { opacity: imageOpacity }]} />}
      <StatusBar barStyle="dark-content" backgroundColor={headerColor} translucent={false} />
      <View style={[styles.header, { backgroundColor: headerImageUrl ? 'transparent' : headerColor }]}>
        {headerImageUrl ? <Image source={{ uri: headerImageUrl }} style={styles.headerBgImage} /> : null}
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuButton}><Ionicons name="menu" size={28} color="#1F2937" /></TouchableOpacity>
          <View style={styles.logoContainer}>
            {appLogoUrl ? <Image source={{ uri: appLogoUrl }} style={styles.logo} onError={() => setAppLogoUrl(null)} /> : <Image source={appIcon} style={styles.logo} />}
            <Text style={styles.tagline}>{tagline}</Text>
          </View>
        </View>
        <View style={styles.headerRight}>{renderRegionInHeader()}{renderAvatar()}</View>
      </View>
      {isLoggedIn && <View style={styles.welcomeSection}><Text style={[styles.welcomeText, { fontFamily: fontFamily.arabic }]}>مرحباً، {userData?.full_name || userData?.name}</Text></View>}
      {isLoggedIn && currentOrders.length > 0 && (
        <View style={styles.ordersSection}>
          <View style={styles.ordersHeader}><Text style={[styles.ordersTitle, { fontFamily: fontFamily.arabic }]}>طلباتك الحالية</Text><TouchableOpacity onPress={() => setShowCurrentOrders(!showCurrentOrders)}><Ionicons name={showCurrentOrders ? "chevron-up" : "chevron-down"} size={16} color="#6B7280" /></TouchableOpacity></View>
          {showCurrentOrders && <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.ordersIconsContainer}>{currentOrders.map(order => <OrderIcon key={order.id || order.$id} order={order} services={services} navigation={navigation} />)}</ScrollView>}
        </View>
      )}
      {isLoggedIn && currentOrders.length === 0 && <View style={styles.noOrdersContainer}><Text style={[styles.noOrdersText, { fontFamily: fontFamily.arabic }]}>لا توجد طلبات حالية</Text></View>}
      <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[primaryColor]} tintColor={primaryColor} />} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>{renderServicesByCategory()}<View style={{ height: 80 }} /></ScrollView>

      <Modal visible={showRateReminder} transparent animationType="fade">
        <View style={styles.rateModalOverlay}>
          <View style={styles.rateModalContent}>
            <Ionicons name="star" size={50} color="#F59E0B" />
            <Text style={[styles.rateModalTitle, { fontFamily: fontFamily.arabic }]}>لديك طلبات بدون تقييم</Text>
            <Text style={[styles.rateModalSubtitle, { fontFamily: fontFamily.arabic }]}>لديك {unratedOrders.length} طلبات مكتملة بدون تقييم. تقييمك يساعدنا في تحسين الخدمة.</Text>
            <View style={styles.rateModalBtns}>
              <TouchableOpacity style={styles.rateLaterBtn} onPress={handleRateLater}><Text style={[styles.rateLaterText, { fontFamily: fontFamily.arabic }]}>لاحقاً</Text></TouchableOpacity>
              <TouchableOpacity style={styles.rateNowBtn} onPress={handleRateNow}><Text style={[styles.rateNowText, { fontFamily: fontFamily.arabic }]}>قيم الآن</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={drawerVisible} transparent animationType="slide"><View style={styles.drawerOverlay}><View style={styles.drawerContent}><CustomDrawer isLoggedIn={isLoggedIn} userData={userData} onClose={() => setDrawerVisible(false)} navigation={navigation} onOpenAdminModal={() => setAdminModalVisible(true)} /></View></View></Modal>
      <Modal visible={adminModalVisible} transparent animationType="fade"><View style={styles.modalOverlay}><View style={styles.modalContent}><Text style={[styles.modalTitle, { fontFamily: fontFamily.arabic }]}>دخول الأدمن</Text><Text style={[styles.modalSubtitle, { fontFamily: fontFamily.arabic }]}>أدخل كلمة المرور</Text><TextInput style={styles.modalInput} placeholder="********" secureTextEntry={true} value={adminPassword} onChangeText={setAdminPassword} autoFocus /><View style={styles.modalButtons}><TouchableOpacity style={[styles.modalButton, styles.modalCancel]} onPress={() => { setAdminModalVisible(false); setAdminPassword(''); }}><Text style={[styles.modalCancelText, { fontFamily: fontFamily.arabic }]}>إلغاء</Text></TouchableOpacity><TouchableOpacity style={[styles.modalButton, styles.modalConfirm]} onPress={handleAdminAccess}><Text style={[styles.modalConfirmText, { fontFamily: fontFamily.arabic }]}>دخول</Text></TouchableOpacity></View></View></View></Modal>
      <DynamicMongez screen="home" navigation={navigation} contextData={{ user: userData, isLoggedIn, screen: "home", customerPhone: userPhone }} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  bgImage: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, resizeMode: 'cover' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingTop: Platform.OS === 'ios' ? 8 : 10, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', elevation: 2, overflow: 'hidden' },
  headerBgImage: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, resizeMode: 'cover' },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  menuButton: { padding: 6, borderRadius: 8, backgroundColor: '#F0F0F0', width: 38, height: 38, justifyContent: 'center', alignItems: 'center' },
  logo: { width: 120, height: 50, resizeMode: 'contain' },
  tagline: { fontSize: 10, color: '#6B7280', fontWeight: '500', marginLeft: 4 },
  logoContainer: { alignItems: 'center' },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  headerRegionBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EEF2FF', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, gap: 4, marginRight: 6 },
  headerRegionIcon: { width: 12, height: 12, borderRadius: 4, resizeMode: 'cover' },
  headerRegionText: { fontSize: 10, fontWeight: '600', fontFamily: fontFamily.arabic, maxWidth: 70 },
  profileImage: { width: 38, height: 38, borderRadius: 19, borderWidth: 2 },
  authButtonContainer: { alignItems: 'center', marginTop: 0 },
  registerButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EEF2FF', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, gap: 6 },
  registerText: { fontSize: 12, fontWeight: '600' },
  profileButton: { padding: 2 },
  welcomeSection: { paddingHorizontal: 12, paddingVertical: 6 },
  welcomeText: { fontSize: 13, fontWeight: '500', color: '#1F2937' },
  ordersSection: { marginTop: 4, marginBottom: 8, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: '#F9FAFB', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  ordersHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  ordersTitle: { fontSize: 12, fontWeight: '700', color: '#4B5563' },
  ordersIconsContainer: { flexDirection: 'row', gap: 10, paddingVertical: 2 },
  orderIconCard: { alignItems: 'center', width: 60 },
  orderIconBadge: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center', position: 'relative', marginBottom: 4, backgroundColor: '#F3F4F6' },
  orderCustomIcon: { width: 30, height: 30, borderRadius: 8 },
  orderStatusDot: { position: 'absolute', top: -3, right: -3, width: 10, height: 10, borderRadius: 5, borderWidth: 2, borderColor: '#FFF' },
  orderServiceName: { fontSize: 9, fontWeight: '600', color: '#1F2937', textAlign: 'center', marginBottom: 2 },
  orderStatusMini: { fontSize: 8, fontWeight: '700' },
  noOrdersContainer: { marginHorizontal: 12, marginVertical: 4, padding: 8, backgroundColor: '#F8FAFC', borderRadius: 8, alignItems: 'center' },
  noOrdersText: { fontSize: 12, color: '#6B7280' },
  content: { padding: 12, paddingTop: 8 },
  section: { marginBottom: 20 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
  sectionIcon: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  categoryImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 10 },
  card: { width: CARD_SIZE, height: 140, borderRadius: 16, overflow: 'hidden', marginBottom: 10, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, backgroundColor: '#FFF' },
  cardImage: { width: '100%', height: '100%' },
  placeholderImage: { justifyContent: 'center', alignItems: 'center' },
  disabledCard: { opacity: 0.8 },
  disabledImage: { opacity: 0.5 },
  disabledOverlay: { backgroundColor: 'rgba(0,0,0,0.4)' },
  disabledCardTitle: { color: '#FFF', opacity: 0.9, fontSize: 14 },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center', padding: 8 },
  cardTitle: { color: '#FFF', fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'center', textShadowColor: "#000", textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 4 },
  maintenanceBadge: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#EF4444', paddingVertical: 4, alignItems: 'center' },
  maintenanceText: { color: '#FFF', fontSize: 11, fontWeight: 'bold' },
  emptyContainer: { alignItems: 'center', paddingVertical: 60 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
  retryButton: { marginTop: 12, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 10 },
  retryButtonText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  drawerContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 25, borderTopRightRadius: 25, height: '80%', overflow: 'hidden' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24, width: '80%', alignItems: 'center' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  modalSubtitle: { fontSize: 14, color: '#6B7280', marginBottom: 16 },
  modalInput: { width: '100%', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, padding: 12, marginBottom: 20, fontSize: 16, textAlign: 'center' },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-between', width: '100%', gap: 10 },
  modalButton: { flex: 1, padding: 12, borderRadius: 12, alignItems: 'center' },
  modalCancel: { backgroundColor: '#F3F4F6' },
  modalConfirm: { backgroundColor: '#EF4444' },
  modalCancelText: { color: '#1F2937', fontSize: 16, fontWeight: '600' },
  modalConfirmText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  rateModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  rateModalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 30, alignItems: 'center', width: '85%' },
  rateModalTitle: { fontSize: 20, fontWeight: '700', color: '#1F2937', marginTop: 12 },
  rateModalSubtitle: { fontSize: 14, color: '#6B7280', marginTop: 8, textAlign: 'center' },
  rateModalBtns: { flexDirection: 'row', gap: 12, marginTop: 24 },
  rateLaterBtn: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center' },
  rateLaterText: { color: '#6B7280', fontSize: 15, fontWeight: '600' },
  rateNowBtn: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: '#F59E0B', alignItems: 'center' },
  rateNowText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});

export default HomeScreen;
