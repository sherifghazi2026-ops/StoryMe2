import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, ActivityIndicator, Dimensions, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getActiveOffers } from '../services/offersService';
import { supabase } from '../lib/supabaseClient';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

export default function OffersScreen({ navigation }) {
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [headerImage, setHeaderImage] = useState(null);

  useEffect(() => { 
    loadOffers(); 
    loadHeaderImage();
  }, []);

  const loadHeaderImage = async () => {
    try {
      const { data } = await supabase
        .from('services')
        .select('image_url')
        .eq('id', 'offers_header')
        .single();
      if (data?.image_url) setHeaderImage(data.image_url);
    } catch (error) {}
  };

  const loadOffers = async () => {
    setLoading(true);
    const result = await getActiveOffers();
    if (result.success) setOffers(result.data);
    setLoading(false);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#F59E0B" />
          <Text style={styles.loadingText}>جاري تحميل العروض...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* ✅ Header صورة فقط بدون أي كتابة */}
      {headerImage ? (
        <View style={styles.headerImageContainer}>
          <Image source={{ uri: headerImage }} style={styles.headerBgImage} resizeMode="cover" />
        </View>
      ) : (
        <LinearGradient colors={['#F59E0B', '#EF4444']} style={styles.header}>
          <View style={styles.headerContent}>
            <Ionicons name="flame" size={28} color="#FFF" />
            <Text style={styles.headerTitle}>عروض حصرية 🔥</Text>
            <Text style={styles.headerSubtitle}>خصومات ولفترة محدودة</Text>
          </View>
        </LinearGradient>
      )}

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {offers.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="pricetag-outline" size={80} color="#E5E7EB" />
            <Text style={styles.emptyTitle}>لا توجد عروض حالياً</Text>
            <Text style={styles.emptySubtitle}>تابعنا باستمرار للحصول على أحدث العروض</Text>
          </View>
        ) : (
          <View style={styles.offersGrid}>
            {offers.map((offer) => (
              <View key={offer.id} style={styles.offerCard}>
                <View style={styles.imageContainer}>
                  {offer.image_url ? (
                    <Image source={{ uri: offer.image_url }} style={styles.offerImage} />
                  ) : (
                    <LinearGradient colors={['#FCD34D', '#F59E0B']} style={styles.imagePlaceholder}>
                      <Ionicons name="pricetag" size={50} color="#FFF" />
                    </LinearGradient>
                  )}
                  {offer.discount_percent > 0 && (
                    <LinearGradient colors={['#EF4444', '#DC2626']} style={styles.discountBadge}>
                      <Text style={styles.discountText}>%{offer.discount_percent}</Text>
                      <Text style={styles.discountLabel}>خصم</Text>
                    </LinearGradient>
                  )}
                  <View style={styles.timeBadge}>
                    <Ionicons name="time-outline" size={12} color="#FFF" />
                    <Text style={styles.timeText}>عرض محدود</Text>
                  </View>
                </View>

                <View style={styles.offerContent}>
                  <Text style={styles.offerTitle} numberOfLines={2}>{offer.title}</Text>
                  {offer.merchant_name && (
                    <Text style={styles.merchantName}>{offer.merchant_name}</Text>
                  )}
                  {offer.description && (
                    <Text style={styles.offerDesc} numberOfLines={2}>{offer.description}</Text>
                  )}

                  <View style={styles.priceRow}>
                    {offer.original_price && (
                      <View style={styles.originalPriceContainer}>
                        <Text style={styles.originalPriceLabel}>قبل</Text>
                        <Text style={styles.originalPrice}>{offer.original_price} ج</Text>
                      </View>
                    )}
                    {offer.offer_price && (
                      <View style={styles.offerPriceContainer}>
                        <Text style={styles.offerPriceLabel}>الآن</Text>
                        <Text style={styles.offerPrice}>{offer.offer_price} ج</Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 12, fontSize: 16, color: '#6B7280' },

  // ✅ Header صورة فقط - بدون أي نص
  headerImageContainer: { height: 200, width: '100%' },
  headerBgImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  backButton: { position: 'absolute', top: 50, left: 16, zIndex: 10, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },

  // Header متدرج افتراضي
  header: { paddingVertical: 40, paddingHorizontal: 20, borderBottomLeftRadius: 30, borderBottomRightRadius: 30, elevation: 5, shadowColor: '#F59E0B', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
  headerContent: { alignItems: 'center' },
  headerTitle: { fontSize: 24, fontWeight: '800', color: '#FFF', marginTop: 8 },
  headerSubtitle: { fontSize: 13, color: 'rgba(255,255,255,0.8)', marginTop: 4 },

  content: { padding: 16 },
  offersGrid: { gap: 16 },
  emptyContainer: { alignItems: 'center', paddingVertical: 60 },
  emptyTitle: { fontSize: 18, fontWeight: '600', color: '#9CA3AF', marginTop: 16 },
  emptySubtitle: { fontSize: 13, color: '#D1D5DB', marginTop: 6 },
  offerCard: { backgroundColor: '#FFF', borderRadius: 20, overflow: 'hidden', elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 12 },
  imageContainer: { position: 'relative', height: 180 },
  offerImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
  discountBadge: { position: 'absolute', top: 12, left: 12, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 6, alignItems: 'center', elevation: 3 },
  discountText: { fontSize: 18, fontWeight: '800', color: '#FFF' },
  discountLabel: { fontSize: 10, color: '#FFF', marginTop: -2 },
  timeBadge: { position: 'absolute', bottom: 12, right: 12, flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, gap: 4 },
  timeText: { fontSize: 11, color: '#FFF', fontWeight: '500' },
  offerContent: { padding: 16 },
  offerTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', lineHeight: 24 },
  merchantName: { fontSize: 12, color: '#6B7280', marginTop: 4 },
  offerDesc: { fontSize: 13, color: '#6B7280', marginTop: 6, lineHeight: 20 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 14, paddingTop: 14, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  originalPriceContainer: { alignItems: 'center' },
  originalPriceLabel: { fontSize: 11, color: '#9CA3AF' },
  originalPrice: { fontSize: 16, color: '#9CA3AF', textDecorationLine: 'line-through', fontWeight: '600' },
  offerPriceContainer: { alignItems: 'center' },
  offerPriceLabel: { fontSize: 11, color: '#10B981', fontWeight: '600' },
  offerPrice: { fontSize: 22, fontWeight: '800', color: '#10B981' },
});
