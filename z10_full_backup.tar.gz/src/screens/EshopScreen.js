import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, TextInput, ActivityIndicator, Alert, Modal, Dimensions,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getShopSettings, getShopProducts, getFeaturedProducts, createShopOrder } from '../services/shopService';
import { useCart } from '../context/CartContext';
import Mongez from '../components/Mongez';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 48) / 2;

export default function EshopScreen({ navigation }) {
  const [settings, setSettings] = useState(null);
  const [products, setProducts] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [searchText, setSearchText] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);

  const { cartItems, addToCart, updateQuantity, removeFromCart, clearCart, getTotalPrice, itemCount } = useCart();

  const categories = ['الكل', 'عروض', 'رجال', 'نساء', 'أطفال', 'منزل', 'إلكترونيات'];

  useFocusEffect(useCallback(() => { loadAll(); }, []));

  const loadAll = async () => {
    setLoading(true);
    try {
      const [s, p, f] = await Promise.all([getShopSettings(), getShopProducts(), getFeaturedProducts()]);
      setSettings(s);
      if (p && p.data) setProducts(p.data); else setProducts([]);
      if (f && f.data) setFeatured(f.data); else setFeatured([]);
      const userDataStr = await AsyncStorage.getItem('userData');
      if (userDataStr) {
        const user = JSON.parse(userDataStr);
        setIsLoggedIn(true);
        setName(user.full_name || user.name || '');
        setPhone(user.phone || '');
      }
    } catch (e) { Alert.alert('خطأ', 'فشل تحميل البيانات'); }
    setLoading(false);
  };

  const cartTotal = getTotalPrice();
  const shipping = cartTotal >= (settings?.free_shipping_min_order || 200) ? 0 : 30;

  const handleRegister = () => {
    setShowSuccessModal(false);
    navigation.navigate("CustomerAuth", { prefillName: name, prefillPhone: phone, fromGuestCheckout: true, pendingOrderId: lastOrderId });
  };

  const sendOrder = async () => {
    if (!isLoggedIn && (!name.trim() || !phone.trim() || !address.trim())) { Alert.alert('تنبيه', 'يرجى إدخال جميع البيانات'); return; }
    if (isLoggedIn && !address.trim()) { Alert.alert('تنبيه', 'يرجى إدخال العنوان'); return; }
    if (cartItems.length === 0) { Alert.alert('تنبيه', 'السلة فارغة'); return; }
    setSending(true);
    const userDataStr = await AsyncStorage.getItem('userData');
    const user = userDataStr ? JSON.parse(userDataStr) : null;
    const userId = user?.id || user?.$id || null;
    const result = await createShopOrder({
      userId, name: name.trim(), phone: phone.trim(), address: address.trim(),
      items: cartItems.map(i => `${i.name} x${i.quantity || 1} = ${i.price * (i.quantity || 1)}ج`),
      total: cartTotal, shipping, notes: notes.trim()
    });
    setSending(false);
    if (result.success) {
      clearCart(); setShowCheckout(false); setShowCart(false);
      if (!isLoggedIn) { setLastOrderId(result.data?.id); setShowSuccessModal(true); }
      else Alert.alert('✅ تم', 'تم إرسال طلبك بنجاح');
    } else Alert.alert('خطأ', result.error);
  };

  const filteredProducts = products.filter(p => {
    const matchCategory = selectedCategory === 'الكل' || p.category === selectedCategory;
    const matchSearch = !searchText.trim() || (p.name && p.name.includes(searchText.trim()));
    return matchCategory && matchSearch;
  });

  const getDiscountPercent = (item) => {
    if (item.original_price && item.original_price > item.price) return Math.round((1 - item.price / item.original_price) * 100);
    return 0;
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  if (!settings?.is_active) return <SafeAreaView style={styles.center}><Ionicons name="construct-outline" size={90} color="#F59E0B" /><Text style={styles.maintenanceTitle}>قريباً</Text><Text style={styles.maintenanceText}>{settings?.maintenance_message || 'المتجر قيد التجهيز'}</Text></SafeAreaView>;

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#FFFFFF', '#F8FAFC']} style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.openDrawer()} style={styles.menuButton}>
            <Ionicons name="menu-outline" size={28} color="#1F2937" />
          </TouchableOpacity>
          <View style={styles.logoContainer}>
            <Ionicons name="storefront-outline" size={22} color="#4F46E5" />
            <Text style={styles.logo}>متجر <Text style={styles.logoAccent}>زِد</Text></Text>
          </View>
        </View>
        <TouchableOpacity style={styles.cartButton} onPress={() => setShowCart(true)}>
          <Ionicons name="cart-outline" size={26} color="#1F2937" />
          {itemCount > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{itemCount > 99 ? '99+' : itemCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesContainer}>
          {categories.map((cat, idx) => (
            <TouchableOpacity key={cat || idx} style={[styles.catButton, selectedCategory === cat && styles.catActive]} onPress={() => setSelectedCategory(cat)}>
              <Text style={[styles.catText, selectedCategory === cat && styles.catTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.searchContainer}>
          <Ionicons name="search-outline" size={20} color="#9CA3AF" />
          <TextInput style={styles.searchInput} placeholder="ابحث عن منتج..." placeholderTextColor="#9CA3AF" value={searchText} onChangeText={setSearchText} />
          {searchText.length > 0 && (<TouchableOpacity onPress={() => setSearchText('')}><Ionicons name="close-circle" size={20} color="#9CA3AF" /></TouchableOpacity>)}
        </View>

        {settings?.banner_image && <Image source={{ uri: settings.banner_image }} style={styles.banner} resizeMode="cover" />}

        {featured.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>🔥 عروض خاصة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {featured.map(item => {
                const discount = getDiscountPercent(item);
                return (
                  <TouchableOpacity key={item.id} style={styles.featuredCard} onPress={() => navigation.navigate("ProductDetailsScreen", { product: item, providerName: "المتجر" })}>
                    <Image source={{ uri: item.image_url }} style={styles.featuredImage} />
                    {discount > 0 && <View style={styles.discountBadge}><Text style={styles.discountText}>%{discount}</Text></View>}
                    <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={styles.featuredOverlay}>
                      <Text style={styles.featuredName}>{item.name}</Text>
                      <View style={styles.featuredPriceRow}><Text style={styles.featuredPrice}>{item.price} ج</Text>{item.original_price > item.price && <Text style={styles.featuredOldPrice}>{item.original_price} ج</Text>}</View>
                    </LinearGradient>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🛍️ المنتجات المتوفرة</Text>
          {filteredProducts.length === 0 ? (
            <View style={{ padding: 20, alignItems: 'center' }}><Ionicons name="cube-outline" size={50} color="#D1D5DB" /><Text style={{ fontSize: 16, color: '#6B7280', marginTop: 10, textAlign: 'center' }}>لا توجد منتجات متاحة{'\n'}<Text style={{ fontSize: 12, color: '#9CA3AF' }}>سيتم إضافة المنتجات قريباً</Text></Text></View>
          ) : (
            <View style={styles.grid}>
              {filteredProducts.map((item) => {
                const discount = getDiscountPercent(item);
                return (
                  <View key={item.id} style={styles.productCard}>
                    <TouchableOpacity onPress={() => navigation.navigate("ProductDetailsScreen", { product: item, providerName: "المتجر" })}>
                      {item.image_url ? (<View><Image source={{ uri: item.image_url }} style={styles.productImage} />{discount > 0 && <View style={styles.productDiscountBadge}><Text style={styles.productDiscountText}>%{discount}</Text></View>}</View>) : <View style={styles.productPlaceholder}><Ionicons name="cube-outline" size={40} color="#D1D5DB" /></View>}
                    </TouchableOpacity>
                    <View style={styles.productInfo}><Text style={styles.productName} numberOfLines={2}>{item.name}</Text><View style={styles.productPriceRow}><Text style={styles.productPrice}>{item.price} ج</Text>{item.original_price > item.price && <Text style={styles.productOldPrice}>{item.original_price} ج</Text>}</View></View>
                    <TouchableOpacity style={styles.addToCartButton} onPress={() => addToCart({ ...item, quantity: 1, isUnified: false })}><Ionicons name="cart" size={16} color="#FFF" /><Text style={styles.addToCartText}>أضف للسلة</Text></TouchableOpacity>
                  </View>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>

      <Modal visible={showCart} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.cartModal}><View style={styles.cartHeader}><Text style={styles.cartTitle}>🛒 سلة المشتريات</Text><TouchableOpacity onPress={() => setShowCart(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          {cartItems.length === 0 ? <Text style={styles.emptyCart}>السلة فارغة</Text> :
            <>{cartItems.map(item => (<View key={item.id} style={styles.cartItem}><Text style={styles.cartItemName} numberOfLines={1}>{item.name}</Text><View style={styles.cartItemQty}><TouchableOpacity onPress={() => updateQuantity(item.id, -1)}><Ionicons name="remove-circle" size={24} color="#EF4444" /></TouchableOpacity><Text style={styles.cartQtyText}>{item.quantity || 1}</Text><TouchableOpacity onPress={() => updateQuantity(item.id, 1)}><Ionicons name="add-circle" size={24} color="#10B981" /></TouchableOpacity></View><Text style={styles.cartItemPrice}>{item.price * (item.quantity || 1)} ج</Text></View>))}
              <View style={styles.cartTotal}><Text style={styles.cartTotalLabel}>الإجمالي:</Text><Text style={styles.cartTotalPrice}>{cartTotal} ج</Text></View>
              <Text style={styles.shippingText}>الشحن: {shipping === 0 ? 'مجاني  🎉' : shipping + ' ج'}</Text>
              <TouchableOpacity style={styles.checkoutBtn} onPress={() => { setShowCart(false); setShowCheckout(true); }}><Text style={styles.checkoutText}>إتمام الطلب</Text></TouchableOpacity></>}
        </View></View>
      </Modal>

      <Modal visible={showCheckout} transparent animationType="slide">
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalOverlay}>
          <View style={styles.checkoutModal}>
            <View style={styles.cartHeader}><Text style={styles.cartTitle}>📝 بيانات الطلب</Text><TouchableOpacity onPress={() => setShowCheckout(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              {!isLoggedIn && <><TextInput style={styles.input} placeholder="الاسم *" value={name} onChangeText={setName} /><TextInput style={styles.input} placeholder="رقم الهاتف *" value={phone} onChangeText={setPhone} keyboardType="phone-pad" /></>}
              <TextInput style={styles.input} placeholder="العنوان *" value={address} onChangeText={setAddress} />
              <TextInput style={[styles.input, { minHeight: 60 }]} placeholder="ملاحظات (اختياري)" value={notes} onChangeText={setNotes} multiline />
              <Text style={styles.orderSummary}>إجمالي الطلب: {cartTotal} ج + شحن {shipping} ج = {cartTotal + shipping} ج</Text>
              <TouchableOpacity style={[styles.checkoutBtn, sending && styles.disabled]} onPress={sendOrder} disabled={sending}>
                {sending ? <ActivityIndicator color="#FFF" /> : <Text style={styles.checkoutText}>إرسال الطلب</Text>}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <Modal visible={!!selectedImage} transparent animationType="fade"><View style={styles.imageModal}><TouchableOpacity style={styles.imageClose} onPress={() => setSelectedImage(null)}><Ionicons name="close" size={34} color="#FFF" /></TouchableOpacity>{selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImage} resizeMode="contain" />}</View></Modal>

      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.successModalOverlay}><View style={styles.successModalContent}>
          <View style={styles.successIcon}><Ionicons name="checkmark-circle" size={60} color="#10B981" /></View>
          <Text style={styles.successTitle}>✅ تم استلام طلبك!</Text>
          <View style={styles.successDivider} />
          <Text style={styles.successText}>رقم الطلب: <Text style={styles.successOrderId}>#{lastOrderId?.slice(-6) || '......'}</Text></Text>
          <Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text>
          <TouchableOpacity style={styles.successRegisterBtn} onPress={handleRegister} activeOpacity={0.8}><Ionicons name="person-add" size={20} color="#FFF" /><Text style={styles.successRegisterText}>حفظ بياناتي واستكمال التسجيل</Text></TouchableOpacity>
          <TouchableOpacity style={styles.successLaterBtn} onPress={() => setShowSuccessModal(false)}><Text style={styles.successLaterText}>لاحقاً</Text></TouchableOpacity>
        </View></View>
      </Modal>

      <Mongez screen="eshop" navigation={navigation} contextData={{ products: products.map(p => ({ id: p.id, name: p.name, price: p.price, category: p.category, image_url: p.image_url })), cartCount: itemCount }} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  menuButton: { padding: 4 },
  logoContainer: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  logo: { fontSize: 22, fontWeight: '800', color: '#1F2937' },
  logoAccent: { color: '#4F46E5' },
  cartButton: { position: 'relative', padding: 4 },
  cartBadge: { position: 'absolute', top: -6, right: -6, backgroundColor: '#EF4444', minWidth: 20, height: 20, borderRadius: 10, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 4 },
  cartBadgeText: { color: '#FFF', fontSize: 11, fontWeight: '700' },
  categoriesContainer: { paddingVertical: 12, paddingHorizontal: 16, backgroundColor: '#FFF' },
  catButton: { paddingHorizontal: 18, paddingVertical: 8, borderRadius: 30, backgroundColor: '#F1F5F9', marginRight: 8, borderWidth: 1, borderColor: 'transparent' },
  catActive: { backgroundColor: '#EFF6FF', borderColor: '#4F46E5' },
  catText: { fontSize: 14, color: '#64748B', fontWeight: '600' },
  catTextActive: { color: '#4F46E5', fontWeight: '700' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', marginHorizontal: 16, marginTop: 12, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: '#E5E7EB', gap: 8 },
  searchInput: { flex: 1, fontSize: 15, color: '#1F2937', paddingVertical: 4 },
  banner: { width: '100%', height: 180, marginVertical: 8 },
  section: { paddingHorizontal: 20, marginBottom: 24 },
  sectionTitle: { fontSize: 19, fontWeight: '700', color: '#1F2937', marginBottom: 14 },
  featuredCard: { width: 200, height: 150, borderRadius: 20, overflow: 'hidden', marginRight: 16 },
  featuredImage: { width: '100%', height: '100%' },
  discountBadge: { position: 'absolute', top: 10, left: 10, backgroundColor: '#EF4444', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4, zIndex: 2 },
  discountText: { color: '#FFF', fontSize: 13, fontWeight: '800' },
  productDiscountBadge: { position: 'absolute', top: 8, left: 8, backgroundColor: '#EF4444', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 3 },
  productDiscountText: { color: '#FFF', fontSize: 11, fontWeight: '800' },
  featuredOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'flex-end', padding: 14 },
  featuredName: { fontSize: 16, fontWeight: '700', color: '#FFF' },
  featuredPriceRow: { flexDirection: 'row', gap: 8 },
  featuredPrice: { fontSize: 18, fontWeight: '800', color: '#FCD34D' },
  featuredOldPrice: { fontSize: 13, color: '#CBD5E1', textDecorationLine: 'line-through' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  productCard: { width: CARD_WIDTH, backgroundColor: '#FFF', borderRadius: 20, marginBottom: 20, overflow: 'hidden', borderWidth: 1, borderColor: '#F1F5F9', elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 10 },
  productImage: { width: '100%', height: 150, resizeMode: 'cover' },
  productPlaceholder: { width: '100%', height: 150, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center' },
  productInfo: { padding: 10, paddingBottom: 50 },
  productName: { fontSize: 14, fontWeight: '600', color: '#1F2937', marginBottom: 6, lineHeight: 18 },
  productPriceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 6 },
  productPrice: { fontSize: 16, fontWeight: '700', color: '#4F46E5' },
  productOldPrice: { fontSize: 12, color: '#94A3B8', textDecorationLine: 'line-through' },
  addToCartButton: { position: 'absolute', bottom: 8, left: 8, right: 8, backgroundColor: '#4F46E5', borderRadius: 20, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, elevation: 5, shadowColor: '#4F46E5', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 6 },
  addToCartText: { color: '#FFF', fontWeight: '700', fontSize: 13 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  cartModal: { backgroundColor: '#FFF', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '70%' },
  cartHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  cartTitle: { fontSize: 18, fontWeight: '700' },
  emptyCart: { textAlign: 'center', color: '#9CA3AF', padding: 20 },
  cartItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  cartItemName: { flex: 2, fontSize: 14 },
  cartItemQty: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  cartQtyText: { fontSize: 16, fontWeight: '600' },
  cartItemPrice: { flex: 1, textAlign: 'right', fontWeight: '600', fontSize: 14, color: '#F59E0B' },
  cartTotal: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderTopWidth: 2, borderTopColor: '#F3F4F6', marginTop: 8 },
  cartTotalLabel: { fontSize: 16, fontWeight: '600' },
  cartTotalPrice: { fontSize: 20, fontWeight: '800', color: '#F59E0B' },
  shippingText: { textAlign: 'right', color: '#10B981', fontSize: 12, marginBottom: 12 },
  checkoutBtn: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center' },
  checkoutText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  disabled: { opacity: 0.6 },
  checkoutModal: { backgroundColor: '#FFF', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '80%' },
  input: { backgroundColor: '#F9FAFB', borderRadius: 10, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB', fontSize: 15 },
  orderSummary: { textAlign: 'center', fontSize: 16, fontWeight: '600', paddingVertical: 12, color: '#1F2937' },
  imageModal: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center', alignItems: 'center' },
  imageClose: { position: 'absolute', top: 60, right: 20, zIndex: 10 },
  fullImage: { width: '100%', height: '80%' },
  maintenanceTitle: { fontSize: 32, fontWeight: '800', color: '#F59E0B', marginTop: 20 },
  maintenanceText: { fontSize: 16, color: '#64748B', textAlign: 'center', marginTop: 12 },
  successModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModalContent: { backgroundColor: '#FFF', borderRadius: 24, padding: 28, alignItems: 'center', width: '88%', elevation: 10 },
  successIcon: { marginBottom: 12 },
  successTitle: { fontSize: 20, fontWeight: '800', color: '#1F2937', marginTop: 8 },
  successDivider: { height: 1, width: 40, backgroundColor: '#E5E7EB', marginVertical: 14 },
  successText: { fontSize: 14, color: '#4B5563' },
  successOrderId: { fontWeight: '700', color: '#4F46E5', fontSize: 16 },
  successSubtext: { fontSize: 13, color: '#6B7280', marginTop: 14, textAlign: 'center', lineHeight: 20 },
  successRegisterBtn: { flexDirection: 'row', backgroundColor: '#4F46E5', padding: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 20, gap: 8 },
  successRegisterText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  successLaterBtn: { marginTop: 12, padding: 8 },
  successLaterText: { color: '#9CA3AF', fontSize: 14 },
});
