import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';
import { fontFamily } from '../utils/fonts';

export default function ServiceProviderScreen({ navigation }) {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    if (!phone || !password) {
      Alert.alert('تنبيه', 'أدخل رقم الهاتف وكلمة المرور');
      return;
    }

    setLoading(true);
    try {
      const { data: users, error } = await supabase
        .from(TABLES.PROFILES)
        .select('*')
        .eq('phone', phone)
        .limit(1);

      if (error) throw error;

      if (!users || users.length === 0) {
        Alert.alert('خطأ', 'رقم الهاتف أو كلمة المرور غير صحيحة');
        setLoading(false);
        return;
      }

      const user = users[0];

      if (user.password !== password) {
        Alert.alert('خطأ', 'رقم الهاتف أو كلمة المرور غير صحيحة');
        setLoading(false);
        return;
      }

      if (!user.active) {
        Alert.alert('خطأ', 'هذا الحساب غير نشط. تواصل مع الإدارة');
        setLoading(false);
        return;
      }

      const userDataToStore = {
        id: user.id,
        $id: user.id,
        full_name: user.full_name,
        name: user.full_name,
        phone: user.phone,
        role: user.role,
        merchantType: user.merchant_type,
        bio: user.bio,
        portfolio_images: user.portfolio_images,
        bio_approved: user.bio_approved,
        portfolio_approved: user.portfolio_approved,
        image_url: user.image_url,
      };

      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await AsyncStorage.setItem('userRole', user.role);
      await AsyncStorage.setItem('userPhone', phone);

      Alert.alert('مرحباً', `تم تسجيل الدخول بنجاح`);

      if (user.role === 'merchant') {
        navigation.replace('MerchantDashboard');
      } else if (user.role === 'driver') {
        navigation.replace('DriverDashboard');
      } else {
        navigation.replace('MainTabs');
      }

    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('خطأ', 'حدث خطأ في الاتصال');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-forward" size={28} color="#1F2937" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>دخول مقدمي الخدمة</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Ionicons name="call-outline" size={20} color="#9CA3AF" />
            <TextInput
              style={styles.input}
              placeholder="رقم الهاتف"
              placeholderTextColor="#9CA3AF"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              editable={!loading}
            />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color="#9CA3AF" />
            <TextInput
              style={[styles.input, { flex: 1 }]}
              placeholder="كلمة المرور"
              placeholderTextColor="#9CA3AF"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              editable={!loading}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
              <Ionicons
                name={showPassword ? "eye-off-outline" : "eye-outline"}
                size={20}
                color="#9CA3AF"
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.loginButton}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text style={[styles.loginButtonText, { fontFamily: fontFamily.arabic }]}>دخول</Text>
            )}
          </TouchableOpacity>

          <View style={styles.registerContainer}>
            <Text style={[styles.registerText, { fontFamily: fontFamily.arabic }]}>ليس لديك حساب؟</Text>
            <TouchableOpacity
              style={styles.registerButton}
              onPress={() => navigation.navigate('MerchantRegister')}
            >
              <Text style={[styles.registerButtonText, { fontFamily: fontFamily.arabic }]}>تسجيل حساب جديد</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  form: { backgroundColor: '#FFF', borderRadius: 12, padding: 20 },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    paddingHorizontal: 12,
    marginBottom: 16,
    height: 50,
    gap: 8,
  },
  input: { flex: 1, fontSize: 14, color: '#1F2937' },
  loginButton: { backgroundColor: '#4F46E5', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  loginButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  registerContainer: { alignItems: 'center', marginTop: 20 },
  registerText: { fontSize: 14, color: '#6B7280', marginBottom: 10 },
  registerButton: { backgroundColor: '#F3F4F6', padding: 12, borderRadius: 8, width: '100%', alignItems: 'center' },
  registerButtonText: { color: '#4F46E5', fontSize: 14, fontWeight: '600' },
});
