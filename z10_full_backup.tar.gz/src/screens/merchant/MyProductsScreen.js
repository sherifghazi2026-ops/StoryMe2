import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, ActivityIndicator, Alert, Modal, TextInput, Switch, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { getMerchantProducts, deleteProduct } from '../../services/productService';
import { uploadToImageKit } from '../../services/uploadService';

export default function MyProductsScreen({ navigation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [merchantId, setMerchantId] = useState(null);
  const [merchantServiceType, setMerchantServiceType] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);
  const [editPrice, setEditPrice] = useState('');
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editImageUrl, setEditImageUrl] = useState('');
  const [editCategoryId, setEditCategoryId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState([]);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);

  useEffect(() => { loadUserAndProducts(); }, []);

  const loadUserAndProducts = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (!userData) { setLoading(false); return; }
      const user = JSON.parse(userData);
      const { data: merchants } = await supabase.from('merchants').select('id, service_type').eq('user_id', user.id).limit(1);
      if (!merchants || merchants.length === 0) { setProducts([]); setLoading(false); return; }
      setMerchantId(merchants[0].id);
      setMerchantServiceType(merchants[0].service_type);
      await loadCategories(merchants[0].service_type);
      await loadProducts(merchants[0].id);
    } catch (e) { setLoading(false); }
  };

  const loadCategories = async (service) => {
    const { data } = await supabase
      .from('product_categories')
      .select('*')
      .eq('service_id', service)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    setCategories(data || []);
  };

  const loadProducts = async (mId) => {
    let all = [];
    const { data: prices } = await supabase.from('merchant_product_prices').select('template_product_id, price, is_available').eq('merchant_id', mId);
    if (prices && prices.length > 0) {
      const ids = prices.map(p => p.template_product_id);
      const { data: templates } = await supabase.from('template_products').select('*').in('id', ids);
      if (templates) {
        templates.forEach(t => {
          const p = prices.find(x => x.template_product_id === t.id);
          all.push({ ...t, price: p?.price || 0, is_unified: true, status: 'approved', is_available: p?.is_available !== false });
        });
      }
    }
    if (mId) {
      const { data: merchant } = await supabase.from('merchants').select('user_id').eq('id', mId).limit(1).single();
      if (merchant?.user_id) {
        const { data: ownProducts } = await supabase.from('products').select('*').eq('merchant_id', merchant.user_id).order('created_at', { ascending: false });
        if (ownProducts) {
          all = [...all, ...ownProducts.map(p => ({ ...p, is_unified: false, is_available: p.is_available !== false }))];
        }
      }
    }
    setProducts(all);
    setLoading(false);
  };

  const toggleAvailability = async (product) => {
    const newValue = !product.is_available;
    if (product.is_unified) {
      await supabase.from('merchant_product_prices').update({ is_available: newValue }).eq('merchant_id', merchantId).eq('template_product_id', product.id);
    } else {
      await supabase.from('products').update({ is_available: newValue }).eq('id', product.id);
    }
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, is_available: newValue } : p));
  };

  const handleDelete = (product) => {
    Alert.alert('حذف', 'حذف "' + product.name + '"؟', [
      { text: 'إلغاء' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
        if (product.is_unified) {
          await supabase.from('merchant_product_prices').delete().eq('merchant_id', merchantId).eq('template_product_id', product.id);
        } else {
          await deleteProduct(product.id);
        }
        loadProducts(merchantId);
      }},
    ]);
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setEditPrice(String(product.price || ''));
    setEditName(product.name || '');
    setEditDescription(product.description || '');
    setEditImageUrl(product.image_url || '');
    setEditCategoryId(product.category_id || null);
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const uploadRes = await uploadToImageKit(result.assets[0].uri, 'product_' + Date.now() + '.jpg', 'products');
      setUploading(false);
      if (uploadRes.success) setEditImageUrl(uploadRes.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSaveEdit = async () => {
    if (!editPrice.trim() || isNaN(parseFloat(editPrice))) {
      Alert.alert('تنبيه', 'يرجى إدخال سعر صحيح');
      return;
    }
    setSaving(true);
    try {
      if (editingProduct.is_unified) {
        await supabase.from('merchant_product_prices').upsert({
          merchant_id: merchantId,
          template_product_id: editingProduct.id,
          price: parseFloat(editPrice),
        }, { onConflict: 'merchant_id,template_product_id' });
      } else {
        await supabase.from('products').update({
          name: editName.trim(),
          description: editDescription.trim(),
          price: parseFloat(editPrice),
          image_url: editImageUrl,
          category_id: editCategoryId,
          updated_at: new Date().toISOString(),
        }).eq('id', editingProduct.id);
      }
      Alert.alert('✅ تم', 'تم حفظ التعديلات');
      setEditingProduct(null);
      loadProducts(merchantId);
    } catch (e) { Alert.alert('خطأ', e.message); }
    finally { setSaving(false); }
  };

  const getBadge = (s) => {
    switch(s) {
      case 'pending': return { t: 'قيد المراجعة', c: '#F59E0B', b: '#FEF3C7' };
      case 'approved': return { t: 'مقبول', c: '#10B981', b: '#D1FAE5' };
      case 'rejected': return { t: 'مرفوض', c: '#EF4444', b: '#FEE2E2' };
      default: return { t: s || 'مقبول', c: '#6B7280', b: '#F3F4F6' };
    }
  };

  if (loading) return <View style={styles.c}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.s}>
      <View style={styles.h}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.ht}>منتجاتي</Text>
        <TouchableOpacity onPress={() => navigation.navigate('AddProductScreen')}><Ionicons name="add-circle" size={28} color="#4F46E5" /></TouchableOpacity>
      </View>
      <FlatList
        data={products}
        keyExtractor={i => i.id}
        contentContainerStyle={styles.l}
        renderItem={({ item }) => {
          const b = getBadge(item.status);
          return (
            <View style={[styles.pc, !item.is_available && { opacity: 0.5 }]}>
              {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.pi} /> : <View style={[styles.pi, styles.pp]}><Ionicons name="image-outline" size={24} color="#9CA3AF" /></View>}
              <View style={styles.pn}>
                <Text style={styles.pname}>{item.name}</Text>
                <Text style={styles.ppr}>{item.price} ج</Text>
                <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
                  <View style={[styles.sb, { backgroundColor: b.b }]}><Text style={[styles.st, { color: b.c }]}>{b.t}</Text></View>
                  {item.is_unified && <Text style={styles.unifiedBadge}>📦 منتج موحد</Text>}
                  {!item.is_available && <Text style={styles.hiddenBadge}>مخفي</Text>}
                </View>
              </View>
              <View style={styles.actions}>
                <Switch
                  value={item.is_available}
                  onValueChange={() => toggleAvailability(item)}
                  trackColor={{ false: '#E5E7EB', true: '#10B981' }}
                  thumbColor={item.is_available ? '#FFF' : '#9CA3AF'}
                  style={{ transform: [{ scaleX: 0.7 }, { scaleY: 0.7 }] }}
                />
                <TouchableOpacity onPress={() => handleEdit(item)} style={styles.editBtn}>
                  <Ionicons name="pencil" size={20} color="#4F46E5" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDelete(item)}>
                  <Ionicons name="trash-outline" size={24} color="#EF4444" />
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.ec}>
            <Ionicons name="cube-outline" size={80} color="#E5E7EB" />
            <Text style={styles.et}>لا توجد منتجات</Text>
            <TouchableOpacity style={styles.ab} onPress={() => navigation.navigate('AddProductScreen')}><Text style={styles.abt}>إضافة منتج جديد</Text></TouchableOpacity>
          </View>
        }
      />

      {/* Modal التعديل */}
      <Modal visible={!!editingProduct} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>تعديل المنتج</Text>
              <TouchableOpacity onPress={() => setEditingProduct(null)}>
                <Ionicons name="close" size={24} color="#EF4444" />
              </TouchableOpacity>
            </View>
            <ScrollView style={{ maxHeight: 500 }} showsVerticalScrollIndicator={true}>
              {editingProduct?.is_unified && (
                <View style={styles.unifiedNotice}>
                  <Ionicons name="information-circle" size={20} color="#2563EB" />
                  <Text style={styles.unifiedNoticeText}>هذا منتج موحد. يمكنك تعديل السعر فقط.</Text>
                </View>
              )}
              {!editingProduct?.is_unified && (
                <>
                  <Text style={styles.label}>اسم المنتج</Text>
                  <TextInput style={styles.input} value={editName} onChangeText={setEditName} />
                  <Text style={styles.label}>الوصف</Text>
                  <TextInput style={styles.input} value={editDescription} onChangeText={setEditDescription} />
                  <Text style={styles.label}>صورة المنتج</Text>
                  <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
                    {uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : editImageUrl ? <Image source={{ uri: editImageUrl }} style={styles.imagePreview} /> : <View style={styles.imagePlaceholder}><Ionicons name="camera" size={30} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 12 }}>تغيير الصورة</Text></View>}
                  </TouchableOpacity>
                  {editImageUrl && !uploading && (
                    <TouchableOpacity onPress={() => setEditImageUrl('')} style={styles.removeImageBtn}><Ionicons name="trash-outline" size={16} color="#EF4444" /><Text style={styles.removeImageText}>إزالة الصورة</Text></TouchableOpacity>
                  )}

                  {/* ✅ اختيار الفئة */}
                  <Text style={styles.label}>الفئة</Text>
                  <TouchableOpacity style={styles.categorySelector} onPress={() => setShowCategoryPicker(true)}>
                    <Ionicons name="folder-outline" size={18} color="#8B5CF6" />
                    <Text style={styles.categorySelectorText}>
                      {editCategoryId ? categories.find(c => c.id === editCategoryId)?.name || 'غير معروف' : 'بدون فئة'}
                    </Text>
                    <Ionicons name="chevron-down" size={18} color="#9CA3AF" />
                  </TouchableOpacity>
                </>
              )}
              <Text style={styles.label}>السعر (ج)</Text>
              <TextInput style={styles.input} value={editPrice} onChangeText={setEditPrice} keyboardType="numeric" />
            </ScrollView>
            <TouchableOpacity style={[styles.saveBtn, saving && styles.disabled]} onPress={handleSaveEdit} disabled={saving}>
              {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>حفظ التعديلات</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal اختيار الفئة */}
      <Modal visible={showCategoryPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.pickerContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>اختر الفئة</Text>
              <TouchableOpacity onPress={() => setShowCategoryPicker(false)}>
                <Ionicons name="close" size={24} color="#EF4444" />
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.pickerItem} onPress={() => { setEditCategoryId(null); setShowCategoryPicker(false); }}>
              <Text style={[styles.pickerItemText, !editCategoryId && { color: '#8B5CF6', fontWeight: '700' }]}>بدون فئة</Text>
            </TouchableOpacity>
            {categories.map(cat => (
              <TouchableOpacity key={cat.id} style={styles.pickerItem} onPress={() => { setEditCategoryId(cat.id); setShowCategoryPicker(false); }}>
                <Ionicons name={cat.icon || 'cube'} size={20} color="#8B5CF6" />
                <Text style={styles.pickerItemText}>{cat.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  s: { flex: 1, backgroundColor: '#F9FAFB' },
  c: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  h: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  ht: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  l: { padding: 16 },
  pc: { flexDirection: 'row', backgroundColor: '#FFF', borderRadius: 12, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB', alignItems: 'center' },
  pi: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  pp: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  pn: { flex: 1 },
  pname: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  ppr: { fontSize: 14, color: '#F59E0B', fontWeight: '600', marginTop: 2 },
  sb: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12 },
  st: { fontSize: 10, fontWeight: '600' },
  unifiedBadge: { fontSize: 10, color: '#8B5CF6', alignSelf: 'flex-start' },
  hiddenBadge: { fontSize: 10, color: '#EF4444', backgroundColor: '#FEE2E2', paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8, alignSelf: 'flex-start' },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  editBtn: { padding: 4 },
  ec: { alignItems: 'center', padding: 40 },
  et: { fontSize: 16, color: '#6B7280', marginBottom: 20 },
  ab: { backgroundColor: '#4F46E5', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 8 },
  abt: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '85%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  unifiedNotice: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EFF6FF', padding: 12, borderRadius: 8, marginBottom: 16, gap: 8 },
  unifiedNoticeText: { fontSize: 13, color: '#2563EB', flex: 1 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginTop: 12 },
  input: { backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, marginTop: 6, borderWidth: 1, borderColor: '#E5E7EB', fontSize: 15 },
  imagePicker: { height: 120, backgroundColor: '#F3F4F6', borderRadius: 8, marginTop: 6, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  imagePreview: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  removeImageBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-end', marginTop: 6, gap: 4 },
  removeImageText: { fontSize: 12, color: '#EF4444' },
  categorySelector: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, marginTop: 6, borderWidth: 1, borderColor: '#E5E7EB', gap: 10 },
  categorySelectorText: { flex: 1, fontSize: 14, color: '#1F2937' },
  pickerContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '60%' },
  pickerItem: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#F3F4F6', gap: 10 },
  pickerItemText: { fontSize: 15, color: '#1F2937' },
  saveBtn: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, marginTop: 20, alignItems: 'center' },
  disabled: { opacity: 0.6 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
