import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView,
  ActivityIndicator, Alert, Modal, TextInput, Image, FlatList, Linking,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

export default function EditMerchantScreen({ navigation, route }) {
  const { merchant } = route.params;

  const [deliveryFee, setDeliveryFee] = useState('');
  const [deliveryTime, setDeliveryTime] = useState('');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [placeName, setPlaceName] = useState('');
  const [hasDriver, setHasDriver] = useState(false); // ✅ تفعيل المندوب
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadType, setUploadType] = useState('');

  const [imageUrl, setImageUrl] = useState('');
  const [imagePending, setImagePending] = useState('');
  const [imageApproved, setImageApproved] = useState(true);

  const [bio, setBio] = useState('');
  const [bioApproved, setBioApproved] = useState(true);

  useEffect(() => {
    if (merchant) {
      setName(merchant.name || '');
      setPhone(merchant.phone || '');
      setPlaceName(merchant.place_name || merchant.placeName || '');
      setDeliveryFee(String(merchant.delivery_fee || merchant.deliveryFee || '0'));
      setDeliveryTime(String(merchant.delivery_time || merchant.deliveryTime || '30'));
      setHasDriver(merchant.has_driver || false); // ✅ تحميل حالة المندوب
      setImageUrl(merchant.image_url || '');
      setBio(merchant.bio || '');
    }
  }, [merchant]);

  const handleSave = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.from('merchants').update({
        name: name.trim(),
        phone: phone.trim(),
        place_name: placeName.trim(),
        delivery_fee: parseFloat(deliveryFee) || 0,
        delivery_time: parseInt(deliveryTime) || 30,
        has_driver: hasDriver, // ✅ حفظ حالة المندوب
        bio: bio.trim(),
        updated_at: new Date().toISOString(),
      }).eq('id', merchant.id);

      if (error) throw error;
      Alert.alert('✅ تم', 'تم حفظ الإعدادات بنجاح');
      navigation.goBack();
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={28} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إعدادات المتجر</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.label}>اسم المتجر</Text>
        <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="اسم المتجر" />

        <Text style={styles.label}>رقم الهاتف</Text>
        <TextInput style={styles.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="رقم الهاتف" />

        <Text style={styles.label}>اسم المكان</Text>
        <TextInput style={styles.input} value={placeName} onChangeText={setPlaceName} placeholder="اسم المكان" />

        <Text style={styles.label}>رسوم التوصيل (ج)</Text>
        <TextInput style={styles.input} value={deliveryFee} onChangeText={setDeliveryFee} keyboardType="numeric" placeholder="0" />

        <Text style={styles.label}>وقت التوصيل (دقائق)</Text>
        <TextInput style={styles.input} value={deliveryTime} onChangeText={setDeliveryTime} keyboardType="numeric" placeholder="30" />

        {/* ✅ Toggle تفعيل المندوب */}
        <View style={styles.switchRow}>
          <Text style={styles.label}>تفعيل المندوب</Text>
          <TouchableOpacity 
            style={[styles.toggleSwitch, hasDriver && styles.toggleSwitchActive]} 
            onPress={() => setHasDriver(!hasDriver)}
            activeOpacity={0.8}
          >
            <View style={[styles.toggleKnob, hasDriver && styles.toggleKnobActive]} />
          </TouchableOpacity>
        </View>
        <Text style={styles.hint}>عند التفعيل، سيظهر خيار اختيار مندوب أو توصيل بنفسي</Text>

        <Text style={styles.label}>النبذة التعريفية</Text>
        <TextInput style={styles.textArea} value={bio} onChangeText={setBio} placeholder="اكتب نبذة عن متجرك..." multiline numberOfLines={4} />

        <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={loading}>
          {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16, paddingBottom: 40 },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 6, marginTop: 16 },
  input: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, padding: 12, fontSize: 14, color: '#1F2937' },
  textArea: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, padding: 12, fontSize: 14, color: '#1F2937', minHeight: 100, textAlignVertical: 'top' },
  hint: { fontSize: 11, color: '#9CA3AF', marginTop: 4 },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 },
  toggleSwitch: { width: 50, height: 28, borderRadius: 14, backgroundColor: '#D1D5DB', padding: 2, justifyContent: 'center' },
  toggleSwitchActive: { backgroundColor: '#10B981' },
  toggleKnob: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFF' },
  toggleKnobActive: { marginLeft: 'auto' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 32 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});
