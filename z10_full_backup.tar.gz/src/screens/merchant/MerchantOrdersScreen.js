import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView, ActivityIndicator,
  RefreshControl, Image, ScrollView, Modal, Alert, TextInput,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  getMerchantOrders, updateOrderStatus,
  ORDER_STATUS, stopOrderNotificationSound
} from '../../services/orderService';
import { getAvailableDrivers } from '../../services/driverService';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';
import { stopNotificationSound } from '../../utils/SoundHelper';

export default function MerchantOrdersScreen({ navigation }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userData, setUserData] = useState(null);
  const [merchantData, setMerchantData] = useState(null);
  const [steps, setSteps] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showImageModal, setShowImageModal] = useState(false);
  const [activeTab, setActiveTab] = useState('pending');
  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [priceModal, setPriceModal] = useState(false);
  const [price, setPrice] = useState('');
  const [deliveryFee, setDeliveryFee] = useState('');
  const [deliveryModalVisible, setDeliveryModalVisible] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [drivers, setDrivers] = useState([]);
  const [loadingDrivers, setLoadingDrivers] = useState(false);

  useEffect(() => {
    loadUserData();
    stopNotificationSound(); // ✅ إيقاف الصوت عند الدخول للشاشة
  }, []);

  useEffect(() => {
    if (userData && merchantData) { loadOrders(); loadDrivers(); }
  }, [userData, merchantData]);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setUserData(user);
      const { data: merchant } = await supabase
        .from('merchants')
        .select('id, service_type, name, has_driver')
        .eq('user_id', user.id || user.$id)
        .single();
      if (merchant) {
        setMerchantData(merchant);
        await loadSteps(merchant.service_type);
      }
    }
    setLoading(false);
  };

  const loadSteps = async (serviceType) => {
    if (!serviceType) return;
    const { data } = await supabase
      .from('service_tracking_steps')
      .select('*')
      .eq('service_id', serviceType)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (data && data.length > 0) {
      setSteps(data.map(s => ({ ...s, sub: s.description || '' })));
    }
  };

  const loadOrders = async () => {
    if (!merchantData) return;
    const result = await getMerchantOrders(merchantData.id);
    if (result.success) {
      setOrders(result.data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
    }
    setRefreshing(false);
  };

  const loadDrivers = async () => {
    setLoadingDrivers(true);
    const result = await getAvailableDrivers();
    if (result.success) setDrivers(result.data);
    setLoadingDrivers(false);
  };

  const getFilteredOrders = () => {
    if (steps.length === 0) return orders;
    const allStepKeys = steps.map(s => s.step_key);
    const firstStep = allStepKeys[0];
    const lastStep = allStepKeys[allStepKeys.length - 1];
    const middleSteps = allStepKeys.slice(1, -1);
    if (activeTab === 'pending') return orders.filter(o => o.status === firstStep || o.status === ORDER_STATUS.PENDING);
    else if (activeTab === 'active') return orders.filter(o => middleSteps.includes(o.status));
    else return orders.filter(o => o.status === lastStep || o.status === ORDER_STATUS.CANCELLED);
  };

  const getNextStep = (orderStatus) => {
    const currentIdx = steps.findIndex(s => s.step_key === orderStatus);
    if (currentIdx >= 0 && currentIdx < steps.length - 1) return steps[currentIdx + 1];
    return null;
  };

  const handleNextStep = async (order) => {
    const nextStep = getNextStep(order.status);
    if (!nextStep) return;

    // ✅ لو التاجر مفعل المندوب والخطوة مندوب ← يظهر popup
    if (merchantData?.has_driver && nextStep?.label?.includes('مندوب')) {
      setSelectedOrder(order);
      await loadDrivers();
      setDeliveryModalVisible(true);
      return;
    }

    const result = await updateOrderStatus(order.id, nextStep.step_key);
    if (result.success) {
      await stopOrderNotificationSound();
      loadOrders();
      Alert.alert('✅ تم', `تم التحديث إلى "${nextStep.label}"`);
    } else Alert.alert('خطأ', result.error);
  };

  const openImage = (url) => { setSelectedImage(url); setShowImageModal(true); };

  const handleRejectOrder = async () => {
    if (!rejectReason.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال سبب الرفض'); return; }
    const result = await updateOrderStatus(selectedOrder.id, ORDER_STATUS.CANCELLED, { cancellation_reason: rejectReason });
    if (result.success) { await stopOrderNotificationSound(); setRejectModal(false); setRejectReason(''); loadOrders(); Alert.alert('تم', 'تم رفض الطلب'); }
    else Alert.alert('خطأ', result.error);
  };

  const handleSelfDelivery = async () => {
    const nextStep = getNextStep(selectedOrder.status);
    if (nextStep) {
      const result = await updateOrderStatus(selectedOrder.id, nextStep.step_key);
      if (result.success) { setDeliveryModalVisible(false); loadOrders(); Alert.alert('تم', 'تم بدء التوصيل'); }
      else Alert.alert('خطأ', result.error);
    }
  };

  const handleAssignDriver = async () => {
    if (!selectedDriver) { Alert.alert('تنبيه', 'الرجاء اختيار مندوب'); return; }
    const driverName = selectedDriver.name || selectedDriver.full_name || 'مندوب';
    const nextStep = getNextStep(selectedOrder.status);
    if (nextStep) {
      const result = await updateOrderStatus(selectedOrder.id, nextStep.step_key, { driver_id: selectedDriver.id, driver_name: driverName });
      if (result.success) { setDeliveryModalVisible(false); loadOrders(); Alert.alert('تم', 'تم تعيين المندوب ' + driverName); }
      else Alert.alert('خطأ', result.error);
    }
  };

  const getStatusColor = (status) => {
    const c = { [ORDER_STATUS.PENDING]: '#F59E0B', [ORDER_STATUS.ACCEPTED]: '#3B82F6', [ORDER_STATUS.PREPARING]: '#8B5CF6', [ORDER_STATUS.READY]: '#10B981', [ORDER_STATUS.DRIVER_ASSIGNED]: '#3B82F6', [ORDER_STATUS.ON_THE_WAY]: '#F59E0B', [ORDER_STATUS.DELIVERED]: '#10B981', [ORDER_STATUS.CANCELLED]: '#EF4444' };
    return c[status] || '#6B7280';
  };

  const getStatusText = (status) => {
    const step = steps.find(s => s.step_key === status);
    return step?.label || status;
  };

  const renderOrder = ({ item }) => {
    if (!item?.id) return null;
    const displayId = String(item.id).slice(-6);
    const nextStep = getNextStep(item.status);
    
    return (
      <View style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <View><Text style={styles.orderId}>طلب #{displayId}</Text><Text style={styles.orderTime}>{new Date(item.created_at).toLocaleString('ar-EG')}</Text></View>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}><Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{getStatusText(item.status)}</Text></View>
        </View>
        <View style={styles.customerInfo}>
          <View style={styles.infoRow}><Ionicons name="person-outline" size={16} color="#6B7280" /><Text style={styles.infoText}>{item.customer_name}</Text></View>
          <View style={styles.infoRow}><Ionicons name="call-outline" size={16} color="#6B7280" /><Text style={styles.infoText}>{item.customer_phone}</Text></View>
          <View style={styles.infoRow}><Ionicons name="location-outline" size={16} color="#6B7280" /><Text style={styles.infoText}>{item.customer_address}</Text></View>
        </View>
        {item.image_urls?.length > 0 && (
          <ScrollView horizontal style={styles.imagesContainer}>
            {item.image_urls.map((url, i) => (<TouchableOpacity key={i} onPress={() => openImage(url)}><Image source={{ uri: url }} style={styles.thumbnailImage} /></TouchableOpacity>))}
          </ScrollView>
        )}
        {item.items?.length > 0 && (
          <View style={styles.itemsContainer}><Text style={styles.itemsTitle}>المنتجات:</Text>{item.items.map((it,i)=>(<Text key={i} style={styles.itemText}>• {it}</Text>))}</View>
        )}
        <View style={styles.priceRow}><Text style={styles.priceLabel}>الإجمالي:</Text><Text style={styles.priceValue}>{item.final_total || item.total_price || 0} ج</Text></View>
        
        <View style={styles.actionsContainer}>
          {item.status === (steps[0]?.step_key || ORDER_STATUS.PENDING) && (<>
            <TouchableOpacity style={[styles.actionButton, styles.acceptButton]} onPress={() => handleNextStep(item)}>
              <Ionicons name="checkmark-circle" size={18} color="#FFF" />
              <Text style={styles.actionButtonText}>قبول</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionButton, styles.rejectButton]} onPress={() => { setSelectedOrder(item); setRejectModal(true); }}>
              <Ionicons name="close-circle" size={18} color="#FFF" />
              <Text style={styles.actionButtonText}>رفض</Text>
            </TouchableOpacity>
          </>)}
          {nextStep && item.status !== (steps[0]?.step_key || ORDER_STATUS.PENDING) && (
            <TouchableOpacity style={[styles.actionButton, { backgroundColor: getStatusColor(item.status) }]} onPress={() => handleNextStep(item)}>
              <Ionicons name="arrow-back-circle" size={18} color="#FFF" />
              <Text style={styles.actionButtonText}>{nextStep.label}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  const filteredOrders = getFilteredOrders();
  const allStepKeys = steps.map(s => s.step_key);
  const firstStep = allStepKeys[0] || ORDER_STATUS.PENDING;
  const lastStep = allStepKeys[allStepKeys.length - 1] || ORDER_STATUS.DELIVERED;
  const pendingCount = orders.filter(o => o.status === firstStep || o.status === ORDER_STATUS.PENDING).length;
  const activeCount = orders.filter(o => steps.length > 0 && allStepKeys.slice(1, -1).includes(o.status)).length;
  const completedCount = orders.filter(o => o.status === lastStep || o.status === ORDER_STATUS.CANCELLED).length;

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity><Text style={styles.headerTitle}>الطلبات</Text><TouchableOpacity onPress={loadOrders}><Ionicons name="refresh" size={24} color="#4F46E5" /></TouchableOpacity></View>
      <View style={styles.tabContainer}>
        <TouchableOpacity style={[styles.tab, activeTab==='pending'&&styles.activeTab]} onPress={()=>setActiveTab('pending')}><Text style={[styles.tabText, activeTab==='pending'&&styles.activeTabText]}>معلقة ({pendingCount})</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab==='active'&&styles.activeTab]} onPress={()=>setActiveTab('active')}><Text style={[styles.tabText, activeTab==='active'&&styles.activeTabText]}>نشطة ({activeCount})</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab==='completed'&&styles.activeTab]} onPress={()=>setActiveTab('completed')}><Text style={[styles.tabText, activeTab==='completed'&&styles.activeTabText]}>منتهية ({completedCount})</Text></TouchableOpacity>
      </View>
      <FlatList data={filteredOrders} renderItem={renderOrder} keyExtractor={item=>item?.id||Math.random().toString()} contentContainerStyle={styles.list} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadOrders} />} ListEmptyComponent={<View style={styles.emptyContainer}><Ionicons name="cart-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>{activeTab==='pending'?'لا توجد طلبات معلقة':activeTab==='active'?'لا توجد طلبات نشطة':'لا توجد طلبات منتهية'}</Text></View>} />
      <Modal visible={rejectModal} transparent animationType="fade"><View style={styles.modalOverlay}><View style={styles.modalContent}><Text style={styles.modalTitle}>سبب الرفض</Text><TextInput style={styles.modalInput} placeholder="أدخل سبب الرفض..." placeholderTextColor="#9CA3AF" value={rejectReason} onChangeText={setRejectReason} multiline numberOfLines={3} /><View style={styles.modalButtons}><TouchableOpacity style={[styles.modalButton,styles.cancelButton]} onPress={()=>{setRejectModal(false);setRejectReason('');}}><Text style={styles.cancelButtonText}>إلغاء</Text></TouchableOpacity><TouchableOpacity style={[styles.modalButton,styles.rejectConfirmButton]} onPress={handleRejectOrder}><Text style={styles.confirmButtonText}>تأكيد الرفض</Text></TouchableOpacity></View></View></View></Modal>
      <Modal visible={deliveryModalVisible} transparent animationType="slide"><View style={styles.modalOverlay}><View style={[styles.modalContent,{maxHeight:'80%'}]}><Text style={styles.modalTitle}>تحديد التوصيل</Text><TouchableOpacity style={styles.deliveryOption} onPress={handleSelfDelivery}><Ionicons name="car-outline" size={30} color="#4F46E5" /><View style={styles.deliveryOptionInfo}><Text style={styles.deliveryOptionTitle}>توصيل بنفسي</Text><Text style={styles.deliveryOptionSubtitle}>ستقوم بتوصيل الطلب بنفسك</Text></View><Ionicons name="chevron-forward" size={20} color="#9CA3AF" /></TouchableOpacity><View style={styles.divider} /><Text style={styles.deliverySectionTitle}>{loadingDrivers?'جاري تحميل المندوبين...':'اختر مندوب:'}</Text>{loadingDrivers?<ActivityIndicator style={styles.loader} color="#4F46E5" />:drivers.length===0?<View style={styles.noDriversContainer}><Ionicons name="alert-circle-outline" size={40} color="#F59E0B" /><Text style={styles.noDriversText}>لا يوجد مندوبين متاحين</Text></View>:<FlatList data={drivers} keyExtractor={item=>item.id} style={styles.driversList} renderItem={({item})=>(<TouchableOpacity style={[styles.driverItem,selectedDriver?.id===item.id&&styles.driverItemSelected]} onPress={()=>setSelectedDriver(item)}><Ionicons name="person-circle-outline" size={40} color="#4F46E5" /><View style={styles.driverInfo}><Text style={styles.driverName}>{item.name||item.full_name||'مندوب'}</Text><Text style={styles.driverPhone}>{item.phone||item.mobile||'رقم غير متوفر'}</Text></View>{selectedDriver?.id===item.id&&<Ionicons name="checkmark-circle" size={28} color="#10B981" />}</TouchableOpacity>)} />}<View style={styles.modalButtons}><TouchableOpacity style={[styles.modalButton,styles.cancelButton]} onPress={()=>setDeliveryModalVisible(false)}><Text style={styles.cancelButtonText}>إلغاء</Text></TouchableOpacity><TouchableOpacity style={[styles.modalButton,styles.confirmButton,!selectedDriver&&styles.disabledButton]} onPress={handleAssignDriver} disabled={!selectedDriver}><Text style={styles.confirmButtonText}>تعيين</Text></TouchableOpacity></View></View></View></Modal>
      <Modal visible={showImageModal} transparent animationType="fade"><View style={styles.imageModalOverlay}><TouchableOpacity style={styles.closeImageButton} onPress={()=>setShowImageModal(false)}><Ionicons name="close" size={30} color="#FFF" /></TouchableOpacity>{selectedImage&&<Image source={{uri:selectedImage}} style={styles.fullImage} resizeMode="contain" />}</View></Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  tabContainer: { flexDirection: 'row', backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  activeTab: { borderBottomWidth: 2, borderBottomColor: '#4F46E5' },
  tabText: { fontSize: 14, color: '#6B7280' },
  activeTabText: { color: '#4F46E5', fontWeight: '600' },
  list: { padding: 16 },
  orderCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  orderTime: { fontSize: 10, color: '#9CA3AF', marginTop: 2 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600' },
  customerInfo: { marginBottom: 12, gap: 4 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoText: { fontSize: 13, color: '#4B5563' },
  imagesContainer: { flexDirection: 'row', marginBottom: 12, gap: 8 },
  thumbnailImage: { width: 60, height: 60, borderRadius: 8, backgroundColor: '#F3F4F6' },
  itemsContainer: { marginBottom: 12 },
  itemsTitle: { fontSize: 12, fontWeight: '600', color: '#4B5563', marginBottom: 4 },
  itemText: { fontSize: 12, color: '#6B7280', marginBottom: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 8, borderTopWidth: 1, borderTopColor: '#F3F4F6', marginBottom: 8 },
  priceLabel: { fontSize: 14, color: '#4B5563' },
  priceValue: { fontSize: 16, fontWeight: 'bold', color: '#F59E0B' },
  actionsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 },
  actionButton: { flex: 1, minWidth: '30%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 8, borderRadius: 8, gap: 4 },
  acceptButton: { backgroundColor: '#10B981' },
  rejectButton: { backgroundColor: '#EF4444' },
  actionButtonText: { color: '#FFF', fontSize: 11, fontWeight: '600' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#9CA3AF' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 12, padding: 20, width: '90%', maxWidth: 400 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  modalInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 14, minHeight: 80, textAlignVertical: 'top', color: '#1F2937' },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-between', gap: 8, marginTop: 8 },
  modalButton: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#F3F4F6' },
  confirmButton: { backgroundColor: '#4F46E5' },
  rejectConfirmButton: { backgroundColor: '#EF4444' },
  disabledButton: { opacity: 0.5 },
  cancelButtonText: { color: '#374151', fontSize: 14, fontWeight: '600' },
  confirmButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 16 },
  deliveryOption: { flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: '#EEF2FF', borderRadius: 12, gap: 12 },
  deliveryOptionInfo: { flex: 1 },
  deliveryOptionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  deliveryOptionSubtitle: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  driversList: { maxHeight: 300 },
  driverItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6', gap: 12 },
  driverItemSelected: { backgroundColor: '#EEF2FF', borderRadius: 8 },
  driverInfo: { flex: 1 },
  driverName: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  driverPhone: { fontSize: 12, color: '#6B7280' },
  loader: { padding: 20 },
  noDriversContainer: { alignItems: 'center', padding: 20 },
  noDriversText: { fontSize: 14, fontWeight: '600', color: '#F59E0B', marginTop: 8 },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center', alignItems: 'center' },
  closeImageButton: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 10 },
  fullImage: { width: '100%', height: '80%', resizeMode: 'contain' },
});
