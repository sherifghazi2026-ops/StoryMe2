import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView, Alert, ActivityIndicator, Image, Modal, FlatList, StatusBar, BackHandler } from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { getMerchantOrders, ORDER_STATUS, registerUserToken } from '../../services/orderService';
import { getProviderReviews, getProviderAverageRating } from '../../services/reviewService';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import CustomDrawer from '../../components/CustomDrawer';
import { fontFamily } from '../../utils/fonts';
import { startNotificationSound, stopNotificationSound } from '../../utils/SoundHelper';

export default function MerchantDashboard({ navigation }) {
  const [userData, setUserData] = useState(null);
  const [merchantData, setMerchantData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [pendingOrders, setPendingOrders] = useState(0);
  const [acceptedOrders, setAcceptedOrders] = useState(0);
  const [reviews, setReviews] = useState([]);
  const [averageRating, setAverageRating] = useState(0);
  const [reviewsCount, setReviewsCount] = useState(0);
  const [showReviewsModal, setShowReviewsModal] = useState(false);
  const [merchantImage, setMerchantImage] = useState(null);
  const [deliveryFee, setDeliveryFee] = useState(10);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [serviceName, setServiceName] = useState('');

  useEffect(() => {
    const registerToken = async () => {
      try {
        const userDataStr = await AsyncStorage.getItem('userData');
        if (userDataStr) {
          const user = JSON.parse(userDataStr);
          const userId = user.id || user.$id;
          if (userId) {
            const { status } = await Notifications.requestPermissionsAsync();
            if (status === 'granted') {
              const token = await Notifications.getExpoPushTokenAsync({ projectId: '269d52f2-14ab-478f-8c83-3bda7816fe99' });
              await registerUserToken(userId, token.data);
            }
          }
        }
      } catch (error) {}
    };
    registerToken();
  }, []);

  useEffect(() => {
    const fetchMerchantData = async () => {
      if (!userData) return;
      const uid = userData.id || userData.$id;
      const { data: merchant } = await supabase.from('merchants').select('id, service_type').eq('user_id', uid).single();
      if (merchant) {
        setMerchantData(merchant);
        const { data: service } = await supabase.from('services').select('name').eq('id', merchant.service_type).single();
        if (service?.name) setServiceName(service.name);
      }
    };
    fetchMerchantData();
  }, [userData]);

  useEffect(() => { loadUserData(); }, []);

  useEffect(() => {
    if (userData && merchantData) {
      loadReviews(merchantData?.id);
      loadMerchantImage(getUserId());
      loadDeliveryFee(getUserId());
    }
  }, [userData, merchantData]);

  useEffect(() => {
    loadOrdersCount();
    const interval = setInterval(loadOrdersCount, 5000);
    return () => { stopNotificationSound(); clearInterval(interval); };
  }, [merchantData]);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true);
    return () => backHandler.remove();
  }, []);

  const getUserId = () => (userData?.id || userData?.$id) || null;

  const loadUserData = async () => {
    try { const data = await AsyncStorage.getItem('userData'); if (data) setUserData(JSON.parse(data)); }
    catch (error) {}
    setLoading(false);
  };

  const loadMerchantImage = async (userId) => {
    try { const { data } = await supabase.from(TABLES.PROFILES).select('image_url').eq('id', userId).single(); if (data) setMerchantImage(data.image_url); } catch (error) {}
  };

  const loadDeliveryFee = async (userId) => {
    try { const { data } = await supabase.from(TABLES.PROFILES).select('delivery_fee').eq('id', userId).single(); if (data) setDeliveryFee(data.delivery_fee); } catch (error) {}
  };

  const loadOrdersCount = async () => {
    if (!merchantData) return;
    const result = await getMerchantOrders(merchantData.id);
    if (result.success) {
      const pending = result.data.filter(o => o.status === 'pending').length;
      if (pending > 0) startNotificationSound();
      setPendingOrders(pending);
      setAcceptedOrders(result.data.filter(o => o.status === 'accepted').length);
    }
  };

  const loadReviews = async (providerId) => {
    if (!providerId) return;
    const result = await getProviderReviews(providerId);
    if (result.success) setReviews(result.data);
    const avgResult = await getProviderAverageRating(providerId);
    if (avgResult.success) { setAverageRating(avgResult.average); setReviewsCount(avgResult.count); }
  };

  const handleLogout = async () => {
    stopNotificationSound();
    Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'خروج', onPress: async () => { stopNotificationSound(); await AsyncStorage.removeItem('userData'); await AsyncStorage.removeItem('userRole'); navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] }); }}
    ]);
  };

  const renderStars = (rating) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) stars.push(<Ionicons key={i} name={i <= rating ? 'star' : 'star-outline'} size={16} color={i <= rating ? '#F59E0B' : '#D1D5DB'} />);
    return stars;
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuButton}><Ionicons name="menu" size={28} color="#1F2937" /></TouchableOpacity>
        <View style={styles.headerInfo}>
          <View style={styles.merchantImageContainer}>{merchantImage ? <Image source={{ uri: merchantImage }} style={styles.merchantImage} /> : <View style={[styles.merchantImage, styles.merchantImagePlaceholder]}><Ionicons name="person" size={40} color="#9CA3AF" /></View>}</View>
          <View><Text style={styles.welcome}>مرحباً، {userData?.full_name || userData?.name}</Text><View style={styles.merchantTypeBadge}><Text style={styles.merchantTypeText}>{serviceName || userData?.merchantType || 'تاجر'}</Text></View></View>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}><Ionicons name="log-out-outline" size={24} color="#EF4444" /></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <TouchableOpacity style={styles.ratingCard} onPress={() => setShowReviewsModal(true)}><View style={styles.ratingHeader}><Text style={styles.ratingTitle}>تقييم العملاء</Text><View style={styles.starsContainer}>{renderStars(averageRating)}<Text style={styles.ratingValue}>{averageRating.toFixed(1)}</Text></View></View><Text style={styles.reviewsCount}>({reviewsCount} تقييم)</Text></TouchableOpacity>
        <View style={styles.statsContainer}>
          <View style={[styles.statCard, { backgroundColor: '#FEF3C7' }]}><Text style={styles.statNumber}>{pendingOrders}</Text><Text style={styles.statLabel}>طلبات معلقة</Text><Ionicons name="time-outline" size={24} color="#92400E" /></View>
          <View style={[styles.statCard, { backgroundColor: '#DBEAFE' }]}><Text style={styles.statNumber}>{acceptedOrders}</Text><Text style={styles.statLabel}>مقبولة</Text><Ionicons name="checkmark-circle-outline" size={24} color="#1E40AF" /></View>
        </View>
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>القائمة الرئيسية</Text>
          <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('MerchantOrdersScreen')}>
            <View style={[styles.menuIcon, { backgroundColor: '#4F46E520' }]}><Ionicons name="cart-outline" size={24} color="#4F46E5" /></View>
            <View style={styles.menuTextContainer}><Text style={styles.menuTitle}>الطلبات</Text><Text style={styles.menuSubtitle}>عرض وإدارة الطلبات</Text></View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Profile')}>
            <View style={[styles.menuIcon, { backgroundColor: '#6B728020' }]}><Ionicons name="person-outline" size={24} color="#4B5563" /></View>
            <View style={styles.menuTextContainer}><Text style={styles.menuTitle}>الملف الشخصي</Text><Text style={styles.menuSubtitle}>عرض وتعديل بياناتك</Text></View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('AddOfferScreen')}>
            <View style={[styles.menuIcon, { backgroundColor: '#F59E0B20' }]}><Ionicons name="pricetag-outline" size={24} color="#F59E0B" /></View>
            <View style={styles.menuTextContainer}><Text style={styles.menuTitle}>عروضي</Text><Text style={styles.menuSubtitle}>إضافة وإدارة العروض</Text></View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </TouchableOpacity>
        </View>
        <View style={styles.infoSection}><Text style={styles.infoTitle}>معلومات التاجر</Text><View style={styles.infoRow}><Text style={styles.infoLabel}>رقم الهاتف:</Text><Text style={styles.infoValue}>{userData?.phone}</Text></View><View style={styles.infoRow}><Text style={styles.infoLabel}>رسوم التوصيل:</Text><Text style={styles.infoValue}>{deliveryFee} ج</Text></View></View>
      </ScrollView>
      <Modal visible={showReviewsModal} transparent animationType="slide"><View style={styles.modalOverlay}><View style={[styles.modalContent, { maxHeight: '80%' }]}><View style={styles.modalHeader}><Text style={styles.modalTitle}>تقييمات العملاء</Text><TouchableOpacity onPress={() => setShowReviewsModal(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View><View style={styles.reviewsSummary}><Text style={styles.summaryRating}>{averageRating.toFixed(1)}</Text><View style={styles.summaryStars}>{renderStars(Math.round(averageRating))}</View><Text style={styles.summaryCount}>من {reviewsCount} تقييم</Text></View><FlatList data={reviews} keyExtractor={(item) => item.id} renderItem={({ item }) => (<View style={styles.reviewItem}><View style={styles.reviewHeader}><Text style={styles.reviewerName}>{item.profiles?.full_name || 'عميل'}</Text><View style={styles.reviewStars}>{renderStars(item.rating)}</View></View>{item.comment && <Text style={styles.reviewComment}>{item.comment}</Text>}<Text style={styles.reviewDate}>{new Date(item.created_at).toLocaleDateString('ar-EG')}</Text></View>)} ListEmptyComponent={<Text style={styles.noReviewsText}>لا توجد تقييمات بعد</Text>} /></View></View></Modal>
      <Modal visible={drawerVisible} transparent animationType="slide"><View style={styles.drawerOverlay}><View style={styles.drawerContent}><CustomDrawer isLoggedIn={true} userData={userData} onClose={() => setDrawerVisible(false)} navigation={navigation} onOpenAdminModal={() => {}} /></View></View></Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  menuButton: { padding: 8 },
  headerInfo: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  merchantImageContainer: { position: 'relative' },
  merchantImage: { width: 50, height: 50, borderRadius: 25, borderWidth: 2, borderColor: '#4F46E5' },
  merchantImagePlaceholder: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  welcome: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  merchantTypeBadge: { backgroundColor: '#4F46E5', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, marginTop: 4 },
  merchantTypeText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  logoutButton: { padding: 8 },
  content: { padding: 20 },
  ratingCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  ratingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  ratingTitle: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  starsContainer: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingValue: { fontSize: 14, fontWeight: 'bold', color: '#F59E0B', marginLeft: 4 },
  reviewsCount: { fontSize: 12, color: '#6B7280' },
  statsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  statCard: { flex: 1, minWidth: '45%', borderRadius: 12, padding: 16, alignItems: 'center' },
  statNumber: { fontSize: 28, fontWeight: 'bold', color: '#1F2937', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#4B5563', marginBottom: 8 },
  menuSection: { marginBottom: 24 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 12 },
  menuItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  menuIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  menuTextContainer: { flex: 1 },
  menuTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 2 },
  menuSubtitle: { fontSize: 12, color: '#6B7280' },
  infoSection: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  infoTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 12 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  infoLabel: { fontSize: 14, color: '#6B7280' },
  infoValue: { fontSize: 14, fontWeight: '500', color: '#1F2937' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '100%', maxWidth: 400 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  reviewsSummary: { alignItems: 'center', marginBottom: 16, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  summaryRating: { fontSize: 32, fontWeight: 'bold', color: '#F59E0B' },
  summaryStars: { flexDirection: 'row', marginTop: 4 },
  summaryCount: { fontSize: 12, color: '#6B7280', marginTop: 4 },
  reviewItem: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  reviewHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  reviewerName: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  reviewStars: { flexDirection: 'row' },
  reviewComment: { fontSize: 13, color: '#4B5563', marginTop: 4 },
  reviewDate: { fontSize: 10, color: '#9CA3AF', marginTop: 4 },
  noReviewsText: { textAlign: 'center', color: '#9CA3AF', padding: 20 },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  drawerContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 25, borderTopRightRadius: 25, height: '80%', overflow: 'hidden' },
});
