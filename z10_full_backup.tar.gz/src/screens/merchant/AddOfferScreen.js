import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { uploadToImageKit } from '../../services/uploadService';
import { createOffer } from '../../services/offersService';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function AddOfferScreen({ navigation }) {
  const [merchantId, setMerchantId] = useState(null);
  const [merchantName, setMerchantName] = useState('');
  const [serviceType, setServiceType] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [offerPrice, setOfferPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadMerchantData(); }, []);

  const loadMerchantData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      const { data: merchant } = await supabase.from('merchants').select('id, name, service_type').eq('user_id', user.id).single();
      if (merchant) {
        setMerchantId(merchant.id);
        setMerchantName(merchant.name);
        setServiceType(merchant.service_type);
      }
    }
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadToImageKit(result.assets[0].uri, 'offer_' + Date.now() + '.jpg', 'offers');
      setUploading(false);
      if (res.success) setImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSubmit = async () => {
    if (!title.trim()) { Alert.alert('تنبيه', 'يرجى إدخال عنوان العرض'); return; }
    setSaving(true);
    const result = await createOffer({
      merchant_id: merchantId,
      merchant_name: merchantName,
      service_type: serviceType,
      title: title.trim(),
      description: description.trim(),
      image_url: imageUrl,
      discount_percent: discountPercent ? parseInt(discountPercent) : null,
      original_price: originalPrice ? parseFloat(originalPrice) : null,
      offer_price: offerPrice ? parseFloat(offerPrice) : null,
    });
    setSaving(false);
    if (result.success) {
      Alert.alert('✅ تم', 'تم إرسال العرض للمراجعة');
      navigation.goBack();
    } else {
      Alert.alert('خطأ', result.error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity><Text style={styles.headerTitle}>إضافة عرض</Text><View style={{ width: 28 }} /></View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.label}>عنوان العرض *</Text>
        <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="مثال: خصم 20% على كل المنتجات" />
        <Text style={styles.label}>الوصف</Text>
        <TextInput style={[styles.input, { minHeight: 80 }]} value={description} onChangeText={setDescription} multiline placeholder="تفاصيل العرض..." />
        <View style={styles.row}>
          <View style={styles.half}><Text style={styles.label}>نسبة الخصم %</Text><TextInput style={styles.input} value={discountPercent} onChangeText={setDiscountPercent} keyboardType="numeric" placeholder="20" /></View>
          <View style={styles.half}><Text style={styles.label}>السعر الأصلي</Text><TextInput style={styles.input} value={originalPrice} onChangeText={setOriginalPrice} keyboardType="numeric" placeholder="100" /></View>
        </View>
        <Text style={styles.label}>سعر العرض</Text>
        <TextInput style={styles.input} value={offerPrice} onChangeText={setOfferPrice} keyboardType="numeric" placeholder="80" />
        <Text style={styles.label}>صورة العرض</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
          {imageUrl ? <Image source={{ uri: imageUrl }} style={styles.imagePreview} /> : <View style={styles.imagePlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text>اختر صورة</Text></View>}
        </TouchableOpacity>
        <TouchableOpacity style={[styles.saveBtn, saving && styles.disabled]} onPress={handleSubmit} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>إرسال العرض للمراجعة</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginTop: 12 },
  input: { backgroundColor: '#FFF', borderRadius: 8, padding: 12, marginTop: 6, borderWidth: 1, borderColor: '#E5E7EB' },
  row: { flexDirection: 'row', gap: 10 },
  half: { flex: 1 },
  imagePicker: { height: 150, backgroundColor: '#F3F4F6', borderRadius: 8, marginTop: 6, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  imagePreview: { width: '100%', height: '100%' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  saveBtn: { backgroundColor: '#F59E0B', padding: 16, borderRadius: 8, marginTop: 20, alignItems: 'center' },
  disabled: { opacity: 0.6 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
