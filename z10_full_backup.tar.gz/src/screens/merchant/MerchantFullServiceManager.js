import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Switch, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';

export default function MerchantFullServiceManager({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [subServices, setSubServices] = useState([]);
  const [merchantSettings, setMerchantSettings] = useState({});
  const [fields, setFields] = useState({});
  const [expandedSub, setExpandedSub] = useState(null);
  const [merchantType, setMerchantType] = useState(null);
  const [merchantId, setMerchantId] = useState(null);

  useEffect(() => { loadMerchantData(); }, []);

  const loadMerchantData = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (!userData) {
        Alert.alert('خطأ', 'يرجى تسجيل الدخول كتاجر');
        navigation.goBack();
        return;
      }
      const user = JSON.parse(userData);
      const merchantTypeId = user.merchantType;
      setMerchantType(merchantTypeId);
      setMerchantId(user.id);

      if (!merchantTypeId) {
        Alert.alert('تنبيه', 'لم يتم تحديد نوع الخدمة لهذا التاجر');
        setLoading(false);
        return;
      }

      const { data: fullService } = await supabase
        .from('full_services')
        .select('id')
        .eq('service_id', merchantTypeId)
        .single();

      if (fullService) {
        // جلب فقط الخدمات الفرعية التي مفعلها الـ Admin
        const { data: subs } = await supabase
          .from('sub_services')
          .select('*')
          .eq('full_service_id', fullService.id)
          .eq('is_active', true)
          .order('sort_order', { ascending: true });

        // جلب إعدادات التاجر
        const { data: settings } = await supabase
          .from('merchant_sub_services')
          .select('*')
          .eq('merchant_id', user.id);

        const settingsMap = {};
        (settings || []).forEach(s => {
          settingsMap[s.sub_service_id] = s;
        });
        setMerchantSettings(settingsMap);

        setSubServices(subs || []);

        // جلب الحقول
        const fieldsMap = {};
        for (const sub of (subs || [])) {
          const { data: subFields } = await supabase
            .from('service_fields')
            .select('*')
            .eq('sub_service_id', sub.id)
            .order('sort_order', { ascending: true });
          fieldsMap[sub.id] = subFields || [];
        }
        setFields(fieldsMap);
      }
    } catch (error) {
      console.error(error);
      Alert.alert('خطأ', 'فشل تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  // تبديل إظهار/إخفاء الخدمة للعملاء
  const toggleVisibility = async (subId) => {
    const setting = merchantSettings[subId];
    const currentValue = setting ? setting.show_title !== false : true;
    const newValue = !currentValue;

    const { data: existing } = await supabase
      .from('merchant_sub_services')
      .select('id')
      .eq('merchant_id', merchantId)
      .eq('sub_service_id', subId)
      .single();

    let error;
    if (existing) {
      const { error: updateError } = await supabase
        .from('merchant_sub_services')
        .update({ show_title: newValue, updated_at: new Date() })
        .eq('id', existing.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase
        .from('merchant_sub_services')
        .insert({
          merchant_id: merchantId,
          sub_service_id: subId,
          is_active: true,
          show_title: newValue
        });
      error = insertError;
    }

    if (error) {
      Alert.alert('خطأ', error.message);
    } else {
      setMerchantSettings(prev => ({
        ...prev,
        [subId]: { ...prev[subId], sub_service_id: subId, show_title: newValue }
      }));
    }
  };

  // تبديل إظهار/إخفاء حقل للعملاء
  const toggleFieldVisibility = async (fieldId, currentValue) => {
    const newValue = !currentValue;
    const { error } = await supabase
      .from('service_fields')
      .update({ is_visible: newValue })
      .eq('id', fieldId);

    if (error) {
      Alert.alert('خطأ', error.message);
    } else {
      setFields(prev => {
        const newFields = { ...prev };
        for (const key in newFields) {
          newFields[key] = newFields[key].map(f =>
            f.id === fieldId ? { ...f, is_visible: newValue } : f
          );
        }
        return newFields;
      });
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#8B5CF6" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة خدماتي</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {subServices.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="apps-outline" size={60} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد خدمات فرعية نشطة</Text>
          </View>
        ) : (
          subServices.map(sub => {
            const subFields = fields[sub.id] || [];
            const isExpanded = expandedSub === sub.id;
            const setting = merchantSettings[sub.id];
            const isVisible = setting ? setting.show_title !== false : true;

            return (
              <View key={sub.id} style={[styles.subCard, !isVisible && styles.subCardHidden]}>
                <TouchableOpacity
                  style={styles.subHeader}
                  onPress={() => setExpandedSub(isExpanded ? null : sub.id)}
                >
                  {sub.image_url ? (
                    <Image source={{ uri: sub.image_url }} style={styles.subImage} />
                  ) : (
                    <View style={styles.subIcon}>
                      <Ionicons name="document-text" size={20} color="#6B7280" />
                    </View>
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.subName, !isVisible && styles.subNameHidden]}>
                      {sub.name}
                    </Text>
                    {!isVisible && <Text style={styles.hiddenBadge}>مخفي عن العملاء</Text>}
                  </View>
                  <Ionicons name={isExpanded ? "chevron-up" : "chevron-down"} size={20} color="#9CA3AF" />
                </TouchableOpacity>

                {/* زر واحد فقط: إظهار/إخفاء للعملاء */}
                <View style={styles.subActions}>
                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>إظهار للعملاء</Text>
                    <Switch
                      value={isVisible}
                      onValueChange={() => toggleVisibility(sub.id)}
                      trackColor={{ false: '#E5E7EB', true: '#8B5CF6' }}
                      thumbColor={isVisible ? '#FFF' : '#9CA3AF'}
                    />
                  </View>
                </View>

                {/* الحقول تظهر عند التوسيع */}
                {isExpanded && subFields.length > 0 && (
                  <View style={styles.fieldsContainer}>
                    <Text style={styles.fieldsTitle}>الحقول المخصصة</Text>
                    {subFields.map(field => (
                      <View key={field.id} style={styles.fieldRow}>
                        <Text style={styles.fieldLabel}>{field.field_label}</Text>
                        <View style={styles.switchRowSmall}>
                          <Text style={styles.switchLabelSmall}>إظهار</Text>
                          <Switch
                            value={field.is_visible !== false}
                            onValueChange={() => toggleFieldVisibility(field.id, field.is_visible !== false)}
                            trackColor={{ false: '#E5E7EB', true: '#10B981' }}
                            thumbColor={field.is_visible !== false ? '#FFF' : '#9CA3AF'}
                          />
                        </View>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB'
  },
  backCircle: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center', alignItems: 'center'
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  subCard: {
    backgroundColor: '#FFF', borderRadius: 12, marginBottom: 12,
    borderWidth: 1, borderColor: '#E5E7EB', overflow: 'hidden'
  },
  subCardHidden: { opacity: 0.55 },
  subHeader: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 10 },
  subImage: { width: 40, height: 40, borderRadius: 20 },
  subIcon: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: '#F3F4F6',
    justifyContent: 'center', alignItems: 'center'
  },
  subName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  subNameHidden: { color: '#9CA3AF' },
  hiddenBadge: {
    fontSize: 10, color: '#F59E0B', backgroundColor: '#FEF3C7',
    paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8,
    alignSelf: 'flex-start', marginTop: 4
  },
  subActions: {
    flexDirection: 'row', justifyContent: 'flex-end',
    paddingHorizontal: 12, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: '#F3F4F6'
  },
  switchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  switchLabel: { fontSize: 13, color: '#4B5563' },
  fieldsContainer: { padding: 12, backgroundColor: '#F9FAFB' },
  fieldsTitle: { fontSize: 12, fontWeight: '600', color: '#6B7280', marginBottom: 8 },
  fieldRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingVertical: 6
  },
  fieldLabel: { fontSize: 13, color: '#1F2937' },
  switchRowSmall: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  switchLabelSmall: { fontSize: 11, color: '#6B7280' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 14, color: '#9CA3AF', marginTop: 8 },
});
