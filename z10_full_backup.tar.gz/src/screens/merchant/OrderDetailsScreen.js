import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView,
  ActivityIndicator, Alert, Modal, TextInput, Image, FlatList, Linking,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import {
  updateOrderStatus, ORDER_STATUS, stopOrderNotificationSound,
} from '../../services/orderService';

// ✅ خطوات افتراضية (بتستخدم لو مفيش خطوات مخصصة من الأدمن)
const DEFAULT_STEPS = [
  { step_key: ORDER_STATUS.PENDING, label: 'معلق', icon: 'time-outline' },
  { step_key: ORDER_STATUS.ACCEPTED, label: 'تم القبول', icon: 'checkmark-circle-outline' },
  { step_key: ORDER_STATUS.PREPARING, label: 'تجهيز', icon: 'construct-outline' },
  { step_key: ORDER_STATUS.READY, label: 'جاهز', icon: 'cube-outline' },
  { step_key: ORDER_STATUS.DRIVER_ASSIGNED, label: 'مندوب', icon: 'person-outline' },
  { step_key: ORDER_STATUS.ON_THE_WAY, label: 'في الطريق', icon: 'bicycle-outline' },
  { step_key: ORDER_STATUS.DELIVERED, label: 'تم التسليم', icon: 'checkmark-done-circle-outline' },
];

export default function OrderDetailsScreen({ route, navigation }) {
  const { orderId } = route.params;
  const [order, setOrder] = useState(null);
  const [steps, setSteps] = useState(DEFAULT_STEPS);
  const [trackingImage, setTrackingImage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  useEffect(() => {
    loadOrder();
    const interval = setInterval(loadOrder, 5000);
    return () => clearInterval(interval);
  }, []);

  // ✅ تحميل خطوات التتبع من الداتابيز (نفس العميل بالظبط)
  const loadSteps = async (serviceType) => {
    const { data } = await supabase
      .from('service_tracking_steps')
      .select('*')
      .eq('service_id', serviceType)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (data && data.length > 0) {
      setSteps(data.map(s => ({ ...s, sub: s.description || '' })));
      return data.map(s => ({ ...s, sub: s.description || '' }));
    } else {
      setSteps(DEFAULT_STEPS);
      return DEFAULT_STEPS;
    }
  };

  const loadOrder = async () => {
    try {
      const { data, error } = await supabase.from(TABLES.ORDERS).select('*').eq('id', orderId).single();
      if (error) throw error;
      setOrder(data);
      if (data?.service_type) {
        await loadSteps(data.service_type);
        await loadTrackingImage(data.service_type);
      }
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  };

  const loadTrackingImage = async (serviceType) => {
    if (!serviceType) return;
    try {
      const serviceId = serviceType === 'eshop' ? 'eshop' : serviceType;
      const { data } = await supabase.from('services').select('tracking_image, image_url').eq('id', serviceId).single();
      if (data?.tracking_image || data?.image_url) {
        setTrackingImage(data.tracking_image || data.image_url);
      }
    } catch (e) {}
  };

  const refreshOrder = () => loadOrder();
  const makePhoneCall = (phone) => phone && Linking.openURL(`tel:${phone}`);

  // ✅ تغيير الحالة للخطوة التالية
  const handleNextStep = () => {
    const nextStep = getNextStep();
    if (!nextStep) return;
    
    Alert.alert(
      'تأكيد',
      `تغيير الحالة إلى "${nextStep.label}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'نعم', onPress: async () => {
          const result = await updateOrderStatus(orderId, nextStep.step_key);
          if (result.success) {
            Alert.alert('✅ تم التحديث');
            refreshOrder();
          } else {
            Alert.alert('خطأ', result.error);
          }
        }}
      ]
    );
  };

  const handleReject = () => {
    Alert.alert('تأكيد الرفض', 'هل أنت متأكد من رفض الطلب؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'رفض', style: 'destructive', onPress: async () => {
        const result = await updateOrderStatus(orderId, ORDER_STATUS.CANCELLED, { cancellation_reason: rejectReason || 'تم الرفض بواسطة التاجر' });
        if (result.success) {
          Alert.alert('✅ تم رفض الطلب');
          refreshOrder();
        }
      }}
    ]);
  };

  const getNextStep = () => {
    if (!order?.status) return null;
    const currentIdx = steps.findIndex(s => s.step_key === order.status);
    if (currentIdx >= 0 && currentIdx < steps.length - 1) {
      return steps[currentIdx + 1];
    }
    return null;
  };

  const getStatusColor = (status) => {
    const colors = {
      [ORDER_STATUS.PENDING]: '#F59E0B',
      [ORDER_STATUS.ACCEPTED]: '#3B82F6',
      [ORDER_STATUS.PREPARING]: '#8B5CF6',
      [ORDER_STATUS.READY]: '#10B981',
      [ORDER_STATUS.DRIVER_ASSIGNED]: '#3B82F6',
      [ORDER_STATUS.ON_THE_WAY]: '#F59E0B',
      [ORDER_STATUS.DELIVERED]: '#10B981',
      [ORDER_STATUS.CANCELLED]: '#EF4444',
    };
    return colors[status] || '#6B7280';
  };

  const getStepStatus = (stepKey) => {
    if (!order?.status) return 'pending';
    const currentIdx = steps.findIndex(s => s.step_key === order.status);
    const stepIdx = steps.findIndex(s => s.step_key === stepKey);
    if (currentIdx > stepIdx) return 'completed';
    if (currentIdx === stepIdx) return 'current';
    return 'pending';
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;
  if (!order) return <View style={styles.center}><Text>الطلب غير موجود</Text></View>;

  const displayId = String(order.id).slice(-6);
  const nextStep = getNextStep();
  const isCompleted = steps.length > 0 && !nextStep;
  const statusColor = getStatusColor(order.status);

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={28} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>طلب #{displayId}</Text>
        <TouchableOpacity onPress={refreshOrder}>
          <Ionicons name="refresh" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {trackingImage && (
          <TouchableOpacity onPress={() => { setSelectedImage(trackingImage); setShowImageModal(true); }}>
            <Image source={{ uri: trackingImage }} style={styles.trackingImage} resizeMode="cover" />
          </TouchableOpacity>
        )}

        <View style={[styles.statusCard, { backgroundColor: statusColor + '15', borderLeftColor: statusColor, borderLeftWidth: 6 }]}>
          <Ionicons name="information-circle" size={48} color={statusColor} />
          <View style={styles.statusInfo}>
            <Text style={[styles.statusBigText, { color: statusColor }]}>
              {steps.find(s => s.step_key === order.status)?.label || 'غير معروف'}
            </Text>
            <Text style={styles.statusDate}>
              {new Date(order.created_at).toLocaleString('ar-EG', {
                year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
              })}
            </Text>
          </View>
        </View>

        {/* Progress Steps */}
        <View style={styles.trackingSection}>
          <Text style={styles.sectionTitle}>📍 مراحل الطلب</Text>
          <View style={styles.stepsContainer}>
            {steps.map((step, index) => {
              const status = getStepStatus(step.step_key);
              const isCompleted = status === 'completed';
              const isCurrent = status === 'current';
              return (
                <View key={step.step_key || index} style={styles.stepItem}>
                  <View style={[
                    styles.stepCircle,
                    isCompleted && styles.stepCompleted,
                    isCurrent && styles.stepCurrent
                  ]}>
                    {isCompleted ? (
                      <Ionicons name="checkmark" size={18} color="#FFF" />
                    ) : (
                      <Ionicons name={step.icon || 'ellipse-outline'} size={18} color={isCurrent ? '#FFF' : '#9CA3AF'} />
                    )}
                  </View>
                  <Text style={[
                    styles.stepLabel,
                    isCompleted && styles.stepLabelCompleted,
                    isCurrent && styles.stepLabelCurrent
                  ]} numberOfLines={1}>
                    {step.label}
                  </Text>
                  {index < steps.length - 1 && (
                    <View style={[styles.stepConnector, isCompleted && styles.stepConnectorCompleted]} />
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* معلومات العميل */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>👤 معلومات العميل</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Ionicons name="person-outline" size={22} color="#6B7280" />
              <Text style={styles.infoText}>{order.customer_name}</Text>
              <TouchableOpacity onPress={() => makePhoneCall(order.customer_phone)} style={styles.callButton}>
                <Ionicons name="call" size={18} color="#FFF" />
                <Text style={styles.callButtonText}>اتصل</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.infoRow}>
              <Ionicons name="location-outline" size={22} color="#6B7280" />
              <Text style={styles.infoText}>{order.customer_address}</Text>
            </View>
          </View>
        </View>

        {/* المنتجات */}
        {order.items?.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>📦 المنتجات</Text>
            <View style={styles.itemsCard}>
              <FlatList
                data={order.items}
                keyExtractor={(_, i) => i.toString()}
                renderItem={({ item }) => (
                  <Text style={styles.itemText}>• {item}</Text>
                )}
                scrollEnabled={false}
              />
            </View>
          </View>
        )}

        {/* الفاتورة */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💰 الفاتورة</Text>
          <View style={styles.invoiceCard}>
            <View style={styles.invoiceRow}>
              <Text style={styles.invoiceLabel}>قيمة المنتجات</Text>
              <Text style={styles.invoiceValue}>{order.total_price || 0} ج.م</Text>
            </View>
            <View style={styles.invoiceRow}>
              <Text style={styles.invoiceLabel}>رسوم التوصيل</Text>
              <Text style={styles.invoiceValue}>{order.delivery_fee || 0} ج.م</Text>
            </View>
            <View style={styles.invoiceTotal}>
              <Text style={styles.totalLabel}>الإجمالي</Text>
              <Text style={styles.totalValue}>{order.final_total || order.total_price || 0} ج.م</Text>
            </View>
          </View>
        </View>

        {/* ✅ زر واحد: الخطوة التالية - أو رفض */}
        {!isCompleted && (
          <View style={styles.actionsContainer}>
            {nextStep && (
              <TouchableOpacity style={[styles.actionButton, { backgroundColor: statusColor }]} onPress={handleNextStep}>
                <Ionicons name="arrow-back-circle" size={22} color="#FFF" />
                <Text style={styles.actionButtonText}>{nextStep.label}</Text>
              </TouchableOpacity>
            )}
            {order.status === ORDER_STATUS.PENDING && (
              <TouchableOpacity style={[styles.actionButton, styles.rejectButton]} onPress={handleReject}>
                <Ionicons name="close-circle" size={22} color="#FFF" />
                <Text style={styles.actionButtonText}>رفض الطلب</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </ScrollView>

      {/* Modal الصورة */}
      <Modal visible={showImageModal} transparent animationType="fade">
        <View style={styles.imageModalOverlay}>
          <TouchableOpacity style={styles.closeImageButton} onPress={() => setShowImageModal(false)}>
            <Ionicons name="close" size={34} color="#FFF" />
          </TouchableOpacity>
          {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImage} resizeMode="contain" />}
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 20, fontWeight: '700', color: '#1F2937' },
  content: { padding: 16, paddingBottom: 40 },
  trackingImage: { width: '100%', height: 220, borderRadius: 16, marginBottom: 20, backgroundColor: '#F1F5F9' },
  statusCard: { flexDirection: 'row', alignItems: 'center', padding: 20, borderRadius: 16, marginBottom: 24, backgroundColor: '#FFF', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 12, elevation: 5 },
  statusInfo: { marginLeft: 16, flex: 1 },
  statusBigText: { fontSize: 22, fontWeight: '700' },
  statusDate: { fontSize: 13, color: '#64748B', marginTop: 4 },
  trackingSection: { marginBottom: 28 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 12 },
  stepsContainer: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#FFF', paddingVertical: 20, paddingHorizontal: 16, borderRadius: 16, borderWidth: 1, borderColor: '#E2E8F0' },
  stepItem: { alignItems: 'center', flex: 1, position: 'relative' },
  stepCircle: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 8, borderWidth: 3, borderColor: '#E2E8F0' },
  stepCompleted: { backgroundColor: '#10B981', borderColor: '#10B981' },
  stepCurrent: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  stepLabel: { fontSize: 10.5, color: '#64748B', textAlign: 'center', fontWeight: '600' },
  stepLabelCompleted: { color: '#10B981' },
  stepLabelCurrent: { color: '#4F46E5', fontWeight: '700' },
  stepConnector: { position: 'absolute', top: 18, left: '52%', right: '-45%', height: 3, backgroundColor: '#E2E8F0', zIndex: -1 },
  stepConnectorCompleted: { backgroundColor: '#10B981' },
  section: { marginBottom: 24 },
  infoCard: { backgroundColor: '#FFF', borderRadius: 16, padding: 18, borderWidth: 1, borderColor: '#E2E8F0', gap: 14 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  infoText: { fontSize: 15.5, color: '#334155', flex: 1 },
  callButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 12, gap: 6 },
  callButtonText: { color: '#FFF', fontWeight: '700', fontSize: 13 },
  itemsCard: { backgroundColor: '#FFF', borderRadius: 16, padding: 18, borderWidth: 1, borderColor: '#E2E8F0' },
  itemText: { fontSize: 15, color: '#475569', marginBottom: 8, lineHeight: 22 },
  invoiceCard: { backgroundColor: '#FEFCE8', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#FDE047' },
  invoiceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  invoiceLabel: { fontSize: 15, color: '#854D0E' },
  invoiceValue: { fontSize: 15, fontWeight: '600', color: '#854D0E' },
  invoiceTotal: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, paddingTop: 12, borderTopWidth: 1.5, borderTopColor: '#FACC15' },
  totalLabel: { fontSize: 17, fontWeight: '700', color: '#854D0E' },
  totalValue: { fontSize: 20, fontWeight: '800', color: '#CA8A04' },
  actionsContainer: { marginTop: 12, gap: 12 },
  actionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, paddingHorizontal: 20, borderRadius: 16, gap: 10, minHeight: 56 },
  rejectButton: { backgroundColor: '#EF4444' },
  actionButtonText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.97)', justifyContent: 'center', alignItems: 'center' },
  closeImageButton: { position: 'absolute', top: 60, right: 20, zIndex: 10 },
  fullImage: { width: '92%', height: '75%' },
});
