import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator, Image, FlatList, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { uploadToImageKit } from '../../services/uploadService';
import { addProduct } from '../../services/productService';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function AddProductScreen({ navigation, route }) {
  const [userData, setUserData] = useState(null);
  const [merchantId, setMerchantId] = useState(null);
  const [merchantName, setMerchantName] = useState('');
  const [serviceType, setServiceType] = useState('');
  const [templateProducts, setTemplateProducts] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [useTemplate, setUseTemplate] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [additionalImages, setAdditionalImages] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);

  useEffect(() => { loadUserData(); }, []);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setUserData(user);
      const { data: merchant } = await supabase
        .from('merchants')
        .select('id, service_type, name')
        .eq('user_id', user.id)
        .single();
      if (merchant) {
        setMerchantId(merchant.id);
        setMerchantName(merchant.name);
        setServiceType(merchant.service_type);
        loadTemplates(merchant.service_type);
        loadCategories(merchant.service_type);
      }
    }
  };

  const loadTemplates = async (service) => {
    const { data } = await supabase
      .from('template_products')
      .select('*')
      .eq('is_approved', true)
      .eq('service_type', service);
    setTemplateProducts(data || []);
  };

  const loadCategories = async (service) => {
    const { data } = await supabase
      .from('product_categories')
      .select('*')
      .eq('service_id', service)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    setCategories(data || []);
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const uploadRes = await uploadToImageKit(result.assets[0].uri, 'product_' + Date.now() + '.jpg', 'products');
      setUploading(false);
      if (uploadRes.success) {
        if (!imageUrl) {
          setImageUrl(uploadRes.fileUrl);
        } else {
          setAdditionalImages(prev => [...prev, uploadRes.fileUrl]);
        }
      } else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const removeAdditionalImage = (index) => {
    setAdditionalImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!name.trim() || !price) { Alert.alert('تنبيه', 'يرجى إدخال الاسم والسعر'); return; }
    if (!useTemplate && !imageUrl) { Alert.alert('تنبيه', 'يرجى اختيار صورة رئيسية للمنتج'); return; }

    setSaving(true);

    try {
      const finalMerchantId = useTemplate ? merchantId : (userData?.id || userData?.$id);

      const productData = {
        name: name.trim(),
        description: description.trim(),
        price: parseFloat(price),
        image_url: imageUrl,
        images: additionalImages,
        merchant_id: finalMerchantId,
        merchant_name: merchantName,
        service_id: serviceType,
        is_unified: useTemplate,
        template_product_id: selectedTemplate?.id || null,
        category_id: selectedCategory?.id || null,
      };

      const result = await addProduct(productData);

      if (result.success) {
        Alert.alert('✅ تم', useTemplate ? 'تم حفظ المنتج الموحد وسيظهر فوراً' : 'تم إرسال المنتج للمراجعة');
        navigation.goBack();
      } else {
        Alert.alert('خطأ', result.error);
      }
    } catch (e) {
      Alert.alert('خطأ', e.message);
    } finally {
      setSaving(false);
    }
  };

  const openTemplatePicker = () => {
    if (templateProducts.length === 0) { Alert.alert('تنبيه', 'لا توجد منتجات موحدة متاحة'); return; }
    setShowTemplatePicker(true);
  };

  const selectTemplate = (item) => {
    setSelectedTemplate(item);
    setName(item.name);
    setDescription(item.description || '');
    setImageUrl(item.image_url || '');
    setPrice('');
    setUseTemplate(true);
    setShowTemplatePicker(false);
  };

  if (!serviceType) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إضافة منتج</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <TouchableOpacity style={styles.categoryButton} onPress={() => setShowCategoryPicker(true)}>
          <Ionicons name="folder-outline" size={20} color="#8B5CF6" />
          <Text style={styles.categoryButtonText}>
            {selectedCategory ? selectedCategory.name : 'اختيار الفئة (اختياري)'}
          </Text>
          <Ionicons name="chevron-down" size={18} color="#9CA3AF" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.templateButton} onPress={openTemplatePicker}>
          <Ionicons name="library-outline" size={24} color="#4F46E5" />
          <Text style={styles.templateButtonText}>{useTemplate ? 'تغيير المنتج الموحد' : 'اختيار من المنتجات الموحدة'}</Text>
        </TouchableOpacity>

        {useTemplate && selectedTemplate && (
          <View style={styles.selectedCard}>
            {selectedTemplate.image_url && <Image source={{ uri: selectedTemplate.image_url }} style={styles.selectedImage} />}
            <View><Text style={styles.selectedName}>{selectedTemplate.name}</Text><Text style={styles.selectedCat}>{selectedTemplate.category}</Text></View>
          </View>
        )}

        {!useTemplate && (
          <>
            <Text style={styles.label}>اسم المنتج *</Text>
            <TextInput style={styles.input} value={name} onChangeText={setName} />
            <Text style={styles.label}>الوصف</Text>
            <TextInput style={styles.input} value={description} onChangeText={setDescription} />
            <Text style={styles.label}>صورة المنتج الرئيسية *</Text>
            <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
              {uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : imageUrl ? <Image source={{ uri: imageUrl }} style={styles.imagePreview} /> : <View style={styles.imagePlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text>اختر صورة</Text></View>}
            </TouchableOpacity>

            {/* ✅ صور إضافية */}
            <Text style={styles.label}>صور إضافية (اختياري)</Text>
            {additionalImages.length > 0 && (
              <View style={styles.additionalImagesRow}>
                {additionalImages.map((img, index) => (
                  <View key={index} style={styles.additionalImageItem}>
                    <Image source={{ uri: img }} style={styles.additionalImage} />
                    <TouchableOpacity style={styles.removeImageBtn} onPress={() => removeAdditionalImage(index)}>
                      <Ionicons name="close-circle" size={22} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
            <TouchableOpacity style={styles.addImageBtn} onPress={pickImage} disabled={uploading}>
              <Ionicons name="add-circle-outline" size={24} color="#4F46E5" />
              <Text style={styles.addImageBtnText}>إضافة صورة إضافية</Text>
            </TouchableOpacity>
          </>
        )}

        <Text style={styles.label}>السعر (ج) *</Text>
        <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="numeric" />

        <TouchableOpacity style={[styles.saveBtn, saving && styles.disabled]} onPress={handleSave} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{useTemplate ? 'حفظ المنتج الموحد' : 'إرسال للمراجعة'}</Text>}
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={showCategoryPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر الفئة</Text><TouchableOpacity onPress={() => setShowCategoryPicker(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <TouchableOpacity style={styles.categoryOption} onPress={() => { setSelectedCategory(null); setShowCategoryPicker(false); }}><Text style={[styles.categoryOptionText, !selectedCategory && { color: '#8B5CF6', fontWeight: '700' }]}>بدون فئة</Text></TouchableOpacity>
          {categories.map(cat => (
            <TouchableOpacity key={cat.id} style={styles.categoryOption} onPress={() => { setSelectedCategory(cat); setShowCategoryPicker(false); }}>
              <Ionicons name={cat.icon || 'cube'} size={20} color="#8B5CF6" />
              <Text style={styles.categoryOptionText}>{cat.name}</Text>
            </TouchableOpacity>
          ))}
        </View></View>
      </Modal>

      <Modal visible={showTemplatePicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر منتج موحد</Text><TouchableOpacity onPress={() => setShowTemplatePicker(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={templateProducts} keyExtractor={item => item.id} renderItem={({ item }) => (
            <TouchableOpacity style={styles.templateRow} onPress={() => selectTemplate(item)}>
              {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.templateImg} /> : <Ionicons name="image-outline" size={30} color="#D1D5DB" />}
              <View style={{ flex: 1 }}><Text style={styles.templateName}>{item.name}</Text><Text style={styles.templateCat}>{item.category}</Text></View>
              <Ionicons name="add-circle" size={24} color="#4F46E5" />
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  categoryButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F0F0FF', padding: 14, borderRadius: 10, marginBottom: 12, gap: 10 },
  categoryButtonText: { flex: 1, color: '#8B5CF6', fontWeight: '600', fontSize: 15 },
  categoryOption: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#F3F4F6', gap: 10 },
  categoryOptionText: { fontSize: 15, color: '#1F2937' },
  templateButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EEF2FF', padding: 14, borderRadius: 10, marginBottom: 12, gap: 10 },
  templateButtonText: { color: '#4F46E5', fontWeight: '600', fontSize: 15 },
  selectedCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F0FDF4', padding: 10, borderRadius: 10, marginBottom: 12, gap: 10 },
  selectedImage: { width: 60, height: 60, borderRadius: 8 },
  selectedName: { fontWeight: '600', fontSize: 16 },
  selectedCat: { color: '#6B7280', fontSize: 12 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginTop: 12 },
  input: { backgroundColor: '#FFF', borderRadius: 8, padding: 12, marginTop: 6, borderWidth: 1, borderColor: '#E5E7EB' },
  imagePicker: { height: 150, backgroundColor: '#F3F4F6', borderRadius: 8, marginTop: 6, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  imagePreview: { width: '100%', height: '100%' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  // ✅ صور إضافية
  additionalImagesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 },
  additionalImageItem: { position: 'relative' },
  additionalImage: { width: 80, height: 80, borderRadius: 8 },
  removeImageBtn: { position: 'absolute', top: -6, right: -6, backgroundColor: '#FFF', borderRadius: 12 },
  addImageBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginTop: 8 },
  addImageBtnText: { color: '#4F46E5', fontSize: 14 },
  saveBtn: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, marginTop: 20, alignItems: 'center' },
  disabled: { opacity: 0.6 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold' },
  templateRow: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6', gap: 10 },
  templateImg: { width: 40, height: 40, borderRadius: 6 },
  templateName: { fontWeight: '600', fontSize: 15 },
  templateCat: { color: '#6B7280', fontSize: 12 },
});
