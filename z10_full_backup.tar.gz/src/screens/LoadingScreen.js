import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, StatusBar, Image, Animated, Easing, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';
import * as FileSystem from 'expo-file-system/legacy';

export default function LoadingScreen({ navigation }) {
  const [progress, setProgress] = useState(0);
  const [loadingStep, setLoadingStep] = useState(0);
  const [dots, setDots] = useState('');

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.96)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  const loadingMessages = [
    'جاري تجهيز التطبيق',
    'جاري تحميل الإعدادات',
    'جاري تجهيز الوسائط',
    'جاهز للانطلاق'
  ];

  useEffect(() => {
    startAnimations();
    loadApp();

    const interval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 400);

    return () => clearInterval(interval);
  }, []);

  const startAnimations = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
    ]).start();
  };

  const animateProgress = (toValue, duration = 600) => {
    Animated.timing(progressAnim, {
      toValue,
      duration,
      easing: Easing.out(Easing.quad),
      useNativeDriver: false,
    }).start();

    let start = progress;
    const intervalTime = Math.floor(duration / (toValue - start));
    const timer = setInterval(() => {
      if (start < toValue) {
        start++;
        setProgress(start);
      } else {
        clearInterval(timer);
      }
    }, intervalTime > 0 ? intervalTime : 12);
  };

  const updateStep = (step) => {
    setLoadingStep(step);
    const progressValue = [20, 50, 80, 100][step];
    animateProgress(progressValue, 1000);
  };

  const loadApp = async () => {
    try {
      updateStep(0);
      await new Promise(resolve => setTimeout(resolve, 1500));

      updateStep(1);
      const { data: settings } = await supabase
        .from('app_settings')
        .select('*')
        .order('id', { ascending: false })
        .limit(1)
        .single();

      if (settings) {
        await AsyncStorage.setItem('appSettings', JSON.stringify(settings));

        // الخطوة 2 - تحميل كل الوسائط
        updateStep(2);

        // تحميل GIF البداية
        if (settings.splash_gif_url) {
          try {
            const gifPath = `${FileSystem.cacheDirectory}splash.gif`;
            const gifExists = await FileSystem.getInfoAsync(gifPath);
            if (!gifExists.exists) await FileSystem.downloadAsync(settings.splash_gif_url, gifPath);
          } catch(e) {}
        }

        // تحميل فيديو البداية
        if (settings.splash_video_url) {
          try {
            const videoPath = `${FileSystem.cacheDirectory}splash.mp4`;
            const videoExists = await FileSystem.getInfoAsync(videoPath);
            if (!videoExists.exists) await FileSystem.downloadAsync(settings.splash_video_url, videoPath);
          } catch(e) {}
        }

        // تحميل صور الأزرار السفلية
        if (settings.tab1_image) {
          try {
            const path = `${FileSystem.cacheDirectory}tab1.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.tab1_image, path);
            Image.prefetch(settings.tab1_image);
          } catch(e) {}
        }
        if (settings.tab2_image) {
          try {
            const path = `${FileSystem.cacheDirectory}tab2.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.tab2_image, path);
            Image.prefetch(settings.tab2_image);
          } catch(e) {}
        }
        if (settings.tab3_image) {
          try {
            const path = `${FileSystem.cacheDirectory}tab3.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.tab3_image, path);
            Image.prefetch(settings.tab3_image);
          } catch(e) {}
        }
        if (settings.tab4_image) {
          try {
            const path = `${FileSystem.cacheDirectory}tab4.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.tab4_image, path);
            Image.prefetch(settings.tab4_image);
          } catch(e) {}
        }

        // تحميل صورة خلفية تسجيل الدخول
        if (settings.customer_auth_background_url) {
          try {
            const path = `${FileSystem.cacheDirectory}customer_auth_bg.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.customer_auth_background_url, path);
            Image.prefetch(settings.customer_auth_background_url);
          } catch(e) {}
        }

        // تحميل صورة الخلفية الرئيسية
        if (settings.background_image_url) {
          try {
            const path = `${FileSystem.cacheDirectory}background.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.background_image_url, path);
            Image.prefetch(settings.background_image_url);
          } catch(e) {}
        }

        // تحميل صورة الهيدر
        if (settings.header_image_url) {
          try {
            const path = `${FileSystem.cacheDirectory}header.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.header_image_url, path);
            Image.prefetch(settings.header_image_url);
          } catch(e) {}
        }

        // تحميل شعار التطبيق
        if (settings.app_logo_url) {
          try {
            const path = `${FileSystem.cacheDirectory}app_logo.jpg`;
            const exists = await FileSystem.getInfoAsync(path);
            if (!exists.exists) await FileSystem.downloadAsync(settings.app_logo_url, path);
          } catch(e) {}
        }
      }

      updateStep(3);
      await new Promise(resolve => setTimeout(resolve, 600));

      navigation.replace('Splash');
    } catch (error) {
      console.log('Error loading:', error);
      navigation.replace('Splash');
    }
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%']
  });

  return (
    <ImageBackground
      source={require('../../assets/loading_bg.png')}
      style={styles.container}
      resizeMode="cover"
    >
      <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent />

      <Animated.View style={[
        styles.content,
        { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }
      ]}>

        <View style={styles.logoContainer}>
          <Image
            source={require('../../assets/icons/ZidiconSP.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        <View style={styles.centerLoadingSection}>

          <View style={styles.progressInfo}>
            <Text style={styles.loadingText}>
              {loadingMessages[loadingStep]}{dots}
            </Text>
            <Text style={styles.progressPercent}>{progress}%</Text>
          </View>

          <View style={styles.progressBarContainer}>
            <Animated.View style={[styles.progressBar, { width: progressWidth }]} />
          </View>

          <View style={styles.circlesContainer}>
            {[0, 1, 2, 3].map((i) => {
              const isActive = loadingStep >= i;
              const isCurrent = loadingStep === i;
              return (
                <View
                  key={i}
                  style={[
                    styles.circle,
                    isActive && styles.circleActive,
                    isCurrent && styles.circleCurrent
                  ]}
                />
              );
            })}
          </View>

        </View>

      </Animated.View>

      <View style={styles.footerContainer}>
        <Text style={styles.footerText}>ZID</Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 45 },
  logoContainer: { marginBottom: 40, alignItems: 'center' },
  logo: { width: 180, height: 180 },
  centerLoadingSection: { width: '100%', marginTop: 30, alignItems: 'center' },
  progressInfo: { flexDirection: 'row-reverse', justifyContent: 'space-between', width: '100%', marginBottom: 12, paddingHorizontal: 2 },
  loadingText: { fontSize: 13, fontWeight: '600', color: '#FFFFFF' },
  progressPercent: { fontSize: 14, fontWeight: '800', color: '#FFFFFF' },
  progressBarContainer: { width: '100%', height: 5, backgroundColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 10, overflow: 'hidden' },
  progressBar: { height: '100%', borderRadius: 10, backgroundColor: '#FFFFFF' },
  circlesContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 25 },
  circle: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255, 255, 255, 0.3)', marginHorizontal: 5 },
  circleActive: { backgroundColor: '#FFFFFF' },
  circleCurrent: { width: 16, borderRadius: 3, backgroundColor: '#6366F1' },
  footerContainer: { position: 'absolute', bottom: 40, left: 0, right: 0, alignItems: 'center' },
  footerText: { fontSize: 12, fontWeight: '700', color: '#D1D5DB', letterSpacing: 3 },
});
