import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Alert,
  TextInput, Modal, Dimensions, FlatList, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../../context/CartContext';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

const { width } = Dimensions.get('window');

export default function ProductDetailsScreen({ route, navigation }) {
  const { product, providerName } = route.params || {};
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [reviews, setReviews] = useState([]);
  const [avgRating, setAvgRating] = useState(0);

  const allImages = [product?.image_url, ...(product?.images || [])].filter(Boolean);

  useEffect(() => { if (product?.id) loadReviews(); }, [product?.id]);

  const loadReviews = async () => {
    const { data } = await supabase.from('shop_reviews').select('*').eq('product_id', product.id).eq('is_approved', true).order('created_at', { ascending: false });
    if (data) {
      setReviews(data);
      if (data.length > 0) setAvgRating((data.reduce((s, r) => s + r.rating, 0) / data.length).toFixed(1));
    }
  };

  const discountPercent = product?.discount_percent || (product?.original_price && product?.original_price > product?.price ? Math.round((1 - product.price / product.original_price) * 100) : 0);
  const hasDiscount = discountPercent > 0;

  if (!product) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}><TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={22} color="#FFF" /></TouchableOpacity><Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>تفاصيل المنتج</Text><View style={{ width: 40 }} /></View>
        <View style={styles.center}><Text>المنتج غير موجود</Text></View>
      </SafeAreaView>
    );
  }

  const handleAddToCart = () => {
    addToCart({ ...product, quantity, notes });
    Alert.alert('✅ تم', 'تم إضافة المنتج إلى السلة', [{ text: 'متابعة التسوق', style: 'cancel' }, { text: 'عرض السلة', onPress: () => navigation.navigate('Cart') }]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={22} color="#FFF" /></TouchableOpacity><Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>تفاصيل المنتج</Text><TouchableOpacity onPress={() => navigation.navigate('Cart')}><Ionicons name="cart-outline" size={28} color="#4F46E5" /></TouchableOpacity></View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {allImages.length > 0 ? (
            <View style={styles.galleryContainer}>
              <TouchableOpacity onPress={() => setShowImageModal(true)}>
                <Image source={{ uri: allImages[selectedImageIndex] }} style={styles.mainImage} resizeMode="cover" />
                {hasDiscount && <View style={styles.discountBadge}><Text style={styles.discountText}>%{discountPercent}</Text></View>}
                <View style={styles.imageCounter}><Text style={styles.imageCounterText}>{selectedImageIndex + 1}/{allImages.length}</Text></View>
              </TouchableOpacity>
              {allImages.length > 1 && (
                <FlatList horizontal data={allImages} showsHorizontalScrollIndicator={false} contentContainerStyle={styles.thumbnailsContainer} keyExtractor={(_, i) => i.toString()}
                  renderItem={({ item, index }) => (
                    <TouchableOpacity onPress={() => setSelectedImageIndex(index)} style={[styles.thumbnailWrapper, selectedImageIndex === index && styles.thumbnailActive]}><Image source={{ uri: item }} style={styles.thumbnail} /></TouchableOpacity>
                  )} />
              )}
            </View>
          ) : <View style={[styles.mainImage, styles.placeholderImage]}><Ionicons name="image-outline" size={60} color="#9CA3AF" /><Text style={styles.placeholderText}>لا توجد صورة</Text></View>}

          <Text style={[styles.productName, { fontFamily: fontFamily.arabic }]}>{product.name}</Text>
          <View style={styles.priceRow}><Text style={[styles.productPrice, { fontFamily: fontFamily.arabic }]}>{product.price} ج</Text>{product.original_price && <Text style={styles.oldPrice}>{product.original_price} ج</Text>}{hasDiscount && <View style={styles.discountChip}><Text style={styles.discountChipText}>خصم %{discountPercent}</Text></View>}</View>

          <TouchableOpacity style={styles.ratingRow}>
            <View style={{ flexDirection: 'row' }}>{[1, 2, 3, 4, 5].map(s => <Ionicons key={s} name={s <= Math.round(avgRating) ? 'star' : 'star-outline'} size={18} color="#F59E0B" />)}</View>
            <Text style={styles.ratingText}>{avgRating > 0 ? `${avgRating} (${reviews.length})` : 'لا تقييمات بعد'}</Text>
          </TouchableOpacity>

          {providerName && <View style={styles.merchantContainer}><Ionicons name="storefront-outline" size={16} color="#6B7280" /><Text style={[styles.merchantText, { fontFamily: fontFamily.arabic }]}>{providerName}</Text></View>}
          {product.description ? <View style={styles.sectionContainer}><Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>📝 الوصف</Text><Text style={[styles.sectionText, { fontFamily: fontFamily.arabic, writingDirection: 'rtl', textAlign: 'right' }]}>{product.description}</Text></View> : null}

          {reviews.length > 0 && (
            <View style={styles.sectionContainer}>
              <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>⭐ تقييمات العملاء</Text>
              {reviews.map(r => (
                <View key={r.id} style={styles.reviewCard}>
                  <View style={styles.reviewHeader}>
                    <View style={styles.reviewAvatar}>
                      {r.profile_image || r.customer_image_url ? <Image source={{ uri: r.profile_image || r.customer_image_url }} style={styles.reviewAvatarImg} /> : <Ionicons name="person-circle" size={36} color="#4F46E5" />}
                    </View>
                    <View style={styles.reviewInfo}>
                      <Text style={styles.reviewName}>{r.customer_name || 'عميل'}</Text>
                      <View style={{ flexDirection: 'row', marginTop: 2 }}>{[1, 2, 3, 4, 5].map(s => <Ionicons key={s} name={s <= r.rating ? 'star' : 'star-outline'} size={14} color="#F59E0B" />)}</View>
                    </View>
                  </View>
                  {r.comment ? <Text style={styles.reviewComment}>{r.comment}</Text> : null}
                  <Text style={styles.reviewDate}>{new Date(r.created_at).toLocaleDateString('ar-EG')}</Text>
                </View>
              ))}
            </View>
          )}

          <View style={styles.quantityContainer}><Text style={[styles.quantityLabel, { fontFamily: fontFamily.arabic }]}>الكمية:</Text><View style={styles.quantityControls}><TouchableOpacity onPress={() => setQuantity(Math.max(1, quantity - 1))} style={styles.quantityBtn}><Ionicons name="remove" size={20} color="#FFF" /></TouchableOpacity><Text style={[styles.quantityValue, { fontFamily: fontFamily.arabic }]}>{quantity}</Text><TouchableOpacity onPress={() => setQuantity(quantity + 1)} style={[styles.quantityBtn, styles.plusBtn]}><Ionicons name="add" size={20} color="#FFF" /></TouchableOpacity></View></View>
          <View style={styles.totalContainer}><Text style={[styles.totalLabel, { fontFamily: fontFamily.arabic }]}>الإجمالي:</Text><Text style={[styles.totalValue, { fontFamily: fontFamily.arabic }]}>{product.price * quantity} ج</Text></View>
          <TextInput style={[styles.notesInput, { fontFamily: fontFamily.arabic }]} placeholder="ملاحظات إضافية (اختياري)" placeholderTextColor="#9CA3AF" value={notes} onChangeText={setNotes} multiline numberOfLines={3} textAlignVertical="top" />

          <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCart}><Text style={[styles.addToCartText, { fontFamily: fontFamily.arabic }]}>إضافة إلى السلة - {(product.price * quantity)} ج</Text></TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={showImageModal} transparent animationType="fade">
        <View style={styles.imageModalOverlay}><TouchableOpacity style={styles.closeImageButton} onPress={() => setShowImageModal(false)}><Ionicons name="close" size={30} color="#FFF" /></TouchableOpacity>{allImages[selectedImageIndex] && <Image source={{ uri: allImages[selectedImageIndex] }} style={styles.fullImage} resizeMode="contain" />}
          {allImages.length > 1 && <View style={styles.modalNav}><TouchableOpacity onPress={() => setSelectedImageIndex(Math.max(0, selectedImageIndex - 1))} style={styles.navButton}><Ionicons name="chevron-back" size={30} color="#FFF" /></TouchableOpacity><Text style={styles.navCounter}>{selectedImageIndex + 1}/{allImages.length}</Text><TouchableOpacity onPress={() => setSelectedImageIndex(Math.min(allImages.length - 1, selectedImageIndex + 1))} style={styles.navButton}><Ionicons name="chevron-forward" size={30} color="#FFF" /></TouchableOpacity></View>}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', flex: 1, textAlign: 'center' },
  content: { padding: 16 },
  galleryContainer: { marginBottom: 16 },
  mainImage: { width: '100%', height: 280, borderRadius: 16, backgroundColor: '#F3F4F6' },
  discountBadge: { position: 'absolute', top: 12, left: 12, backgroundColor: '#EF4444', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  discountText: { color: '#FFF', fontSize: 14, fontWeight: '800' },
  imageCounter: { position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  imageCounterText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  thumbnailsContainer: { marginTop: 10, gap: 8, paddingHorizontal: 4 },
  thumbnailWrapper: { width: 60, height: 60, borderRadius: 10, overflow: 'hidden', borderWidth: 2, borderColor: 'transparent' },
  thumbnailActive: { borderColor: '#4F46E5' },
  thumbnail: { width: '100%', height: '100%' },
  placeholderImage: { justifyContent: 'center', alignItems: 'center' },
  placeholderText: { marginTop: 8, color: '#9CA3AF', fontSize: 14 },
  productName: { fontSize: 22, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  productPrice: { fontSize: 20, fontWeight: '600', color: '#F59E0B' },
  oldPrice: { fontSize: 14, color: '#9CA3AF', textDecorationLine: 'line-through' },
  discountChip: { backgroundColor: '#FEE2E2', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  discountChipText: { color: '#EF4444', fontSize: 12, fontWeight: '700' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, paddingVertical: 8 },
  ratingText: { fontSize: 14, color: '#6B7280', fontFamily: fontFamily?.arabic },
  merchantContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 6 },
  merchantText: { fontSize: 14, color: '#6B7280' },
  sectionContainer: { marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 8 },
  sectionText: { fontSize: 14, color: '#4B5563', lineHeight: 22 },
  reviewCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB' },
  reviewHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  reviewAvatar: { marginRight: 10 },
  reviewAvatarImg: { width: 36, height: 36, borderRadius: 18 },
  reviewInfo: { flex: 1 },
  reviewName: { fontSize: 14, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily?.arabic },
  reviewComment: { fontSize: 13, color: '#4B5563', marginTop: 6, lineHeight: 20, fontFamily: fontFamily?.arabic },
  reviewDate: { fontSize: 11, color: '#9CA3AF', marginTop: 8, textAlign: 'left' },
  quantityContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  quantityLabel: { fontSize: 16, fontWeight: '600', color: '#4B5563' },
  quantityControls: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  quantityBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#EF4444', justifyContent: 'center', alignItems: 'center' },
  plusBtn: { backgroundColor: '#10B981' },
  quantityValue: { fontSize: 18, fontWeight: '600', color: '#1F2937', minWidth: 30, textAlign: 'center' },
  totalContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FEF3C7', padding: 12, borderRadius: 10, marginBottom: 16 },
  totalLabel: { fontSize: 14, fontWeight: '600', color: '#92400E' },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#F59E0B' },
  notesInput: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, fontSize: 14, minHeight: 80, marginBottom: 20, color: '#1F2937' },
  addToCartButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center' },
  addToCartText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center', alignItems: 'center' },
  closeImageButton: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 10 },
  fullImage: { width: width, height: width, resizeMode: 'contain' },
  modalNav: { flexDirection: 'row', alignItems: 'center', position: 'absolute', bottom: 40, gap: 20 },
  navButton: { padding: 10 },
  navCounter: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});
