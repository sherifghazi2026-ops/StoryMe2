import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, TextInput, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { updateProviderRating } from '../../services/reviewService';

export default function RateOrderScreen({ route, navigation }) {
  const { orderId, providerId, providerName } = route.params || {};
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [existingRating, setExistingRating] = useState(null);

  useEffect(() => { if (orderId) checkExistingRating(); }, [orderId]);

  const checkExistingRating = async () => {
    try {
      const { data } = await supabase.from('reviews').select('rating, comment').eq('order_id', orderId).single();
      if (data) { setExistingRating(data); setRating(data.rating); setComment(data.comment || ''); }
    } catch (error) {}
  };

  const submitRating = async () => {
    if (rating === 0) { Alert.alert('تنبيه', 'الرجاء اختيار التقييم'); return; }
    setSubmitting(true);
    try {
      const reviewData = { order_id: orderId, provider_id: providerId, rating: rating, comment: comment.trim() || null, created_at: new Date().toISOString() };
      let result;
      const { data: existing } = await supabase.from('reviews').select('id').eq('order_id', orderId).single();
      if (existing) {
        result = await supabase.from('reviews').update(reviewData).eq('order_id', orderId);
      } else {
        result = await supabase.from('reviews').insert([reviewData]);
      }
      if (result.error) throw result.error;
      
      // تحديث متوسط التقييم للتاجر
      if (providerId) await updateProviderRating(providerId);
      
      Alert.alert('✅ شكراً لك', 'تم إرسال تقييمك بنجاح', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]);
    } catch (error) { Alert.alert('خطأ', 'فشل في إرسال التقييم'); }
    finally { setSubmitting(false); }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>تقييم الخدمة</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.title}>تقييم {providerName || 'التاجر'}</Text>
          <Text style={styles.subtitle}>كيف تقيم تجربتك معنا؟</Text>
          <View style={styles.starsContainer}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity key={star} onPress={() => setRating(star)} style={styles.starButton}>
                <Ionicons name={star <= rating ? 'star' : 'star-outline'} size={48} color={star <= rating ? '#F59E0B' : '#D1D5DB'} />
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.ratingText}>
            {rating === 1 && 'سيء جداً'}{rating === 2 && 'سيء'}{rating === 3 && 'متوسط'}{rating === 4 && 'جيد'}{rating === 5 && 'ممتاز'}
          </Text>
          <Text style={styles.label}>أضف تعليقاً (اختياري)</Text>
          <TextInput style={styles.textArea} placeholder="شاركنا رأيك في الخدمة..." value={comment} onChangeText={setComment} multiline numberOfLines={4} />
          <TouchableOpacity style={[styles.button, submitting && styles.disabled]} onPress={submitRating} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.buttonText}>إرسال التقييم</Text>}
          </TouchableOpacity>
          {existingRating && <Text style={styles.editNote}>يمكنك تعديل تقييمك السابق</Text>}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontWeight: 'bold' },
  content: { padding: 20, flexGrow: 1 },
  card: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, alignItems: 'center', elevation: 2 },
  title: { fontSize: 22, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#6B7280', marginBottom: 24 },
  starsContainer: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 16 },
  starButton: { padding: 4 },
  ratingText: { fontSize: 16, color: '#4F46E5', fontWeight: '500', marginBottom: 24 },
  label: { fontSize: 14, fontWeight: '500', color: '#4B5563', alignSelf: 'flex-start', marginBottom: 8 },
  textArea: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, padding: 12, fontSize: 14, minHeight: 100, textAlignVertical: 'top', width: '100%', marginBottom: 24 },
  button: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', width: '100%' },
  disabled: { opacity: 0.6 },
  buttonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  editNote: { fontSize: 12, color: '#9CA3AF', marginTop: 16 },
});
