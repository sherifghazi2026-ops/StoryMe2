import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Alert, TextInput,
  ActivityIndicator, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCart } from '../../context/CartContext';
import { createOrder } from '../../services/orderService';
import { playSendSound } from '../../utils/SoundHelper';
import Checkbox from 'expo-checkbox';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

export default function CartScreen({ navigation }) {
  const { cartItems, currentMerchant, updateQuantity, removeFromCart, clearCart, getTotalPrice } = useCart();
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [address, setAddress] = useState('');
  const [sending, setSending] = useState(false);
  const [merchantDeliveryFee, setMerchantDeliveryFee] = useState(10);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);

  useEffect(() => { loadUserData(); loadSavedData(); }, []);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem("userData");
    if (data) {
      const parsed = JSON.parse(data);
      setUserData(parsed); setIsLoggedIn(true);
      setGuestPhone(parsed.phone || ''); setGuestName(parsed.full_name || parsed.name || '');
    }
  };

  const loadSavedData = async () => {
    const savedAddress = await AsyncStorage.getItem('zayed_address');
    if (savedAddress) setAddress(savedAddress);
  };

  const getTotalWithDelivery = () => getTotalPrice() + merchantDeliveryFee;

  const validateGuestInfo = () => {
    if (!isLoggedIn) {
      if (!guestName.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال الاسم'); return false; }
      if (!guestPhone.trim() || guestPhone.length < 10) { Alert.alert('تنبيه', 'الرجاء إدخال رقم هاتف صحيح'); return false; }
      if (!termsAccepted) { Alert.alert('تنبيه', 'يجب الموافقة على شروط الاستخدام'); return false; }
    }
    if (!address.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال العنوان'); return false; }
    return true;
  };

  const sendOrder = async () => {
    if (cartItems.length === 0) { Alert.alert('تنبيه', 'السلة فارغة'); return; }
    if (cartItems.some(item => item.isUnified)) {
      navigation.navigate('FulfillmentScreen', { cartItems: cartItems.filter(i => i.isUnified), serviceId: cartItems[0].serviceType, serviceName: cartItems[0].serviceName });
      return;
    }
    if (!validateGuestInfo()) return;
    setSending(true);
    try {
      const customerName = isLoggedIn ? (userData?.full_name || userData?.name || 'عميل') : guestName.trim();
      const customerPhone = isLoggedIn ? (userData?.phone || '') : guestPhone.trim();
      const itemsList = cartItems.map(i => `${i.name} x${i.quantity || 1}`);
      const subtotal = getTotalPrice(); const total = subtotal + merchantDeliveryFee;
      const orderData = { customer_name: customerName, customer_phone: customerPhone, customer_address: address, service_type: cartItems[0]?.serviceType || 'products', service_name: currentMerchant?.name || 'الخدمة', merchant_id: currentMerchant?.id || null, merchant_name: currentMerchant?.name || null, items: itemsList, total_price: subtotal, delivery_fee: merchantDeliveryFee, final_total: total, notes, payment_method: 'cash_on_delivery', status: 'pending', is_guest: !isLoggedIn, guest_phone: !isLoggedIn ? guestPhone : null, user_id: userData?.id || null };
      const result = await createOrder(orderData);
      if (result.success) {
        await AsyncStorage.setItem('zayed_address', address); await playSendSound();
        setLastOrderId(result.data.id); clearCart();
        if (!isLoggedIn) { setShowSuccessModal(true); }
        else { Alert.alert('✅ تم', 'تم إرسال الطلب', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]); }
      } else { Alert.alert('خطأ', result.error || 'فشل إرسال الطلب'); }
    } catch (e) { Alert.alert('خطأ', 'فشل إرسال الطلب'); }
    finally { setSending(false); }
  };

  const handleRegister = () => { setShowSuccessModal(false); navigation.navigate('CustomerAuth', { prefillName: guestName, prefillPhone: guestPhone, fromGuestCheckout: true, pendingOrderId: lastOrderId }); };

  if (cartItems.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-forward" size={28} color="#1F2937" /></TouchableOpacity><Text style={styles.headerTitle}>سلة التسوق</Text><View style={{ width: 28 }} /></View>
        <View style={styles.emptyContainer}><Ionicons name="cart-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>السلة فارغة</Text></View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-forward" size={28} color="#1F2937" /></TouchableOpacity><Text style={styles.headerTitle}>سلة التسوق</Text><TouchableOpacity onPress={clearCart}><Ionicons name="trash-outline" size={24} color="#EF4444" /></TouchableOpacity></View>

      {/* ✅ KeyboardAvoidingView + ScrollView */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {currentMerchant && <View style={styles.merchantInfo}><Ionicons name="storefront-outline" size={20} color="#4F46E5" /><Text style={styles.merchantName}>{currentMerchant.name}</Text></View>}
          <View style={styles.itemsSection}><Text style={styles.sectionTitle}>المنتجات المختارة ({cartItems.length})</Text>
            {cartItems.map((item, idx) => (
              <View key={`${item.id}_${idx}`} style={styles.cartItem}>
                <Image source={{ uri: item.image_url || 'https://via.placeholder.com/60' }} style={styles.itemImage} />
                <View style={styles.itemInfo}><Text style={styles.itemName}>{item.name}</Text><Text style={styles.itemPrice}>{item.price || 0} ج × {item.quantity || 1}</Text><Text style={styles.itemTotal}>{(item.price || 0) * (item.quantity || 1)} ج</Text></View>
                <View style={styles.quantityControls}>
                  <TouchableOpacity onPress={() => updateQuantity(item.id, -1)}><Ionicons name="remove-circle" size={28} color="#EF4444" /></TouchableOpacity>
                  <Text style={styles.quantityText}>{item.quantity || 1}</Text>
                  <TouchableOpacity onPress={() => updateQuantity(item.id, 1)}><Ionicons name="add-circle" size={28} color="#10B981" /></TouchableOpacity>
                  <TouchableOpacity onPress={() => removeFromCart(item.id)}><Ionicons name="close-circle" size={28} color="#9CA3AF" /></TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
          <View style={styles.section}><Text style={styles.sectionTitle}>📞 بيانات التوصيل</Text>
            {!isLoggedIn ? (<><TextInput style={styles.simpleInput} placeholder="الاسم *" placeholderTextColor="#9CA3AF" value={guestName} onChangeText={setGuestName} /><TextInput style={styles.simpleInput} placeholder="رقم الهاتف *" placeholderTextColor="#9CA3AF" value={guestPhone} onChangeText={setGuestPhone} keyboardType="phone-pad" /></>) : (<View style={styles.readonlyContainer}><Text style={styles.readonlyText}>{userData?.phone || 'غير متاح'}</Text></View>)}
            <TextInput style={styles.simpleInput} placeholder="العنوان *" placeholderTextColor="#9CA3AF" value={address} onChangeText={setAddress} multiline />
            <TextInput style={styles.simpleInput} placeholder="ملاحظات (اختياري)" placeholderTextColor="#9CA3AF" value={notes} onChangeText={setNotes} multiline />
          </View>
          <View style={styles.invoiceSection}><Text style={styles.sectionTitle}>💰 الفاتورة</Text><View style={styles.invoiceRow}><Text style={styles.invoiceLabel}>إجمالي المنتجات:</Text><Text style={styles.invoiceValue}>{getTotalPrice()} ج</Text></View><View style={styles.invoiceRow}><Text style={styles.invoiceLabel}>رسوم التوصيل:</Text><Text style={styles.invoiceValue}>{merchantDeliveryFee} ج</Text></View><View style={styles.invoiceTotal}><Text style={styles.totalLabel}>الإجمالي الكلي:</Text><Text style={styles.totalValue}>{getTotalWithDelivery()} ج</Text></View></View>
          {!isLoggedIn && (<View style={styles.termsRow}><Checkbox value={termsAccepted} onValueChange={setTermsAccepted} color={termsAccepted ? '#4F46E5' : undefined} /><TouchableOpacity onPress={() => navigation.navigate('TermsScreen', { onAccept: () => setTermsAccepted(true) })}><Text style={styles.termsText}>أوافق على <Text style={styles.termsLink}>شروط وأحكام تطبيق Zid</Text></Text></TouchableOpacity></View>)}
          <TouchableOpacity style={[styles.sendButton, (!isLoggedIn && !termsAccepted) || sending ? styles.disabled : null]} onPress={sendOrder} disabled={(!isLoggedIn && !termsAccepted) || sending}>{sending ? (<View style={styles.sendingContainer}><ActivityIndicator color="#FFF" /><Text style={styles.sendingText}>جاري إرسال الطلب...</Text></View>) : (<Text style={styles.sendButtonText}>تأكيد الطلب</Text>)}</TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={showSuccessModal} transparent animationType="fade"><View style={styles.modalOverlay}><View style={styles.successModal}><Ionicons name="checkmark-circle" size={60} color="#10B981" /><Text style={styles.successTitle}>✅ طلبك قيد التنفيذ!</Text><Text style={styles.successText}>تم استلام طلبك رقم #{lastOrderId?.slice(-6) || '......'}</Text><Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text><TouchableOpacity style={[styles.successButton, styles.saveButton]} onPress={handleRegister}><Text style={styles.saveButtonText}>حفظ بياناتي واستكمال التسجيل</Text></TouchableOpacity></View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#9CA3AF' },
  content: { padding: 16, paddingBottom: 30 },
  merchantInfo: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EEF2FF', padding: 12, borderRadius: 8, marginBottom: 16, gap: 8 },
  merchantName: { fontSize: 14, color: '#4F46E5', fontWeight: '600', flex: 1 },
  itemsSection: { marginBottom: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 12, fontFamily: fontFamily.arabic },
  cartItem: { flexDirection: 'row', backgroundColor: '#FFF', borderRadius: 12, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB', alignItems: 'center' },
  itemImage: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 4, fontFamily: fontFamily.arabic },
  itemPrice: { fontSize: 12, color: '#4B5563', marginBottom: 2 },
  itemTotal: { fontSize: 14, fontWeight: '600', color: '#F59E0B' },
  quantityControls: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  quantityText: { fontSize: 16, fontWeight: '600', color: '#1F2937', minWidth: 20, textAlign: 'center' },
  section: { marginBottom: 20 },
  simpleInput: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, marginBottom: 12, color: '#1F2937', textAlign: 'right', fontFamily: fontFamily.arabic },
  readonlyContainer: { backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, marginBottom: 12 },
  readonlyText: { fontSize: 14, color: '#1F2937', fontWeight: '500' },
  invoiceSection: { backgroundColor: '#FEF3C7', borderRadius: 12, padding: 16, marginBottom: 20 },
  invoiceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  invoiceLabel: { fontSize: 14, color: '#92400E', fontFamily: fontFamily.arabic },
  invoiceValue: { fontSize: 14, fontWeight: '600', color: '#92400E' },
  invoiceTotal: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#F59E0B' },
  totalLabel: { fontSize: 16, fontWeight: '600', color: '#92400E', fontFamily: fontFamily.arabic },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#F59E0B' },
  termsRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 16, gap: 8 },
  termsText: { fontSize: 12, color: '#4B5563', flex: 1, fontFamily: fontFamily.arabic },
  termsLink: { color: '#4F46E5', textDecorationLine: 'underline' },
  sendButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  sendButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  disabled: { opacity: 0.6 },
  sendingContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  sendingText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModal: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, alignItems: 'center', width: '85%' },
  successTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937', marginTop: 12, fontFamily: fontFamily.arabic },
  successText: { fontSize: 14, color: '#4B5563', marginTop: 8, textAlign: 'center' },
  successSubtext: { fontSize: 14, color: '#4B5563', marginTop: 16, textAlign: 'center' },
  successButton: { paddingVertical: 14, borderRadius: 8, alignItems: 'center', width: '100%' },
  saveButton: { backgroundColor: '#4F46E5' },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});
