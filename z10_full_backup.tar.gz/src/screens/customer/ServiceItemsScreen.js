import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image,
  ActivityIndicator, Alert, TextInput, Modal
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { createOrder } from '../../services/orderService';
import Checkbox from 'expo-checkbox';

export default function ServiceItemsScreen({ route, navigation }) {
  const { serviceId, serviceName, subServices = [], serviceColor, serviceHeaderImage } = route.params;
  const [items, setItems] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);

  useEffect(() => { loadItems(); loadUserData(); loadSavedAddress(); }, []);

  async function loadItems() {
    try {
      const { data, error } = await supabase.from('service_items').select('*').eq('service_id', serviceId).order('name', { ascending: true });
      if (error) throw error;
      setItems(data || []);
      const initialQtys = {};
      (data || []).forEach(item => { const prices = item.variant_prices || {}; Object.keys(prices).forEach(variant => { if (prices[variant] > 0) initialQtys[`${item.id}_${variant}`] = 0; }); });
      setQuantities(initialQtys);
    } catch (error) { Alert.alert('خطأ', 'فشل في تحميل المنتجات'); } finally { setLoading(false); }
  }

  const loadUserData = async () => { const data = await AsyncStorage.getItem('userData'); if (data) { const parsed = JSON.parse(data); setUserData(parsed); setIsLoggedIn(true); setGuestName(parsed.full_name || parsed.name || ''); setGuestPhone(parsed.phone || ''); } };
  const loadSavedAddress = async () => { const saved = await AsyncStorage.getItem('zayed_address'); if (saved) setAddress(saved); };
  const updateQty = (productId, variant, delta) => { const key = `${productId}_${variant}`; setQuantities(prev => ({ ...prev, [key]: Math.max(0, (prev[key] || 0) + delta) })); };
  const calculateTotal = () => { let total = 0; items.forEach(item => { const prices = item.variant_prices || {}; Object.keys(prices).forEach(variant => { total += (quantities[`${item.id}_${variant}`] || 0) * (prices[variant] || 0); }); }); return total; };
  const getOrderItems = () => { const list = []; items.forEach(item => { const prices = item.variant_prices || {}; Object.keys(prices).forEach(variant => { const key = `${item.id}_${variant}`; const qty = quantities[key] || 0; if (qty > 0) list.push(`${item.name} (${variant}) x${qty} = ${qty * prices[variant]}ج`); }); }); return list; };

  const validateGuestInfo = () => {
    if (!isLoggedIn) { if (!guestName.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال الاسم'); return false; } if (!guestPhone.trim() || guestPhone.length < 10) { Alert.alert('تنبيه', 'الرجاء إدخال رقم هاتف صحيح'); return false; } if (!termsAccepted) { Alert.alert('تنبيه', 'يجب الموافقة على شروط الاستخدام'); return false; } }
    if (!address.trim()) { Alert.alert('تنبيه', 'العنوان مطلوب'); return false; }
    if (calculateTotal() === 0) { Alert.alert('تنبيه', 'اختر منتجات أولاً'); return false; }
    return true;
  };

  const sendOrder = async () => { if (!validateGuestInfo()) return; setSending(true); try { const customerName = isLoggedIn ? (userData?.full_name || userData?.name || 'عميل') : guestName.trim(); const customerPhone = isLoggedIn ? (userData?.phone || '') : guestPhone.trim(); const result = await createOrder({ customer_name: customerName, customer_phone: customerPhone, customer_address: address, service_type: serviceId, service_name: serviceName, items: getOrderItems(), total_price: calculateTotal(), notes: notes, is_guest: !isLoggedIn, guest_phone: !isLoggedIn ? guestPhone : null }); if (result.success) { await AsyncStorage.setItem('zayed_address', address); setLastOrderId(result.data.id); if (!isLoggedIn) { setShowSuccessModal(true); } else { Alert.alert('✅ تم إرسال طلبك', 'تم إرسال طلبك بنجاح', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]); } } else { Alert.alert('خطأ', result.error || 'فشل في إرسال الطلب'); } } catch (error) { Alert.alert('خطأ', 'فشل في إرسال الطلب'); } finally { setSending(false); } };
  const handleRegister = () => { setShowSuccessModal(false); navigation.navigate('CustomerAuth', { prefillName: guestName, prefillPhone: guestPhone, fromGuestCheckout: true, pendingOrderId: lastOrderId }); };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* ✅ Header مع زر رجوع دائري */}
      {serviceHeaderImage ? (
        <View style={styles.headerImageContainer}>
          <Image source={{ uri: serviceHeaderImage }} style={styles.headerImage} />
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <Text style={styles.headerImageTitle}>{serviceName}</Text>
        </View>
      ) : (
        <View style={[styles.header, { backgroundColor: serviceColor || '#4F46E5' }]}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <View style={styles.headerCenter}><Text style={styles.headerTitle}>{serviceName}</Text><Text style={styles.headerSubtitle}>اختر منتجاتك</Text></View>
          <View style={{ width: 40 }} />
        </View>
      )}

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* بيانات العميل */}
        <View style={styles.guestCard}>
          <View style={styles.guestCardHeader}><Ionicons name={isLoggedIn ? "person-circle" : "person-outline"} size={24} color="#4F46E5" /><Text style={styles.guestCardTitle}>{isLoggedIn ? 'مرحباً بعودتك' : 'بيانات الطلب'}</Text></View>
          {!isLoggedIn ? (<><View style={styles.inputGroup}><Ionicons name="person-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="الاسم الكامل" placeholderTextColor="#9CA3AF" value={guestName} onChangeText={setGuestName} /></View><View style={styles.inputGroup}><Ionicons name="call-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="رقم الهاتف" placeholderTextColor="#9CA3AF" value={guestPhone} onChangeText={setGuestPhone} keyboardType="phone-pad" /></View></>) : (<View style={styles.loggedInInfo}><View style={styles.infoChip}><Ionicons name="person" size={14} color="#4F46E5" /><Text style={styles.infoChipText}>{userData?.full_name || userData?.name}</Text></View><View style={styles.infoChip}><Ionicons name="call" size={14} color="#4F46E5" /><Text style={styles.infoChipText}>{userData?.phone || 'غير متاح'}</Text></View></View>)}
          <View style={styles.inputGroup}><Ionicons name="location-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={styles.modernInput} placeholder="العنوان التفصيلي" placeholderTextColor="#9CA3AF" value={address} onChangeText={setAddress} /></View>
        </View>

        <Text style={styles.sectionTitle}>🛒 المنتجات المتاحة</Text>
        {items.map((item) => {
          const prices = item.variant_prices || {};
          const hasVariants = Object.keys(prices).filter(v => prices[v] > 0).length > 0;
          if (!hasVariants) return null;
          return (
            <View key={item.id} style={styles.productCard}>
              <View style={styles.productHeader}>
                {item.image_url ? (<Image source={{ uri: item.image_url }} style={styles.productImage} />) : (<View style={styles.productImagePlaceholder}><Ionicons name="image-outline" size={24} color="#D1D5DB" /></View>)}
                <View style={styles.productInfo}><Text style={styles.productName}>{item.name}</Text>{item.description && <Text style={styles.productDesc} numberOfLines={2}>{item.description}</Text>}</View>
              </View>
              <View style={styles.variantsContainer}>
                {Object.keys(prices).map((variant) => {
                  const price = prices[variant]; if (price <= 0) return null;
                  const key = `${item.id}_${variant}`; const qty = quantities[key] || 0;
                  return (
                    <View key={variant} style={styles.variantRow}>
                      <View style={styles.variantInfo}><Text style={styles.variantName}>{variant}</Text><Text style={styles.variantPrice}>{price} ج.م</Text></View>
                      <View style={styles.counter}>
                        <TouchableOpacity onPress={() => updateQty(item.id, variant, -1)} style={[styles.counterBtn, qty === 0 && styles.counterBtnDisabled]}><Ionicons name="remove" size={16} color={qty === 0 ? '#D1D5DB' : '#FFF'} /></TouchableOpacity>
                        <View style={styles.qtyBadge}><Text style={styles.qtyText}>{qty}</Text></View>
                        <TouchableOpacity onPress={() => updateQty(item.id, variant, 1)} style={[styles.counterBtn, styles.plusBtn]}><Ionicons name="add" size={16} color="#FFF" /></TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          );
        })}

        {calculateTotal() > 0 && (
          <View style={styles.totalCard}><View style={styles.totalRow}><Text style={styles.totalLabel}>الإجمالي</Text><Text style={styles.totalPrice}>{calculateTotal()} ج.م</Text></View></View>
        )}
        <View style={styles.inputGroup}><Ionicons name="chatbubble-outline" size={18} color="#9CA3AF" style={styles.inputIcon} /><TextInput style={[styles.modernInput, styles.notesInput]} placeholder="ملاحظات إضافية (اختياري)" placeholderTextColor="#9CA3AF" value={notes} onChangeText={setNotes} multiline /></View>
        {!isLoggedIn && (<TouchableOpacity style={[styles.termsCard, termsAccepted && styles.termsCardActive]} onPress={() => setTermsAccepted(!termsAccepted)} activeOpacity={0.8}><View style={[styles.checkbox, termsAccepted && styles.checkboxActive]}>{termsAccepted && <Ionicons name="checkmark" size={16} color="#FFF" />}</View><Text style={styles.termsText}>أوافق على <Text style={styles.termsLink} onPress={(e) => { e.stopPropagation(); navigation.navigate('TermsScreen'); }}>شروط وأحكام تطبيق Zid</Text></Text></TouchableOpacity>)}
        <TouchableOpacity style={[styles.sendButton, (!isLoggedIn && !termsAccepted) || sending || calculateTotal() === 0 ? styles.disabled : null]} onPress={sendOrder} disabled={(!isLoggedIn && !termsAccepted) || sending || calculateTotal() === 0} activeOpacity={0.8}>{sending ? <ActivityIndicator color="#FFF" /> : <View style={styles.sendButtonContent}><Ionicons name="send" size={20} color="#FFF" /><Text style={styles.sendButtonText}>إرسال الطلب</Text></View>}</TouchableOpacity>
      </ScrollView>

      <Modal visible={showSuccessModal} transparent animationType="fade"><View style={styles.modalOverlay}><View style={styles.successModal}><View style={styles.successIcon}><Ionicons name="checkmark-circle" size={60} color="#10B981" /></View><Text style={styles.successTitle}>✅ تم استلام طلبك!</Text><View style={styles.successDivider} /><Text style={styles.successText}>رقم الطلب: <Text style={styles.successOrderId}>#{lastOrderId?.slice(-6) || '......'}</Text></Text><Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text><TouchableOpacity style={styles.registerButton} onPress={handleRegister} activeOpacity={0.8}><Ionicons name="person-add" size={20} color="#FFF" /><Text style={styles.registerButtonText}>حفظ بياناتي واستكمال التسجيل</Text></TouchableOpacity><TouchableOpacity style={styles.laterButton} onPress={() => setShowSuccessModal(false)}><Text style={styles.laterButtonText}>لاحقاً</Text></TouchableOpacity></View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  // Header صورة
  headerImageContainer: { height: 160, position: "relative", justifyContent: "center", alignItems: "center" },
  headerImage: { width: "100%", height: "100%", resizeMode: "cover", position: "absolute", top: 0, left: 0 },
  backButton: { position: 'absolute', top: 12, left: 12, zIndex: 10 },
  backButtonCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  headerImageTitle: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, textAlign: "center", textAlignVertical: "center", fontSize: 28, fontWeight: "800", color: "#FFF", textShadowColor: "#000", textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, paddingTop: 40 },
  // Header ملون
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, elevation: 2 },
  headerCenter: { alignItems: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#FFF' },
  headerSubtitle: { fontSize: 11, color: 'rgba(255,255,255,0.8)', marginTop: 1 },
  content: { padding: 16, paddingBottom: 40 },
  guestCard: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E8ECF0', elevation: 1 },
  guestCardHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 16 },
  guestCardTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  inputGroup: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  inputIcon: { marginRight: 10, width: 20, textAlign: 'center' },
  modernInput: { flex: 1, backgroundColor: '#F5F7FA', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1F2937', borderWidth: 1, borderColor: '#E8ECF0' },
  loggedInInfo: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  infoChip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EEF2FF', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  infoChipText: { fontSize: 13, color: '#4F46E5', fontWeight: '500' },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 14 },
  productCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#E8ECF0', elevation: 1 },
  productHeader: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  productImage: { width: 56, height: 56, borderRadius: 12 },
  productImagePlaceholder: { width: 56, height: 56, borderRadius: 12, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  productInfo: { flex: 1, justifyContent: 'center' },
  productName: { fontSize: 15, fontWeight: '600', color: '#1F2937', marginBottom: 3 },
  productDesc: { fontSize: 12, color: '#9CA3AF', lineHeight: 16 },
  variantsContainer: { borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingTop: 10 },
  variantRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F9FAFB' },
  variantInfo: { flex: 1 },
  variantName: { fontSize: 14, fontWeight: '500', color: '#374151' },
  variantPrice: { fontSize: 12, color: '#4F46E5', fontWeight: '600', marginTop: 2 },
  counter: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  counterBtn: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center', backgroundColor: '#4F46E5' },
  counterBtnDisabled: { backgroundColor: '#E5E7EB' },
  plusBtn: { backgroundColor: '#10B981' },
  qtyBadge: { minWidth: 28, backgroundColor: '#F3F4F6', borderRadius: 14, paddingHorizontal: 8, paddingVertical: 4, alignItems: 'center' },
  qtyText: { fontSize: 15, fontWeight: '700', color: '#1F2937' },
  totalCard: { backgroundColor: '#FFFBEB', borderRadius: 14, padding: 16, marginVertical: 16, borderWidth: 1, borderColor: '#FEF3C7' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  totalLabel: { fontSize: 16, fontWeight: '600', color: '#92400E' },
  totalPrice: { fontSize: 22, fontWeight: '800', color: '#F59E0B' },
  notesInput: { minHeight: 60, textAlignVertical: 'top' },
  termsCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: '#FFF', borderWidth: 1.5, borderColor: '#E5E7EB', marginBottom: 16, gap: 10 },
  termsCardActive: { borderColor: '#4F46E5', backgroundColor: '#EEF2FF' },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: '#D1D5DB', justifyContent: 'center', alignItems: 'center' },
  checkboxActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  termsText: { fontSize: 13, color: '#4B5563', flex: 1, lineHeight: 18 },
  termsLink: { color: '#4F46E5', fontWeight: '600' },
  sendButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 30, elevation: 2 },
  disabled: { opacity: 0.5, elevation: 0 },
  sendButtonContent: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sendButtonText: { color: '#FFF', fontSize: 17, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModal: { backgroundColor: '#FFF', borderRadius: 24, padding: 28, alignItems: 'center', width: '88%', elevation: 10 },
  successIcon: { marginBottom: 12 },
  successTitle: { fontSize: 20, fontWeight: '800', color: '#1F2937', marginTop: 8 },
  successDivider: { height: 1, width: 40, backgroundColor: '#E5E7EB', marginVertical: 14 },
  successText: { fontSize: 14, color: '#4B5563' },
  successOrderId: { fontWeight: '700', color: '#4F46E5', fontSize: 16 },
  successSubtext: { fontSize: 13, color: '#6B7280', marginTop: 14, textAlign: 'center', lineHeight: 20 },
  registerButton: { flexDirection: 'row', backgroundColor: '#4F46E5', padding: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 20, gap: 8 },
  registerButtonText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  laterButton: { marginTop: 12, padding: 8 },
  laterButtonText: { color: '#9CA3AF', fontSize: 14 },
});
