import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image,
  ActivityIndicator, Alert, TextInput, Modal, KeyboardAvoidingView, Platform, AppState, Animated, StatusBar
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';
import Checkbox from 'expo-checkbox';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createOrder } from '../../services/orderService';
import { playSendSound } from '../../utils/SoundHelper';
import { useCart } from '../../context/CartContext';

const WAIT_TIME = 60;

export default function FulfillmentScreen({ route, navigation }) {
  const { cartItems: routeCartItems, serviceId, serviceName } = route.params || {};
  const { cartItems: ctxCartItems, clearCart } = useCart();
  const allItems = routeCartItems || ctxCartItems;

  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMerchants, setSelectedMerchants] = useState(new Set());
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);
  const [detailsModal, setDetailsModal] = useState(null);
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  const [orderStatus, setOrderStatus] = useState('selecting');
  const [waitTimeLeft, setWaitTimeLeft] = useState(WAIT_TIME);
  const [acceptedMerchant, setAcceptedMerchant] = useState(null);
  const [acceptedOrderId, setAcceptedOrderId] = useState(null);
  const [sentOrderIds, setSentOrderIds] = useState([]);
  const [waitingImage, setWaitingImage] = useState(null);
  const [waitingHeader, setWaitingHeader] = useState(null);
  const [topBarImage, setTopBarImage] = useState(null);
  const timerRef = useRef(null);
  const startTimeRef = useRef(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const [waitingMsg, setWaitingMsg] = useState('جاري إرسال طلبك للتجار...');

  useEffect(() => { loadUserData(); loadSettings(); analyzeCart(); }, []);

  // ✅ إعادة تحميل بيانات المستخدم عند العودة من CustomerAuth
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadUserData();
    });
    return unsubscribe;
  }, [navigation]);

  useEffect(() => {
    if (orderStatus === 'waiting') {
      Animated.loop(Animated.sequence([Animated.timing(pulseAnim, { toValue: 1.1, duration: 800, useNativeDriver: true }), Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true })])).start();
    } else { pulseAnim.setValue(1); }
  }, [orderStatus]);

  useEffect(() => {
    if (orderStatus === 'waiting') {
      const msgs = ['جاري إرسال طلبك للتجار...', 'في انتظار ردود مقدمي الخدمة...', 'سيتم إعلامك فور القبول...', 'مقدمي الخدمة يشاهدون طلبك الآن...'];
      let i = 0;
      const msgInterval = setInterval(() => { setWaitingMsg(msgs[i % msgs.length]); i++; }, 4000);
      return () => clearInterval(msgInterval);
    }
  }, [orderStatus]);

  useEffect(() => {
    if (orderStatus === 'waiting' && waitTimeLeft > 0) {
      timerRef.current = setInterval(() => {
        setWaitTimeLeft(prev => {
          if (prev <= 1) { clearInterval(timerRef.current); setOrderStatus('expired'); return 0; }
          if (prev % 5 === 0 && startTimeRef.current) { const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000); return Math.max(0, WAIT_TIME - elapsed); }
          return prev - 1;
        });
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [orderStatus, waitTimeLeft]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'active' && orderStatus === 'waiting' && startTimeRef.current) {
        const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        const remaining = Math.max(0, WAIT_TIME - elapsed);
        setWaitTimeLeft(remaining);
        if (remaining <= 0) { clearInterval(timerRef.current); setOrderStatus('expired'); }
      }
    });
    return () => subscription.remove();
  }, [orderStatus]);

  useEffect(() => {
    if (orderStatus === 'waiting' && sentOrderIds.length > 0) {
      const checkInterval = setInterval(async () => {
        const { data: orders } = await supabase.from('orders').select('id, status, merchant_name').in('id', sentOrderIds).eq('status', 'accepted').limit(1);
        if (orders && orders.length > 0) { clearInterval(checkInterval); setAcceptedMerchant(orders[0].merchant_name); setAcceptedOrderId(orders[0].id); setOrderStatus('accepted'); }
      }, 3000);
      return () => clearInterval(checkInterval);
    }
  }, [orderStatus, sentOrderIds]);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setUserData(user); setIsLoggedIn(true);
      setCustomerName(user.full_name || user.name || '');
      setCustomerPhone(user.phone || '');
      setAddress(user.address || await AsyncStorage.getItem('zayed_address') || '');
    } else {
      setIsLoggedIn(false);
      const savedAddress = await AsyncStorage.getItem('zayed_address');
      if (savedAddress) setAddress(savedAddress);
    }
  };

  const loadSettings = async () => {
    try {
      const { data } = await supabase.from('app_settings').select('*').eq('id', 1).single();
      if (data) {
        setWaitingImage(data.waiting_image_url || null);
        setWaitingHeader(data.waiting_header_url || null);
        setTopBarImage(data.top_bar_image_url || null);
      }
    } catch (e) {}
  };

  const analyzeCart = async () => {
    console.log('🛒 allItems:', JSON.stringify(allItems.map(i => ({ id: i.id, cartItemId: i.cartItemId, name: i.name }))));
    if (!allItems || allItems.length === 0) { setLoading(false); return; }
    if (!allItems.some(item => item.id || item.cartItemId)) { setLoading(false); return; }
    try {
      const productIds = allItems.map(item => item.id || item.cartItemId).filter(Boolean);
      console.log('🔍 analyzeCart - productIds:', productIds);
      const { data: priceEntries } = await supabase.from('all_merchant_products').select('merchant_id, id, price').in('id', productIds).eq('is_available', true);
      const merchantMap = {};
      for (const entry of (priceEntries || [])) {
        if (!merchantMap[entry.merchant_id]) merchantMap[entry.merchant_id] = { id: entry.merchant_id, products: {}, total: 0, deliveryFee: 0, name: '' };
        const cartItem = allItems.find(item => item.id === entry.id);
        const quantity = cartItem ? cartItem.quantity || 1 : 1;
        const price = parseFloat(entry.price || 0);
        merchantMap[entry.merchant_id].products[entry.id] = { price, quantity, name: cartItem?.name || '' };
        merchantMap[entry.merchant_id].total += price * quantity;
      }
      const eligible = Object.values(merchantMap).filter(m => { const ownedProductIds = Object.keys(m.products); return productIds.every(pid => ownedProductIds.includes(pid)); });
      console.log('📊 merchantMap:', JSON.stringify(Object.keys(merchantMap)));
      console.log('✅ eligible:', eligible.length);
      if (eligible.length === 0) { Alert.alert('عذراً', 'لا يوجد مقدم خدمة'); navigation.goBack(); return; }
      const merchantIds = eligible.map(m => m.id);
      const { data: merchantsData } = await supabase.from('merchants').select('id, name, delivery_fee, image_url').in('id', merchantIds);
      const finalMerchants = await Promise.all(eligible.map(async (m) => {
        const info = (merchantsData || []).find(md => md.id === m.id) || {};
        const { data: reviews } = await supabase.from('reviews').select('rating').eq('provider_id', info.id || m.id);
        let avgRating = 0, reviewCount = 0;
        if (reviews && reviews.length > 0) { reviewCount = reviews.length; avgRating = reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviewCount; }
        return { ...m, name: info.name || 'مقدم خدمة', deliveryFee: parseFloat(info.delivery_fee || 0), imageUrl: info.image_url, avgRating: Math.round(avgRating * 10) / 10, reviewCount };
      }));
      setMerchants(finalMerchants);
    } catch (e) { Alert.alert('خطأ', 'فشل تحليل الأسعار'); }
    finally { setLoading(false); }
  };

  const toggleMerchant = (id) => { if (orderStatus !== 'selecting') return; const newSet = new Set(selectedMerchants); newSet.has(id) ? newSet.delete(id) : newSet.add(id); setSelectedMerchants(newSet); };

  const handleSend = async () => {
    if (selectedMerchants.size === 0) { Alert.alert('تنبيه', 'اختر مقدم خدمة'); return; }
    if (!address.trim()) { Alert.alert('تنبيه', 'العنوان مطلوب'); return; }

    // ✅ لو مش مسجل، انقله لـ CustomerAuth
    if (!isLoggedIn) {
      navigation.navigate('CustomerAuth', {
        fromFulfillment: true,
        serviceId,
        serviceName,
        address,
        notes,
      });
      return;
    }

    // ✅ مسجل - أرسل الطلب مباشرة
    setSending(true);
    try {
      const orderIds = [];
      for (const mid of selectedMerchants) {
        const m = merchants.find(x => x.id === mid);
        const result = await createOrder({
          customer_name: customerName || 'عميل',
          customer_phone: customerPhone || '01000000000',
          customer_address: address,
          service_type: serviceId,
          service_name: serviceName,
          merchant_id: mid,
          merchant_name: m.name,
          items: Object.entries(m.products).map(([pid, d]) => `${d.name} x${d.quantity} = ${d.price * d.quantity} ج`),
          total_price: m.total,
          delivery_fee: m.deliveryFee,
          final_total: m.total + m.deliveryFee,
          notes,
          payment_method: 'cash_on_delivery',
          status: 'pending',
          is_guest: false,
          user_id: userData?.id || null
        });
        if (result.success) orderIds.push(result.data.id);
      }
      await AsyncStorage.setItem('zayed_address', address);
      clearCart();
      await playSendSound();
      setSentOrderIds(orderIds);
      setOrderStatus('waiting');
      setWaitTimeLeft(WAIT_TIME);
      startTimeRef.current = Date.now();
    } catch (e) { Alert.alert('خطأ', 'فشل الإرسال'); }
    finally { setSending(false); }
  };

  const handleRetry = () => { setOrderStatus('selecting'); setWaitTimeLeft(WAIT_TIME); setSentOrderIds([]); setAcceptedMerchant(null); setAcceptedOrderId(null); startTimeRef.current = null; };

  const handleCancelOrder = async () => {
    Alert.alert('إلغاء الطلب', 'هل أنت متأكد من إلغاء الطلب؟', [{ text: 'لا', style: 'cancel' }, { text: 'نعم', onPress: async () => {
      if (timerRef.current) clearInterval(timerRef.current);
      for (const oid of sentOrderIds) { await supabase.from('orders').update({ status: 'cancelled' }).eq('id', oid); }
      setOrderStatus('selecting'); setWaitTimeLeft(WAIT_TIME); setSentOrderIds([]); Alert.alert('تم', 'تم إلغاء الطلب');
    }}]);
  };

  const renderStars = (rating) => { const stars = []; const fullStars = Math.floor(rating); const halfStar = rating % 1 >= 0.5; const emptyStars = 5 - fullStars - (halfStar ? 1 : 0); for (let i = 0; i < fullStars; i++) stars.push('star'); if (halfStar) stars.push('star-half'); for (let i = 0; i < emptyStars; i++) stars.push('star-outline'); return stars; };

  if (loading) return <SafeAreaView style={styles.container}><ActivityIndicator size="large" color="#4F46E5" style={{marginTop:50}} /></SafeAreaView>;

  const getTopBarTitle = () => {
    if (orderStatus === 'accepted') return '🎉 تم قبول طلبك';
    if (orderStatus === 'waiting') return 'طلبك قيد المراجعة';
    if (orderStatus === 'expired') return 'انتهت مدة الانتظار';
    return 'اختر مقدمي الخدمة';
  };

  const renderTopBar = () => (
    <View style={styles.topBarContainer}>
      {topBarImage ? <Image source={{ uri: topBarImage }} style={styles.topBarImage} resizeMode="cover" /> : <View style={styles.topBarPlaceholder} />}
      <View style={styles.topBarOverlay}>
        <TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={22} color="#FFF" /></TouchableOpacity>
        <Text style={styles.topBarTitle}>{getTopBarTitle()}</Text>
        <View style={{ width: 40 }} />
      </View>
    </View>
  );

  if (orderStatus === 'waiting') {
    const progress = waitTimeLeft / WAIT_TIME;
    const selectedList = merchants.filter(m => selectedMerchants.has(m.id));
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        {renderTopBar()}
        <ScrollView contentContainerStyle={styles.waitingContainer} keyboardShouldPersistTaps="handled">
          <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>{waitingImage ? <Image source={{uri:waitingImage}} style={styles.waitingImage} resizeMode="contain" /> : <Ionicons name="time-outline" size={80} color="#4F46E5" />}</Animated.View>
          <Text style={styles.waitingMsgBig}>{waitingMsg}</Text>
          <View style={styles.timerBar}><View style={[styles.timerFill, {width: `${progress*100}%`}]} /></View>
          <Text style={styles.timerText}>{waitTimeLeft} ثانية متبقية</Text>
          {selectedList.length > 0 && (<View style={styles.selectedMerchantsList}><Text style={styles.selectedTitle}>تم الإرسال إلى:</Text><View style={styles.merchantsRow}>{selectedList.map(m => (<View key={m.id} style={styles.miniMerchantCard}>{m.imageUrl ? <Image source={{uri:m.imageUrl}} style={styles.miniMerchantImg} /> : <Ionicons name="storefront-outline" size={16} color="#6B7280" />}<Text style={styles.miniMerchantName}>{m.name}</Text></View>))}</View></View>)}
          <View style={styles.bottomActions}><TouchableOpacity style={styles.cancelOrderBtn} onPress={handleCancelOrder}><Ionicons name="close-circle-outline" size={18} color="#EF4444" /><Text style={styles.cancelOrderText}>إلغاء الطلب</Text></TouchableOpacity></View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (orderStatus === 'accepted') {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        {renderTopBar()}
        <View style={styles.waitingContainer}><Ionicons name="checkmark-circle" size={80} color="#10B981" /><Text style={styles.waitingMsgBig}>تم قبول طلبك!</Text><Text style={styles.waitingSubtitle}>{acceptedMerchant || 'مقدم خدمة'} سيتولى توصيل طلبك.</Text><TouchableOpacity style={styles.sendButton} onPress={() => navigation.navigate('OrderTrackingScreen', {orderId: acceptedOrderId})}><Text style={styles.sendText}>📋 تتبع الطلب</Text></TouchableOpacity></View>
      </SafeAreaView>
    );
  }

  if (orderStatus === 'expired') {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        {renderTopBar()}
        <View style={styles.waitingContainer}><Ionicons name="alert-circle" size={80} color="#F59E0B" /><Text style={styles.waitingMsgBig}>لم يقبل أي مقدم خدمة</Text><Text style={styles.waitingSubtitle}>انتهت مدة الانتظار دون قبول أي مقدم خدمة لطلبك.</Text><View style={styles.bottomActions}><TouchableOpacity style={styles.sendButton} onPress={handleRetry}><Text style={styles.sendText}>🔄 إعادة إرسال الطلب</Text></TouchableOpacity></View></View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {renderTopBar()}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{flex:1}} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.infoBanner}><Ionicons name="information-circle" size={24} color="#4F46E5" /><Text style={styles.infoText}>طلبك معروض على مقدمي الخدمة أدناه. اختر من تريد إرسال الطلب إليهم. أول من يقبل سيتولى توصيل طلبك.</Text></View>
          <Text style={styles.sectionTitle}>{merchants.length} مقدم خدمة متوفر</Text>
          {merchants.map((m) => (
            <View key={m.id} style={styles.merchantCard}>
              <View style={styles.merchantHeader}><View style={styles.priceTag}><Text style={styles.priceText}>{m.total + m.deliveryFee} ج</Text></View>
                <View style={styles.merchantIdentityBox}>{m.imageUrl ? <Image source={{uri:m.imageUrl}} style={styles.merchantImage} /> : <View style={styles.merchantImagePlaceholder}><Ionicons name="storefront-outline" size={20} color="#6B7280" /></View>}<View style={styles.merchantInfo}><Text style={styles.merchantName}>{m.name}</Text><View style={styles.ratingRow}>{m.reviewCount > 0 ? <>{renderStars(m.avgRating).map((icon,i) => <Ionicons key={i} name={icon} size={12} color="#F59E0B" />)}<Text style={styles.ratingText}>{m.avgRating} ({m.reviewCount})</Text></> : <Text style={styles.ratingText}>جديد</Text>}</View></View></View>
                <Checkbox value={selectedMerchants.has(m.id)} onValueChange={() => toggleMerchant(m.id)} color={selectedMerchants.has(m.id) ? '#4F46E5' : undefined} />
              </View>
              <View style={styles.productsList}>{Object.entries(m.products).map(([pid,details]) => <View key={pid} style={styles.productRow}><Text style={styles.productPrice}>{details.price * details.quantity} ج</Text><Text style={styles.productName}>{details.name} ×{details.quantity}</Text></View>)}<View style={styles.deliveryRow}><View style={styles.deliveryLeft}><Ionicons name="bicycle" size={14} color="#6B7280" /><Text style={styles.deliveryText}>رسوم التوصيل: {m.deliveryFee} ج</Text></View><TouchableOpacity onPress={() => setDetailsModal(m)}><Ionicons name="information-circle-outline" size={20} color="#4F46E5" /></TouchableOpacity></View></View>
            </View>
          ))}
          <View style={styles.deliverySection}><View style={styles.sectionHeader}><Text style={styles.sectionTitle2}>📞 بيانات التوصيل</Text></View>{isLoggedIn ? <><View style={styles.readonlyField}><Ionicons name="person-outline" size={18} color="#6B7280" /><Text style={styles.readonlyText}>{customerName}</Text></View><View style={styles.readonlyField}><Ionicons name="call-outline" size={18} color="#6B7280" /><Text style={styles.readonlyText}>{customerPhone}</Text></View></> : null}<TextInput style={styles.input} placeholder="العنوان *" value={address} onChangeText={setAddress} textAlign="right" /><TextInput style={styles.input} placeholder="ملاحظات (اختياري)" value={notes} onChangeText={setNotes} textAlign="right" multiline /></View>
          <TouchableOpacity style={[styles.sendButton, selectedMerchants.size===0 && styles.disabled]} onPress={handleSend} disabled={selectedMerchants.size===0||sending}>
            {sending ? <ActivityIndicator color="#FFF" /> : <Text style={styles.sendText}>
              {!isLoggedIn ? 'تسجيل الدخول وإرسال الطلب' : `إرسال الطلب للتجار المحددين (${selectedMerchants.size})`}
            </Text>}
          </TouchableOpacity>
          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
      <Modal visible={!!detailsModal} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}><Text style={styles.modalTitle}>تفاصيل {detailsModal?.name}</Text>{detailsModal?.products && Object.entries(detailsModal.products).map(([pid,d]) => <View key={pid} style={styles.detailRow}><Text style={styles.detailPrice}>{d.price * d.quantity} ج</Text><Text style={styles.detailName}>{d.name} ×{d.quantity}</Text></View>)}<View style={styles.detailRow}><Text style={styles.detailName}>🚚 رسوم التوصيل: {detailsModal?.deliveryFee || 0} ج</Text></View><View style={styles.detailTotal}><Text style={styles.totalLabel}>الإجمالي:</Text><Text style={styles.totalValue}>{(detailsModal?.total || 0) + (detailsModal?.deliveryFee || 0)} ج</Text></View><TouchableOpacity style={styles.closeButton} onPress={() => setDetailsModal(null)}><Text style={styles.closeButtonText}>إغلاق</Text></TouchableOpacity></View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  content: { padding:16, paddingBottom:40 },
  topBarContainer: { height: 60, position: 'relative' },
  topBarImage: { width: '100%', height: '100%', position: 'absolute' },
  topBarPlaceholder: { width: '100%', height: '100%', position: 'absolute', backgroundColor: '#4F46E5' },
  topBarOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, backgroundColor: 'rgba(0,0,0,0.15)' },
  topBarTitle: { fontSize: 16, fontWeight: '700', color: '#FFF', fontFamily: fontFamily.arabic, textAlign: 'center', flex: 1, textShadowColor: 'rgba(0,0,0,0.8)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 4 },
  backCircle: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  infoBanner: { flexDirection:'row', alignItems:'flex-start', backgroundColor:'#EEF2FF', borderRadius:12, padding:12, marginBottom:16, gap:8 },
  infoText: { flex:1, fontSize:13, color:"#4F46E5", fontFamily:fontFamily.arabic, lineHeight:20, textAlign:"right" },
  sectionTitle: { fontSize:14, color:'#6B7280', marginBottom:12, fontFamily:fontFamily.arabic },
  merchantCard: { backgroundColor:'#FFF', borderRadius:16, padding:16, marginBottom:16, borderWidth:1, borderColor:'#E5E7EB', elevation:2 },
  merchantHeader: { flexDirection:'row', alignItems:'center', gap:8, marginBottom:12 },
  priceTag: { backgroundColor:'#10B98120', paddingHorizontal:10, paddingVertical:5, borderRadius:8, borderWidth:1, borderColor:'#10B981' },
  priceText: { fontSize:14, fontWeight:'700', color:'#10B981' },
  merchantIdentityBox: { flex:1, flexDirection:'row', alignItems:'center', justifyContent:'center', gap:8 },
  merchantImage: { width:36, height:36, borderRadius:18, backgroundColor:'#F3F4F6' },
  merchantImagePlaceholder: { width:36, height:36, borderRadius:18, backgroundColor:'#F3F4F6', justifyContent:'center', alignItems:'center' },
  merchantInfo: { alignItems:'center' },
  merchantName: { fontSize:15, fontWeight:'600', color:'#1F2937', fontFamily:fontFamily.arabic },
  ratingRow: { flexDirection:'row', alignItems:'center', gap:3, marginTop:2 },
  ratingText: { fontSize:11, color:'#F59E0B', fontFamily:fontFamily.arabic },
  productsList: { borderTopWidth:1, borderTopColor:'#F3F4F6', paddingTop:12 },
  productRow: { flexDirection:'row', justifyContent:'space-between', marginBottom:6 },
  productName: { fontSize:13, color:'#4B5563', fontFamily:fontFamily.arabic, flex:1, textAlign:'right' },
  productPrice: { fontSize:13, fontWeight:'600', color:'#4F46E5', marginRight:12 },
  deliveryRow: { flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginTop:8, paddingTop:8, borderTopWidth:1, borderTopColor:'#F3F4F6' },
  deliveryLeft: { flexDirection:'row', alignItems:'center', gap:4 },
  deliveryText: { fontSize:12, color:'#6B7280', fontFamily:fontFamily.arabic },
  deliverySection: { marginTop:24 },
  sectionHeader: { flexDirection:'row', alignItems:'flex-end', marginBottom:12 },
  sectionTitle2: { fontSize:16, fontWeight:'700', color:'#1F2937', fontFamily:fontFamily.arabic },
  readonlyField: { flexDirection:'row', alignItems:'center', backgroundColor:'#F3F4F6', borderRadius:8, padding:12, marginBottom:8, gap:8 },
  readonlyText: { fontSize:14, color:'#1F2937', fontFamily:fontFamily.arabic, flex:1, textAlign:'right' },
  input: { backgroundColor:'#FFF', borderWidth:1, borderColor:'#E5E7EB', borderRadius:8, padding:12, marginBottom:10, fontSize:14, fontFamily:fontFamily.arabic },
  sendButton: { backgroundColor:'#4F46E5', padding:16, borderRadius:12, alignItems:'center', marginTop:20 },
  disabled: { opacity:0.5 },
  sendText: { color:'#FFF', fontSize:16, fontWeight:'600', fontFamily:fontFamily.arabic },
  modalOverlay: { flex:1, backgroundColor:'rgba(0,0,0,0.5)', justifyContent:'center', padding:20 },
  modalContent: { backgroundColor:'#FFF', borderRadius:16, padding:20 },
  modalTitle: { fontSize:18, fontWeight:'bold', color:'#1F2937', marginBottom:16, fontFamily:fontFamily.arabic, textAlign:'center' },
  detailRow: { flexDirection:'row', justifyContent:'space-between', marginBottom:8, paddingBottom:8, borderBottomWidth:1, borderBottomColor:'#F3F4F6' },
  detailName: { fontSize:14, color:'#4B5563', fontFamily:fontFamily.arabic, flex:1 },
  detailPrice: { fontSize:14, fontWeight:'600', color:'#4F46E5' },
  detailTotal: { flexDirection:'row', justifyContent:'space-between', marginTop:12, paddingTop:12, borderTopWidth:1, borderTopColor:'#E5E7EB' },
  totalLabel: { fontSize:16, fontWeight:'600', color:'#1F2937', fontFamily:fontFamily.arabic },
  totalValue: { fontSize:18, fontWeight:'800', color:'#10B981' },
  closeButton: { marginTop:16, alignSelf:'center', padding:12 },
  closeButtonText: { color:'#4F46E5', fontSize:16, fontWeight:'600' },
  waitingContainer: { flexGrow:1, justifyContent:'flex-start', alignItems:'center', paddingTop:20, padding:40, backgroundColor:'#FFFFFF' },
  waitingImage: { width:250, height:250, marginBottom:20, borderRadius:20 },
  waitingMsgBig: { fontSize:22, fontWeight:'700', color:'#1F2937', marginTop:10, textAlign:'center', fontFamily:fontFamily.arabic, lineHeight:30 },
  waitingSubtitle: { fontSize:14, color:'#6B7280', marginTop:10, textAlign:'center', fontFamily:fontFamily.arabic, lineHeight:22 },
  timerBar: { width:'80%', height:6, backgroundColor:'#E5E7EB', borderRadius:3, marginTop:30, overflow:'hidden' },
  timerFill: { height:'100%', backgroundColor:'#4F46E5', borderRadius:3 },
  timerText: { fontSize:14, color:'#4F46E5', marginTop:10, fontWeight:'600', fontFamily:fontFamily.arabic },
  selectedMerchantsList: { width:'100%', marginTop:30, paddingHorizontal:20 },
  selectedTitle: { fontSize:14, fontWeight:'600', color:'#1F2937', marginBottom:10, fontFamily:fontFamily.arabic, textAlign:'center' },
  merchantsRow: { flexDirection:'row', flexWrap:'wrap', justifyContent:'center', gap:8 },
  miniMerchantCard: { flexDirection:'row', alignItems:'center', backgroundColor:'#FFF', paddingHorizontal:10, paddingVertical:6, borderRadius:20, borderWidth:1, borderColor:'#E5E7EB', gap:6 },
  miniMerchantImg: { width:24, height:24, borderRadius:12 },
  miniMerchantName: { fontSize:12, color:'#4B5563', fontFamily:fontFamily.arabic },
  bottomActions: { width:'100%', alignItems:'center', marginTop:30, paddingBottom:40 },
  cancelOrderBtn: { flexDirection:'row', alignItems:'center', padding:10, gap:6 },
  cancelOrderText: { fontSize:14, color:'#EF4444', fontFamily:fontFamily.arabic, fontWeight:'600' },
});
