import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView,
  ActivityIndicator, Alert, Linking, Image, Modal, Animated, StatusBar, Platform
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { ORDER_STATUS, cancelOrder } from '../../services/orderService';
import { fontFamily } from '../../utils/fonts';

const DEFAULT_STEPS = [
  { step_key: ORDER_STATUS.PENDING, label: 'معلق', icon: 'time-outline' },
  { step_key: ORDER_STATUS.ACCEPTED, label: 'تم القبول', icon: 'checkmark-circle-outline' },
  { step_key: ORDER_STATUS.PREPARING, label: 'تجهيز', icon: 'construct-outline' },
  { step_key: ORDER_STATUS.DRIVER_ASSIGNED, label: 'مندوب', icon: 'person-outline' },
  { step_key: ORDER_STATUS.ON_THE_WAY, label: 'توصيل', icon: 'bicycle-outline' },
  { step_key: ORDER_STATUS.DELIVERED, label: 'تم التوصيل', icon: 'checkmark-done-circle-outline' },
];

// ✅ الحالات النهائية اللي لو وصلها الطلب يظهر التقييم
const FINAL_STATUSES = [ORDER_STATUS.DELIVERED, ORDER_STATUS.CANCELLED];

export default function OrderTrackingScreen({ route, navigation }) {
  const orderId = route.params?.orderId || route.params?.id;
  const [order, setOrder] = useState(null);
  const [serviceData, setServiceData] = useState(null);
  const [steps, setSteps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showRateModal, setShowRateModal] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (!orderId) { Alert.alert('خطأ', 'رقم الطلب غير موجود'); navigation.goBack(); return; }
    loadOrder();
    const interval = setInterval(loadOrder, 5000);
    return () => clearInterval(interval);
  }, [orderId]);

  const loadSteps = async (serviceType) => {
    const { data } = await supabase
      .from('service_tracking_steps')
      .select('*')
      .eq('service_id', serviceType)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (data && data.length > 0) {
      const loadedSteps = data.map(s => ({ ...s, sub: s.description || '' }));
      setSteps(loadedSteps);
      return loadedSteps;
    } else {
      setSteps(DEFAULT_STEPS);
      return DEFAULT_STEPS;
    }
  };

  const loadOrder = async () => {
    if (!orderId) return;
    try {
      const { data } = await supabase.from(TABLES.ORDERS).select('*').eq('id', orderId).single();
      if (!data) return;
      setOrder(data);
      if (data.service_type) {
        const loadedSteps = await loadSteps(data.service_type);
        const { data: svc } = await supabase.from(TABLES.SERVICES).select('*').eq('id', data.service_type).single();
        if (svc) setServiceData(svc);

        // ✅ الحصول على آخر خطوة
        const lastStepKey = loadedSteps.length > 0 
          ? loadedSteps[loadedSteps.length - 1].step_key 
          : ORDER_STATUS.DELIVERED;

        // ✅ لو الطلب وصل لآخر خطوة أو CANCELLED
        if (data.status === lastStepKey || FINAL_STATUSES.includes(data.status)) {
          const rateShown = await AsyncStorage.getItem(`rate_shown_${orderId}`);
          if (!rateShown) {
            const { data: review } = await supabase.from("reviews").select("id").eq("order_id", orderId).maybeSingle();
            if (!review) {
              setShowRateModal(true);
              await AsyncStorage.setItem(`rate_shown_${orderId}`, 'true');
            }
          }
        }
      }
    } catch (error) { console.log(error); }
    finally { setLoading(false); }
  };

  const getStepStatus = (stepKey) => {
    if (!order?.status) return 'pending';
    const currentIdx = steps.findIndex(s => s.step_key === order.status);
    const stepIdx = steps.findIndex(s => s.step_key === stepKey);
    if (currentIdx > stepIdx) return 'completed';
    if (currentIdx === stepIdx) return 'current';
    return 'pending';
  };

  const serviceColor = serviceData?.color || '#8B5CF6';
  const trackingImage = serviceData?.tracking_image;
  const currentStep = steps.find(s => s.step_key === order?.status);

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={serviceColor} /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

      <View style={styles.header}>
        <TouchableOpacity style={styles.backCircle} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color="#FFF" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>
          تتبع الطلب #{String(orderId).slice(-6)}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {trackingImage ? (
          <View style={styles.trackingContainer}>
            <Image source={{ uri: trackingImage }} style={styles.trackingImage} resizeMode="cover" />
            <View style={styles.statusTextOverlay}>
              <Text style={styles.statusTextOverlayContent}>
                {steps.find(s => s.step_key === order?.status)?.label || 'قيد التنفيذ'}
              </Text>
            </View>
          </View>
        ) : (
          <View style={[styles.statusCard, { backgroundColor: serviceColor + '15' }]}>
            <Ionicons name="time-outline" size={50} color={serviceColor} />
            <Text style={[styles.statusText, { color: serviceColor }]}>
              {steps.find(s => s.step_key === order?.status)?.label || 'قيد التنفيذ'}
            </Text>
          </View>
        )}

        {currentStep?.attachment_url && (
          <TouchableOpacity style={styles.attachmentCard} onPress={() => setSelectedImage(currentStep.attachment_url)}>
            <Text style={styles.attachmentTitle}>🖼️ {currentStep.label}</Text>
            <Image source={{ uri: currentStep.attachment_url }} style={styles.attachmentImage} resizeMode="cover" />
            <Text style={styles.attachmentHint}>اضغط للتكبير</Text>
          </TouchableOpacity>
        )}

        <View style={styles.trackingSection}>
          <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>📋 مراحل الطلب</Text>
          <View style={styles.stepsRow}>
            {steps.map((step, index) => {
              const status = getStepStatus(step.step_key);
              const isCompleted = status === 'completed';
              const isCurrent = status === 'current';
              return (
                <View key={step.step_key || index} style={styles.stepItem}>
                  {index > 0 && (
                    <View style={[styles.connector, { left: '-50%', right: '50%' }, isCompleted && { backgroundColor: serviceColor }]} />
                  )}
                  <View style={[styles.stepCircle, isCompleted && { backgroundColor: serviceColor, borderColor: serviceColor }, isCurrent && { backgroundColor: '#FFF', borderColor: serviceColor, borderWidth: 3, width: 52, height: 52, borderRadius: 26, shadowColor: serviceColor, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 8 }, isCompleted && { width: 38, height: 38, borderRadius: 19 }]}>
                    {isCurrent && (
                      <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                        {step.image_url ? <Image source={{ uri: step.image_url }} style={styles.stepCircleImage} /> : <Ionicons name={step.icon || 'ellipse'} size={22} color={serviceColor} />}
                      </Animated.View>
                    )}
                    {isCompleted && (step.image_url ? <Image source={{ uri: step.image_url }} style={styles.stepCircleImageSmall} /> : <Ionicons name="checkmark" size={16} color="#FFF" />)}
                    {!isCompleted && !isCurrent && (step.image_url ? <Image source={{ uri: step.image_url }} style={styles.stepCircleImageSmall} /> : <Ionicons name={step.icon || 'ellipse-outline'} size={14} color="#D1D5DB" />)}
                  </View>
                  <Text style={[styles.stepLabel, isCurrent && { color: serviceColor, fontWeight: '700', fontSize: 11 }, isCompleted && { color: serviceColor, fontWeight: '600' }]} numberOfLines={1}>{step.label}</Text>
                  {isCurrent && step.sub && <Text style={[styles.stepSub, { color: serviceColor }]} numberOfLines={1}>{step.sub}</Text>}
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>📋 تفاصيل الطلب</Text>
          <View style={styles.infoCard}>
            <Text style={[styles.serviceName, { fontFamily: fontFamily.arabic }]}>{order?.merchant_name || order?.service_name}</Text>
            <View style={styles.infoRow}><Ionicons name="call-outline" size={18} color="#6B7280" /><Text style={styles.infoLabel}>رقم العميل:</Text><TouchableOpacity onPress={() => order?.customer_phone && Linking.openURL(`tel:${order.customer_phone}`)}><Text style={[styles.infoValue, styles.phoneLink]}>{order?.customer_phone}</Text></TouchableOpacity></View>
            <View style={styles.infoRow}><Ionicons name="location-outline" size={18} color="#6B7280" /><Text style={styles.infoLabel}>العنوان:</Text><Text style={styles.infoValue}>{order?.customer_address}</Text></View>
            {order?.items?.length > 0 && (<View style={styles.itemsContainer}><Text style={styles.itemsTitle}>المنتجات:</Text>{order.items.map((item, i) => <Text key={i} style={styles.itemText}>• {item}</Text>)}</View>)}
          </View>
        </View>

        {order?.total_price > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>💰 الفاتورة</Text>
            <View style={styles.invoiceCard}>
              <View style={styles.invoiceRow}><Text style={styles.invoiceLabel}>قيمة الطلب:</Text><Text style={styles.invoiceValue}>{order.total_price} ج</Text></View>
              {order.delivery_fee > 0 && (<View style={styles.invoiceRow}><Text style={styles.invoiceLabel}>تكلفة التوصيل:</Text><Text style={styles.invoiceValue}>{order.delivery_fee} ج</Text></View>)}
              <View style={styles.invoiceTotal}><Text style={styles.totalLabel}>الإجمالي:</Text><Text style={styles.totalValue}>{order.final_total || order.total_price} ج</Text></View>
            </View>
          </View>
        )}

        {order?.merchant_name && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>🏪 معلومات التاجر</Text>
            <View style={styles.contactCard}>
              <View style={styles.contactRow}><Ionicons name="business-outline" size={20} color="#F59E0B" /><Text style={styles.contactName}>{order.merchant_place || order.merchant_name}</Text></View>
              {order.merchant_phone && (<TouchableOpacity style={styles.contactButton} onPress={() => Linking.openURL(`tel:${order.merchant_phone}`)}><Ionicons name="call" size={18} color="#FFF" /><Text style={styles.contactButtonText}>اتصل بالتاجر</Text></TouchableOpacity>)}
            </View>
          </View>
        )}

        {order?.status === ORDER_STATUS.PENDING && (
          <TouchableOpacity style={[styles.cancelBtn]} onPress={() => {
            Alert.alert('إلغاء الطلب', 'هل أنت متأكد؟', [
              { text: 'لا', style: 'cancel' },
              { text: 'نعم، إلغاء', style: 'destructive', onPress: async () => {
                  const result = await cancelOrder(order.id, 'تم الإلغاء بواسطة العميل');
                  if (result.success) { Alert.alert('✅ تم', 'تم إلغاء الطلب'); loadOrder(); }
                  else Alert.alert('خطأ', result.error);
                }
              }
            ]);
          }}>
            <Ionicons name="close-circle-outline" size={20} color="#FFF" />
            <Text style={styles.cancelBtnText}>إلغاء الطلب</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 30 }} />
      </ScrollView>

      {/* Modal تقييم تلقائي */}
      <Modal visible={showRateModal} transparent animationType="fade">
        <View style={styles.rateModalOverlay}>
          <View style={styles.rateModalContent}>
            <Ionicons name="star" size={50} color="#F59E0B" />
            <Text style={styles.rateTitle}>تقيم الخدمة</Text>
            <Text style={styles.rateSubtitle}>هل تريد تقييم {order?.merchant_name || "التاجر"}؟</Text>
            <View style={styles.rateButtons}>
              <TouchableOpacity style={styles.rateLaterBtn} onPress={() => setShowRateModal(false)}>
                <Text>لاحقاً</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.rateNowBtn} onPress={() => { setShowRateModal(false); navigation.navigate("RateOrderScreen", { orderId: order.id, providerId: order.merchant_id, providerName: order.merchant_name }); }}>
                <Text style={{ color: "#FFF" }}>تقييم الآن</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedImage} transparent animationType="fade">
        <View style={styles.imageModalOverlay}>
          <TouchableOpacity style={styles.closeImageButton} onPress={() => setSelectedImage(null)}><Ionicons name="close" size={34} color="#FFF" /></TouchableOpacity>
          {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImage} resizeMode="contain" />}
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB'
  },
  backCircle: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center', alignItems: 'center'
  },
  headerTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', flex: 1, textAlign: 'center' },
  content: { padding: 16 },
  trackingContainer: { width: '100%', height: 130, borderRadius: 14, marginBottom: 16, overflow: 'hidden' },
  trackingImage: { width: '100%', height: '100%' },
  statusTextOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.55)', padding: 10, alignItems: 'center' },
  statusTextOverlayContent: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  statusCard: { alignItems: 'center', padding: 24, borderRadius: 14, marginBottom: 16 },
  statusText: { fontSize: 18, fontWeight: '700', marginTop: 8 },
  attachmentCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 12, marginBottom: 18, borderWidth: 1, borderColor: '#E5E7EB' },
  attachmentTitle: { fontSize: 14, fontWeight: '700', color: '#1F2937', marginBottom: 10, textAlign: 'right' },
  attachmentImage: { width: '100%', height: 200, borderRadius: 10 },
  attachmentHint: { fontSize: 11, color: '#9CA3AF', textAlign: 'center', marginTop: 6 },
  trackingSection: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, marginBottom: 18, borderWidth: 1, borderColor: '#E5E7EB' },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#1F2937', marginBottom: 20 },
  stepsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 4 },
  stepItem: { flex: 1, alignItems: 'center', position: 'relative' },
  connector: { position: 'absolute', top: 18, height: 2, backgroundColor: '#E5E7EB', zIndex: 0 },
  stepCircle: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#E5E7EB', zIndex: 1, overflow: 'hidden' },
  stepCircleImage: { width: 40, height: 40, borderRadius: 20, resizeMode: 'cover' },
  stepCircleImageSmall: { width: 28, height: 28, borderRadius: 14, resizeMode: 'cover' },
  stepLabel: { fontSize: 9, color: '#9CA3AF', textAlign: 'center', marginTop: 8, maxWidth: 60 },
  stepSub: { fontSize: 8, textAlign: 'center', marginTop: 2, maxWidth: 60 },
  section: { marginBottom: 18 },
  infoCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  serviceName: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 12 },
  infoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
  infoLabel: { fontSize: 14, color: '#6B7280', width: 70 },
  infoValue: { fontSize: 14, color: '#1F2937', flex: 1 },
  phoneLink: { color: '#3B82F6', textDecorationLine: 'underline' },
  itemsContainer: { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  itemsTitle: { fontSize: 14, fontWeight: '600', color: '#1F2937', marginBottom: 4 },
  itemText: { fontSize: 13, color: '#6B7280', marginBottom: 2 },
  invoiceCard: { backgroundColor: '#FEF3C7', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#F59E0B' },
  invoiceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  invoiceLabel: { fontSize: 14, color: '#92400E' },
  invoiceValue: { fontSize: 14, fontWeight: '600', color: '#92400E' },
  invoiceTotal: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#F59E0B' },
  totalLabel: { fontSize: 16, fontWeight: '600', color: '#92400E' },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#92400E' },
  contactCard: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  contactRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
  contactName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  contactButton: { backgroundColor: '#F59E0B', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 10, borderRadius: 8, gap: 6 },
  contactButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  cancelBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EF4444', padding: 14, borderRadius: 12, gap: 8 },
  cancelBtnText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center', alignItems: 'center' },
  closeImageButton: { position: 'absolute', top: 50, right: 20, zIndex: 10 },
  fullImage: { width: '92%', height: '75%' },
  rateModalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", alignItems: "center", padding: 20 },
  rateModalContent: { backgroundColor: "#FFF", borderRadius: 20, padding: 30, alignItems: "center", width: "85%" },
  rateTitle: { fontSize: 22, fontWeight: "700", marginTop: 12, color: "#1F2937" },
  rateSubtitle: { fontSize: 14, color: "#6B7280", marginTop: 8, textAlign: "center" },
  rateButtons: { flexDirection: "row", gap: 12, marginTop: 24 },
  rateLaterBtn: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: "#F3F4F6", alignItems: "center" },
  rateNowBtn: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: "#F59E0B", alignItems: "center" },
});
