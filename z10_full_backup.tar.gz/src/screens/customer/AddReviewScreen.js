import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function AddReviewScreen({ route, navigation }) {
  const { productId, productName } = route.params;
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  const submitReview = async () => {
    if (rating === 0) { Alert.alert('تنبيه', 'اختر تقييم بالنجوم'); return; }
    setSaving(true);
    try {
      const userDataStr = await AsyncStorage.getItem('userData');
      const user = userDataStr ? JSON.parse(userDataStr) : null;
      console.log('📝 productId:', productId);
      console.log('👤 user:', user?.full_name);
      const { error } = await supabase.from('shop_reviews').insert([{
        product_id: productId,
        customer_name: user?.full_name || user?.name || 'عميل',
        customer_id: user?.id || null,
        customer_image_url: user?.image_url || null,
        rating,
        comment: comment.trim(),
        is_approved: false,
      }]);
      if (error) {
        console.log('❌ supabase error:', error.message);
        Alert.alert('خطأ', error.message);
      } else {
        console.log('✅ تم الحفظ');
        Alert.alert('✅ تم', 'تم إرسال تقييمك وسيظهر بعد موافقة الأدمن');
        navigation.goBack();
      }
    } catch (e) {
      console.log('❌ catch error:', e.message);
      Alert.alert('خطأ', e.message);
    }
    setSaving(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>تقييم {productName}</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.label}>تقييمك</Text>
        <View style={styles.starsRow}>
          {[1, 2, 3, 4, 5].map(s => (
            <TouchableOpacity key={s} onPress={() => setRating(s)}>
              <Ionicons name={s <= rating ? 'star' : 'star-outline'} size={40} color="#F59E0B" />
            </TouchableOpacity>
          ))}
        </View>
        <Text style={styles.label}>تعليقك (اختياري)</Text>
        <TextInput style={styles.input} value={comment} onChangeText={setComment} multiline placeholder="اكتب تعليقك عن المنتج..." placeholderTextColor="#9CA3AF" textAlignVertical="top" />
        <TouchableOpacity style={[styles.submitBtn, saving && { opacity: 0.6 }]} onPress={submitReview} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.submitText}>إرسال التقييم</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  label: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 12, marginTop: 20 },
  starsRow: { flexDirection: 'row', gap: 12, justifyContent: 'center' },
  input: { backgroundColor: '#FFF', borderRadius: 12, padding: 14, fontSize: 15, minHeight: 120, borderWidth: 1, borderColor: '#E5E7EB' },
  submitBtn: { backgroundColor: '#F59E0B', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 30 },
  submitText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
