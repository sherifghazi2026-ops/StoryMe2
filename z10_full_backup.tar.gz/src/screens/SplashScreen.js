import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Dimensions, StatusBar, Image, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Video from 'react-native-video';

const { width, height } = Dimensions.get('window');

export default function SplashScreen({ navigation }) {
  const timeoutRef = useRef(null);
  const [splashType, setSplashType] = useState('gif');
  const [splashGifUrl, setSplashGifUrl] = useState(null);
  const [splashVideoUrl, setSplashVideoUrl] = useState(null);
  const [splashText, setSplashText] = useState('مرحباً بك في زد');
  const [appVersion, setAppVersion] = useState('ZID V1.0.0');
  const [splashTextColor, setSplashTextColor] = useState('#FFFFFF');
  const [splashBgColor, setSplashBgColor] = useState('#1a1a2e');
  const [logoUrl, setLogoUrl] = useState(null);

  useEffect(() => {
    loadSettingsAndNavigate();
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const loadSettingsAndNavigate = async () => {
    try {
      const settingsStr = await AsyncStorage.getItem('appSettings');
      if (settingsStr) {
        const settings = JSON.parse(settingsStr);

        setSplashType(settings.splash_type || 'gif');
        setSplashGifUrl(settings.splash_gif_url || null);
        setSplashVideoUrl(settings.splash_video_url || null);
        setSplashText(settings.splash_text || 'مرحباً بك في زد');
        setAppVersion(settings.app_version || 'ZID V1.0.0');
        setSplashTextColor(settings.splash_text_color || '#FFFFFF');
        setSplashBgColor(settings.splash_bg_color || '#1a1a2e');
        setLogoUrl(settings.app_logo_url || null);

        const durationMode = settings.duration_mode || 'auto';
        let duration = settings.splash_duration || 5000;

        console.log(`📊 الإعدادات: mode=${durationMode}, duration=${duration}`);

        if (splashType === 'video' && splashVideoUrl && durationMode === 'auto') {
          console.log(`🎬 وضع "تلقائي" للفيديو`);
        } else {
          console.log(`⏱️ وضع "محدد". سيتم الانتقال بعد ${duration} مللي ثانية.`);
          timeoutRef.current = setTimeout(() => navigateToApp(), duration);
        }
      } else {
        timeoutRef.current = setTimeout(() => navigateToApp(), 5000);
      }
    } catch (error) {
      console.log('خطأ:', error);
      timeoutRef.current = setTimeout(() => navigateToApp(), 5000);
    }
  };

  const onLoadVideo = (data) => {
    if (data && data.duration) {
      const durationInMs = data.duration * 1000;
      console.log(`✅ تم تحميل الفيديو. المدة: ${data.duration} ثانية`);

      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        console.log('🚀 انتهت مدة الفيديو');
        navigateToApp();
      }, durationInMs);
    } else {
      console.warn('⚠️ لم نتمكن من معرفة مدة الفيديو');
      timeoutRef.current = setTimeout(() => navigateToApp(), 10000);
    }
  };

  const onErrorVideo = (error) => {
    console.error('❌ خطأ في تحميل الفيديو:', error);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => navigateToApp(), 5000);
  };

  const navigateToApp = async () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    try {
      const userDataStr = await AsyncStorage.getItem('userData');
      if (userDataStr) {
        const user = JSON.parse(userDataStr);
        if (user.role === 'merchant') { navigation.replace('MerchantDashboard'); return; }
        if (user.role === 'driver') { navigation.replace('DriverDashboard'); return; }
        if (user.role === 'admin') { navigation.replace('AdminHome'); return; }
      }
      navigation.replace('MainTabs');
    } catch (e) { navigation.replace('MainTabs'); }
  };

  const handleSkip = () => {
    navigateToApp();
  };

  if (splashType === 'video' && splashVideoUrl) {
    return (
      <View style={styles.videoContainer}>
        <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
        <Video
          source={{ uri: splashVideoUrl }}
          style={styles.fullVideo}
          resizeMode="stretch"
          onLoad={onLoadVideo}
          onError={onErrorVideo}
          repeat={false}
          paused={false}
          volume={1.0}
          controls={false}
          playInBackground={false}
          playWhenInactive={false}
          ignoreSilentSwitch="ignore"
        />
        <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
          <Text style={styles.skipText}>تخطي</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: splashBgColor }]}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      {splashGifUrl ? (
        <Image source={{ uri: splashGifUrl }} style={styles.fullImage} resizeMode="cover" />
      ) : null}

      <View style={styles.overlay}>
        <View style={styles.content}>
          <View style={styles.logoWrapper}>
            {logoUrl ? (
              <Image source={{ uri: logoUrl }} style={styles.logo} resizeMode="contain" />
            ) : (
              <Image source={require('../../assets/icons/ZidiconSP.png')} style={styles.logo} resizeMode="contain" />
            )}
          </View>

          <View style={styles.textContainer}>
            <Text style={[styles.mainTitle, { color: splashTextColor }]}>{splashText}</Text>
            <View style={[styles.accentLine, { backgroundColor: splashTextColor === '#FFFFFF' ? '#8B5CF6' : splashTextColor }]} />
          </View>
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerBrand, { color: splashTextColor === '#FFFFFF' ? 'rgba(255,255,255,0.7)' : splashTextColor + '80' }]}>
            {appVersion}
          </Text>
        </View>
      </View>

      <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
        <Text style={styles.skipText}>تخطي</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  videoContainer: { flex: 1, backgroundColor: '#000' },
  fullImage: { width, height, position: 'absolute' },
  fullVideo: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: { alignItems: 'center' },
  logoWrapper: { width: width * 0.55, height: width * 0.55, justifyContent: 'center', alignItems: 'center' },
  logo: { width: '100%', height: '100%' },
  textContainer: { marginTop: 0, alignItems: 'center' },
  mainTitle: { fontSize: 23, fontWeight: '500', textAlign: 'center', letterSpacing: 0.5, textShadowColor: 'rgba(0,0,0,0.3)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 },
  accentLine: { width: 30, height: 3, marginTop: 8, borderRadius: 2 },
  footer: { position: 'absolute', bottom: 80 },
  footerBrand: { fontSize: 15, fontWeight: '700', letterSpacing: 4 },
  skipButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    zIndex: 99,
  },
  skipText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '600',
  },
});
