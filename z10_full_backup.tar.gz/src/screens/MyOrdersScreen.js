import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getOrders, ORDER_STATUS } from '../services/orderService';

export default function MyOrdersScreen({ navigation }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userPhone, setUserPhone] = useState('');

  useEffect(() => { loadUserPhone(); }, []);
  useEffect(() => { if (userPhone) loadOrders(); }, [userPhone]);

  const loadUserPhone = async () => {
    const phone = await AsyncStorage.getItem('userPhone');
    if (phone) { setUserPhone(phone); }
    else {
      const userData = await AsyncStorage.getItem('userData');
      if (userData) { const user = JSON.parse(userData); setUserPhone(user.phone || ''); }
    }
  };

  const loadOrders = async () => {
    if (!userPhone) return;
    setLoading(true);
    try {
      const result = await getOrders({ customerPhone: userPhone });
      if (result.success) {
        const sortedOrders = result.data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        setOrders(sortedOrders);
      }
    } catch (error) { console.error('خطأ:', error); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const onRefresh = () => { setRefreshing(true); loadOrders(); };

  const getStatusColor = (status) => {
    const c = { [ORDER_STATUS.PENDING]: '#F59E0B', [ORDER_STATUS.ACCEPTED]: '#3B82F6', [ORDER_STATUS.PREPARING]: '#8B5CF6', [ORDER_STATUS.READY]: '#10B981', [ORDER_STATUS.DRIVER_ASSIGNED]: '#3B82F6', [ORDER_STATUS.ON_THE_WAY]: '#3B82F6', [ORDER_STATUS.DELIVERED]: '#10B981', [ORDER_STATUS.CANCELLED]: '#EF4444' };
    return c[status] || '#6B7280';
  };

  const getStatusText = (status) => {
    const t = { [ORDER_STATUS.PENDING]: 'معلق', [ORDER_STATUS.ACCEPTED]: 'تم القبول', [ORDER_STATUS.PREPARING]: 'جاري التجهيز', [ORDER_STATUS.READY]: 'جاهز', [ORDER_STATUS.DRIVER_ASSIGNED]: 'مندوب معين', [ORDER_STATUS.ON_THE_WAY]: 'جاري التوصيل', [ORDER_STATUS.DELIVERED]: 'تم التوصيل', [ORDER_STATUS.CANCELLED]: 'ملغي' };
    return t[status] || status;
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  // ✅ التنقل الصحيح لتتبع الطلب (للتقييم)
  const handleOrderPress = (order) => {
    navigation.navigate('OrderTrackingScreen', { orderId: order.id });
  };

  const renderOrder = ({ item }) => {
    const orderId = item.id || item.$id;
    const displayId = orderId ? String(orderId).slice(-6) : '000000';
    const totalPrice = item.final_total || item.total_price || 0;
    const canRate = item.status === ORDER_STATUS.DELIVERED && !item.hasRated;

    return (
      <TouchableOpacity style={styles.orderCard} onPress={() => handleOrderPress(item)}>
        <View style={styles.orderHeader}>
          <Text style={styles.orderId}>طلب #{displayId}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
            <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{getStatusText(item.status)}</Text>
          </View>
        </View>
        <Text style={styles.serviceName} numberOfLines={1}>{item.merchant_place || item.merchant_name || item.service_name || 'طلب'}</Text>
        <View style={styles.orderFooter}>
          <Text style={styles.orderDate}>{formatDate(item.created_at)}</Text>
          <View style={styles.priceRow}>
            <Text style={styles.orderPrice}>{totalPrice} ج</Text>
            {canRate && (
              <View style={styles.rateBadge}>
                <Ionicons name="star" size={14} color="#F59E0B" />
                <Text style={styles.rateText}>تقييم</Text>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><View style={styles.backCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View></TouchableOpacity>
        <Text style={styles.headerTitle}>طلباتي السابقة</Text>
        <View style={{ width: 28 }} />
      </View>
      <FlatList
        data={orders}
        renderItem={renderOrder}
        keyExtractor={item => item.id || item.$id || Math.random().toString()}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={<View style={styles.emptyContainer}><Ionicons name="cart-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد طلبات سابقة</Text></View>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
   backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  list: { padding: 16 },
  orderCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600' },
  serviceName: { fontSize: 16, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingTop: 8, marginTop: 4 },
  orderDate: { fontSize: 12, color: '#9CA3AF' },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  orderPrice: { fontSize: 14, fontWeight: '600', color: '#F59E0B' },
  rateBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, gap: 4 },
  rateText: { fontSize: 11, color: '#F59E0B', fontWeight: '600' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
});
