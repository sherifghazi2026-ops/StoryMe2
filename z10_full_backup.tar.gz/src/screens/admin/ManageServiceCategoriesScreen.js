import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
  ActivityIndicator, Modal, TextInput, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { uploadServiceImage } from '../../services/uploadService';

export default function ManageServiceCategoriesScreen({ navigation }) {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [name, setName] = useState('');
  const [sortOrder, setSortOrder] = useState('0');
  const [isActive, setIsActive] = useState(true);
  const [imageUrl, setImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [textColor, setTextColor] = useState("#1F2937");

  useEffect(() => { loadCategories(); }, []);
  useEffect(() => { AsyncStorage.getItem("appSettings").then(c => { if (c) { const s = JSON.parse(c); if (s.service_category_color) setTextColor(s.service_category_color); } }); }, []);

  const loadCategories = async () => {
    const { data } = await supabase.from('service_categories').select('*').order('sort_order');
    setCategories(data || []);
    setLoading(false);
  };

  const resetForm = () => { setEditingCategory(null); setName(''); setSortOrder('0'); setIsActive(true); setImageUrl(''); };
  const openAddModal = () => { resetForm(); setModalVisible(true); };
  const openEditModal = (cat) => { setEditingCategory(cat); setName(cat.name); setSortOrder(String(cat.sort_order || 0)); setIsActive(cat.is_active !== false); setImageUrl(cat.image_url || ''); setModalVisible(true); };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadServiceImage(result.assets[0].uri);
      setUploading(false);
      if (res.success) setImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSave = async () => {
    if (!name.trim()) { Alert.alert('تنبيه', 'الاسم مطلوب'); return; }
    setSubmitting(true);
    try {
      const catData = { name: name.trim(), sort_order: parseInt(sortOrder) || 0, is_active: isActive, image_url: imageUrl, updated_at: new Date().toISOString() };
      if (editingCategory) {
        const { error } = await supabase.from('service_categories').update(catData).eq('id', editingCategory.id);
        if (error) throw error;
        Alert.alert('✅ تم', 'تم تحديث الفئة');
      } else {
        Alert.alert('تنبيه', 'الإضافة غير متاحة - عدل الفئات الموجودة فقط');
      }
      setModalVisible(false); resetForm(); loadCategories();
    } catch (error) { Alert.alert('خطأ', error.message); }
    finally { setSubmitting(false); }
  };

  const renderCategory = ({ item }) => (
    <View style={styles.card}>
      {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.cardImage} /> : <View style={styles.cardImagePlaceholder}><Ionicons name="apps-outline" size={24} color="#8B5CF6" /></View>}
      <View style={{ flex: 1 }}><Text style={[styles.cardName, { color: textColor }]}>{item.name}</Text><Text style={styles.cardMeta}>ترتيب: {item.sort_order}</Text></View>
      <TouchableOpacity onPress={() => openEditModal(item)}><Ionicons name="create-outline" size={20} color="#F59E0B" /></TouchableOpacity>
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>فئات الخدمات</Text>
        <View style={{ width: 28 }} />
      </View>
      <FlatList data={categories} renderItem={renderCategory} keyExtractor={item => item.id} contentContainerStyle={styles.list} ListEmptyComponent={<View style={styles.empty}><Ionicons name="folder-outline" size={60} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد فئات</Text></View>} />
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalBox}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>تعديل الفئة</Text><TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <Text style={styles.label}>الاسم</Text><TextInput style={styles.input} value={name} onChangeText={setName} />
          <Text style={styles.label}>الصورة</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
            {uploading ? <ActivityIndicator /> : imageUrl ? <Image source={{ uri: imageUrl }} style={styles.previewImg} /> : <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 12 }}>رفع صورة</Text></View>}
          </TouchableOpacity>
          <Text style={styles.label}>الترتيب</Text><TextInput style={styles.input} value={sortOrder} onChangeText={setSortOrder} keyboardType="numeric" />
          <TouchableOpacity style={[styles.saveBtn, submitting && { opacity: 0.6 }]} onPress={handleSave} disabled={submitting}>{submitting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>حفظ</Text>}</TouchableOpacity>
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB', gap: 12 },
  cardImage: { width: 50, height: 50, borderRadius: 12 },
  cardImagePlaceholder: { width: 50, height: 50, borderRadius: 12, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  cardName: { fontSize: 16, fontWeight: '600' },
  cardMeta: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  empty: { alignItems: 'center', padding: 40 },
  emptyText: { color: '#9CA3AF', marginTop: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalBox: { backgroundColor: '#FFF', borderRadius: 16, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 6, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, fontSize: 14, marginBottom: 8 },
  imagePicker: { height: 120, backgroundColor: '#F3F4F6', borderRadius: 12, marginBottom: 12, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  previewImg: { width: '100%', height: '100%', resizeMode: 'cover' },
  imgPlaceholder: { justifyContent: 'center', alignItems: 'center' },
  saveBtn: { backgroundColor: '#8B5CF6', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 12 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
