import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
  ActivityIndicator, Modal, TextInput, RefreshControl, ScrollView, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { uploadServiceImage } from '../../services/uploadService';
import { fontFamily } from '../../utils/fonts';

export default function ManageProductCategoriesScreen({ navigation }) {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [categoryName, setCategoryName] = useState('');
  const [categoryIcon, setCategoryIcon] = useState('cube');
  const [sortOrder, setSortOrder] = useState('0');
  const [selectedService, setSelectedService] = useState(null);
  const [services, setServices] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [filterService, setFilterService] = useState(null);
  const [showServicePicker, setShowServicePicker] = useState(false);

  const ICONS = ['cube', 'cafe', 'pizza', 'nutrition', 'fast-food', 'archive', 'sparkles', 'cart', 'basket', 'wine', 'ice-cream', 'fish'];

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => { await loadServices(); await loadCategories(); };

  const loadServices = async () => {
    const { data } = await supabase.from('services').select('id, name').in('type', ['items', 'products']);
    setServices(data || []);
  };

  const loadCategories = async () => {
    try {
      const { data, error } = await supabase.from('product_categories').select('*').order('sort_order', { ascending: true });
      if (error) throw error;
      setCategories(data || []);
    } catch (error) { Alert.alert('خطأ', 'فشل تحميل الأقسام'); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const resetForm = () => {
    setEditingCategory(null);
    setCategoryName(''); setCategoryIcon('cube'); setSortOrder('0');
    setSelectedService(null); setImageUrl('');
  };

  const openAddModal = () => { resetForm(); setModalVisible(true); };

  const openEditModal = (cat) => {
    setEditingCategory(cat);
    setCategoryName(cat.name); setCategoryIcon(cat.icon || 'cube');
    setSortOrder(String(cat.sort_order || 0)); setSelectedService(cat.service_id);
    setImageUrl(cat.image_url || ''); setModalVisible(true);
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadServiceImage(result.assets[0].uri);
      setUploading(false);
      if (res.success) setImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSave = async () => {
    if (!categoryName.trim()) { Alert.alert('تنبيه', 'اسم القسم مطلوب'); return; }
    if (!selectedService) { Alert.alert('تنبيه', 'اختر الخدمة المرتبطة'); return; }
    setSubmitting(true);
    try {
      const catData = {
        name: categoryName.trim(), icon: categoryIcon,
        sort_order: parseInt(sortOrder) || 0, service_id: selectedService,
        image_url: imageUrl, updated_at: new Date().toISOString(),
      };
      if (editingCategory) {
        const { error } = await supabase.from('product_categories').update(catData).eq('id', editingCategory.id);
        if (error) throw error;
        Alert.alert('✅ تم', 'تم تحديث القسم');
      } else {
        catData.created_at = new Date().toISOString();
        const { error } = await supabase.from('product_categories').insert([catData]);
        if (error) throw error;
        Alert.alert('✅ تم', 'تم إضافة القسم');
      }
      setModalVisible(false); resetForm(); loadCategories();
    } catch (error) { Alert.alert('خطأ', error.message); }
    finally { setSubmitting(false); }
  };

  const handleDelete = (cat) => {
    Alert.alert('حذف القسم', `حذف "${cat.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
          await supabase.from('product_categories').delete().eq('id', cat.id); loadCategories();
        }
      }
    ]);
  };

  const getServiceName = (serviceId) => {
    const s = services.find(x => x.id === serviceId);
    return s ? s.name : serviceId;
  };

  const filteredCategories = filterService
    ? categories.filter(cat => cat.service_id === filterService)
    : categories;

  const selectedServiceName = filterService ? getServiceName(filterService) : 'كل الخدمات';

  const renderCategory = ({ item }) => (
    <View style={styles.card}>
      {item.image_url ? <Image source={{ uri: item.image_url }} style={styles.cardImage} /> : null}
      <View style={styles.cardInfo}>
        <View style={styles.cardRow}>
          <Ionicons name={item.icon || 'cube'} size={24} color="#8B5CF6" />
          <View style={{ flex: 1 }}>
            <Text style={styles.cardName}>{item.name}</Text>
            <Text style={styles.cardService}>{getServiceName(item.service_id)}</Text>
          </View>
        </View>
      </View>
      <View style={styles.actions}>
        <TouchableOpacity style={[styles.btn, styles.editBtn]} onPress={() => openEditModal(item)}>
          <Ionicons name="create-outline" size={16} color="#FFF" />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.btn, styles.delBtn]} onPress={() => handleDelete(item)}>
          <Ionicons name="trash-outline" size={16} color="#FFF" />
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>فئات المنتجات</Text>
        <TouchableOpacity onPress={openAddModal}><Ionicons name="add-circle" size={28} color="#8B5CF6" /></TouchableOpacity>
      </View>

      {/* Dropdown لاختيار الخدمة */}
      <TouchableOpacity style={styles.dropdown} onPress={() => setShowServicePicker(true)}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Ionicons name="layers-outline" size={18} color="#8B5CF6" />
          <Text style={styles.dropdownText}>{selectedServiceName}</Text>
        </View>
        <Ionicons name="chevron-down" size={18} color="#9CA3AF" />
      </TouchableOpacity>

      {filterService && (
        <Text style={styles.resultCount}>{filteredCategories.length} فئة</Text>
      )}

      <FlatList
        data={filteredCategories} renderItem={renderCategory} keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadCategories} />}
        ListEmptyComponent={
          <View style={styles.empty}><Ionicons name="folder-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد فئات</Text></View>
        }
      />

      {/* Modal اختيار الخدمة */}
      <Modal visible={showServicePicker} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowServicePicker(false)}>
          <View style={styles.pickerModal}>
            <Text style={styles.pickerTitle}>اختر الخدمة</Text>
            <ScrollView>
              <TouchableOpacity
                style={[styles.pickerItem, !filterService && styles.pickerItemActive]}
                onPress={() => { setFilterService(null); setShowServicePicker(false); }}
              >
                <Ionicons name="apps-outline" size={20} color={!filterService ? '#8B5CF6' : '#6B7280'} />
                <Text style={[styles.pickerItemText, !filterService && styles.pickerItemTextActive]}>كل الخدمات</Text>
                {!filterService && <Ionicons name="checkmark" size={20} color="#8B5CF6" />}
              </TouchableOpacity>
              {services.map(s => (
                <TouchableOpacity
                  key={s.id}
                  style={[styles.pickerItem, filterService === s.id && styles.pickerItemActive]}
                  onPress={() => { setFilterService(s.id); setShowServicePicker(false); }}
                >
                  <Ionicons name="ellipse-outline" size={20} color={filterService === s.id ? '#8B5CF6' : '#6B7280'} />
                  <Text style={[styles.pickerItemText, filterService === s.id && styles.pickerItemTextActive]}>{s.name}</Text>
                  {filterService === s.id && <Ionicons name="checkmark" size={20} color="#8B5CF6" />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Modal إضافة/تعديل */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingCategory ? 'تعديل فئة' : 'إضافة فئة'}</Text>
              <TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}>
                <Ionicons name="close" size={24} color="#EF4444" />
              </TouchableOpacity>
            </View>

            <ScrollView style={{ maxHeight: 420 }} showsVerticalScrollIndicator={true} nestedScrollEnabled={true}>
              <Text style={styles.label}>الخدمة *</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipRow}>
                {services.map(s => (
                  <TouchableOpacity key={s.id} style={[styles.chip, selectedService === s.id && styles.chipActive]} onPress={() => setSelectedService(s.id)}>
                    <Text style={[styles.chipText, selectedService === s.id && styles.chipTextActive]}>{s.name}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.label}>اسم الفئة *</Text>
              <TextInput style={styles.input} placeholder="مثال: مشروبات غازية" value={categoryName} onChangeText={setCategoryName} />

              <Text style={styles.label}>صورة الفئة</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
                {uploading ? <ActivityIndicator size="large" color="#8B5CF6" /> :
                  imageUrl ? <Image source={{ uri: imageUrl }} style={styles.previewImg} /> :
                  <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 12 }}>رفع صورة</Text></View>}
              </TouchableOpacity>

              <Text style={styles.label}>الأيقونة</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipRow}>
                {ICONS.map(icon => (
                  <TouchableOpacity key={icon} style={[styles.iconChip, categoryIcon === icon && styles.iconChipActive]} onPress={() => setCategoryIcon(icon)}>
                    <Ionicons name={icon} size={22} color={categoryIcon === icon ? '#FFF' : '#8B5CF6'} />
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.label}>الترتيب</Text>
              <TextInput style={styles.input} placeholder="0" value={sortOrder} onChangeText={setSortOrder} keyboardType="numeric" />
            </ScrollView>

            <TouchableOpacity style={[styles.saveBtn, submitting && { opacity: 0.6 }]} onPress={handleSave} disabled={submitting}>
              {submitting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{editingCategory ? 'حفظ التعديلات' : 'إضافة الفئة'}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  // Dropdown
  dropdown: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#FFF', marginHorizontal: 14, marginTop: 12, padding: 14,
    borderRadius: 14, borderWidth: 1, borderColor: '#E5E7EB', elevation: 1,
  },
  dropdownText: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  resultCount: { textAlign: 'center', color: '#6B7280', fontSize: 12, marginTop: 6, fontFamily: fontFamily.arabic },
  list: { padding: 14 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, padding: 10, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB', gap: 10 },
  cardImage: { width: 50, height: 50, borderRadius: 10 },
  cardInfo: { flex: 1 },
  cardRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  cardName: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  cardService: { fontSize: 11, color: '#6B7280', marginTop: 2 },
  actions: { flexDirection: 'row', gap: 8 },
  btn: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  editBtn: { backgroundColor: '#F59E0B' },
  delBtn: { backgroundColor: '#EF4444' },
  empty: { alignItems: 'center', padding: 50 },
  emptyText: { color: '#9CA3AF', marginTop: 8, fontFamily: fontFamily.arabic },
  // Modal الخدمات
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  pickerModal: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '100%', maxWidth: 340, maxHeight: '60%' },
  pickerTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  pickerItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 10, marginBottom: 4, gap: 12 },
  pickerItemActive: { backgroundColor: '#F5F3FF' },
  pickerItemText: { flex: 1, fontSize: 15, color: '#374151', fontFamily: fontFamily.arabic },
  pickerItemTextActive: { color: '#8B5CF6', fontWeight: '600' },
  // Modal إضافة
  modalBox: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  label: { fontSize: 13, fontWeight: '600', color: '#4B5563', marginBottom: 6, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, fontSize: 14, marginBottom: 8 },
  chipRow: { marginBottom: 12, flexDirection: 'row' },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 16, backgroundColor: '#F3F4F6', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  chipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  chipText: { fontSize: 13, color: '#4B5563' },
  chipTextActive: { color: '#FFF', fontWeight: '600' },
  imagePicker: { height: 130, backgroundColor: '#F3F4F6', borderRadius: 12, marginBottom: 12, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  previewImg: { width: '100%', height: '100%', resizeMode: 'cover' },
  imgPlaceholder: { justifyContent: 'center', alignItems: 'center' },
  iconChip: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  iconChipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  saveBtn: { backgroundColor: '#8B5CF6', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 12 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
