import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Modal, TextInput, Switch, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { getFullServices, createFullService, getSubServices, createSubService, updateSubService, deleteSubService, toggleSubServiceActive, getServiceFields, createServiceField, updateServiceField, deleteServiceField } from '../../services/fullServiceService';
import * as ImagePicker from 'expo-image-picker';
import { uploadServiceImage } from '../../services/uploadService';

const FIELD_TYPES = [
  { label: 'نص قصير', value: 'text' }, { label: 'نص طويل', value: 'textarea' },
  { label: 'رقم', value: 'number' }, { label: 'تاريخ', value: 'date' },
  { label: 'اختيار من متعدد', value: 'select' },
];
const COLORS = ['#8B5CF6','#4F46E5','#10B981','#F59E0B','#EF4444','#EC4899','#6B7280'];

export default function FullServiceManager({ navigation, route }) {
  const [fullServices, setFullServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedService, setSelectedService] = useState(null);
  const [subServices, setSubServices] = useState([]);
  const [selectedSubService, setSelectedSubService] = useState(null);
  const [fields, setFields] = useState([]);
  const [showAddService, setShowAddService] = useState(false);
  const [showEditService, setShowEditService] = useState(false);
  const [showAddSub, setShowAddSub] = useState(false);
  const [showEditSub, setShowEditSub] = useState(false);
  const [showAddField, setShowAddField] = useState(false);
  const [showEditField, setShowEditField] = useState(false);
  const [newServiceName, setNewServiceName] = useState('');
  const [newServiceId, setNewServiceId] = useState('');
  const [newServiceColor, setNewServiceColor] = useState('#8B5CF6');
  const [newServiceImage, setNewServiceImage] = useState(null);
  const [editServiceName, setEditServiceName] = useState('');
  const [editServiceId, setEditServiceId] = useState('');
  const [editServiceColor, setEditServiceColor] = useState('#8B5CF6');
  const [editServiceImage, setEditServiceImage] = useState(null);
  const [editingService, setEditingService] = useState(null);
  const [newSubName, setNewSubName] = useState('');
  const [newSubImage, setNewSubImage] = useState(null);
  const [newSubTrackingIcon, setNewSubTrackingIcon] = useState(null);
  const [editSubName, setEditSubName] = useState('');
  const [editSubImage, setEditSubImage] = useState(null);
  const [editSubTrackingIcon, setEditSubTrackingIcon] = useState(null);
  const [editingSub, setEditingSub] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [fieldLabel, setFieldLabel] = useState('');
  const [fieldType, setFieldType] = useState('text');
  const [fieldRequired, setFieldRequired] = useState(true);
  const [fieldOptions, setFieldOptions] = useState('');
  const [fieldPlaceholder, setFieldPlaceholder] = useState('');
  const [fieldHelp, setFieldHelp] = useState('');
  const [editingField, setEditingField] = useState(null);
  const [editFieldLabel, setEditFieldLabel] = useState('');
  const [editFieldType, setEditFieldType] = useState('text');
  const [editFieldRequired, setEditFieldRequired] = useState(true);
  const [editFieldOptions, setEditFieldOptions] = useState('');
  const [editFieldPlaceholder, setEditFieldPlaceholder] = useState('');
  const [editFieldHelp, setEditFieldHelp] = useState('');

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => { const data = await getFullServices(); setFullServices(data); setLoading(false); };

  const loadSubServices = async (service) => {
    setSelectedService(service);
    const data = await getSubServices(service.id);
    setSubServices(data);
    setSelectedSubService(null);
    setFields([]);
  };

  const loadFields = async (sub) => {
    setSelectedSubService(sub);
    const data = await getServiceFields(sub.id);
    setFields(data);
  };

  const pickImage = async (target) => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadServiceImage(result.assets[0].uri);
      setUploading(false);
      if (res.success) {
        switch(target) {
          case 'newService': setNewServiceImage(res.fileUrl); break;
          case 'editService': setEditServiceImage(res.fileUrl); break;
          case 'newSub': setNewSubImage(res.fileUrl); break;
          case 'newSubTracking': setNewSubTrackingIcon(res.fileUrl); break;
          case 'editSub': setEditSubImage(res.fileUrl); break;
          case 'editSubTracking': setEditSubTrackingIcon(res.fileUrl); break;
        }
      }
    }
  };

  const handleAddService = async () => {
    if (!newServiceName.trim()) return Alert.alert('تنبيه', 'اسم الخدمة مطلوب');
    if (!newServiceId.trim()) return Alert.alert('تنبيه', 'معرف الخدمة مطلوب');
    const serviceId = newServiceId.trim().toLowerCase().replace(/\s+/g, '_');
    await createFullService({ service_id: serviceId, name: newServiceName.trim(), image_url: newServiceImage, color: newServiceColor });
    await supabase.from('services').upsert({ id: serviceId, name: newServiceName.trim(), type: 'full_service', icon: 'briefcase', color: newServiceColor, image_url: newServiceImage, is_active: true, is_visible: true, category: 'other', order: 99 }, { onConflict: 'id' });
    setShowAddService(false); setNewServiceName(''); setNewServiceId(''); setNewServiceImage(null); loadAll();
  };

  const openEditService = (service) => {
    setEditingService(service);
    setEditServiceName(service.name);
    setEditServiceId(service.service_id || service.id);
    setEditServiceColor(service.color||'#8B5CF6');
    setEditServiceImage(service.image_url||null);
    setShowEditService(true);
  };

  const handleEditService = async () => {
    if (!editServiceName.trim()) return Alert.alert('تنبيه', 'اسم الخدمة مطلوب');
    const serviceId = editServiceId.trim().toLowerCase().replace(/\s+/g, '_');
    await supabase.from('full_services').update({ service_id: serviceId, name: editServiceName.trim(), color: editServiceColor, image_url: editServiceImage, updated_at: new Date() }).eq('id', editingService.id);
    await supabase.from('services').update({ id: serviceId, name: editServiceName.trim(), color: editServiceColor, image_url: editServiceImage }).eq('id', editingService.service_id);
    setShowEditService(false); loadAll(); setSelectedService(null);
  };

  const handleDeleteService = (service) => {
    Alert.alert('حذف', `حذف "${service.name}" وجميع خدماتها الفرعية؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
          await supabase.from('services').delete().eq('id', service.service_id);
          await supabase.from('full_services').delete().eq('id', service.id);
          setSelectedService(null); setSubServices([]); loadAll();
          Alert.alert('✅ تم', 'تم حذف الخدمة');
        }
      }
    ]);
  };

  const handleAddSub = async () => {
    if (!newSubName.trim()) return Alert.alert('تنبيه', 'اسم الخدمة الفرعية مطلوب');
    await createSubService({ full_service_id: selectedService.id, name: newSubName.trim(), image_url: newSubImage, tracking_icon_url: newSubTrackingIcon });
    setShowAddSub(false); setNewSubName(''); setNewSubImage(null); setNewSubTrackingIcon(null);
    loadSubServices(selectedService);
  };

  const openEditSub = (sub) => {
    setEditingSub(sub);
    setEditSubName(sub.name);
    setEditSubImage(sub.image_url||null);
    setEditSubTrackingIcon(sub.tracking_icon_url||null);
    setShowEditSub(true);
  };

  const handleEditSub = async () => {
    if (!editSubName.trim()) return Alert.alert('تنبيه', 'اسم الخدمة الفرعية مطلوب');
    await updateSubService(editingSub.id, { name: editSubName.trim(), image_url: editSubImage, tracking_icon_url: editSubTrackingIcon });
    setShowEditSub(false); loadSubServices(selectedService);
  };

  const handleDeleteSub = async (sub) => {
    Alert.alert('حذف', `حذف "${sub.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', onPress: async () => { await deleteSubService(sub.id); loadSubServices(selectedService); } }
    ]);
  };

  const handleToggleSubActive = async (sub) => {
    await toggleSubServiceActive(sub.id, !sub.is_active);
    loadSubServices(selectedService);
  };

  const handleAddField = async () => {
    if (!fieldLabel.trim()) return Alert.alert('تنبيه', 'اسم الحقل مطلوب');
    if (!selectedSubService) return Alert.alert('تنبيه', 'اختر خدمة فرعية أولاً');
    const opts = fieldType==='select'?fieldOptions.split(',').map(o=>o.trim()).filter(Boolean):[];
    await createServiceField({
      sub_service_id: selectedSubService.id,
      service_id: selectedSubService.name,
      field_name: fieldLabel.trim().toLowerCase().replace(/\s+/g,'_'),
      field_label: fieldLabel.trim(),
      field_type: fieldType,
      field_options: opts,
      is_required: fieldRequired,
      placeholder: fieldPlaceholder,
      help_text: fieldHelp,
      sort_order: fields.length,
      is_visible: true
    });
    setShowAddField(false);
    resetFieldForm();
    loadFields(selectedSubService);
  };

  const openEditField = (f) => { setEditingField(f); setEditFieldLabel(f.field_label); setEditFieldType(f.field_type); setEditFieldRequired(f.is_required); setEditFieldOptions((f.field_options||[]).join(', ')); setEditFieldPlaceholder(f.placeholder||''); setEditFieldHelp(f.help_text||''); setShowEditField(true); };

  const handleEditField = async () => {
    if (!editFieldLabel.trim()) return Alert.alert('تنبيه', 'اسم الحقل مطلوب');
    const opts = editFieldType==='select'?editFieldOptions.split(',').map(o=>o.trim()).filter(Boolean):[];
    await updateServiceField(editingField.id, {
      field_label: editFieldLabel.trim(),
      field_type: editFieldType,
      field_options: opts,
      is_required: editFieldRequired,
      placeholder: editFieldPlaceholder,
      help_text: editFieldHelp
    });
    setShowEditField(false);
    loadFields(selectedSubService);
  };

  const handleDeleteField = async (f) => { await deleteServiceField(f.id); loadFields(selectedSubService); };

  const resetFieldForm = () => { setFieldLabel(''); setFieldType('text'); setFieldRequired(true); setFieldOptions(''); setFieldPlaceholder(''); setFieldHelp(''); };

  const syncAllServices = async () => {
    Alert.alert('مزامنة', 'سيتم مزامنة جميع الخدمات الشاملة مع جداول الخدمات. هل تريد المتابعة؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مزامنة', onPress: async () => {
          try {
            const { data: fullServices, error: fullError } = await supabase.from('full_services').select('service_id, name, icon, color, image_url').eq('is_active', true);
            if (fullError) throw fullError;
            for (const fs of fullServices) {
              await supabase.from('services').upsert({ id: fs.service_id, name: fs.name, type: 'full_service', icon: fs.icon || 'briefcase', color: fs.color || '#8B5CF6', image_url: fs.image_url, is_active: true, is_visible: true, category: 'other', order: 99 }, { onConflict: 'id' });
            }
            Alert.alert('✅ تم', 'تمت مزامنة جميع الخدمات الشاملة بنجاح');
            loadAll();
          } catch (error) { Alert.alert('خطأ', error.message); }
        }
      }
    ]);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>الخدمات الشاملة</Text>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <TouchableOpacity onPress={syncAllServices}><Ionicons name="sync-outline" size={24} color="#10B981" /></TouchableOpacity>
          <TouchableOpacity onPress={() => setShowAddService(true)}><Ionicons name="add-circle" size={24} color="#8B5CF6" /></TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {fullServices.map(service => (
          <View key={service.id} style={styles.card}>
            <View style={styles.serviceRow}>
              <TouchableOpacity style={{flex:1,flexDirection:'row',alignItems:'center',gap:12}} onPress={() => loadSubServices(service)}>
                {service.image_url?<Image source={{uri:service.image_url}} style={styles.serviceImg}/>:<View style={[styles.serviceImg,{backgroundColor:(service.color||'#8B5CF6')+'20',justifyContent:'center',alignItems:'center'}]}><Ionicons name="briefcase" size={20} color={service.color||'#8B5CF6'}/></View>}
                <View style={{flex:1}}><Text style={styles.serviceName}>{service.name}</Text></View>
                <Ionicons name={selectedService?.id===service.id?'chevron-up':'chevron-down'} size={18} color="#9CA3AF"/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => openEditService(service)} style={{padding:4}}><Ionicons name="create-outline" size={18} color="#F59E0B"/></TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteService(service)}><Ionicons name="trash-outline" size={18} color="#EF4444"/></TouchableOpacity>
            </View>

            {selectedService?.id===service.id&&(
              <View style={styles.subContainer}>
                <View style={styles.subHeader}>
                  <Text style={styles.subTitle}>الخدمات الفرعية</Text>
                  <TouchableOpacity onPress={()=>{setShowAddSub(true); setNewSubTrackingIcon(null); setNewSubImage(null); setNewSubName('');}}><Ionicons name="add" size={22} color="#4F46E5"/></TouchableOpacity>
                </View>

                {subServices.map(sub=>(
                  <View key={sub.id} style={[styles.subCard, !sub.is_active && {opacity:0.5}]}>
                    <View style={styles.subRow}>
                      <TouchableOpacity style={{flex:1,flexDirection:'row',alignItems:'center',gap:8}} onPress={()=>loadFields(sub)}>
                        {sub.image_url?<Image source={{uri:sub.image_url}} style={styles.subImg}/>:<Ionicons name="document-text" size={18} color="#8B5CF6"/>}
                        {sub.tracking_icon_url && <Image source={{uri:sub.tracking_icon_url}} style={{width:20,height:20,borderRadius:4,marginRight:4}} />}
                        <Text style={styles.subName}>{sub.name}</Text>
                        {!sub.is_active && <Text style={styles.hiddenBadge}>معطل</Text>}
                        <Ionicons name={selectedSubService?.id===sub.id?'chevron-up':'chevron-down'} size={16} color="#9CA3AF"/>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={()=>openEditSub(sub)} style={styles.iconBtnEdit}><Ionicons name="create-outline" size={14} color="#FFF"/></TouchableOpacity>
                      <Switch value={sub.is_active} onValueChange={() => handleToggleSubActive(sub)} trackColor={{ false: '#E5E7EB', true: '#8B5CF6' }} thumbColor={sub.is_active ? '#FFF' : '#9CA3AF'} style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }} />
                      <TouchableOpacity onPress={()=>handleDeleteSub(sub)}><Ionicons name="trash-outline" size={16} color="#EF4444"/></TouchableOpacity>
                    </View>

                    {selectedSubService?.id===sub.id&&(
                      <View style={styles.fieldsContainer}>
                        <View style={styles.subHeader}>
                          <Text style={styles.fieldsTitle}>الحقول المخصصة</Text>
                          <TouchableOpacity onPress={()=>setShowAddField(true)}><Ionicons name="add-circle" size={22} color="#10B981"/></TouchableOpacity>
                        </View>
                        {fields.filter(f => f.sub_service_id === sub.id).map(f=>(
                          <View key={f.id} style={styles.fieldRow}>
                            <Text style={styles.fieldLabel}>{f.field_label} ({f.field_type}) {f.is_required?'*':''}</Text>
                            <View style={{ flexDirection: 'row', gap: 8 }}>
                              <TouchableOpacity onPress={()=>openEditField(f)}><Ionicons name="create-outline" size={16} color="#F59E0B"/></TouchableOpacity>
                              <TouchableOpacity onPress={()=>handleDeleteField(f)}><Ionicons name="trash-outline" size={16} color="#EF4444"/></TouchableOpacity>
                            </View>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>
                ))}
              </View>
            )}
          </View>
        ))}
      </ScrollView>

      <Modal visible={showAddService} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>إضافة خدمة شاملة</Text>
        <TextInput style={styles.input} placeholder="معرف الخدمة (service_id)" value={newServiceId} onChangeText={setNewServiceId} autoCapitalize="none" />
        <TextInput style={styles.input} placeholder="اسم الخدمة" value={newServiceName} onChangeText={setNewServiceName} />
        <Text style={styles.label}>اللون</Text>
        <ScrollView horizontal style={{marginBottom:12}}>{COLORS.map(c=>(<TouchableOpacity key={c} style={[styles.colorDot,{backgroundColor:c},newServiceColor===c&&{borderWidth:3,borderColor:'#1F2937'}]} onPress={()=>setNewServiceColor(c)}/>))}</ScrollView>
        <Text style={styles.label}>صورة الخدمة</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('newService')} disabled={uploading}>{newServiceImage?<Image source={{uri:newServiceImage}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>setShowAddService(false)}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleAddService}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>

      <Modal visible={showEditService} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>تعديل خدمة شاملة</Text>
        <TextInput style={styles.input} placeholder="معرف الخدمة (service_id)" value={editServiceId} onChangeText={setEditServiceId} autoCapitalize="none" />
        <TextInput style={styles.input} placeholder="اسم الخدمة" value={editServiceName} onChangeText={setEditServiceName} />
        <Text style={styles.label}>اللون</Text>
        <ScrollView horizontal style={{marginBottom:12}}>{COLORS.map(c=>(<TouchableOpacity key={c} style={[styles.colorDot,{backgroundColor:c},editServiceColor===c&&{borderWidth:3,borderColor:'#1F2937'}]} onPress={()=>setEditServiceColor(c)}/>))}</ScrollView>
        <Text style={styles.label}>صورة الخدمة</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('editService')} disabled={uploading}>{editServiceImage?<Image source={{uri:editServiceImage}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>setShowEditService(false)}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleEditService}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>

      <Modal visible={showAddSub} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>إضافة خدمة فرعية</Text>
        <TextInput style={styles.input} placeholder="اسم الخدمة الفرعية" value={newSubName} onChangeText={setNewSubName}/>
        <Text style={styles.label}>أيقونة التتبع (للطلبات)</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('newSubTracking')} disabled={uploading}>{newSubTrackingIcon?<Image source={{uri:newSubTrackingIcon}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="location-outline" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <Text style={styles.label}>صورة الخدمة الفرعية</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('newSub')} disabled={uploading}>{newSubImage?<Image source={{uri:newSubImage}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>setShowAddSub(false)}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleAddSub}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>

      <Modal visible={showEditSub} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>تعديل خدمة فرعية</Text>
        <TextInput style={styles.input} placeholder="اسم الخدمة الفرعية" value={editSubName} onChangeText={setEditSubName}/>
        <Text style={styles.label}>أيقونة التتبع (للطلبات)</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('editSubTracking')} disabled={uploading}>{editSubTrackingIcon?<Image source={{uri:editSubTrackingIcon}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="location-outline" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <Text style={styles.label}>صورة الخدمة الفرعية</Text>
        <TouchableOpacity style={styles.imagePicker} onPress={()=>pickImage('editSub')} disabled={uploading}>{editSubImage?<Image source={{uri:editSubImage}} style={styles.previewImg}/>:<View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF"/></View>}</TouchableOpacity>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>setShowEditSub(false)}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleEditSub}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>

      <Modal visible={showAddField} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>إضافة حقل جديد</Text>
        <TextInput style={styles.input} placeholder="اسم الحقل" value={fieldLabel} onChangeText={setFieldLabel}/>
        <Text style={styles.label}>نوع الحقل</Text>
        <View style={styles.typeRow}>{FIELD_TYPES.map(t=>(<TouchableOpacity key={t.value} style={[styles.typeBtn,fieldType===t.value&&styles.typeBtnActive]} onPress={()=>setFieldType(t.value)}><Text style={[styles.typeText,fieldType===t.value&&styles.typeTextActive]}>{t.label}</Text></TouchableOpacity>))}</View>
        {fieldType==='select'&&<TextInput style={styles.input} placeholder="الخيارات (مفصولة بفواصل)" value={fieldOptions} onChangeText={setFieldOptions}/>}
        <TextInput style={styles.input} placeholder="نص توضيحي" value={fieldPlaceholder} onChangeText={setFieldPlaceholder}/>
        <TextInput style={styles.input} placeholder="نص مساعدة" value={fieldHelp} onChangeText={setFieldHelp}/>
        <View style={styles.switchRow}><Text>مطلوب</Text><Switch value={fieldRequired} onValueChange={setFieldRequired}/></View>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>{setShowAddField(false);resetFieldForm();}}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleAddField}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>

      <Modal visible={showEditField} transparent animationType="slide"><View style={styles.modalOverlay}><View style={styles.modalContent}>
        <Text style={styles.modalTitle}>تعديل حقل</Text>
        <TextInput style={styles.input} placeholder="اسم الحقل" value={editFieldLabel} onChangeText={setEditFieldLabel}/>
        <Text style={styles.label}>نوع الحقل</Text>
        <View style={styles.typeRow}>{FIELD_TYPES.map(t=>(<TouchableOpacity key={t.value} style={[styles.typeBtn,editFieldType===t.value&&styles.typeBtnActive]} onPress={()=>setEditFieldType(t.value)}><Text style={[styles.typeText,editFieldType===t.value&&styles.typeTextActive]}>{t.label}</Text></TouchableOpacity>))}</View>
        {editFieldType==='select'&&<TextInput style={styles.input} placeholder="الخيارات (مفصولة بفواصل)" value={editFieldOptions} onChangeText={setEditFieldOptions}/>}
        <TextInput style={styles.input} placeholder="نص توضيحي" value={editFieldPlaceholder} onChangeText={setEditFieldPlaceholder}/>
        <TextInput style={styles.input} placeholder="نص مساعدة" value={editFieldHelp} onChangeText={setEditFieldHelp}/>
        <View style={styles.switchRow}><Text>مطلوب</Text><Switch value={editFieldRequired} onValueChange={setEditFieldRequired}/></View>
        <View style={styles.modalBtns}><TouchableOpacity style={styles.cancelBtn} onPress={()=>setShowEditField(false)}><Text>إلغاء</Text></TouchableOpacity><TouchableOpacity style={styles.saveBtn} onPress={handleEditField}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity></View>
      </View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#F9FAFB'},center:{flex:1,justifyContent:'center',alignItems:'center'},
  header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',padding:16,backgroundColor:'#FFF',borderBottomWidth:1,borderBottomColor:'#E5E7EB'},
  headerTitle:{fontSize:18,fontWeight:'bold',color:'#1F2937'},content:{padding:16},
  card:{backgroundColor:'#FFF',borderRadius:12,padding:16,marginBottom:12,borderWidth:1,borderColor:'#E5E7EB'},
  serviceRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:8},
  serviceImg:{width:40,height:40,borderRadius:20},serviceName:{flex:1,fontSize:16,fontWeight:'600',color:'#1F2937'},
  subContainer:{marginTop:12,paddingTop:12,borderTopWidth:1,borderTopColor:'#F3F4F6'},
  subHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:8},
  subTitle:{fontSize:14,fontWeight:'600',color:'#4B5563'},
  subCard:{marginBottom:4},
  subRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:6,gap:6},
  subImg:{width:24,height:24,borderRadius:12},
  subName:{flex:1,fontSize:13,color:'#1F2937'},
  hiddenBadge:{fontSize:10,color:'#EF4444',backgroundColor:'#FEE2E2',paddingHorizontal:4,borderRadius:4},
  iconBtnEdit:{width:28,height:28,borderRadius:14,backgroundColor:'#F59E0B',justifyContent:'center',alignItems:'center'},
  fieldsContainer:{marginLeft:16,paddingTop:8,borderTopWidth:1,borderTopColor:'#F3F4F6'},
  fieldsTitle:{fontSize:12,fontWeight:'600',color:'#6B7280'},
  fieldRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:4,gap:4},
  fieldLabel:{flex:1,fontSize:12,color:'#4B5563'},
  modalOverlay:{flex:1,backgroundColor:'rgba(0,0,0,0.5)',justifyContent:'center',padding:20},
  modalContent:{backgroundColor:'#FFF',borderRadius:16,padding:20},
  modalTitle:{fontSize:18,fontWeight:'bold',marginBottom:16,textAlign:'center'},
  input:{backgroundColor:'#F9FAFB',borderWidth:1,borderColor:'#E5E7EB',borderRadius:8,padding:12,marginBottom:12,fontSize:14},
  label:{fontSize:14,fontWeight:'600',color:'#4B5563',marginBottom:8},
  colorDot:{width:36,height:36,borderRadius:18,marginRight:8},
  imagePicker:{height:120,backgroundColor:'#F3F4F6',borderRadius:8,marginBottom:12,justifyContent:'center',alignItems:'center',overflow:'hidden'},
  previewImg:{width:'100%',height:'100%',resizeMode:'cover'},imgPlaceholder:{justifyContent:'center',alignItems:'center'},
  typeRow:{flexDirection:'row',flexWrap:'wrap',gap:6,marginBottom:12},
  typeBtn:{paddingHorizontal:10,paddingVertical:6,borderRadius:16,backgroundColor:'#F3F4F6',borderWidth:1,borderColor:'#E5E7EB'},
  typeBtnActive:{backgroundColor:'#8B5CF6',borderColor:'#8B5CF6'},
  typeText:{fontSize:11,color:'#4B5563'},typeTextActive:{color:'#FFF',fontWeight:'600'},
  switchRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:12},
  modalBtns:{flexDirection:'row',justifyContent:'flex-end',gap:10},
  cancelBtn:{padding:10,backgroundColor:'#E5E7EB',borderRadius:8},
  saveBtn:{padding:10,backgroundColor:'#8B5CF6',borderRadius:8},
  saveText:{color:'#FFF',fontWeight:'600'},
});
