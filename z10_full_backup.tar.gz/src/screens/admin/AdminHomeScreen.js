import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView, Alert, ActivityIndicator, Modal, StatusBar, BackHandler } from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { getOrders } from '../../services/orderService';
import CustomDrawer from '../../components/CustomDrawer';
import { fontFamily } from '../../utils/fonts';

export default function AdminHomeScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    pendingOrders: 0,
    pendingProducts: 0,
    pendingVerifications: 0,
    pendingOffers: 0,
    merchants: 0,
    customers: 0,
  });
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [userData, setUserData] = useState(null);

  useEffect(() => { loadUserData(); loadStats(); const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true); return () => backHandler.remove(); }, []);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      if (user.role === 'admin' && user.id !== 'master_admin') {
        const { data: profile } = await supabase.from('profiles').select('admin_level').eq('id', user.id).single();
        if (profile?.admin_level) { user.admin_level = profile.admin_level; await AsyncStorage.setItem('userData', JSON.stringify(user)); }
        if (user.admin_level === 'super') await AsyncStorage.setItem('masterAdminPassword', 'Admin135792');
      }
      if (user.id === 'master_admin') await AsyncStorage.setItem('masterAdminPassword', 'Admin135792');
      setUserData(user);
    }
  };

  const loadStats = async () => {
    setLoading(true);
    try {
      const ordersResult = await getOrders({ status: 'pending' });
      const pendingOrders = ordersResult.success ? ordersResult.data.length : 0;
      const { count: pendingProducts } = await supabase.from(TABLES.PRODUCTS).select('*', { count: 'exact', head: true }).eq('status', 'pending');
      const { count: pendingVerifications } = await supabase.from(TABLES.PROFILES).select('*', { count: 'exact', head: true }).eq('role', 'merchant').eq('is_verified', false);
      const { count: pendingOffers } = await supabase.from('offers').select('*', { count: 'exact', head: true }).eq('status', 'pending');
      const { count: merchants } = await supabase.from(TABLES.PROFILES).select('*', { count: 'exact', head: true }).eq('role', 'merchant');
      const { count: customers } = await supabase.from(TABLES.PROFILES).select('*', { count: 'exact', head: true }).eq('role', 'customer');

      setStats({ pendingOrders, pendingProducts: pendingProducts || 0, pendingVerifications: pendingVerifications || 0, pendingOffers: pendingOffers || 0, merchants: merchants || 0, customers: customers || 0 });
    } catch (error) { console.error('خطأ:', error); } finally { setLoading(false); setRefreshing(false); }
  };

  const handleRefresh = () => { setRefreshing(true); loadStats(); };

  const handleLogout = async () => {
    Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
      { text: 'إلغاء' },
      { text: 'خروج', onPress: async () => { await AsyncStorage.removeItem('userData'); await AsyncStorage.removeItem('userRole'); await AsyncStorage.removeItem('masterAdminPassword'); navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] }); } }
    ]);
  };

  const urgentItems = [
    { id: 'orders', icon: 'cart', color: '#F59E0B', label: 'إدارة الطلبات', screen: 'AdminOrders', badge: stats.pendingOrders },
    { id: 'review_products', icon: 'checkmark-done-circle', color: '#EF4444', label: 'مراجعة المنتجات', screen: 'ReviewProductsScreen', badge: stats.pendingProducts },
    { id: 'unified_verification', icon: 'shield-checkmark', color: '#3B82F6', label: 'توثيق التجار', screen: 'UnifiedVerificationScreen', badge: stats.pendingVerifications },
    { id: 'manage_offers', icon: 'pricetag', color: '#10B981', label: 'طلبات العروض', screen: 'ManageOffersScreen', badge: stats.pendingOffers },
  ];

  const storeItems = [
    { id: 'shop_management', icon: 'cart', color: '#10B981', label: 'المتجر', screen: 'ShopManagement' },
    { id: 'template_products', icon: 'pricetags', color: '#8B5CF6', label: 'المنتجات الموحدة', screen: 'TemplateProductsScreen' },
    { id: 'all_products', icon: 'cube', color: '#6B7280', label: 'جميع المنتجات', screen: 'ManageAllProductsScreen' },
    { id: 'product_categories', icon: 'folder-open', color: '#8B5CF6', label: 'فئات الأقسام', screen: 'ManageProductCategoriesScreen' },
  ];

  const systemItems = [
    { id: 'services', icon: 'apps', color: '#4F46E5', label: 'واجهة الخدمات', screen: 'ServicesManagement' },
    { id: 'service_categories', icon: 'pricetags', color: '#F59E0B', label: 'تقسيم الخدمات', screen: 'ManageServiceCategoriesScreen' },
    { id: 'assistants', icon: 'chatbubbles', color: '#8B5CF6', label: 'المساعد الذكي', screen: 'AdminAssistants' },
    { id: 'tracking_steps', icon: 'git-branch-outline', color: '#8B5CF6', label: 'خطوات التتبع', screen: 'ManageTrackingStepsScreen' },
    { id: 'settings', icon: 'settings-outline', color: '#6366F1', label: 'الإعدادات', screen: 'Settings' },
  ];

  const adminItems = [
    { id: 'all_users', icon: 'people', color: '#4F46E5', label: 'إدارة المستخدمين', screen: 'UserManagement', badge: stats.merchants + stats.customers },
    { id: 'add_user', icon: 'person-add', color: '#10B981', label: 'إضافة مستخدم', screen: 'AddUser' },
    { id: 'regions', icon: 'location-outline', color: '#0891B2', label: 'إدارة المناطق', screen: 'ManageRegionsScreen' },
    { id: 'places', icon: 'location', color: '#14B8A6', label: 'مواقع التجار', screen: 'ManagePlacesScreen' },
  ];

  const renderSection = (title, items) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.grid}>
        {items.map((item) => (
          <TouchableOpacity key={item.id} style={styles.menuCard} onPress={() => navigation.navigate(item.screen)}>
            <View style={[styles.iconCircle, { backgroundColor: item.color + '20' }]}>
              <Ionicons name={item.icon} size={24} color={item.color} />
            </View>
            <Text style={styles.menuText}>{item.label}</Text>
            {item.badge > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{item.badge}</Text></View>}
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuButton}><Ionicons name="menu" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.title}>لوحة التحكم</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshBtn} disabled={refreshing}>
            <Ionicons name="refresh" size={22} color={refreshing ? '#9CA3AF' : '#4F46E5'} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogout}><Ionicons name="log-out-outline" size={24} color="#EF4444" /></TouchableOpacity>
        </View>
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {renderSection('📂 العمليات العاجلة', urgentItems)}
        {renderSection('📦 المتجر والمخزون', storeItems)}
        {renderSection('🛠️ النظام والخدمات', systemItems)}
        {renderSection('👥 الإدارة العامة', adminItems)}
        <View style={{ height: 40 }} />
      </ScrollView>
      <Modal visible={drawerVisible} transparent animationType="slide"><View style={styles.drawerOverlay}><View style={styles.drawerContent}><CustomDrawer isLoggedIn={true} userData={userData} onClose={() => setDrawerVisible(false)} navigation={navigation} onOpenAdminModal={() => {}} /></View></View></Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  menuButton: { padding: 8 },
  title: { fontSize: 20, fontWeight: '700', color: '#1F2937', flex: 1, textAlign: 'center', fontFamily: fontFamily.arabic },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  refreshBtn: { padding: 8, borderRadius: 20, backgroundColor: '#EEF2FF' },
  content: { padding: 16 },
  section: { marginBottom: 24 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 12, fontFamily: fontFamily.arabic },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  menuCard: { width: '47%', backgroundColor: '#FFF', borderRadius: 16, padding: 18, alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB', position: 'relative' },
  iconCircle: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  menuText: { fontSize: 13, fontWeight: '600', color: '#1F2937', textAlign: 'center', fontFamily: fontFamily.arabic },
  badge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#EF4444', borderRadius: 10, minWidth: 22, height: 22, justifyContent: 'center', alignItems: 'center' },
  badgeText: { color: '#FFF', fontSize: 10, fontWeight: 'bold' },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  drawerContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 25, borderTopRightRadius: 25, height: '80%', overflow: 'hidden' },
});
