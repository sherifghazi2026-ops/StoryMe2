import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput, Alert,
  ActivityIndicator, Image, Modal, FlatList, ScrollView, RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useFocusEffect } from '@react-navigation/native';
import { supabase } from '../../lib/supabaseClient';
import { uploadToImageKit, uploadServiceImage } from '../../services/uploadService';
import { fontFamily } from '../../utils/fonts';

const CAT_ICONS = ['folder-outline','cube','cafe','pizza','nutrition','fast-food','cart','basket','wine','ice-cream','fish','archive','sparkles'];

export default function TemplateProductsScreen({ navigation }) {
  const [services, setServices] = useState([]);
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // ====== Dropdown الخدمة ======
  const [selectedServiceId, setSelectedServiceId] = useState(null);
  const [selectedServiceName, setSelectedServiceName] = useState('كل الخدمات');
  const [showServicePicker, setShowServicePicker] = useState(false);

  // ====== مودال القسم ======
  const [showCatModal, setShowCatModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [catName, setCatName] = useState('');
  const [catIcon, setCatIcon] = useState('folder-outline');
  const [catSortOrder, setCatSortOrder] = useState('0');
  const [catImageUrl, setCatImageUrl] = useState('');
  const [catServiceId, setCatServiceId] = useState(null);
  const [uploadingCat, setUploadingCat] = useState(false);
  const [submittingCat, setSubmittingCat] = useState(false);

  // ====== مودال المنتج ======
  const [showProdModal, setShowProdModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodCategoryId, setProdCategoryId] = useState(null);
  const [prodCategoryName, setProdCategoryName] = useState('');
  const [prodImageUrl, setProdImageUrl] = useState('');
  const [uploadingProd, setUploadingProd] = useState(false);
  const [submittingProd, setSubmittingProd] = useState(false);
  const [showProdCatPicker, setShowProdCatPicker] = useState(false);

  useFocusEffect(useCallback(() => { loadAll(); }, []));

  const loadAll = async () => {
    setLoading(true);
    await Promise.all([loadServices(), loadCategories(), loadProducts()]);
    setLoading(false);
    setRefreshing(false);
  };

  const loadServices = async () => {
    const { data } = await supabase
      .from('services')
      .select('id, name, type')
      .in('type', ['items', 'products'])
      .order('name');
    if (data) {
      setServices(data);
      if (!selectedServiceId && data.length > 0) {
        setSelectedServiceId(data[0].id);
        setSelectedServiceName(data[0].name);
      }
    }
  };

  const loadCategories = async () => {
    const { data } = await supabase.from('product_categories').select('*').order('sort_order', { ascending: true });
    if (data) setCategories(data);
  };

  const loadProducts = async () => {
    const { data } = await supabase.from('template_products').select('*').order('name');
    if (data) setProducts(data);
  };

  // تجميع المنتجات حسب الخدمة
  const getGroupedData = () => {
    const filteredProds = selectedServiceId ? products.filter(p => p.service_type === selectedServiceId) : products;
    const filteredCats = selectedServiceId ? categories.filter(c => c.service_id === selectedServiceId) : categories;

    // تجميع حسب الخدمة
    const servicesMap = {};
    filteredProds.forEach(p => {
      const sid = p.service_type || 'أخرى';
      if (!servicesMap[sid]) {
        const svc = services.find(s => s.id === sid) || { name: sid, id: sid };
        servicesMap[sid] = { service: svc, categories: {} };
      }
      const catId = p.category_id || 'عام';
      if (!servicesMap[sid].categories[catId]) {
        const cat = filteredCats.find(c => c.id === catId) || { id: catId, name: p.category || 'عام', icon: 'folder-outline' };
        servicesMap[sid].categories[catId] = { ...cat, products: [] };
      }
      servicesMap[sid].categories[catId].products.push(p);
    });

    // إضافة الأقسام الفارغة
    filteredCats.forEach(cat => {
      const sid = cat.service_id;
      if (servicesMap[sid] && !servicesMap[sid].categories[cat.id]) {
        servicesMap[sid].categories[cat.id] = { ...cat, products: [] };
      }
    });

    return Object.values(servicesMap);
  };

  const groupedData = getGroupedData();

  // ====== القسم ======
  const resetCatForm = () => {
    setEditingCategory(null); setCatName(''); setCatIcon('folder-outline');
    setCatSortOrder('0'); setCatImageUrl(''); setCatServiceId(selectedServiceId);
  };

  const openAddCat = () => { resetCatForm(); setShowCatModal(true); };
  const openEditCat = (cat) => {
    setEditingCategory(cat); setCatName(cat.name); setCatIcon(cat.icon || 'folder-outline');
    setCatSortOrder(String(cat.sort_order || 0)); setCatImageUrl(cat.image_url || '');
    setCatServiceId(cat.service_id); setShowCatModal(true);
  };

  const pickCatImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploadingCat(true);
      const res = await uploadServiceImage(result.assets[0].uri);
      setUploadingCat(false);
      if (res.success) setCatImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const saveCategory = async () => {
    if (!catName.trim()) { Alert.alert('تنبيه', 'اسم القسم مطلوب'); return; }
    if (!catServiceId) { Alert.alert('تنبيه', 'اختر الخدمة'); return; }
    setSubmittingCat(true);
    try {
      const data = {
        name: catName.trim(), icon: catIcon, sort_order: parseInt(catSortOrder) || 0,
        service_id: catServiceId, image_url: catImageUrl, updated_at: new Date().toISOString(),
      };
      if (editingCategory) {
        await supabase.from('product_categories').update(data).eq('id', editingCategory.id);
      } else {
        await supabase.from('product_categories').insert([{ ...data, created_at: new Date().toISOString() }]);
      }
      setShowCatModal(false); resetCatForm(); loadCategories();
    } catch (e) { Alert.alert('خطأ', e.message); }
    setSubmittingCat(false);
  };

  const deleteCategory = (cat) => {
    Alert.alert('حذف القسم', `حذف "${cat.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
        await supabase.from('product_categories').delete().eq('id', cat.id);
        loadCategories(); loadProducts();
      }}
    ]);
  };

  // ====== المنتج ======
  const resetProdForm = () => {
    setEditingProduct(null); setProdName(''); setProdDesc('');
    setProdCategoryId(null); setProdCategoryName('');
    setProdImageUrl('');
  };

  const openAddProd = (categoryId = null, categoryName = '') => {
    resetProdForm();
    if (categoryId) { setProdCategoryId(categoryId); setProdCategoryName(categoryName); }
    setShowProdModal(true);
  };

  const openEditProd = (prod) => {
    setEditingProduct(prod); setProdName(prod.name); setProdDesc(prod.description || '');
    setProdCategoryId(prod.category_id); setProdCategoryName(prod.category || '');
    setProdImageUrl(prod.image_url || ''); setShowProdModal(true);
  };

  const pickProdImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploadingProd(true);
      const res = await uploadToImageKit(result.assets[0].uri, `template_${Date.now()}.jpg`, 'templates');
      setUploadingProd(false);
      if (res.success) setProdImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const saveProduct = async () => {
    if (!prodName.trim()) { Alert.alert('تنبيه', 'اسم المنتج مطلوب'); return; }
    if (!prodCategoryId) { Alert.alert('تنبيه', 'اختر القسم'); return; }
    setSubmittingProd(true);
    try {
      const data = {
        name: prodName.trim(), description: prodDesc.trim(),
        category_id: prodCategoryId, category: prodCategoryName,
        service_type: selectedServiceId, image_url: prodImageUrl,
        is_approved: true, updated_at: new Date().toISOString(),
      };
      if (editingProduct) {
        await supabase.from('template_products').update(data).eq('id', editingProduct.id);
      } else {
        await supabase.from('template_products').insert([{ ...data, created_at: new Date().toISOString() }]);
      }
      setShowProdModal(false); resetProdForm(); loadProducts();
    } catch (e) { Alert.alert('خطأ', e.message); }
    setSubmittingProd(false);
  };

  const deleteProduct = (prod) => {
    Alert.alert('حذف المنتج', `حذف "${prod.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
        await supabase.from('template_products').delete().eq('id', prod.id);
        loadProducts();
      }}
    ]);
  };

  const handleSelectService = (id, name) => {
    setSelectedServiceId(id);
    setSelectedServiceName(name);
    setShowServicePicker(false);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>المنتجات الموحدة</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={openAddCat} style={styles.headerBtn}>
            <Ionicons name="folder-open-outline" size={22} color="#8B5CF6" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => openAddProd()} style={styles.headerBtn}>
            <Ionicons name="add-circle" size={24} color="#4F46E5" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Dropdown الخدمة */}
      <TouchableOpacity style={styles.dropdown} onPress={() => setShowServicePicker(true)}>
        <View style={styles.dropdownLeft}>
          <Ionicons name="layers-outline" size={18} color="#4F46E5" />
          <Text style={styles.dropdownText}>{selectedServiceName}</Text>
        </View>
        <Ionicons name="chevron-down" size={18} color="#9CA3AF" />
      </TouchableOpacity>

      {/* المحتوى */}
      <FlatList
        data={groupedData}
        keyExtractor={item => item.service.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadAll} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="cube-outline" size={60} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد منتجات موحدة</Text>
          </View>
        }
        renderItem={({ item: serviceGroup }) => {
          const svc = serviceGroup.service;
          const cats = Object.values(serviceGroup.categories);
          const totalProducts = cats.reduce((sum, c) => sum + c.products.length, 0);

          return (
            <View style={styles.serviceBlock}>
              {/* رأس الخدمة */}
              <View style={styles.serviceHeader}>
                <Ionicons name="layers-outline" size={22} color="#4F46E5" />
                <Text style={styles.serviceName}>{svc.name}</Text>
                <Text style={styles.serviceCount}>({totalProducts})</Text>
              </View>

              {/* الأقسام */}
              {cats.map(cat => (
                <View key={cat.id} style={styles.catCard}>
                  <View style={styles.catHeader}>
                    <Ionicons name={cat.icon || 'folder-outline'} size={18} color="#8B5CF6" />
                    <Text style={styles.catName}>{cat.name}</Text>
                    <Text style={styles.catCount}>{cat.products.length}</Text>
                    <View style={styles.catActions}>
                      <TouchableOpacity onPress={() => openAddProd(cat.id, cat.name)}>
                        <Ionicons name="add-circle-outline" size={20} color="#4F46E5" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => openEditCat(cat)}>
                        <Ionicons name="create-outline" size={18} color="#F59E0B" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => deleteCategory(cat)}>
                        <Ionicons name="trash-outline" size={18} color="#EF4444" />
                      </TouchableOpacity>
                    </View>
                  </View>

                  {/* منتجات القسم */}
                  {cat.products.length === 0 ? (
                    <Text style={styles.noProducts}>لا توجد منتجات</Text>
                  ) : (
                    <View style={styles.productsGrid}>
                      {cat.products.map(prod => (
                        <View key={prod.id} style={styles.prodCard}>
                          {prod.image_url ? (
                            <Image source={{ uri: prod.image_url }} style={styles.prodImage} />
                          ) : (
                            <View style={styles.prodPlaceholder}>
                              <Ionicons name="image-outline" size={20} color="#D1D5DB" />
                            </View>
                          )}
                          <Text style={styles.prodName} numberOfLines={2}>{prod.name}</Text>
                          <View style={styles.prodCardActions}>
                            <TouchableOpacity onPress={() => openEditProd(prod)}>
                              <Ionicons name="create-outline" size={16} color="#4F46E5" />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => deleteProduct(prod)}>
                              <Ionicons name="trash-outline" size={16} color="#EF4444" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}
                </View>
              ))}
            </View>
          );
        }}
      />

      {/* ========== مودالات ========== */}
      <Modal visible={showServicePicker} transparent animationType="fade">
        <TouchableOpacity style={styles.pickerOverlay} activeOpacity={1} onPress={() => setShowServicePicker(false)}>
          <View style={styles.pickerModal}>
            <Text style={styles.pickerTitle}>اختر الخدمة</Text>
            <ScrollView>
              {services.map(s => (
                <TouchableOpacity
                  key={s.id}
                  style={[styles.pickerItem, selectedServiceId === s.id && styles.pickerItemActive]}
                  onPress={() => handleSelectService(s.id, s.name)}
                >
                  <Ionicons name="ellipse-outline" size={20} color={selectedServiceId === s.id ? '#4F46E5' : '#6B7280'} />
                  <Text style={[styles.pickerItemText, selectedServiceId === s.id && styles.pickerItemTextActive]}>{s.name}</Text>
                  {selectedServiceId === s.id && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showCatModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingCategory ? 'تعديل القسم' : 'إضافة قسم جديد'}</Text>
              <TouchableOpacity onPress={() => { setShowCatModal(false); resetCatForm(); }}>
                <Ionicons name="close" size={24} color="#EF4444" />
              </TouchableOpacity>
            </View>
            <ScrollView style={{ maxHeight: 400 }} showsVerticalScrollIndicator={true}>
              <Text style={styles.label}>الخدمة *</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                {services.map(s => (
                  <TouchableOpacity key={s.id} style={[styles.chip, catServiceId === s.id && styles.chipActive]} onPress={() => setCatServiceId(s.id)}>
                    <Text style={[styles.chipText, catServiceId === s.id && styles.chipTextActive]}>{s.name}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <Text style={styles.label}>اسم القسم *</Text>
              <TextInput style={styles.input} placeholder="مثال: مشروبات" value={catName} onChangeText={setCatName} />
              <Text style={styles.label}>صورة القسم</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickCatImage} disabled={uploadingCat}>
                {uploadingCat ? <ActivityIndicator size="large" color="#8B5CF6" /> :
                  catImageUrl ? <Image source={{ uri: catImageUrl }} style={styles.previewImg} /> :
                  <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 12 }}>رفع صورة</Text></View>}
              </TouchableOpacity>
              <Text style={styles.label}>الأيقونة</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                {CAT_ICONS.map(icon => (
                  <TouchableOpacity key={icon} style={[styles.iconChip, catIcon === icon && styles.iconChipActive]} onPress={() => setCatIcon(icon)}>
                    <Ionicons name={icon} size={22} color={catIcon === icon ? '#FFF' : '#8B5CF6'} />
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <Text style={styles.label}>الترتيب</Text>
              <TextInput style={styles.input} placeholder="0" value={catSortOrder} onChangeText={setCatSortOrder} keyboardType="numeric" />
            </ScrollView>
            <TouchableOpacity style={[styles.saveBtn, submittingCat && { opacity: 0.6 }]} onPress={saveCategory} disabled={submittingCat}>
              {submittingCat ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{editingCategory ? 'حفظ التعديلات' : 'إضافة القسم'}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showProdModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}</Text>
              <TouchableOpacity onPress={() => { setShowProdModal(false); resetProdForm(); }}>
                <Ionicons name="close" size={24} color="#EF4444" />
              </TouchableOpacity>
            </View>
            <ScrollView style={{ maxHeight: 400 }} showsVerticalScrollIndicator={true}>
              <Text style={styles.label}>القسم *</Text>
              <TouchableOpacity style={styles.selector} onPress={() => setShowProdCatPicker(true)}>
                <Text style={styles.selectorText}>{prodCategoryName || 'اختر القسم'}</Text>
                <Ionicons name="chevron-down" size={18} color="#9CA3AF" />
              </TouchableOpacity>
              <Text style={styles.label}>اسم المنتج *</Text>
              <TextInput style={styles.input} placeholder="اسم المنتج" value={prodName} onChangeText={setProdName} />
              <Text style={styles.label}>الوصف</Text>
              <TextInput style={[styles.input, { height: 80, textAlignVertical: 'top' }]} placeholder="وصف المنتج" value={prodDesc} onChangeText={setProdDesc} multiline />
              <Text style={styles.label}>صورة المنتج</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickProdImage} disabled={uploadingProd}>
                {uploadingProd ? <ActivityIndicator size="large" color="#4F46E5" /> :
                  prodImageUrl ? <Image source={{ uri: prodImageUrl }} style={styles.previewImg} /> :
                  <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 12 }}>رفع صورة</Text></View>}
              </TouchableOpacity>
            </ScrollView>
            <TouchableOpacity style={[styles.saveBtn, submittingProd && { opacity: 0.6 }]} onPress={saveProduct} disabled={submittingProd}>
              {submittingProd ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج'}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showProdCatPicker} transparent animationType="fade">
        <TouchableOpacity style={styles.pickerOverlay} activeOpacity={1} onPress={() => setShowProdCatPicker(false)}>
          <View style={styles.pickerModal}>
            <Text style={styles.pickerTitle}>اختر القسم</Text>
            <ScrollView>
              {categories.filter(c => c.service_id === selectedServiceId).map(cat => (
                <TouchableOpacity
                  key={cat.id}
                  style={[styles.pickerItem, prodCategoryId === cat.id && styles.pickerItemActive]}
                  onPress={() => { setProdCategoryId(cat.id); setProdCategoryName(cat.name); setShowProdCatPicker(false); }}
                >
                  <Ionicons name={cat.icon || 'folder-outline'} size={20} color={prodCategoryId === cat.id ? '#8B5CF6' : '#6B7280'} />
                  <Text style={[styles.pickerItemText, prodCategoryId === cat.id && styles.pickerItemTextActive]}>{cat.name}</Text>
                  {prodCategoryId === cat.id && <Ionicons name="checkmark" size={20} color="#8B5CF6" />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  headerActions: { flexDirection: 'row', gap: 12 },
  headerBtn: { padding: 4 },
  dropdown: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFF', marginHorizontal: 14, marginTop: 12, padding: 14, borderRadius: 14, borderWidth: 1, borderColor: '#E5E7EB', elevation: 1 },
  dropdownLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dropdownText: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  list: { padding: 14, paddingBottom: 40 },
  empty: { alignItems: 'center', paddingVertical: 60 },
  emptyText: { color: '#9CA3AF', fontSize: 16, marginTop: 12, fontFamily: fontFamily.arabic },
  // خدمة
  serviceBlock: { marginBottom: 20 },
  serviceHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, gap: 6 },
  serviceName: { fontSize: 17, fontWeight: '700', color: '#1F2937', fontFamily: fontFamily.arabic },
  serviceCount: { fontSize: 13, color: '#6B7280' },
  // قسم
  catCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB' },
  catHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  catName: { fontSize: 14, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic, flex: 1 },
  catCount: { fontSize: 11, color: '#9CA3AF' },
  catActions: { flexDirection: 'row', gap: 6 },
  noProducts: { color: '#D1D5DB', fontSize: 12, textAlign: 'center', padding: 8 },
  productsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  // منتج
  prodCard: { width: '30%', backgroundColor: '#F9FAFB', borderRadius: 10, padding: 8, alignItems: 'center', borderWidth: 1, borderColor: '#F0F0F0' },
  prodImage: { width: 50, height: 50, borderRadius: 8, marginBottom: 4 },
  prodPlaceholder: { width: 50, height: 50, borderRadius: 8, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginBottom: 4 },
  prodName: { fontSize: 10, fontWeight: '500', color: '#1F2937', textAlign: 'center', fontFamily: fontFamily.arabic },
  prodCardActions: { flexDirection: 'row', gap: 8, marginTop: 4 },
  // Picker
  pickerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  pickerModal: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '100%', maxWidth: 340, maxHeight: '60%' },
  pickerTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  pickerItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 10, marginBottom: 4, gap: 12 },
  pickerItemActive: { backgroundColor: '#F5F3FF' },
  pickerItemText: { flex: 1, fontSize: 15, color: '#374151', fontFamily: fontFamily.arabic },
  pickerItemTextActive: { color: '#4F46E5', fontWeight: '600' },
  // مودال
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  label: { fontSize: 13, fontWeight: '600', color: '#4B5563', marginBottom: 6, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, fontSize: 14, marginBottom: 8, fontFamily: fontFamily.arabic },
  selector: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 8 },
  selectorText: { fontSize: 14, color: '#1F2937', fontFamily: fontFamily.arabic },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 16, backgroundColor: '#F3F4F6', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  chipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  chipText: { fontSize: 13, color: '#4B5563' },
  chipTextActive: { color: '#FFF', fontWeight: '600' },
  iconChip: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  iconChipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  imagePicker: { height: 130, backgroundColor: '#F3F4F6', borderRadius: 12, marginBottom: 12, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  previewImg: { width: '100%', height: '100%', resizeMode: 'cover' },
  imgPlaceholder: { justifyContent: 'center', alignItems: 'center' },
  saveBtn: { backgroundColor: '#4F46E5', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 12 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
