import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image, Alert, ActivityIndicator, Modal, TextInput, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

const IMAGEKIT_PRIVATE_KEY = 'private_EWamixKcyYNZI2xJmmO0iQBN53k=';
const IMAGEKIT_UPLOAD_ENDPOINT = 'https://upload.imagekit.io/api/v1/files/upload';

export default function SettingsAppearanceScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [appLogoUrl, setAppLogoUrl] = useState('');
  const [regionsIcon, setRegionsIcon] = useState('');
  const [offersHeaderUrl, setOffersHeaderUrl] = useState('');
  const [assistantIconUrl, setAssistantIconUrl] = useState('');
  const [headerImageUrl, setHeaderImageUrl] = useState('');
  const [backgroundImageUrl, setBackgroundImageUrl] = useState('');
  const [customerAuthBgUrl, setCustomerAuthBgUrl] = useState('');
  const [primaryColor, setPrimaryColor] = useState('#D946EF');
  const [accentColor, setAccentColor] = useState('#F97316');
  const [backgroundColor, setBackgroundColor] = useState('#FFFFFF');
  const [headerColor, setHeaderColor] = useState('#FFFFFF');
  const [categoryTextColor, setCategoryTextColor] = useState('#1F2937');
  const [serviceCategoryColor, setServiceCategoryColor] = useState('#1F2937');
  const [bgOpacity, setBgOpacity] = useState(30);
  const [cardOpacity, setCardOpacity] = useState(100);
  const [customerAuthOpacity, setCustomerAuthOpacity] = useState(100);
  const [headerStyleType, setHeaderStyleType] = useState('floating');

  const [pickerTarget, setPickerTarget] = useState('');
  const [pickerVisible, setPickerVisible] = useState(false);
  const [pickerValue, setPickerValue] = useState('');

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    setLoading(true);
    
    const { data: settings, error } = await supabase
      .from('app_settings')
      .select('*')
      .eq('id', 1)
      .single();

    if (error) {
      console.error('❌ خطأ في تحميل الإعدادات:', error.message);
    }

    if (settings) {
      setAppLogoUrl(settings.app_logo_url || '');
      setRegionsIcon(settings.regions_icon || '');
      setPrimaryColor(settings.primary_color || '#D946EF');
      setAccentColor(settings.accent_color || '#F97316');
      setHeaderStyleType(settings.header_style_type || 'floating');
      setBackgroundColor(settings.background_color || '#FFFFFF');
      setHeaderColor(settings.header_color || '#FFFFFF');
      setAssistantIconUrl(settings.assistant_icon_url || '');
      setHeaderImageUrl(settings.header_image_url || '');
      setBackgroundImageUrl(settings.background_image_url || '');
      setCustomerAuthBgUrl(settings.customer_auth_background_url || '');
      
      const bgVal = parseFloat(settings.bg_opacity) || 0.3;
      setBgOpacity(Math.round(bgVal * 100));
      
      const cardVal = parseFloat(settings.card_opacity) || 1;
      setCardOpacity(Math.round(cardVal * 100));
      
      const caVal = parseFloat(settings.customer_auth_opacity) || 1;
      setCustomerAuthOpacity(Math.round(caVal * 100));
      
      setCategoryTextColor(settings.category_text_color || '#1F2937');
      setServiceCategoryColor(settings.service_category_color || '#1F2937');
    }

    const { data: service } = await supabase.from('services').select('image_url').eq('id', 'offers_header').single();
    if (service?.image_url) { setOffersHeaderUrl(service.image_url); }
    setLoading(false);
  };

  const saveAllSettings = async () => {
    setSaving(true);
    console.log('💾 بدء حفظ الإعدادات...');

    try {
      const { error } = await supabase
        .from('app_settings')
        .upsert({
          id: 1,
          app_logo_url: appLogoUrl,
          regions_icon: regionsIcon,
          primary_color: primaryColor,
          accent_color: accentColor,
          header_style_type: headerStyleType,
          background_color: backgroundColor,
          header_color: headerColor,
          assistant_icon_url: assistantIconUrl,
          header_image_url: headerImageUrl,
          background_image_url: backgroundImageUrl,
          customer_auth_background_url: customerAuthBgUrl,
          bg_opacity: String(bgOpacity / 100),
          card_opacity: String(cardOpacity / 100),
          customer_auth_opacity: String(customerAuthOpacity / 100),
          category_text_color: categoryTextColor,
          service_category_color: serviceCategoryColor,
          updated_at: new Date().toISOString()
        }, { onConflict: 'id' });

      if (error) {
        console.error('❌ خطأ في الحفظ:', error);
        throw error;
      }

      await supabase.from('services').upsert({
        id: 'offers_header',
        name: 'Header العروض',
        type: 'regular',
        image_url: offersHeaderUrl,
        is_active: true,
        is_visible: false
      }, { onConflict: 'id' });

      console.log('✅ تم الحفظ بنجاح');
      
      const { data: verify } = await supabase.from('app_settings').select('*').eq('id', 1).single();
      console.log('🔍 تحقق:', {
        app_logo_url: verify?.app_logo_url,
        customer_auth_background_url: verify?.customer_auth_background_url,
        background_image_url: verify?.background_image_url
      });

      Alert.alert('✅ تم', 'تم حفظ جميع إعدادات المظهر بنجاح');
    } catch (error) {
      Alert.alert('خطأ', error.message);
      console.error('❌ خطأ في الحفظ:', error);
    }
    setSaving(false);
  };

  const handlePickImage = async (target) => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') { Alert.alert('صلاحية', 'يجب السماح بالوصول للمعرض'); return; }
      
      const result = await ImagePicker.launchImageLibraryAsync({ 
        mediaTypes: ['images'], 
        allowsEditing: true, 
        quality: 0.8 
      });
      
      if (result.canceled || !result.assets?.[0]) return;
      
      setUploading(true);
      const file = result.assets[0];
      const fileName = `${target}_${Date.now()}.jpg`;
      
      console.log('📤 بدء رفع:', { target, fileName });
      
      const fd = new FormData();
      fd.append('file', { uri: file.uri, type: 'image/jpeg', name: fileName });
      fd.append('fileName', fileName);
      fd.append('folder', '/zayedid/pictures');
      fd.append('useUniqueFileName', 'true');
      
      const res = await fetch(IMAGEKIT_UPLOAD_ENDPOINT, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'),
        },
        body: fd,
      });
      
      const json = await res.json();
      
      if (json.url) {
        console.log('✅ تم الرفع:', json.url.substring(0, 50) + '...');
        
        switch(target) {
          case 'appLogo': setAppLogoUrl(json.url); break;
          case 'regionsIcon': setRegionsIcon(json.url); break;
          case 'offersHeader': setOffersHeaderUrl(json.url); break;
          case 'headerImage': setHeaderImageUrl(json.url); break;
          case 'backgroundImage': setBackgroundImageUrl(json.url); break;
          case 'customerAuthBg': setCustomerAuthBgUrl(json.url); break;
          case 'assistantIcon': setAssistantIconUrl(json.url); break;
        }
        
        Alert.alert('✅ تم', 'تم رفع الصورة بنجاح.\nاضغط "حفظ جميع التغييرات" للتثبيت.');
      } else {
        throw new Error(json.message || 'فشل الرفع');
      }
    } catch (e) { 
      console.error('❌ خطأ:', e);
      Alert.alert('خطأ', 'فشل الرفع: ' + (e.message || 'خطأ غير معروف'));
    }
    setUploading(false);
  };

  const openManualEdit = (target) => {
    let currentValue = '';
    switch(target) {
      case 'appLogo': currentValue = appLogoUrl; break;
      case 'regionsIcon': currentValue = regionsIcon; break;
      case 'offersHeader': currentValue = offersHeaderUrl; break;
      case 'assistantIcon': currentValue = assistantIconUrl; break;
      case 'headerImage': currentValue = headerImageUrl; break;
      case 'backgroundImage': currentValue = backgroundImageUrl; break;
      case 'customerAuthBg': currentValue = customerAuthBgUrl; break;
      case 'primaryColor': currentValue = primaryColor; break;
      case 'accentColor': currentValue = accentColor; break;
      case 'backgroundColor': currentValue = backgroundColor; break;
      case 'headerColor': currentValue = headerColor; break;
      case 'categoryTextColor': currentValue = categoryTextColor; break;
      case 'serviceCategoryColor': currentValue = serviceCategoryColor; break;
      case 'bgOpacity': currentValue = String(bgOpacity); break;
      case 'cardOpacity': currentValue = String(cardOpacity); break;
      case 'customerAuthOpacity': currentValue = String(customerAuthOpacity); break;
    }
    setPickerTarget(target);
    setPickerValue(currentValue);
    setPickerVisible(true);
  };

  const saveManualValue = async () => {
    const val = pickerValue.trim();
    switch(pickerTarget) {
      case 'appLogo': setAppLogoUrl(val); break;
      case 'regionsIcon': setRegionsIcon(val); break;
      case 'offersHeader': setOffersHeaderUrl(val); break;
      case 'assistantIcon': setAssistantIconUrl(val); break;
      case 'headerImage': setHeaderImageUrl(val); break;
      case 'backgroundImage': setBackgroundImageUrl(val); break;
      case 'customerAuthBg': setCustomerAuthBgUrl(val); break;
      case 'primaryColor': setPrimaryColor(val); break;
      case 'accentColor': setAccentColor(val); break;
      case 'backgroundColor': setBackgroundColor(val); break;
      case 'headerColor': setHeaderColor(val); break;
      case 'categoryTextColor': setCategoryTextColor(val); break;
      case 'serviceCategoryColor': setServiceCategoryColor(val); break;
      case 'bgOpacity':
        let bgVal = parseInt(val, 10);
        if (isNaN(bgVal)) bgVal = 30;
        bgVal = Math.min(100, Math.max(0, bgVal));
        setBgOpacity(bgVal);
        break;
      case 'cardOpacity':
        let cardVal = parseInt(val, 10);
        if (isNaN(cardVal)) cardVal = 100;
        cardVal = Math.min(100, Math.max(0, cardVal));
        setCardOpacity(cardVal);
        break;
      case 'customerAuthOpacity':
        let caVal = parseInt(val, 10);
        if (isNaN(caVal)) caVal = 100;
        caVal = Math.min(100, Math.max(0, caVal));
        setCustomerAuthOpacity(caVal);
        break;
    }
    setPickerVisible(false);
  };

  const handleToggleHeaderStyle = async (type) => { setHeaderStyleType(type); };

  const renderImageRow = (label, iconName, target, value, color) => (
    <View style={styles.card} key={target}>
      <View style={styles.row}>
        <View style={[styles.iconCircle, { backgroundColor: color + '20' }]}>
          <Ionicons name={iconName} size={22} color={color} />
        </View>
        <View style={styles.rowText}>
          <Text style={styles.rowTitle}>{label}</Text>
          <Text style={styles.rowSub} numberOfLines={1}>{value || 'غير محدد'}</Text>
        </View>
      </View>
      {value ? <Image source={{ uri: value }} style={styles.preview} /> : <View style={styles.noPreview}><Ionicons name="image-outline" size={30} color="#D1D5DB" /></View>}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => handlePickImage(target)} disabled={uploading}>
          {uploading ? <ActivityIndicator size="small" color={primaryColor} /> : <Ionicons name="cloud-upload-outline" size={18} color={primaryColor} />}
          <Text style={{ color: primaryColor, fontSize: 13, marginLeft: 4, fontFamily: fontFamily.arabic }}>رفع</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => openManualEdit(target)}>
          <Ionicons name="create-outline" size={18} color={primaryColor} />
          <Text style={{ color: primaryColor, fontSize: 13, marginLeft: 4, fontFamily: fontFamily.arabic }}>تعديل</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>🎨 مظهر الهوية البصرية</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* ألوان الهوية الرقمية */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>🎨 ألوان الهوية الرقمية</Text>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: primaryColor }]} />
              <View><Text style={styles.colorLabel}>اللون الرئيسي</Text><Text style={styles.colorHex}>{primaryColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: primaryColor}]} onPress={() => openManualEdit('primaryColor')}>
              <Text style={[styles.colorEditBtnText, {color: primaryColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: accentColor }]} />
              <View><Text style={styles.colorLabel}>لون التنبيهات</Text><Text style={styles.colorHex}>{accentColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: accentColor}]} onPress={() => openManualEdit('accentColor')}>
              <Text style={[styles.colorEditBtnText, {color: accentColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ألوان الواجهة */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>📱 ألوان الواجهة</Text>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: backgroundColor }]} />
              <View><Text style={styles.colorLabel}>خلفية الشاشة الرئيسية</Text><Text style={styles.colorHex}>{backgroundColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: backgroundColor}]} onPress={() => openManualEdit('backgroundColor')}>
              <Text style={[styles.colorEditBtnText, {color: backgroundColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: headerColor }]} />
              <View><Text style={styles.colorLabel}>خلفية الهيدر العلوي</Text><Text style={styles.colorHex}>{headerColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: headerColor}]} onPress={() => openManualEdit('headerColor')}>
              <Text style={[styles.colorEditBtnText, {color: headerColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ألوان النصوص */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>📝 ألوان النصوص</Text>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: categoryTextColor }]} />
              <View><Text style={styles.colorLabel}>لون كتابة الفئات</Text><Text style={styles.colorHex}>{categoryTextColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: categoryTextColor}]} onPress={() => openManualEdit('categoryTextColor')}>
              <Text style={[styles.colorEditBtnText, {color: categoryTextColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.colorRow}>
            <View style={styles.colorInfo}>
              <View style={[styles.colorPreview, { backgroundColor: serviceCategoryColor }]} />
              <View><Text style={styles.colorLabel}>لون تقسيم الخدمات</Text><Text style={styles.colorHex}>{serviceCategoryColor}</Text></View>
            </View>
            <TouchableOpacity style={[styles.colorEditBtn, {borderColor: serviceCategoryColor}]} onPress={() => openManualEdit('serviceCategoryColor')}>
              <Text style={[styles.colorEditBtnText, {color: serviceCategoryColor}]}>تغيير</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* صور الواجهة */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>🖼️ صور الواجهة</Text>
          {renderImageRow('أيقونة المساعد الذكي', 'chatbubble-ellipses', 'assistantIcon', assistantIconUrl, '#4F46E5')}
          {renderImageRow('صورة خلفية الشاشة', 'image-outline', 'backgroundImage', backgroundImageUrl, '#8B5CF6')}
          {renderImageRow('صورة خلفية الهيدر', 'image-outline', 'headerImage', headerImageUrl, '#3B82F6')}
          {renderImageRow('شعار التطبيق', 'image-outline', 'appLogo', appLogoUrl, '#3B82F6')}
          {renderImageRow('أيقونة المناطق', 'location-outline', 'regionsIcon', regionsIcon, '#4F46E5')}
          {renderImageRow('Header العروض', 'pricetag-outline', 'offersHeader', offersHeaderUrl, '#F59E0B')}
        </View>

        {/* شفافية الخلفية */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>🏠 شفافية خلفية الرئيسية (Home)</Text>
          <View style={styles.opacityRow}>
            <View style={[styles.opacityPreview, { backgroundColor: primaryColor }]}>
              <Text style={styles.opacityValue}>{bgOpacity}%</Text>
            </View>
            <View style={styles.opacityControls}>
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setBgOpacity(Math.max(0, bgOpacity - 10))}>
                <Ionicons name="remove-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
              <TextInput
                style={styles.opacityInput}
                value={String(bgOpacity)}
                onChangeText={(val) => {
                  let v = parseInt(val, 10);
                  if (isNaN(v)) v = 30;
                  setBgOpacity(Math.min(100, Math.max(0, v)));
                }}
                keyboardType="numeric"
              />
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setBgOpacity(Math.min(100, bgOpacity + 10))}>
                <Ionicons name="add-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.opacityHint}>0% = الصورة تختفي | 100% = الصورة واضحة</Text>
        </View>

        {/* شفافية بطاقات الخدمات */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>🎴 شفافية بطاقات الخدمات (Cards)</Text>
          <View style={styles.opacityRow}>
            <View style={[styles.opacityPreview, { backgroundColor: primaryColor }]}>
              <Text style={styles.opacityValue}>{cardOpacity}%</Text>
            </View>
            <View style={styles.opacityControls}>
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setCardOpacity(Math.max(0, cardOpacity - 10))}>
                <Ionicons name="remove-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
              <TextInput
                style={styles.opacityInput}
                value={String(cardOpacity)}
                onChangeText={(val) => {
                  let v = parseInt(val, 10);
                  if (isNaN(v)) v = 100;
                  setCardOpacity(Math.min(100, Math.max(0, v)));
                }}
                keyboardType="numeric"
              />
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setCardOpacity(Math.min(100, cardOpacity + 10))}>
                <Ionicons name="add-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.opacityHint}>0% = البطاقات شفافة | 100% = البطاقات غير شفافة</Text>
        </View>

        {/* شاشة تسجيل الدخول */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>🔐 شاشة تسجيل الدخول (CustomerAuth)</Text>
          <Text style={styles.subLabel}>صورة الخلفية</Text>
          {renderImageRow('صورة خلفية تسجيل الدخول', 'image-outline', 'customerAuthBg', customerAuthBgUrl, '#EC4899')}
          <Text style={styles.subLabel}>شفافية الخلفية</Text>
          <View style={styles.opacityRow}>
            <View style={[styles.opacityPreview, { backgroundColor: primaryColor }]}>
              <Text style={styles.opacityValue}>{customerAuthOpacity}%</Text>
            </View>
            <View style={styles.opacityControls}>
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setCustomerAuthOpacity(Math.max(0, customerAuthOpacity - 10))}>
                <Ionicons name="remove-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
              <TextInput
                style={styles.opacityInput}
                value={String(customerAuthOpacity)}
                onChangeText={(val) => {
                  let v = parseInt(val, 10);
                  if (isNaN(v)) v = 100;
                  setCustomerAuthOpacity(Math.min(100, Math.max(0, v)));
                }}
                keyboardType="numeric"
              />
              <TouchableOpacity style={styles.opacityBtn} onPress={() => setCustomerAuthOpacity(Math.min(100, customerAuthOpacity + 10))}>
                <Ionicons name="add-outline" size={24} color="#4F46E5" />
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.opacityHint}>0% = الصورة تختفي | 100% = الصورة واضحة</Text>
        </View>

        {/* نمط الهيدر */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>📱 نمط الهيدر</Text>
          <View style={styles.styleSelector}>
            <TouchableOpacity
              style={[styles.selectorBtn, headerStyleType === 'floating' && { backgroundColor: primaryColor + '15', borderColor: primaryColor }]}
              onPress={() => handleToggleHeaderStyle('floating')}>
              <Ionicons name="layers-outline" size={20} color={headerStyleType === 'floating' ? primaryColor : '#6B7280'} />
              <Text style={[styles.selectorText, headerStyleType === 'floating' && { color: primaryColor, fontWeight: '700' }]}>عائم</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.selectorBtn, headerStyleType === 'flat' && { backgroundColor: primaryColor + '15', borderColor: primaryColor }]}
              onPress={() => handleToggleHeaderStyle('flat')}>
              <Ionicons name="square-outline" size={20} color={headerStyleType === 'flat' ? primaryColor : '#6B7280'} />
              <Text style={[styles.selectorText, headerStyleType === 'flat' && { color: primaryColor, fontWeight: '700' }]}>مسطح</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* زر الحفظ */}
        <TouchableOpacity style={[styles.saveButton, saving && styles.disabled]} onPress={saveAllSettings} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : (
            <>
              <Ionicons name="save-outline" size={20} color="#FFF" />
              <Text style={styles.saveButtonText}>حفظ جميع التغييرات</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={pickerVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>تعديل القيمة</Text>
            <TextInput style={styles.modalInput} value={pickerValue} onChangeText={setPickerValue} autoCapitalize="none" />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => setPickerVisible(false)}>
                <Text style={styles.cancelText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.saveBtn, { backgroundColor: primaryColor }]} onPress={saveManualValue}>
                <Text style={styles.saveText}>تطبيق</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  backBtn: { padding: 8, borderRadius: 10, backgroundColor: '#F1F5F9' },
  headerTitle: { fontSize: 17, fontWeight: 'bold', color: '#0F172A', fontFamily: fontFamily.arabic },
  content: { padding: 16, gap: 14, paddingBottom: 50 },
  card: { backgroundColor: '#FFF', borderRadius: 20, padding: 16, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 4 },
  sectionCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 18, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 4 },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: '#1E293B', marginBottom: 16, textAlign: 'right', fontFamily: fontFamily.arabic },
  subLabel: { fontSize: 13, fontWeight: '600', color: '#4B5563', marginTop: 8, marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  iconCircle: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  rowText: { flex: 1, alignItems: 'flex-start' },
  rowTitle: { fontSize: 14, fontWeight: '600', color: '#0F172A', fontFamily: fontFamily.arabic },
  rowSub: { fontSize: 11, color: '#94A3B8', marginTop: 2 },
  preview: { width: '100%', height: 130, borderRadius: 14, marginBottom: 12, resizeMode: 'cover' },
  noPreview: { width: '100%', height: 80, borderRadius: 14, backgroundColor: '#F8FAFC', justifyContent: 'center', alignItems: 'center', marginBottom: 12, borderWidth: 1, borderColor: '#E2E8F0', borderStyle: 'dashed' },
  actions: { flexDirection: 'row', justifyContent: 'space-around', borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 12 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 10, backgroundColor: '#F8FAFC' },
  colorRow: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  colorInfo: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  colorPreview: { width: 36, height: 36, borderRadius: 10, borderWidth: 2, borderColor: '#E2E8F0' },
  colorLabel: { fontSize: 13, fontWeight: '600', color: '#334155', fontFamily: fontFamily.arabic },
  colorHex: { fontSize: 12, color: '#64748B', textAlign: 'right', marginTop: 2, fontWeight: '500' },
  colorEditBtn: { borderWidth: 1, paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8 },
  colorEditBtnText: { fontSize: 12, fontWeight: '600', fontFamily: fontFamily.arabic },
  styleSelector: { flexDirection: 'row', gap: 12, marginTop: 4 },
  selectorBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#F8FAFC' },
  selectorText: { fontSize: 12, color: '#475569', fontFamily: fontFamily.arabic },
  opacityRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  opacityPreview: { width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
  opacityValue: { fontSize: 18, fontWeight: 'bold', color: '#FFF' },
  opacityControls: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  opacityBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  opacityInput: { width: 60, textAlign: 'center', fontSize: 18, fontWeight: '600', padding: 8, backgroundColor: '#FFF', borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0' },
  opacityHint: { fontSize: 11, color: '#64748B', textAlign: 'center', marginTop: 8 },
  saveButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, marginTop: 20, marginBottom: 30 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  disabled: { opacity: 0.6 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(15, 23, 42, 0.45)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 24, padding: 24, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: 16, fontWeight: 'bold', color: '#0F172A', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  modalInput: { borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 14, padding: 14, fontSize: 15, color: '#0F172A', marginBottom: 20, backgroundColor: '#F8FAFC', textAlign: 'center' },
  modalBtns: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  btn: { flex: 1, padding: 14, borderRadius: 14, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#F1F5F9' },
  cancelText: { color: '#475569', fontSize: 14, fontWeight: '600', fontFamily: fontFamily.arabic },
  saveBtn: { backgroundColor: '#4F46E5' },
  saveText: { color: '#FFF', fontSize: 14, fontWeight: '600', fontFamily: fontFamily.arabic },
});
