import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Switch, ActivityIndicator,
  RefreshControl, Image, Modal, Alert, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { verifyMerchant } from '../../services/userService';
import { fontFamily } from '../../utils/fonts';

export default function VerificationRequestsScreen({ navigation }) {
  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedImages, setSelectedImages] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [activeTab, setActiveTab] = useState('verified');

  useEffect(() => { loadMerchants(); }, [activeTab]);

  const loadMerchants = async () => {
    try {
      const { data } = await supabase
        .from(TABLES.PROFILES)
        .select('*')
        .eq('role', 'merchant')
        .order('created_at', { ascending: false });

      const filtered = (data || []).filter(m => 
        activeTab === 'verified' ? m.is_verified === true : m.is_verified === false
      );

      setMerchants(filtered);
    } catch (error) { console.error(error); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const toggleVerification = async (userId, currentValue) => {
    const newValue = !currentValue;
    const result = await verifyMerchant(userId, newValue);
    if (result.success) {
      Alert.alert('✅ تم', newValue ? 'تم توثيق التاجر' : 'تم إلغاء توثيق التاجر');
      loadMerchants();
    } else Alert.alert('خطأ', result.error);
  };

  const openImages = (urls) => { setSelectedImages(urls); setModalVisible(true); };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.header}>
        <View>
          <Text style={[styles.name, { fontFamily: fontFamily.arabic }]}>{item.full_name || item.name}</Text>
          <Text style={styles.phone}>{item.merchant_type}</Text>
        </View>
        <Switch
          value={item.is_verified}
          onValueChange={() => toggleVerification(item.id, item.is_verified)}
          trackColor={{ false: '#E5E7EB', true: '#10B981' }}
          thumbColor={item.is_verified ? '#FFF' : '#9CA3AF'}
        />
      </View>

      {/* المستندات المرفقة */}
      {item.documents?.length > 0 && (
        <TouchableOpacity style={styles.imageRow} onPress={() => openImages(item.documents)}>
          <Ionicons name="folder-open-outline" size={20} color="#4F46E5" />
          <Text style={styles.imageText}>📄 {item.documents.length} ملفات توثيق</Text>
        </TouchableOpacity>
      )}
      {item.verification_image && (
        <TouchableOpacity style={styles.imageRow} onPress={() => openImages([item.verification_image])}>
          <Ionicons name="image-outline" size={20} color="#4F46E5" />
          <Text style={styles.imageText}>صورة البطاقة</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة التوثيق</Text>
        <TouchableOpacity onPress={loadMerchants}><Ionicons name="refresh" size={24} color="#4F46E5" /></TouchableOpacity>
      </View>

      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab === 'verified' && styles.activeTab]} onPress={() => setActiveTab('verified')}>
          <Text style={[styles.tabText, activeTab === 'verified' && styles.activeTabText]}>✅ موثق ({merchants.length})</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'unverified' && styles.activeTab]} onPress={() => setActiveTab('unverified')}>
          <Text style={[styles.tabText, activeTab === 'unverified' && styles.activeTabText]}>⏸️ غير موثق</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={merchants} renderItem={renderItem} keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadMerchants} />}
        ListEmptyComponent={<View style={styles.emptyContainer}><Ionicons name="people-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>{activeTab === 'verified' ? 'جميع التجار موثقين' : 'لا يوجد تجار غير موثقين'}</Text></View>}
      />

      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}><Ionicons name="close" size={30} color="#FFF" /></TouchableOpacity>
          {selectedImages && (
            <ScrollView horizontal pagingEnabled style={{ width: '100%' }}>
              {selectedImages.map((url, i) => (
                <Image key={i} source={{ uri: url }} style={styles.fullImage} resizeMode="contain" />
              ))}
            </ScrollView>
          )}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  tabRow: { flexDirection: 'row', backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  activeTab: { borderBottomWidth: 2, borderBottomColor: '#4F46E5' },
  tabText: { fontSize: 14, color: '#6B7280' },
  activeTabText: { color: '#4F46E5', fontWeight: '600' },
  list: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  name: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  phone: { fontSize: 13, color: '#6B7280' },
  imageRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, gap: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  imageText: { fontSize: 14, color: '#4F46E5' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', justifyContent: 'center', alignItems: 'center' },
  closeButton: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 10 },
  fullImage: { width: 350, height: '80%' },
});
