import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  Switch,
  Image,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { getAllPlaces, createPlace, updatePlace, deletePlace, togglePlaceStatus, uploadPlaceImage } from '../../services/placesService';
import { getAllServices } from '../../services/servicesService';

export default function AdminPlacesScreen({ navigation }) {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingPlace, setEditingPlace] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [services, setServices] = useState([]);

  // حقول النموذج
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [address, setAddress] = useState('');
  const [image, setImage] = useState(null);
  const [deliveryFee, setDeliveryFee] = useState('10');
  const [isActive, setIsActive] = useState(true);
  const [merchantId, setMerchantId] = useState('');
  const [merchantName, setMerchantName] = useState('');

  useEffect(() => {
    loadPlaces();
    loadServices();
  }, []);

  const loadPlaces = async () => {
    setLoading(true);
    const result = await getAllPlaces();
    if (result.success) {
      setPlaces(result.data);
    }
    setLoading(false);
  };

  const loadServices = async () => {
    const result = await getAllServices();
    if (result.success) {
      setServices(result.data.filter(s => s.type === 'items' || s.type === 'items_service'));
    }
  };

  const resetForm = () => {
    setEditingPlace(null);
    setName('');
    setType('');
    setAddress('');
    setImage(null);
    setDeliveryFee('10');
    setIsActive(true);
    setMerchantId('');
    setMerchantName('');
  };

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.7,
        allowsEditing: true,
      });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        setImage(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل اختيار الصورة');
    }
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('تنبيه', 'اسم المكان مطلوب');
      return;
    }
    if (!type) {
      Alert.alert('تنبيه', 'نوع الخدمة مطلوب');
      return;
    }

    setSubmitting(true);
    setUploading(true);

    try {
      let imageUrl = null;
      if (image && !editingPlace?.image_url?.includes(image)) {
        // صورة جديدة، نرفعها أولاً
        const uploadResult = await uploadPlaceImage('temp', image);
        if (uploadResult.success) {
          imageUrl = uploadResult.imageUrl;
        }
      } else if (editingPlace?.image_url) {
        imageUrl = editingPlace.image_url;
      }

      const placeData = {
        name: name.trim(),
        type,
        address: address.trim(),
        image_url: imageUrl,
        delivery_fee: parseFloat(deliveryFee) || 10,
        is_active: isActive,
        merchant_id: merchantId || null,
        merchant_name: merchantName || null,
      };

      let result;
      if (editingPlace) {
        result = await updatePlace(editingPlace.id, placeData);
      } else {
        result = await createPlace(placeData);
      }

      if (result.success) {
        Alert.alert('✅ تم', editingPlace ? 'تم تحديث المكان' : 'تم إضافة المكان');
        setModalVisible(false);
        resetForm();
        loadPlaces();
      } else {
        Alert.alert('خطأ', result.error);
      }
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setSubmitting(false);
      setUploading(false);
    }
  };

  const handleDelete = (place) => {
    Alert.alert(
      'حذف المكان',
      `هل أنت متأكد من حذف "${place.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            const result = await deletePlace(place.id);
            if (result.success) {
              loadPlaces();
              Alert.alert('✅ تم', 'تم حذف المكان');
            } else {
              Alert.alert('خطأ', result.error);
            }
          }
        }
      ]
    );
  };

  const handleToggleStatus = async (place) => {
    const result = await togglePlaceStatus(place.id, !place.is_active);
    if (result.success) {
      loadPlaces();
    }
  };

  const openEditModal = (place) => {
    setEditingPlace(place);
    setName(place.name || '');
    setType(place.type || '');
    setAddress(place.address || '');
    setImage(place.image_url || null);
    setDeliveryFee(String(place.delivery_fee || '10'));
    setIsActive(place.is_active !== false);
    setMerchantId(place.merchant_id || '');
    setMerchantName(place.merchant_name || '');
    setModalVisible(true);
  };

  const renderPlace = ({ item }) => (
    <View style={[styles.placeCard, !item.is_active && styles.placeCardDisabled]}>
      <View style={styles.placeHeader}>
        {item.image_url ? (
          <Image source={{ uri: item.image_url }} style={styles.placeImage} />
        ) : (
          <View style={[styles.placeImage, styles.placeholderImage]}>
            <Ionicons name="storefront-outline" size={30} color="#9CA3AF" />
          </View>
        )}
        <View style={styles.placeInfo}>
          <Text style={styles.placeName}>{item.name}</Text>
          <Text style={styles.placeType}>{item.type}</Text>
          {item.address && <Text style={styles.placeAddress} numberOfLines={1}>{item.address}</Text>}
          <Text style={styles.placeDelivery}>توصيل: {item.delivery_fee} ج</Text>
          {item.merchant_name && (
            <Text style={styles.placeMerchant}>المسؤول: {item.merchant_name}</Text>
          )}
        </View>
        <View style={styles.placeActions}>
          <TouchableOpacity style={[styles.actionButton, styles.editButton]} onPress={() => openEditModal(item)}>
            <Ionicons name="create-outline" size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.toggleButton]} onPress={() => handleToggleStatus(item)}>
            <Ionicons name={item.is_active ? 'close-outline' : 'checkmark-outline'} size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={() => handleDelete(item)}>
            <Ionicons name="trash-outline" size={18} color="#FFF" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة الأماكن</Text>
        <TouchableOpacity onPress={() => { resetForm(); setModalVisible(true); }}>
          <Ionicons name="add-circle" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={places}
        renderItem={renderPlace}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="storefront-outline" size={80} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد أماكن</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => { resetForm(); setModalVisible(true); }}>
              <Text style={styles.addButtonText}>إضافة مكان جديد</Text>
            </TouchableOpacity>
          </View>
        }
      />

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <ScrollView contentContainerStyle={styles.modalScrollContent}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>
                  {editingPlace ? 'تعديل المكان' : 'إضافة مكان جديد'}
                </Text>
                <TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}>
                  <Ionicons name="close" size={24} color="#EF4444" />
                </TouchableOpacity>
              </View>

              <Text style={styles.label}>اسم المكان *</Text>
              <TextInput style={styles.input} placeholder="مثال: صن شاين" value={name} onChangeText={setName} />

              <Text style={styles.label}>نوع الخدمة *</Text>
              <View style={styles.typeContainer}>
                {services.map((s) => (
                  <TouchableOpacity
                    key={s.id}
                    style={[styles.typeButton, type === s.id && styles.typeButtonActive]}
                    onPress={() => setType(s.id)}
                  >
                    <Text style={[styles.typeButtonText, type === s.id && styles.typeButtonTextActive]}>{s.name}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.label}>العنوان</Text>
              <TextInput style={styles.input} placeholder="العنوان بالتفصيل" value={address} onChangeText={setAddress} multiline />

              <Text style={styles.label}>صورة المكان</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
                {image ? (
                  <Image source={{ uri: image }} style={styles.previewImage} />
                ) : (
                  <View style={styles.imagePlaceholder}>
                    {uploading ? (
                      <ActivityIndicator size="large" color="#4F46E5" />
                    ) : (
                      <>
                        <Ionicons name="camera-outline" size={40} color="#9CA3AF" />
                        <Text style={styles.imagePlaceholderText}>اختر صورة</Text>
                      </>
                    )}
                  </View>
                )}
              </TouchableOpacity>

              <Text style={styles.label}>رسوم التوصيل (ج)</Text>
              <TextInput style={styles.input} placeholder="10" value={deliveryFee} onChangeText={setDeliveryFee} keyboardType="numeric" />

              <Text style={styles.label}>معرف التاجر المسؤول (اختياري)</Text>
              <TextInput style={styles.input} placeholder="UUID التاجر" value={merchantId} onChangeText={setMerchantId} />

              <Text style={styles.label}>اسم التاجر المسؤول (اختياري)</Text>
              <TextInput style={styles.input} placeholder="مثال: عم جلال" value={merchantName} onChangeText={setMerchantName} />

              <View style={styles.switchContainer}>
                <Text style={styles.label}>المكان نشط</Text>
                <Switch value={isActive} onValueChange={setIsActive} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} />
              </View>

              <TouchableOpacity style={[styles.saveButton, (submitting || uploading) && styles.disabled]} onPress={handleSave} disabled={submitting || uploading}>
                {submitting || uploading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>{editingPlace ? 'حفظ التغييرات' : 'إضافة المكان'}</Text>}
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#6B7280', marginBottom: 20 },
  addButton: { backgroundColor: '#4F46E5', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 8 },
  addButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  placeCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  placeCardDisabled: { opacity: 0.6, backgroundColor: '#F9FAFB' },
  placeHeader: { flexDirection: 'row' },
  placeImage: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  placeholderImage: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  placeInfo: { flex: 1 },
  placeName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  placeType: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  placeAddress: { fontSize: 12, color: '#4B5563', marginTop: 2 },
  placeDelivery: { fontSize: 11, color: '#F59E0B', marginTop: 2 },
  placeMerchant: { fontSize: 10, color: '#4F46E5', marginTop: 2 },
  placeActions: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  actionButton: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  editButton: { backgroundColor: '#F59E0B' },
  toggleButton: { backgroundColor: '#EF4444' },
  deleteButton: { backgroundColor: '#6B7280' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalScrollContent: { paddingBottom: 20, paddingTop: 60 },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  typeContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  typeButton: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  typeButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  typeButtonText: { fontSize: 12, color: '#4B5563' },
  typeButtonTextActive: { color: '#FFF', fontWeight: '600' },
  imagePicker: { width: '100%', height: 150, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginBottom: 15, overflow: 'hidden' },
  previewImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F9FAFB' },
  imagePlaceholderText: { marginTop: 8, fontSize: 14, color: '#9CA3AF' },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  disabled: { opacity: 0.6 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
