import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image, Alert, ActivityIndicator, Modal, TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

const IMAGEKIT_PRIVATE_KEY = process.env.EXPO_PUBLIC_IMAGEKIT_PRIVATE_KEY || '';
const IMAGEKIT_ENDPOINT = 'https://upload.imagekit.io/api/v1/files/upload';

export default function SettingsBottomTabsScreen({ navigation }) {
  const [tabs, setTabs] = useState([
    { num: 1, label: 'طلب', icon: 'cart', image: '', color: '#F59E0B' },
    { num: 2, label: 'عروض', icon: 'pricetag', image: '', color: '#8B5CF6' },
    { num: 3, label: 'متجر Zid', icon: 'storefront', image: '', color: '#10B981' },
    { num: 4, label: 'طلباتي', icon: 'list', image: '', color: '#3B82F6' },
  ]);
  const [uploading, setUploading] = useState(false);
  const [editorVisible, setEditorVisible] = useState(false);
  const [editingTab, setEditingTab] = useState(null);
  const [tempLabel, setTempLabel] = useState('');
  const [tempIcon, setTempIcon] = useState('');
  const [tempImage, setTempImage] = useState('');

  useEffect(() => { loadTabs(); }, []);

  const loadTabs = async () => {
    const { data } = await supabase.from('app_settings').select('*').eq('id', 1).single();
    if (data) {
      setTabs([
        { num: 1, label: data.tab1_label || 'طلب', icon: data.tab1_icon || 'cart', image: data.tab1_image || '', color: '#F59E0B' },
        { num: 2, label: data.tab2_label || 'عروض', icon: data.tab2_icon || 'pricetag', image: data.tab2_image || '', color: '#8B5CF6' },
        { num: 3, label: data.tab3_label || 'متجر Zid', icon: data.tab3_icon || 'storefront', image: data.tab3_image || '', color: '#10B981' },
        { num: 4, label: data.tab4_label || 'طلباتي', icon: data.tab4_icon || 'list', image: data.tab4_image || '', color: '#3B82F6' },
      ]);
    }
  };

  const saveTab = async () => {
    const n = editingTab.num;
    const updates = { id: 1 };
    updates[`tab${n}_label`] = tempLabel;
    updates[`tab${n}_icon`] = tempIcon;
    updates[`tab${n}_image`] = tempImage;
    updates.updated_at = new Date().toISOString();

    const { error } = await supabase.from('app_settings').upsert(updates, { onConflict: 'id' });
    if (error) { Alert.alert('خطأ', error.message); return; }

    // تحديث الكاش في AsyncStorage
    const cached = await AsyncStorage.getItem('appSettings');
    const parsed = cached ? JSON.parse(cached) : {};
    const updated = { ...parsed, ...updates };
    await AsyncStorage.setItem('appSettings', JSON.stringify(updated));

    const newTabs = tabs.map(t => t.num === n ? { ...t, label: tempLabel, icon: tempIcon, image: tempImage } : t);
    setTabs(newTabs);
    setEditorVisible(false);
    Alert.alert('✅ تم', 'تم تحديث التاب');
  };

  const openEditor = (tab) => {
    setEditingTab(tab);
    setTempLabel(tab.label);
    setTempIcon(tab.icon);
    setTempImage(tab.image);
    setEditorVisible(true);
  };

  const handlePickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('صلاحية', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 });
    if (result.canceled || !result.assets?.[0]) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', { uri: result.assets[0].uri, type: 'image/jpeg', name: `tab_icon_${Date.now()}.jpg` });
      formData.append('fileName', `tab_icon_${Date.now()}`);
      formData.append('folder', '/tabs');
      formData.append('useUniqueFileName', 'true');
      const res = await fetch(IMAGEKIT_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'), 'Accept': 'application/json' },
        body: formData,
      });
      const json = await res.json();
      if (json.url) setTempImage(json.url);
    } catch (e) { Alert.alert('خطأ', 'فشل الرفع'); }
    setUploading(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>📱 الأزرار السفلية</Text>
        <View style={{ width: 40 }} />
      </View>
      <View style={styles.content}>
        {tabs.map(tab => (
          <TouchableOpacity key={tab.num} style={styles.card} onPress={() => openEditor(tab)} activeOpacity={0.7}>
            <View style={[styles.iconCircle, { backgroundColor: tab.color + '20' }]}>
              {tab.image ? <Image source={{ uri: tab.image }} style={styles.tabImage} /> : <Ionicons name={tab.icon} size={24} color={tab.color} />}
            </View>
            <View style={styles.rowText}>
              <Text style={styles.rowTitle}>{tab.label}</Text>
              <Text style={styles.rowSub}>التاب {tab.num}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#D1D5DB" />
          </TouchableOpacity>
        ))}
      </View>

      <Modal visible={editorVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>تعديل التاب {editingTab?.num}</Text>
            <Text style={styles.label}>صورة التاب</Text>
            <TouchableOpacity style={styles.uploadBtn} onPress={handlePickImage} disabled={uploading}>
              {tempImage ? <Image source={{ uri: tempImage }} style={{ width: 50, height: 50, borderRadius: 8 }} /> : <><Ionicons name="image-outline" size={22} color="#4F46E5" /><Text style={styles.uploadText}>رفع صورة</Text></>}
              {uploading && <ActivityIndicator size="small" color="#4F46E5" />}
            </TouchableOpacity>
            <Text style={styles.label}>اسم التاب</Text>
            <TextInput style={styles.input} value={tempLabel} onChangeText={setTempLabel} />
            <Text style={styles.label}>أيقونة التاب (Ionicons)</Text>
            <TextInput style={styles.input} value={tempIcon} onChangeText={setTempIcon} autoCapitalize="none" placeholder="cart, pricetag..." />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => setEditorVisible(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.saveBtn]} onPress={saveTab}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  backBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F3F4F6' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  content: { padding: 16, gap: 10 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#E5E7EB' },
  iconCircle: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  tabImage: { width: 28, height: 28, borderRadius: 6 },
  rowText: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  rowSub: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, maxHeight: '80%' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 6, marginTop: 10 },
  input: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, marginBottom: 8, backgroundColor: '#F9FAFB' },
  uploadBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginBottom: 10, gap: 8 },
  uploadText: { color: '#4F46E5', fontSize: 14 },
  modalBtns: { flexDirection: 'row', justifyContent: 'space-between', gap: 12, marginTop: 16 },
  btn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#F3F4F6' },
  cancelText: { color: '#374151', fontSize: 15, fontWeight: '600' },
  saveBtn: { backgroundColor: '#4F46E5' },
  saveText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});
