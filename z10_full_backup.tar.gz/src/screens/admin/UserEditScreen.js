import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  Alert, ActivityIndicator, ScrollView, Switch, Image, Modal, FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { fontFamily } from '../../utils/fonts';
import { uploadToImageKit } from '../../services/uploadService';

export default function UserEditScreen({ navigation, route }) {
  const { userId } = route.params;
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [user, setUser] = useState(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('');
  const [active, setActive] = useState(true);
  const [merchantType, setMerchantType] = useState('');
  const [placeName, setPlaceName] = useState('');
  const [deliveryFee, setDeliveryFee] = useState('');
  const [serviceArea, setServiceArea] = useState('');
  const [isAvailable, setIsAvailable] = useState(true);
  const [healthCertUrl, setHealthCertUrl] = useState('');
  const [verificationImage, setVerificationImage] = useState('');
  const [commercialRegister, setCommercialRegister] = useState('');
  const [taxCard, setTaxCard] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState('');
  const [regionId, setRegionId] = useState(null);

  const [merchantTypes, setMerchantTypes] = useState([]);
  const [places, setPlaces] = useState([]);
  const [regions, setRegions] = useState([]);
  const [showPlacePicker, setShowPlacePicker] = useState(false);
  const [showRegionPicker, setShowRegionPicker] = useState(false);

  const ROLES = [
    { label: 'عميل', value: 'customer' },
    { label: 'تاجر', value: 'merchant' },
    { label: 'مندوب', value: 'driver' },
    { label: 'أدمن', value: 'admin' },
  ];

  useEffect(() => { loadUser(); loadMerchantTypes(); loadPlaces(); loadRegions(); }, []);

  const loadMerchantTypes = async () => {
    const { data } = await supabase.from('services').select('id, name').neq('type', 'ai').order('name');
    if (data) setMerchantTypes(data.map(s => ({ label: s.name, value: s.id })));
  };

  const loadPlaces = async () => {
    const { data } = await supabase.from('places').select('id, name').eq('is_active', true).order('name');
    if (data) setPlaces(data);
  };

  const loadRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    if (data) setRegions(data);
  };

  const loadUser = async () => {
    try {
      const { data, error } = await supabase.from(TABLES.PROFILES).select('*').eq('id', userId).single();
      if (error) throw error;
      setUser(data);
      setName(data.full_name || '');
      setPhone(data.phone || '');
      setRole(data.role || 'customer');
      setActive(data.active !== false);
      setMerchantType(data.merchant_type || '');
      setPlaceName(data.place_name || '');
      setDeliveryFee(data.delivery_fee?.toString() || '10');
      setServiceArea(data.service_area || '');
      setIsAvailable(data.is_available !== false);
      setHealthCertUrl(data.health_cert_url || '');
      setVerificationImage(data.verification_image || '');
      setCommercialRegister(data.commercial_register || '');
      setTaxCard(data.tax_card || '');
      setImageUrl(data.image_url || '');
      setRegionId(data.region_id || null);
    } catch (error) { Alert.alert('خطأ', 'فشل تحميل بيانات المستخدم'); } finally { setLoading(false); }
  };

  const pickMerchantImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('صلاحيات', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const uploadRes = await uploadToImageKit(result.assets[0].uri, `merchant_${userId}_${Date.now()}.jpg`, 'merchants', name || 'merchant');
      setUploading(false);
      if (uploadRes.success) { setImageUrl(uploadRes.fileUrl); Alert.alert('✅ تم', 'تم رفع الصورة بنجاح'); }
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSave = async () => {
    if (!name.trim()) { Alert.alert('تنبيه', 'الاسم مطلوب'); return; }
    if (!phone.trim()) { Alert.alert('تنبيه', 'رقم الهاتف مطلوب'); return; }
    setSaving(true);
    try {
      const updateData = { full_name: name.trim(), phone: phone.trim(), role: role, active: active, image_url: imageUrl, updated_at: new Date().toISOString() };
      if (role === 'merchant') { updateData.merchant_type = merchantType; updateData.delivery_fee = parseFloat(deliveryFee) || 10; updateData.place_name = placeName; }
      if (role === 'driver') { updateData.service_area = serviceArea; updateData.is_available = isAvailable; }
      if (role === 'merchant' || role === 'customer') { updateData.region_id = regionId; }
      const { error } = await supabase.from(TABLES.PROFILES).update(updateData).eq('id', userId);
      if (error) throw error;
      if (role === 'merchant') {
        const { data: merchant } = await supabase.from('merchants').select('id').eq('user_id', userId).single();
        if (merchant) { await supabase.from('merchants').update({ name: name.trim(), image_url: imageUrl, service_type: merchantType, delivery_fee: parseFloat(deliveryFee) || 10, place_name: placeName }).eq('id', merchant.id); }
      }
      Alert.alert('✅ تم', 'تم تحديث بيانات المستخدم'); navigation.goBack();
    } catch (error) { Alert.alert('خطأ', error.message); } finally { setSaving(false); }
  };

  const openImage = (url) => { setSelectedImage(url); setShowImageModal(true); };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity><Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>تعديل المستخدم</Text><View style={{ width: 28 }} /></View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.form}>
          {role === 'merchant' && (
            <View style={styles.imageSection}>
              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>صورة التاجر (تظهر للعملاء)</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickMerchantImage} disabled={uploading}>
                {uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : imageUrl ? <Image source={{ uri: imageUrl }} style={styles.imagePreview} /> : <View style={styles.imagePlaceholder}><Ionicons name="storefront-outline" size={50} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', marginTop: 8 }}>اضغط لإضافة صورة</Text></View>}
              </TouchableOpacity>
              {imageUrl && <TouchableOpacity style={styles.removeImageBtn} onPress={() => setImageUrl('')}><Ionicons name="trash-outline" size={16} color="#EF4444" /><Text style={{ color: '#EF4444', fontSize: 12 }}>إزالة الصورة</Text></TouchableOpacity>}
            </View>
          )}
          <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>الاسم الكامل *</Text><TextInput style={styles.input} value={name} onChangeText={setName} placeholder="الاسم" />
          <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>رقم الهاتف *</Text><TextInput style={styles.input} value={phone} onChangeText={setPhone} placeholder="رقم الهاتف" keyboardType="phone-pad" />
          <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>الدور</Text>
          <View style={styles.rolesContainer}>{ROLES.map((r) => (<TouchableOpacity key={r.value} style={[styles.roleButton, role === r.value && styles.roleButtonActive]} onPress={() => setRole(r.value)}><Text style={[styles.roleText, role === r.value && styles.roleTextActive]}>{r.label}</Text></TouchableOpacity>))}</View>

          {/* ✅ حقل المنطقة للتاجر والعميل */}
          {(role === 'merchant' || role === 'customer') && (
            <>
              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>المنطقة</Text>
              <TouchableOpacity style={styles.dropdown} onPress={() => setShowRegionPicker(true)}>
                <Text style={[styles.dropdownText, !regionId && { color: '#9CA3AF' }]}>
                  {regions.find(r => r.id === regionId)?.name || 'اختر المنطقة'}
                </Text>
                <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            </>
          )}

          {role === 'merchant' && (
            <>
              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>نوع النشاط</Text>
              <View style={styles.typesContainer}>{merchantTypes.map((type) => (<TouchableOpacity key={type.value} style={[styles.typeButton, merchantType === type.value && styles.typeButtonActive]} onPress={() => setMerchantType(type.value)}><Text style={[styles.typeText, merchantType === type.value && styles.typeTextActive]}>{type.label}</Text></TouchableOpacity>))}</View>

              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>المكان (اختياري)</Text>
              <TouchableOpacity style={styles.dropdown} onPress={() => setShowPlacePicker(true)}>
                <Text style={[styles.dropdownText, !placeName && { color: '#9CA3AF' }]}>{placeName || 'اختر المكان'}</Text>
                <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              </TouchableOpacity>

              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>رسوم التوصيل (ج)</Text>
              <TextInput style={styles.input} value={deliveryFee} onChangeText={setDeliveryFee} keyboardType="numeric" placeholder="10" />

              <Text style={[styles.sectionTitle, { fontFamily: fontFamily.arabic }]}>📄 المستندات المرفوعة</Text>
              {verificationImage ? <TouchableOpacity style={styles.docRow} onPress={() => openImage(verificationImage)}><Ionicons name="id-card-outline" size={20} color="#4F46E5" /><Text style={styles.docText}>بطاقة الهوية</Text><Ionicons name="eye-outline" size={18} color="#9CA3AF" /></TouchableOpacity> : null}
              {commercialRegister ? <TouchableOpacity style={styles.docRow} onPress={() => openImage(commercialRegister)}><Ionicons name="business-outline" size={20} color="#4F46E5" /><Text style={styles.docText}>السجل التجاري</Text><Ionicons name="eye-outline" size={18} color="#9CA3AF" /></TouchableOpacity> : null}
              {taxCard ? <TouchableOpacity style={styles.docRow} onPress={() => openImage(taxCard)}><Ionicons name="document-text-outline" size={20} color="#4F46E5" /><Text style={styles.docText}>البطاقة الضريبية</Text><Ionicons name="eye-outline" size={18} color="#9CA3AF" /></TouchableOpacity> : null}
              {healthCertUrl ? <TouchableOpacity style={styles.docRow} onPress={() => openImage(healthCertUrl)}><Ionicons name="medkit-outline" size={20} color="#10B981" /><Text style={styles.docText}>🩺 الشهادة الصحية</Text><Ionicons name="eye-outline" size={18} color="#9CA3AF" /></TouchableOpacity> : null}
            </>
          )}

          {role === 'driver' && (
            <>
              <Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>منطقة الخدمة</Text>
              <TextInput style={styles.input} value={serviceArea} onChangeText={setServiceArea} placeholder="مثال: الشيخ زايد" />
              <View style={styles.switchContainer}><Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>متاح للتوصيل</Text><Switch value={isAvailable} onValueChange={setIsAvailable} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} /></View>
            </>
          )}

          <View style={styles.switchContainer}><Text style={[styles.label, { fontFamily: fontFamily.arabic }]}>الحساب نشط</Text><Switch value={active} onValueChange={setActive} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} /></View>
          <TouchableOpacity style={[styles.saveButton, saving && styles.disabled]} onPress={handleSave} disabled={saving}>{saving ? <ActivityIndicator color="#FFF" /> : <Text style={[styles.saveButtonText, { fontFamily: fontFamily.arabic }]}>حفظ التغييرات</Text>}</TouchableOpacity>
        </View>
      </ScrollView>

      {/* Modal المناطق */}
      <Modal visible={showRegionPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={[styles.modalContent, { maxHeight: '60%' }]}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر المنطقة</Text><TouchableOpacity onPress={() => setShowRegionPicker(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={regions} keyExtractor={item => item.id} renderItem={({ item }) => (
            <TouchableOpacity style={[styles.optionItem, regionId === item.id && styles.optionItemActive]} onPress={() => { setRegionId(item.id); setShowRegionPicker(false); }}>
              <Text style={[styles.optionText, regionId === item.id && styles.optionTextActive]}>{item.name}</Text>
              {regionId === item.id && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>

      {/* Modal المكان */}
      <Modal visible={showPlacePicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={[styles.modalContent, { maxHeight: '60%' }]}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر المكان</Text><TouchableOpacity onPress={() => setShowPlacePicker(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={places} keyExtractor={item => item.id} renderItem={({ item }) => (
            <TouchableOpacity style={[styles.optionItem, placeName === item.name && styles.optionItemActive]} onPress={() => { setPlaceName(item.name); setShowPlacePicker(false); }}>
              <Text style={[styles.optionText, placeName === item.name && styles.optionTextActive]}>{item.name}</Text>
              {placeName === item.name && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>

      <Modal visible={showImageModal} transparent animationType="fade">
        <View style={styles.imageModalOverlay}><View style={styles.imageModalContent}>
          <TouchableOpacity style={styles.closeButton} onPress={() => setShowImageModal(false)}><Ionicons name="close" size={30} color="#FFF" /></TouchableOpacity>
          {selectedImage ? <Image source={{ uri: selectedImage }} style={styles.fullImage} resizeMode="contain" /> : null}
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' }, center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  form: { backgroundColor: '#FFF', borderRadius: 12, padding: 20 },
  imageSection: { marginBottom: 20 },
  imagePicker: { width: '100%', height: 180, backgroundColor: '#F3F4F6', borderRadius: 12, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', marginTop: 8 },
  imagePreview: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  removeImageBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-end', marginTop: 6, gap: 4 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  dropdown: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 14, marginBottom: 15 },
  dropdownText: { fontSize: 14, color: '#1F2937' },
  rolesContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  roleButton: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  roleButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  roleText: { fontSize: 12, color: '#4B5563' }, roleTextActive: { color: '#FFF', fontWeight: '600' },
  typesContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  typeButton: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  typeButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  typeText: { fontSize: 12, color: '#4B5563' }, typeTextActive: { color: '#FFF', fontWeight: '600' },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10, paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 20 },
  disabled: { opacity: 0.6 }, saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginTop: 20, marginBottom: 10 },
  docRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 10, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  docText: { flex: 1, fontSize: 14, color: '#4F46E5' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  optionItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  optionItemActive: { backgroundColor: '#EEF2FF' },
  optionText: { fontSize: 16, color: '#1F2937' }, optionTextActive: { color: '#4F46E5', fontWeight: '600' },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', justifyContent: 'center', alignItems: 'center' },
  imageModalContent: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
  closeButton: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 10 },
  fullImage: { width: '100%', height: '80%' },
});
