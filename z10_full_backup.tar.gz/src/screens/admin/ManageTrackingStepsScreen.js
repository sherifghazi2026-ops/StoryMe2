import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
  ActivityIndicator, Modal, TextInput, ScrollView, Image, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { uploadServiceImage } from '../../services/uploadService';
import { fontFamily } from '../../utils/fonts';

export default function ManageTrackingStepsScreen({ navigation }) {
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [steps, setSteps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingStep, setEditingStep] = useState(null);
  const [label, setLabel] = useState('');
  const [stepKey, setStepKey] = useState('');
  const [description, setDescription] = useState('');
  const [sortOrder, setSortOrder] = useState('0');
  const [isActive, setIsActive] = useState(true);
  const [iconUrl, setIconUrl] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadTarget, setUploadTarget] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { loadServices(); }, []);

  const loadServices = async () => {
    const { data } = await supabase.from('services').select('id, name, type').order('name');
    setServices(data || []);
    setLoading(false);
  };

  const loadSteps = async (service) => {
    setSelectedService(service);
    const { data } = await supabase
      .from('service_tracking_steps')
      .select('*')
      .eq('service_id', service.id)
      .order('sort_order', { ascending: true });
    setSteps(data || []);
  };

  const resetForm = () => {
    setEditingStep(null);
    setLabel(''); setStepKey(''); setDescription('');
    setSortOrder('0'); setIsActive(true);
    setIconUrl(''); setAttachmentUrl('');
  };

  const openAddModal = () => { resetForm(); setModalVisible(true); };

  const openEditModal = (step) => {
    setEditingStep(step);
    setLabel(step.label);
    setStepKey(step.step_key);
    setDescription(step.description || '');
    setSortOrder(String(step.sort_order || 0));
    setIsActive(step.is_active !== false);
    setIconUrl(step.image_url || '');
    setAttachmentUrl(step.attachment_url || '');
    setModalVisible(true);
  };

  const pickImage = async (target) => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      setUploadTarget(target);
      const res = await uploadServiceImage(result.assets[0].uri);
      setUploading(false);
      if (res.success) {
        if (target === 'icon') setIconUrl(res.fileUrl);
        else setAttachmentUrl(res.fileUrl);
      } else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSave = async () => {
    if (!label.trim() || !stepKey.trim()) { Alert.alert('تنبيه', 'الاسم والمفتاح مطلوبان'); return; }
    if (!selectedService) { Alert.alert('تنبيه', 'اختر خدمة أولاً'); return; }

    setSubmitting(true);
    try {
      const stepData = {
        service_id: selectedService.id,
        step_key: stepKey.trim(),
        label: label.trim(),
        description: description.trim(),
        sort_order: parseInt(sortOrder) || 0,
        is_active: isActive,
        image_url: iconUrl,
        attachment_url: attachmentUrl,
        updated_at: new Date().toISOString(),
      };

      if (editingStep) {
        const { error } = await supabase.from('service_tracking_steps').update(stepData).eq('id', editingStep.id);
        if (error) throw error;
        Alert.alert('✅ تم', 'تم تحديث الخطوة');
      } else {
        stepData.created_at = new Date().toISOString();
        const { error } = await supabase.from('service_tracking_steps').insert([stepData]);
        if (error) throw error;
        Alert.alert('✅ تم', 'تم إضافة الخطوة');
      }

      setModalVisible(false);
      resetForm();
      loadSteps(selectedService);
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = (step) => {
    Alert.alert('حذف', `حذف "${step.label}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
          await supabase.from('service_tracking_steps').delete().eq('id', step.id);
          loadSteps(selectedService);
        }
      }
    ]);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>خطوات التتبع</Text>
        <View style={{ width: 28 }} />
      </View>

      {/* أزرار الخدمات - Tabs منسقة */}
      <View style={styles.tabsWrapper}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabsContainer}>
          {services.map(s => (
            <TouchableOpacity
              key={s.id}
              style={[styles.tab, selectedService?.id === s.id && styles.tabActive]}
              onPress={() => loadSteps(s)}
              activeOpacity={0.7}
            >
              <Ionicons
                name={selectedService?.id === s.id ? 'checkmark-circle' : 'ellipse-outline'}
                size={14}
                color={selectedService?.id === s.id ? '#FFF' : '#9CA3AF'}
              />
              <Text style={[styles.tabText, selectedService?.id === s.id && styles.tabTextActive]}>
                {s.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {selectedService && (
        <>
          <TouchableOpacity style={styles.addButton} onPress={openAddModal}>
            <Ionicons name="add-circle" size={20} color="#FFF" />
            <Text style={styles.addButtonText}>إضافة خطوة لـ {selectedService.name}</Text>
          </TouchableOpacity>

          <FlatList
            data={steps}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.list}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Ionicons name="git-branch-outline" size={50} color="#E5E7EB" />
                <Text style={styles.emptyText}>لا توجد خطوات بعد</Text>
              </View>
            }
            renderItem={({ item }) => (
              <View style={[styles.stepCard, !item.is_active && { opacity: 0.5 }]}>
                <View style={styles.stepLeft}>
                  {item.image_url ? (
                    <Image source={{ uri: item.image_url }} style={styles.stepImg} />
                  ) : (
                    <View style={styles.stepImgPlaceholder}>
                      <Ionicons name="git-commit-outline" size={20} color="#8B5CF6" />
                    </View>
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={styles.stepName}>{item.label}</Text>
                    <Text style={styles.stepKey}>{item.step_key}</Text>
                    <Text style={styles.stepMeta}>الترتيب: {item.sort_order}</Text>
                  </View>
                </View>
                <View style={styles.stepActions}>
                  <TouchableOpacity onPress={() => openEditModal(item)} style={styles.actionBtn}>
                    <Ionicons name="create-outline" size={18} color="#F59E0B" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDelete(item)} style={styles.actionBtn}>
                    <Ionicons name="trash-outline" size={18} color="#EF4444" />
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        </>
      )}

      {!selectedService && !loading && (
        <View style={styles.empty}>
          <Ionicons name="options-outline" size={60} color="#E5E7EB" />
          <Text style={styles.emptyText}>اختر خدمة من الأعلى</Text>
        </View>
      )}

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingStep ? 'تعديل خطوة' : 'إضافة خطوة'}</Text>
              <TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}>
                <Ionicons name="close" size={22} color="#EF4444" />
              </TouchableOpacity>
            </View>

            <ScrollView style={{ maxHeight: 450 }} showsVerticalScrollIndicator={true}>
              <Text style={styles.modalLabel}>اسم الخطوة *</Text>
              <TextInput style={styles.modalInput} placeholder="مثلاً: جاري التجهيز" value={label} onChangeText={setLabel} />

              <Text style={styles.modalLabel}>مفتاح الخطوة *</Text>
              <TextInput style={styles.modalInput} placeholder="مثلاً: preparing" value={stepKey} onChangeText={setStepKey} autoCapitalize="none" />

              <Text style={styles.modalLabel}>وصف الخطوة</Text>
              <TextInput style={styles.modalInput} placeholder="نص وصفي يظهر تحت الخطوة" value={description} onChangeText={setDescription} />

              <Text style={styles.modalLabel}>الترتيب</Text>
              <TextInput style={styles.modalInput} placeholder="0" value={sortOrder} onChangeText={setSortOrder} keyboardType="numeric" />

              <Text style={styles.modalLabel}>أيقونة الخطوة</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('icon')} disabled={uploading}>
                {uploading && uploadTarget === 'icon' ? <ActivityIndicator /> :
                  iconUrl ? <Image source={{ uri: iconUrl }} style={styles.previewImg} /> :
                  <View style={styles.imgPlaceholder}><Ionicons name="camera" size={30} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 11 }}>رفع أيقونة</Text></View>}
              </TouchableOpacity>

              <Text style={styles.modalLabel}>صورة توضيحية للعميل</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('attachment')} disabled={uploading}>
                {uploading && uploadTarget === 'attachment' ? <ActivityIndicator /> :
                  attachmentUrl ? <Image source={{ uri: attachmentUrl }} style={styles.previewImg} /> :
                  <View style={styles.imgPlaceholder}><Ionicons name="document-attach" size={30} color="#9CA3AF" /><Text style={{ color: '#9CA3AF', fontSize: 11 }}>رفع صورة توضيحية</Text></View>}
              </TouchableOpacity>

              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>نشطة</Text>
                <Switch value={isActive} onValueChange={setIsActive} trackColor={{ false: '#E5E7EB', true: '#8B5CF6' }} />
              </View>
            </ScrollView>

            <TouchableOpacity style={[styles.saveBtn, submitting && { opacity: 0.6 }]} onPress={handleSave} disabled={submitting}>
              {submitting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>حفظ</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  // Tabs منسقة
  tabsWrapper: { backgroundColor: '#FFF', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  tabsContainer: { paddingHorizontal: 14, gap: 8 },
  tab: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 20, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', gap: 6,
  },
  tabActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  tabText: { fontSize: 13, color: '#4B5563', fontWeight: '500', fontFamily: fontFamily.arabic },
  tabTextActive: { color: '#FFF', fontWeight: '600' },
  addButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#8B5CF6', margin: 14, padding: 12, borderRadius: 12, gap: 8 },
  addButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600', fontFamily: fontFamily.arabic },
  list: { padding: 14 },
  stepCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: '#E5E7EB', elevation: 1,
  },
  stepLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  stepImg: { width: 46, height: 46, borderRadius: 12 },
  stepImgPlaceholder: { width: 46, height: 46, borderRadius: 12, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  stepName: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  stepKey: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  stepMeta: { fontSize: 11, color: '#6B7280', marginTop: 2 },
  stepActions: { flexDirection: 'row', gap: 4 },
  actionBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F9FAFB' },
  empty: { alignItems: 'center', padding: 50 },
  emptyText: { color: '#9CA3AF', marginTop: 10, fontFamily: fontFamily.arabic },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, maxHeight: '85%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  modalLabel: { fontSize: 13, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  modalInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, fontSize: 14, marginBottom: 4 },
  imagePicker: { height: 100, backgroundColor: '#F3F4F6', borderRadius: 10, marginBottom: 10, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  previewImg: { width: '100%', height: '100%', resizeMode: 'cover' },
  imgPlaceholder: { justifyContent: 'center', alignItems: 'center' },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10 },
  switchLabel: { fontSize: 14, color: '#4B5563' },
  saveBtn: { backgroundColor: '#8B5CF6', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 12 },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
