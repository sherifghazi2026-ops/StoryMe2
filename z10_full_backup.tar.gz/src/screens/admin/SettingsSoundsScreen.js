import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput, Alert, ActivityIndicator, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { createAudioPlayer } from 'expo-audio';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

export default function SettingsSoundsScreen({ navigation }) {
  const [sendSoundUrl, setSendSoundUrl] = useState('');
  const [notifSoundUrl, setNotifSoundUrl] = useState('');
  const [pickerVisible, setPickerVisible] = useState(false);
  const [pickerTarget, setPickerTarget] = useState('');
  const [pickerValue, setPickerValue] = useState('');
  const [playingSend, setPlayingSend] = useState(false);
  const [playingNotif, setPlayingNotif] = useState(false);
  const sendPlayerRef = useRef(null);
  const notifPlayerRef = useRef(null);

  useEffect(() => { loadSettings(); return () => { sendPlayerRef.current?.remove(); notifPlayerRef.current?.remove(); }; }, []);

  const loadSettings = async () => {
    const { data } = await supabase.from('app_settings').select('key, value').in('key', ['send_sound_url', 'notification_sound_url']);
    if (data) {
      data.forEach(item => {
        if (item.key === 'send_sound_url') setSendSoundUrl(item.value || '');
        if (item.key === 'notification_sound_url') setNotifSoundUrl(item.value || '');
      });
    }
  };

  const saveSetting = async (key, value) => {
    await supabase.from('app_settings').upsert({ key, value, updated_at: new Date().toISOString() });
  };

  const openEditor = (target) => {
    setPickerTarget(target);
    setPickerValue(target === 'send' ? sendSoundUrl : notifSoundUrl);
    setPickerVisible(true);
  };

  const saveValue = async () => {
    const key = pickerTarget === 'send' ? 'send_sound_url' : 'notification_sound_url';
    await saveSetting(key, pickerValue.trim());
    if (pickerTarget === 'send') setSendSoundUrl(pickerValue.trim());
    else setNotifSoundUrl(pickerValue.trim());
    setPickerVisible(false);
    Alert.alert('✅ تم', 'تم الحفظ');
  };

  const playSend = async () => {
    if (!sendSoundUrl.trim()) return;
    try {
      if (sendPlayerRef.current) { sendPlayerRef.current.remove(); sendPlayerRef.current = null; }
      setPlayingSend(true);
      const player = createAudioPlayer({ uri: sendSoundUrl.trim() });
      sendPlayerRef.current = player;
      await player.play();
      setTimeout(() => { setPlayingSend(false); sendPlayerRef.current?.remove(); sendPlayerRef.current = null; }, 3000);
    } catch (e) { setPlayingSend(false); }
  };

  const stopSend = () => {
    sendPlayerRef.current?.pause();
    sendPlayerRef.current?.remove();
    sendPlayerRef.current = null;
    setPlayingSend(false);
  };

  const playNotif = async () => {
    if (!notifSoundUrl.trim()) return;
    try {
      if (notifPlayerRef.current) { notifPlayerRef.current.remove(); notifPlayerRef.current = null; }
      setPlayingNotif(true);
      const player = createAudioPlayer({ uri: notifSoundUrl.trim() });
      notifPlayerRef.current = player;
      await player.play();
      setTimeout(() => { setPlayingNotif(false); notifPlayerRef.current?.remove(); notifPlayerRef.current = null; }, 3000);
    } catch (e) { setPlayingNotif(false); }
  };

  const stopNotif = () => {
    notifPlayerRef.current?.pause();
    notifPlayerRef.current?.remove();
    notifPlayerRef.current = null;
    setPlayingNotif(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>🔊 الأصوات</Text>
        <View style={{ width: 40 }} />
      </View>
      <View style={styles.content}>
        {/* صوت الإرسال */}
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={[styles.iconCircle, { backgroundColor: '#3B82F620' }]}>
              <Ionicons name="paper-plane" size={24} color="#3B82F6" />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.rowTitle}>صوت الإرسال</Text>
              <Text style={styles.rowSub} numberOfLines={1}>{sendSoundUrl || 'غير محدد'}</Text>
            </View>
          </View>
          <View style={styles.actions}>
            <TouchableOpacity style={[styles.actionBtn, playingSend && styles.stopBtn]} onPress={playingSend ? stopSend : playSend}>
              <Ionicons name={playingSend ? 'stop' : 'play'} size={20} color="#FFF" />
              <Text style={styles.actionText}>{playingSend ? 'إيقاف' : 'تشغيل'}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.editBtn} onPress={() => openEditor('send')}>
              <Ionicons name="create-outline" size={20} color="#4F46E5" />
              <Text style={styles.editText}>تعديل</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* صوت الإشعارات */}
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={[styles.iconCircle, { backgroundColor: '#EF444420' }]}>
              <Ionicons name="notifications" size={24} color="#EF4444" />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.rowTitle}>صوت الإشعارات</Text>
              <Text style={styles.rowSub} numberOfLines={1}>{notifSoundUrl || 'غير محدد'}</Text>
            </View>
          </View>
          <View style={styles.actions}>
            <TouchableOpacity style={[styles.actionBtn, playingNotif && styles.stopBtn]} onPress={playingNotif ? stopNotif : playNotif}>
              <Ionicons name={playingNotif ? 'stop' : 'play'} size={20} color="#FFF" />
              <Text style={styles.actionText}>{playingNotif ? 'إيقاف' : 'تشغيل'}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.editBtn} onPress={() => openEditor('notif')}>
              <Ionicons name="create-outline" size={20} color="#4F46E5" />
              <Text style={styles.editText}>تعديل</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <Modal visible={pickerVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>رابط الصوت</Text>
            <TextInput style={styles.modalInput} placeholder="https://..." value={pickerValue} onChangeText={setPickerValue} autoCapitalize="none" keyboardType="url" />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => setPickerVisible(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.saveBtn]} onPress={saveValue}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  backBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F3F4F6' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  content: { padding: 16, gap: 12 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  iconCircle: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  rowText: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  rowSub: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  actions: { flexDirection: 'row', justifyContent: 'space-around', borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingTop: 12 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 10, backgroundColor: '#10B981', gap: 6 },
  stopBtn: { backgroundColor: '#EF4444' },
  actionText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  editBtn: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 10, backgroundColor: '#EEF2FF', gap: 6 },
  editText: { color: '#4F46E5', fontSize: 14, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  modalInput: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, padding: 14, fontSize: 16, color: '#1F2937', marginBottom: 16, backgroundColor: '#F9FAFB' },
  modalBtns: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  btn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#F3F4F6' },
  cancelText: { color: '#374151', fontSize: 15, fontWeight: '600' },
  saveBtn: { backgroundColor: '#4F46E5' },
  saveText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});
