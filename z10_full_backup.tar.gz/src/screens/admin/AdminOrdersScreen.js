import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView, ActivityIndicator,
  RefreshControl, Image, Modal, Alert,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getOrders, ORDER_STATUS, updateOrderStatus, deleteOrder } from '../../services/orderService';
import { sendPushNotification } from '../../services/pushNotificationService';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

const TABS = [
  { key: 'pending', label: 'معلقة', color: '#F59E0B', icon: 'time-outline' },
  { key: 'active', label: 'نشطة', color: '#3B82F6', icon: 'sync-outline' },
  { key: 'completed', label: 'مكتملة', color: '#10B981', icon: 'checkmark-done-outline' },
  { key: 'cancelled', label: 'ملغية', color: '#EF4444', icon: 'close-circle-outline' },
];

const NEXT_STEPS = {
  [ORDER_STATUS.PENDING]: [
    { label: 'قبول', status: ORDER_STATUS.ACCEPTED, color: '#3B82F6', icon: 'checkmark-circle-outline' },
    { label: 'إلغاء', status: ORDER_STATUS.CANCELLED, color: '#EF4444', icon: 'close-circle-outline' },
  ],
  [ORDER_STATUS.ACCEPTED]: [
    { label: 'بدء التجهيز', status: ORDER_STATUS.PREPARING, color: '#8B5CF6', icon: 'construct-outline' },
    { label: '🔄 إعادة للمعلق', status: ORDER_STATUS.PENDING, color: '#F59E0B', icon: 'refresh-outline' },
    { label: 'إلغاء', status: ORDER_STATUS.CANCELLED, color: '#EF4444', icon: 'close-circle-outline' },
  ],
  [ORDER_STATUS.PREPARING]: [
    { label: 'جاهز', status: ORDER_STATUS.READY, color: '#10B981', icon: 'cube-outline' },
    { label: '🔄 إعادة للمعلق', status: ORDER_STATUS.PENDING, color: '#F59E0B', icon: 'refresh-outline' },
    { label: 'إلغاء', status: ORDER_STATUS.CANCELLED, color: '#EF4444', icon: 'close-circle-outline' },
  ],
  [ORDER_STATUS.READY]: [
    { label: 'بدء التوصيل', status: ORDER_STATUS.ON_THE_WAY, color: '#F59E0B', icon: 'bicycle-outline' },
    { label: '🔄 إعادة للمعلق', status: ORDER_STATUS.PENDING, color: '#F59E0B', icon: 'refresh-outline' },
  ],
  [ORDER_STATUS.DRIVER_ASSIGNED]: [
    { label: 'بدء التوصيل', status: ORDER_STATUS.ON_THE_WAY, color: '#F59E0B', icon: 'bicycle-outline' },
    { label: '🔄 إعادة للمعلق', status: ORDER_STATUS.PENDING, color: '#F59E0B', icon: 'refresh-outline' },
  ],
  [ORDER_STATUS.ON_THE_WAY]: [
    { label: 'تم التوصيل', status: ORDER_STATUS.DELIVERED, color: '#10B981', icon: 'checkmark-done-circle-outline' },
  ],
};

export default function AdminOrdersScreen({ navigation }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('pending');
  const [selectedImage, setSelectedImage] = useState(null);
  const [showImageModal, setShowImageModal] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  useFocusEffect(useCallback(() => { loadOrders(); checkAdminLevel(); }, [activeTab]));

  const checkAdminLevel = async () => {
    try {
      const masterPwd = await AsyncStorage.getItem('masterAdminPassword');
      if (masterPwd === 'Admin135792') { setIsSuperAdmin(true); return; }
      const userDataStr = await AsyncStorage.getItem('userData');
      if (userDataStr) {
        const user = JSON.parse(userDataStr);
        if (user.admin_level === 'super') { setIsSuperAdmin(true); return; }
      }
      setIsSuperAdmin(false);
    } catch (e) { setIsSuperAdmin(false); }
  };

  const loadOrders = async () => {
    setLoading(true);
    try {
      let statusFilter;
      switch (activeTab) {
        case 'pending': statusFilter = [ORDER_STATUS.PENDING]; break;
        case 'active': statusFilter = [ORDER_STATUS.ACCEPTED, ORDER_STATUS.PREPARING, ORDER_STATUS.READY, ORDER_STATUS.DRIVER_ASSIGNED, ORDER_STATUS.ON_THE_WAY]; break;
        case 'completed': statusFilter = [ORDER_STATUS.DELIVERED]; break;
        case 'cancelled': statusFilter = [ORDER_STATUS.CANCELLED]; break;
        default: statusFilter = null;
      }
      const result = await getOrders(statusFilter ? { status: statusFilter } : {});
      if (result.success) setOrders(result.data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
    } catch (error) { console.error(error); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const openImage = (url) => { setSelectedImage(url); setShowImageModal(true); };

  const getStatusColor = (status) => {
    const c = { [ORDER_STATUS.PENDING]: '#F59E0B', [ORDER_STATUS.ACCEPTED]: '#3B82F6', [ORDER_STATUS.PREPARING]: '#8B5CF6', [ORDER_STATUS.READY]: '#10B981', [ORDER_STATUS.DRIVER_ASSIGNED]: '#6366F1', [ORDER_STATUS.ON_THE_WAY]: '#F59E0B', [ORDER_STATUS.DELIVERED]: '#10B981', [ORDER_STATUS.CANCELLED]: '#EF4444' };
    return c[status] || '#6B7280';
  };

  const getStatusText = (status) => {
    const t = { [ORDER_STATUS.PENDING]: 'معلق', [ORDER_STATUS.ACCEPTED]: 'مقبول', [ORDER_STATUS.PREPARING]: 'قيد التجهيز', [ORDER_STATUS.READY]: 'جاهز', [ORDER_STATUS.DRIVER_ASSIGNED]: 'مندوب معين', [ORDER_STATUS.ON_THE_WAY]: 'جاري التوصيل', [ORDER_STATUS.DELIVERED]: 'تم التوصيل', [ORDER_STATUS.CANCELLED]: 'ملغي' };
    return t[status] || status;
  };

  // ✅ إرسال إشعار للتجار المرتبطين بالخدمة
  const notifyMerchants = async (order) => {
    try {
      // جلب التجار المرتبطين بنفس الخدمة
      const { data: merchants } = await supabase
        .from('merchants')
        .select('user_id')
        .eq('service_type', order.service_type)
        .eq('is_active', true);

      if (merchants && merchants.length > 0) {
        const userIds = merchants.map(m => m.user_id);
        const { data: tokens } = await supabase
          .from('user_tokens')
          .select('expo_push_token')
          .in('user_id', userIds);

        if (tokens) {
          for (const t of tokens) {
            if (t.expo_push_token) {
              await sendPushNotification(
                t.expo_push_token,
                '🔄 طلب جديد متاح',
                `${order.customer_name} يطلب ${order.service_name || order.service_type}`,
                { screen: 'MerchantOrdersScreen', type: 'new_order', orderId: order.id }
              );
            }
          }
        }
      }

      // إشعار للأدمن
      const { data: adminTokens } = await supabase
        .from('user_tokens')
        .select('expo_push_token')
        .in('user_id', (await supabase.from('profiles').select('id').eq('role', 'admin')).data?.map(a => a.id) || []);

      if (adminTokens) {
        for (const t of adminTokens) {
          if (t.expo_push_token) {
            await sendPushNotification(t.expo_push_token, '✅ تم إعادة الطلب', `الطلب #${String(order.id).slice(-6)} أصبح متاحاً للتجار`);
          }
        }
      }
    } catch (e) { console.log('فشل إرسال الإشعارات:', e); }
  };

  const handleChangeStatus = (orderId, newStatus) => {
    const statusName = getStatusText(newStatus);
    const isReopen = newStatus === ORDER_STATUS.PENDING;

    Alert.alert(
      isReopen ? '🔄 إعادة للمعلق' : 'تغيير الحالة',
      isReopen ? 'سيتم إعادة الطلب إلى حالة "معلق" وإرسال إشعار للتجار. هل أنت متأكد؟' : `تغيير حالة الطلب إلى "${statusName}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تأكيد', onPress: async () => {
            const result = await updateOrderStatus(orderId, newStatus);
            if (result.success) {
              if (isReopen && result.data) {
                await notifyMerchants(result.data);
              }
              Alert.alert('✅ تم', `تم تغيير الحالة إلى "${statusName}"`);
              loadOrders();
            }
            else Alert.alert('خطأ', result.error);
          }
        }
      ]
    );
  };

  const handleDelete = (orderId) => {
    if (!isSuperAdmin) { Alert.alert('⛔ ممنوع', 'فقط الأدمن الأساسي يمكنه حذف الطلبات'); return; }
    Alert.alert('🗑️ حذف الطلب', 'سيتم حذف الطلب نهائياً. هل أنت متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف نهائي', style: 'destructive', onPress: async () => {
          const result = await deleteOrder(orderId);
          if (result.success) { Alert.alert('✅ تم', 'تم حذف الطلب'); loadOrders(); }
          else Alert.alert('خطأ', result.error);
        }
      }
    ]);
  };

  const renderOrder = ({ item }) => {
    const nextSteps = NEXT_STEPS[item.status] || [];
    return (
      <View style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <Text style={styles.orderId}>طلب #{String(item.id).slice(-6)}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
            <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{getStatusText(item.status)}</Text>
          </View>
        </View>
        <View style={styles.customerInfo}>
          <Text style={styles.customerName}>{item.customer_name}</Text>
          <Text style={styles.customerPhone}>{item.customer_phone}</Text>
          {item.customer_address && <Text style={styles.customerAddress}>{item.customer_address}</Text>}
        </View>
        {item.items?.length > 0 && (
          <View style={styles.itemsList}>
            {item.items.map((it, i) => (<Text key={i} style={styles.itemText}>• {it}</Text>))}
          </View>
        )}
        <View style={styles.footer}>
          <Text style={styles.price}>{item.final_total || item.total_price || 0} ج</Text>
          <View style={styles.actionButtons}>
            {nextSteps.map((step, i) => (
              <TouchableOpacity key={i} style={[styles.statusBtn, { backgroundColor: step.color }]} onPress={() => handleChangeStatus(item.id, step.status)}>
                <Ionicons name={step.icon} size={14} color="#FFF" />
                <Text style={styles.btnText}>{step.label}</Text>
              </TouchableOpacity>
            ))}
            {isSuperAdmin && (
              <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(item.id)}>
                <Ionicons name="trash-outline" size={16} color="#FFF" />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>
    );
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>الطلبات</Text>
        <TouchableOpacity onPress={loadOrders}>
          <Ionicons name="refresh" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabContainer}>
        {TABS.map(tab => (
          <TouchableOpacity key={tab.key} style={[styles.tab, activeTab === tab.key && styles.activeTab, activeTab === tab.key && { borderColor: tab.color }]} onPress={() => setActiveTab(tab.key)}>
            <Ionicons name={tab.icon} size={16} color={activeTab === tab.key ? tab.color : '#9CA3AF'} />
            <Text style={[styles.tabText, activeTab === tab.key && { color: tab.color, fontWeight: '700' }]}>{tab.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={orders} renderItem={renderOrder} keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadOrders} />}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="cart-outline" size={60} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد طلبات</Text></View>}
      />

      <Modal visible={showImageModal} transparent animationType="fade">
        <View style={styles.imageModalOverlay}>
          <TouchableOpacity style={styles.closeImageButton} onPress={() => setShowImageModal(false)}><Ionicons name="close" size={34} color="#FFF" /></TouchableOpacity>
          {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImage} resizeMode="contain" />}
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 10, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB', gap: 8 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, borderRadius: 12, borderWidth: 1.5, borderColor: '#E5E7EB', backgroundColor: '#F9FAFB', gap: 6 },
  activeTab: { backgroundColor: '#FFF', borderWidth: 2 },
  tabText: { fontSize: 13, color: '#6B7280', fontWeight: '500' },
  list: { padding: 16 },
  orderCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  customerInfo: { marginBottom: 8 },
  customerName: { fontSize: 14, fontWeight: '500', color: '#1F2937' },
  customerPhone: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  customerAddress: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  itemsList: { marginBottom: 8 },
  itemText: { fontSize: 12, color: '#4B5563', marginBottom: 2 },
  footer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingTop: 10 },
  price: { fontSize: 16, fontWeight: 'bold', color: '#F59E0B' },
  actionButtons: { flexDirection: 'row', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' },
  statusBtn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, gap: 4 },
  deleteBtn: { backgroundColor: '#6B7280', padding: 6, borderRadius: 8 },
  btnText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  empty: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#6B7280' },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center', alignItems: 'center' },
  closeImageButton: { position: 'absolute', top: 50, right: 20, zIndex: 10 },
  fullImage: { width: '100%', height: '80%', resizeMode: 'contain' },
});
