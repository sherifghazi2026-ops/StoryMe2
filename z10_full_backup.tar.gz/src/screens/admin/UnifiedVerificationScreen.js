import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Switch,
  ActivityIndicator, RefreshControl, Image, Modal, Alert, ScrollView, Dimensions
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { sendPushNotification } from '../../services/pushNotificationService';

const { width } = Dimensions.get('window');

const getStatusInfo = (approved) => {
  if (approved === true) return { icon: 'checkmark-circle', color: '#10B981', bg: '#D1FAE5', text: 'مقبول' };
  if (approved === false) return { icon: 'close-circle', color: '#EF4444', bg: '#FEE2E2', text: 'مرفوض' };
  return { icon: 'time-outline', color: '#F59E0B', bg: '#FEF3C7', text: 'معلق' };
};

// ✅ دالة إرسال الإشعارات
const notifyUser = async (userId, title, body) => {
  try {
    const { data: tokenData } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', userId).maybeSingle();
    if (tokenData?.expo_push_token) await sendPushNotification(tokenData.expo_push_token, title, body);
  } catch (e) {}
};

export default function UnifiedVerificationScreen({ navigation }) {
  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedMerchant, setSelectedMerchant] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [activeTab, setActiveTab] = useState('pending');
  const [selectedImage, setSelectedImage] = useState(null);

  useEffect(() => { loadMerchants(); }, [activeTab]);

  const loadMerchants = async () => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from(TABLES.PROFILES)
        .select('*')
        .eq('role', 'merchant')
        .order('created_at', { ascending: false });

      let filtered = [];
      if (activeTab === 'pending') {
        filtered = (data || []).filter(m => {
          const hasPendingContent =
            (m.image_url && m.image_approved === null) ||
            (m.bio && m.bio_approved === null) ||
            (m.documents || []).some(d => d.approved === null) ||
            (m.portfolio_images || []).some(p => p.approved === null);
          return !m.is_verified || hasPendingContent;
        });
      } else {
        filtered = (data || []).filter(m => m.is_verified === true);
      }
      setMerchants(filtered);
    } catch (error) { Alert.alert('خطأ', 'فشل جلب بيانات التجار'); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const refreshMerchant = async (id) => {
    const { data } = await supabase.from(TABLES.PROFILES).select('*').eq('id', id).single();
    if (data) setSelectedMerchant(data);
  };

  const toggleVerification = async (userId, currentValue) => {
    const newValue = !currentValue;
    const { error } = await supabase.from(TABLES.PROFILES).update({ is_verified: newValue }).eq('id', userId);
    if (!error) {
      const msg = newValue ? 'تم توثيق التاجر بنجاح' : 'تم إلغاء توثيق التاجر';
      Alert.alert('✅', msg);
      loadMerchants();
    } else Alert.alert('خطأ', 'فشل التحديث');
  };

  // ✅ موافقة مع إشعار
  const approveItem = async (type, index) => {
    if (!selectedMerchant) return;
    const m = { ...selectedMerchant };
    let updates = {};
    let itemName = '';

    if (type === 'image') { updates = { image_approved: true }; itemName = 'الصورة الشخصية'; }
    else if (type === 'bio') { updates = { bio_approved: true }; itemName = 'النبذة'; }
    else if (type === 'doc') {
      const docs = [...(m.documents || [])];
      if (docs[index]) docs[index].approved = true;
      updates = { documents: docs };
      itemName = 'المستند';
    } else if (type === 'portfolio') {
      const pics = [...(m.portfolio_images || [])];
      if (pics[index]) pics[index].approved = true;
      updates = { portfolio_images: pics };
      itemName = 'صورة النشاط';
    }

    await supabase.from(TABLES.PROFILES).update(updates).eq('id', m.id);
    await notifyUser(m.id, '✅ تم قبول المحتوى', `تمت الموافقة على ${itemName}.`);
    refreshMerchant(m.id);
  };

  // ✅ رفض مع إشعار
  const rejectItem = async (type, index) => {
    if (!selectedMerchant) return;
    Alert.alert('رفض', 'هل تريد رفض هذا العنصر؟', [
      { text: 'إلغاء' },
      { text: 'رفض', style: 'destructive', onPress: async () => {
        const m = { ...selectedMerchant };
        let updates = {};
        let itemName = '';

        if (type === 'image') { updates = { image_url: null, image_approved: false }; itemName = 'الصورة الشخصية'; }
        else if (type === 'bio') { updates = { bio: null, bio_approved: false }; itemName = 'النبذة'; }
        else if (type === 'doc') {
          const docs = [...(m.documents || [])];
          if (docs[index]) docs[index].approved = false;
          updates = { documents: docs };
          itemName = 'المستند';
        } else if (type === 'portfolio') {
          const pics = [...(m.portfolio_images || [])];
          if (pics[index]) pics[index].approved = false;
          updates = { portfolio_images: pics };
          itemName = 'صورة النشاط';
        }

        await supabase.from(TABLES.PROFILES).update(updates).eq('id', m.id);
        await notifyUser(m.id, '❌ تم رفض المحتوى', `تم رفض ${itemName}.`);
        refreshMerchant(m.id);
      }}
    ]);
  };

  const openFullImage = (url) => setSelectedImage(url);

  const renderItem = ({ item }) => {
    const isVerified = item.is_verified;
    const hasPendingContent =
      (item.image_url && item.image_approved === null) ||
      (item.bio && item.bio_approved === null) ||
      (item.documents || []).some(d => d.approved === null) ||
      (item.portfolio_images || []).some(p => p.approved === null);

    return (
      <TouchableOpacity style={styles.card} onPress={() => { setSelectedMerchant(item); setModalVisible(true); }} activeOpacity={0.8}>
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            {item.image_url ? (
              <Image source={{ uri: item.image_url }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, styles.avatarPlaceholder]}>
                <Ionicons name="person" size={20} color="#9CA3AF" />
              </View>
            )}
            <View>
              <Text style={styles.name}>{item.full_name || item.name}</Text>
              <Text style={styles.type}>{item.merchant_type || 'غير محدد'}</Text>
            </View>
          </View>
          <Switch
            value={isVerified}
            onValueChange={() => toggleVerification(item.id, isVerified)}
            trackColor={{ false: '#E5E7EB', true: '#10B981' }}
            thumbColor={isVerified ? '#FFF' : '#9CA3AF'}
          />
        </View>
        {hasPendingContent && activeTab === 'pending' && (
          <View style={styles.badgeRow}>
            {item.image_url && item.image_approved === null && <View style={styles.badge}><Ionicons name="image-outline" size={12} color="#F59E0B" /><Text style={styles.badgeText}>صورة</Text></View>}
            {item.bio && item.bio_approved === null && <View style={styles.badge}><Ionicons name="document-text-outline" size={12} color="#F59E0B" /><Text style={styles.badgeText}>نبذة</Text></View>}
            {(item.documents || []).filter(d => d.approved === null).length > 0 && <View style={styles.badge}><Ionicons name="folder-outline" size={12} color="#F59E0B" /><Text style={styles.badgeText}>مستندات</Text></View>}
            {(item.portfolio_images || []).filter(p => p.approved === null).length > 0 && <View style={styles.badge}><Ionicons name="images-outline" size={12} color="#F59E0B" /><Text style={styles.badgeText}>صور</Text></View>}
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>طلبات التوثيق</Text>
        <TouchableOpacity onPress={loadMerchants}><Ionicons name="refresh" size={24} color="#4F46E5" /></TouchableOpacity>
      </View>

      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab === 'pending' && styles.activeTab]} onPress={() => setActiveTab('pending')}>
          <Text style={[styles.tabText, activeTab === 'pending' && styles.activeTabText]}>📥 يحتاج مراجعة</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'approved' && styles.activeTab]} onPress={() => setActiveTab('approved')}>
          <Text style={[styles.tabText, activeTab === 'approved' && styles.activeTabText]}>✅ موثق</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={merchants} renderItem={renderItem} keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadMerchants} />}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="checkmark-done-circle" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>{activeTab === 'pending' ? 'لا توجد طلبات معلقة' : 'لا يوجد تجار موثقين'}</Text></View>}
      />

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedMerchant?.full_name}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {selectedMerchant?.image_url && (
                <View style={styles.mediaSection}>
                  <Text style={styles.mediaTitle}>🖼️ صورة البروفايل</Text>
                  <TouchableOpacity onPress={() => openFullImage(selectedMerchant.image_url)}>
                    <Image source={{ uri: selectedMerchant.image_url }} style={styles.fullImage} />
                  </TouchableOpacity>
                  <StatusBadge status={selectedMerchant.image_approved} onApprove={() => approveItem('image')} onReject={() => rejectItem('image')} />
                </View>
              )}

              {selectedMerchant?.bio && (
                <View style={styles.mediaSection}>
                  <Text style={styles.mediaTitle}>📝 نبذة عن النشاط</Text>
                  <View style={styles.bioBox}><Text style={styles.bioText}>{selectedMerchant.bio}</Text></View>
                  <StatusBadge status={selectedMerchant.bio_approved} onApprove={() => approveItem('bio')} onReject={() => rejectItem('bio')} />
                </View>
              )}

              {(selectedMerchant?.documents || []).length > 0 && (
                <View style={styles.mediaSection}>
                  <Text style={styles.mediaTitle}>📄 ملفات التوثيق</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {(selectedMerchant.documents || []).map((doc, i) => (
                      <View key={i} style={styles.mediaItem}>
                        <TouchableOpacity onPress={() => openFullImage(doc.url)}>
                          <Image source={{ uri: doc.url }} style={styles.mediaImage} />
                        </TouchableOpacity>
                        <StatusBadge status={doc.approved} onApprove={() => approveItem('doc', i)} onReject={() => rejectItem('doc', i)} />
                      </View>
                    ))}
                  </ScrollView>
                </View>
              )}

              {(selectedMerchant?.portfolio_images || []).length > 0 && (
                <View style={styles.mediaSection}>
                  <Text style={styles.mediaTitle}>🖼️ صور النشاط</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {(selectedMerchant.portfolio_images || []).map((img, i) => (
                      <View key={i} style={styles.mediaItem}>
                        <TouchableOpacity onPress={() => openFullImage(img.url)}>
                          <Image source={{ uri: img.url }} style={styles.mediaImage} />
                        </TouchableOpacity>
                        <StatusBadge status={img.approved} onApprove={() => approveItem('portfolio', i)} onReject={() => rejectItem('portfolio', i)} />
                      </View>
                    ))}
                  </ScrollView>
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedImage} transparent animationType="fade">
        <View style={styles.fullImageModal}>
          <TouchableOpacity style={styles.closeBtn} onPress={() => setSelectedImage(null)}>
            <Ionicons name="close" size={34} color="#FFF" />
          </TouchableOpacity>
          {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullScreenImage} resizeMode="contain" />}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const StatusBadge = ({ status, onApprove, onReject }) => {
  const info = getStatusInfo(status);
  return (
    <View style={[styles.statusContainer, { backgroundColor: info.bg }]}>
      <Ionicons name={info.icon} size={18} color={info.color} />
      <Text style={[styles.statusText, { color: info.color, flex: 1 }]}>{info.text}</Text>
      {status === null && (
        <View style={styles.actionIcons}>
          <TouchableOpacity onPress={onApprove} style={styles.iconBtn}><Ionicons name="checkmark-circle" size={22} color="#10B981" /></TouchableOpacity>
          <TouchableOpacity onPress={onReject} style={styles.iconBtn}><Ionicons name="close-circle" size={22} color="#EF4444" /></TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#1F2937' },
  tabRow: { flexDirection: 'row', backgroundColor: '#FFF', paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  activeTab: { borderBottomWidth: 3, borderBottomColor: '#4F46E5' },
  tabText: { fontSize: 15, color: '#6B7280', fontWeight: '500' },
  activeTabText: { color: '#4F46E5', fontWeight: '700' },
  list: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 2, borderWidth: 1, borderColor: '#F1F5F9' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  avatar: { width: 44, height: 44, borderRadius: 22 },
  avatarPlaceholder: { backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  name: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  type: { fontSize: 13, color: '#64748B', marginTop: 2 },
  badgeRow: { flexDirection: 'row', gap: 8, marginTop: 12, flexWrap: 'wrap' },
  badge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, backgroundColor: '#FEF3C7', borderRadius: 12, gap: 4 },
  badgeText: { fontSize: 11, color: '#D97706', fontWeight: '500' },
  empty: { alignItems: 'center', paddingVertical: 60 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 12 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalContainer: { backgroundColor: '#FFF', borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '90%', padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: '#1F2937' },
  mediaSection: { marginBottom: 24 },
  mediaTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 12 },
  fullImage: { width: '100%', height: 180, borderRadius: 12, backgroundColor: '#F1F5F9' },
  bioBox: { backgroundColor: '#F8FAFC', padding: 14, borderRadius: 12, marginBottom: 8 },
  bioText: { fontSize: 14, color: '#334155', lineHeight: 22 },
  mediaItem: { marginRight: 12, alignItems: 'center' },
  mediaImage: { width: 80, height: 80, borderRadius: 10, backgroundColor: '#F1F5F9' },
  statusContainer: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 12, marginTop: 8, gap: 8 },
  statusText: { fontSize: 14, fontWeight: '500' },
  actionIcons: { flexDirection: 'row', gap: 12 },
  iconBtn: { padding: 2 },
  fullImageModal: { flex: 1, backgroundColor: 'rgba(0,0,0,0.96)', justifyContent: 'center', alignItems: 'center' },
  closeBtn: { position: 'absolute', top: 50, right: 20, zIndex: 10, padding: 8 },
  fullScreenImage: { width: width * 0.95, height: '80%' },
});
