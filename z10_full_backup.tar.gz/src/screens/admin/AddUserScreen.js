import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator, TextInput, Switch, Modal, FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';

const ROLES = [
  { label: 'عميل', value: 'customer' },
  { label: 'تاجر', value: 'merchant' },
  { label: 'مندوب', value: 'driver' },
  { label: 'أدمن', value: 'admin' },
];

const ADMIN_LEVELS = [
  { label: 'أدمن أساسي (كل الصلاحيات)', value: 'super' },
  { label: 'أدمن محدود', value: 'basic' },
];

export default function AddUserScreen({ navigation }) {
  const [loading, setLoading] = useState(false);
  const [isMasterOrSuper, setIsMasterOrSuper] = useState(false);
  const [showMerchantType, setShowMerchantType] = useState(false);
  const [showPlace, setShowPlace] = useState(false);
  const [showRegion, setShowRegion] = useState(false);

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('customer');
  const [adminLevel, setAdminLevel] = useState('basic');
  const [active, setActive] = useState(true);
  const [merchantType, setMerchantType] = useState('');
  const [placeName, setPlaceName] = useState('');
  const [deliveryFee, setDeliveryFee] = useState('10');
  const [serviceArea, setServiceArea] = useState('');
  const [places, setPlaces] = useState([]);
  const [merchantTypes, setMerchantTypes] = useState([]);
  const [regions, setRegions] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState(null);

  useEffect(() => { checkAdminLevel(); loadPlaces(); loadMerchantTypes(); loadRegions(); }, []);

  const checkAdminLevel = async () => {
    try {
      const masterPwd = await AsyncStorage.getItem('masterAdminPassword');
      if (masterPwd === 'Admin135792') { setIsMasterOrSuper(true); return; }

      const userDataStr = await AsyncStorage.getItem('userData');
      if (userDataStr) {
        const user = JSON.parse(userDataStr);
        if (user.admin_level === 'super') { setIsMasterOrSuper(true); return; }
      }

      setIsMasterOrSuper(false);
    } catch (error) { setIsMasterOrSuper(false); }
  };

  const loadMerchantTypes = async () => {
    const { data } = await supabase.from('services').select('id, name').neq('type', 'ai').order('name');
    if (data) setMerchantTypes(data.map(s => ({ label: s.name, value: s.id })));
  };

  const loadPlaces = async () => {
    const { data } = await supabase.from('places').select('id, name').eq('is_active', true);
    if (data) setPlaces(data);
  };

  const loadRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    if (data) {
      setRegions(data);
      if (data.length > 0) setSelectedRegion(data[0].id);
    }
  };

  const handleAddUser = async () => {
    if (!fullName.trim()) { Alert.alert('تنبيه', 'الاسم مطلوب'); return; }
    if (!password.trim()) { Alert.alert('تنبيه', 'كلمة المرور مطلوبة'); return; }
    if (role !== 'admin' && !phone.trim()) { Alert.alert('تنبيه', 'رقم الهاتف مطلوب'); return; }

    setLoading(true);
    try {
      const newUser = {
        full_name: fullName.trim(),
        phone: role === 'admin' && !phone.trim() ? null : phone.trim(),
        password: password.trim(),
        role: role,
        admin_level: role === 'admin' ? adminLevel : null,
        active: active,
        merchant_type: role === 'merchant' ? merchantType : null,
        place_name: role === 'merchant' ? placeName : null,
        region_id: (role === 'merchant' || role === 'customer') ? selectedRegion : null,
        delivery_fee: role === 'merchant' ? parseFloat(deliveryFee) || 10 : 10,
        service_area: role === 'driver' ? serviceArea.trim() : null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase.from(TABLES.PROFILES).insert([newUser]);
      if (error) {
        if (error.message.includes('duplicate key')) { Alert.alert('خطأ', 'رقم الهاتف مسجل بالفعل'); }
        else throw error;
        return;
      }

      Alert.alert('✅ تم', 'تم إضافة المستخدم بنجاح', [
        { text: 'حسناً', onPress: () => navigation.goBack() }
      ]);
    } catch (error) { Alert.alert('خطأ', error.message); } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إضافة مستخدم جديد</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.form}>
          <Text style={styles.label}>الاسم الكامل *</Text>
          <TextInput style={styles.input} value={fullName} onChangeText={setFullName} placeholder="الاسم الكامل" />

          <Text style={styles.label}>رقم الهاتف {role !== 'admin' ? '*' : '(اختياري للأدمن)'}</Text>
          <TextInput style={styles.input} value={phone} onChangeText={setPhone} placeholder="01xxxxxxxxx" keyboardType="phone-pad" />

          <Text style={styles.label}>كلمة المرور *</Text>
          <TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="كلمة المرور" secureTextEntry />

          <Text style={styles.label}>الدور</Text>
          <View style={styles.rolesContainer}>
            {ROLES.map((r) => (
              <TouchableOpacity key={r.value} style={[styles.roleButton, role === r.value && styles.roleButtonActive]} onPress={() => setRole(r.value)}>
                <Text style={[styles.roleText, role === r.value && styles.roleTextActive]}>{r.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {role === 'admin' && isMasterOrSuper && (
            <View style={styles.adminLevelSection}>
              <Text style={styles.label}>صلاحيات الأدمن</Text>
              <View style={styles.adminLevelContainer}>
                {ADMIN_LEVELS.map((level) => (
                  <TouchableOpacity key={level.value} style={[styles.adminLevelButton, adminLevel === level.value && styles.adminLevelButtonActive]} onPress={() => setAdminLevel(level.value)}>
                    <Ionicons name={level.value === 'super' ? 'shield-checkmark' : 'shield-outline'} size={18} color={adminLevel === level.value ? '#FFF' : '#4B5563'} />
                    <Text style={[styles.adminLevelText, adminLevel === level.value && styles.adminLevelTextActive]}>{level.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {role === 'admin' && !isMasterOrSuper && (
            <View style={styles.adminNotice}>
              <Ionicons name="information-circle" size={18} color="#F59E0B" />
              <Text style={styles.adminNoticeText}>سيتم إضافة الأدمن كأدمن محدود</Text>
            </View>
          )}

          {/* ✅ حقل المنطقة للتاجر والعميل */}
          {(role === 'merchant' || role === 'customer') && (
            <>
              <Text style={styles.label}>المنطقة</Text>
              <TouchableOpacity style={styles.dropdown} onPress={() => setShowRegion(true)}>
                <Text style={[styles.dropdownText, !selectedRegion && { color: '#9CA3AF' }]}>
                  {regions.find(r => r.id === selectedRegion)?.name || 'اختر المنطقة'}
                </Text>
                <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            </>
          )}

          {role === 'merchant' && (
            <>
              <Text style={styles.label}>نوع النشاط</Text>
              <TouchableOpacity style={styles.dropdown} onPress={() => setShowMerchantType(true)}>
                <Text style={[styles.dropdownText, !merchantType && { color: '#9CA3AF' }]}>
                  {merchantTypes.find(t => t.value === merchantType)?.label || 'اختر نوع النشاط'}
                </Text>
                <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              </TouchableOpacity>

              <Text style={styles.label}>المكان (اختياري)</Text>
              <TouchableOpacity style={styles.dropdown} onPress={() => setShowPlace(true)}>
                <Text style={[styles.dropdownText, !placeName && { color: '#9CA3AF' }]}>
                  {placeName || 'اختر المكان'}
                </Text>
                <Ionicons name="chevron-down" size={20} color="#9CA3AF" />
              </TouchableOpacity>

              <Text style={styles.label}>رسوم التوصيل</Text>
              <TextInput style={styles.input} value={deliveryFee} onChangeText={setDeliveryFee} keyboardType="numeric" placeholder="10" />
            </>
          )}

          {role === 'driver' && (
            <>
              <Text style={styles.label}>منطقة الخدمة</Text>
              <TextInput style={styles.input} value={serviceArea} onChangeText={setServiceArea} placeholder="الشيخ زايد" />
            </>
          )}

          <View style={styles.switchContainer}>
            <Text style={styles.label}>الحساب نشط</Text>
            <Switch value={active} onValueChange={setActive} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} />
          </View>

          <TouchableOpacity style={[styles.saveButton, loading && styles.disabled]} onPress={handleAddUser} disabled={loading}>
            {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>إضافة المستخدم</Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Modal المناطق */}
      <Modal visible={showRegion} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر المنطقة</Text><TouchableOpacity onPress={() => setShowRegion(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={regions} keyExtractor={item => item.id} renderItem={({ item }) => (
            <TouchableOpacity style={[styles.optionItem, selectedRegion === item.id && styles.optionItemActive]} onPress={() => { setSelectedRegion(item.id); setShowRegion(false); }}>
              <Text style={[styles.optionText, selectedRegion === item.id && styles.optionTextActive]}>{item.name}</Text>
              {selectedRegion === item.id && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>

      <Modal visible={showMerchantType} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر نوع النشاط</Text><TouchableOpacity onPress={() => setShowMerchantType(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={merchantTypes} keyExtractor={item => item.value} renderItem={({ item }) => (
            <TouchableOpacity style={[styles.optionItem, merchantType === item.value && styles.optionItemActive]} onPress={() => { setMerchantType(item.value); setShowMerchantType(false); }}>
              <Text style={[styles.optionText, merchantType === item.value && styles.optionTextActive]}>{item.label}</Text>
              {merchantType === item.value && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>

      <Modal visible={showPlace} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر المكان</Text><TouchableOpacity onPress={() => setShowPlace(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <FlatList data={places} keyExtractor={item => item.id} renderItem={({ item }) => (
            <TouchableOpacity style={[styles.optionItem, placeName === item.name && styles.optionItemActive]} onPress={() => { setPlaceName(item.name); setShowPlace(false); }}>
              <Text style={[styles.optionText, placeName === item.name && styles.optionTextActive]}>{item.name}</Text>
              {placeName === item.name && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
            </TouchableOpacity>
          )} />
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  form: { backgroundColor: '#FFF', borderRadius: 12, padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  rolesContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  roleButton: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  roleButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  roleText: { fontSize: 13, color: '#4B5563' },
  roleTextActive: { color: '#FFF', fontWeight: '600' },
  dropdown: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 14, marginBottom: 15 },
  dropdownText: { fontSize: 14, color: '#1F2937' },
  adminLevelSection: { marginTop: 10, marginBottom: 15, backgroundColor: '#F0F9FF', padding: 15, borderRadius: 12, borderWidth: 1, borderColor: '#BAE6FD' },
  adminLevelContainer: { flexDirection: 'row', gap: 10, marginTop: 10 },
  adminLevelButton: { flex: 1, padding: 10, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: '#E5E7EB' },
  adminLevelButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  adminLevelText: { fontSize: 11, color: '#4B5563', textAlign: 'center' },
  adminLevelTextActive: { color: '#FFF', fontWeight: '600' },
  adminNotice: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FEF3C7', padding: 12, borderRadius: 8, marginTop: 10, gap: 8 },
  adminNoticeText: { fontSize: 12, color: '#92400E', flex: 1 },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10, paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 20 },
  disabled: { opacity: 0.6 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '60%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  optionItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  optionItemActive: { backgroundColor: '#EEF2FF' },
  optionText: { fontSize: 16, color: '#1F2937' },
  optionTextActive: { color: '#4F46E5', fontWeight: '600' },
});
