import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image, Alert, ActivityIndicator, Modal, TextInput, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

const IMAGEKIT_PRIVATE_KEY = process.env.EXPO_PUBLIC_IMAGEKIT_PRIVATE_KEY || '';
const IMAGEKIT_ENDPOINT = 'https://upload.imagekit.io/api/v1/files/upload';

export default function SettingsWaitingScreen({ navigation }) {
  const [waitingImageUrl, setWaitingImageUrl] = useState('');
  const [waitingHeaderUrl, setWaitingHeaderUrl] = useState('');
  const [topBarImageUrl, setTopBarImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [pickerTarget, setPickerTarget] = useState('');
  const [pickerVisible, setPickerVisible] = useState(false);
  const [pickerValue, setPickerValue] = useState('');

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    const { data } = await supabase.from('app_settings').select('key, value').in('key', ['waiting_image_url', 'waiting_header_url', 'top_bar_image_url']);
    if (data) {
      data.forEach(item => {
        if (item.key === 'waiting_image_url') setWaitingImageUrl(item.value || '');
        if (item.key === 'waiting_header_url') setWaitingHeaderUrl(item.value || '');
        if (item.key === 'top_bar_image_url') setTopBarImageUrl(item.value || '');
      });
    }
  };

  const saveSetting = async (key, value) => {
    await supabase.from('app_settings').upsert({ key, value, updated_at: new Date().toISOString() });
  };

  const handlePickImage = async (target) => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('صلاحية', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 });
    if (result.canceled || !result.assets?.[0]) return;

    setUploading(true);
    setPickerTarget(target);
    try {
      const formData = new FormData();
      formData.append('file', { uri: result.assets[0].uri, type: 'image/jpeg', name: `${target}_${Date.now()}.jpg` });
      formData.append('fileName', `${target}_${Date.now()}`);
      formData.append('folder', '/app_settings');
      formData.append('useUniqueFileName', 'true');
      const res = await fetch(IMAGEKIT_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Basic ' + btoa(IMAGEKIT_PRIVATE_KEY + ':'), 'Accept': 'application/json' },
        body: formData,
      });
      const json = await res.json();
      if (json.url) {
        const keyMap = { waitingImage: 'waiting_image_url', waitingHeader: 'waiting_header_url', topBar: 'top_bar_image_url' };
        const key = keyMap[target];
        await saveSetting(key, json.url);
        if (target === 'waitingImage') setWaitingImageUrl(json.url);
        if (target === 'waitingHeader') setWaitingHeaderUrl(json.url);
        if (target === 'topBar') setTopBarImageUrl(json.url);
        Alert.alert('✅ تم', 'تم رفع الصورة');
      }
    } catch (e) { Alert.alert('خطأ', 'فشل الرفع'); }
    setUploading(false);
  };

  const openManualEdit = (target) => {
    setPickerTarget(target);
    const map = { waitingImage: waitingImageUrl, waitingHeader: waitingHeaderUrl, topBar: topBarImageUrl };
    setPickerValue(map[target] || '');
    setPickerVisible(true);
  };

  const saveManualValue = async () => {
    const keyMap = { waitingImage: 'waiting_image_url', waitingHeader: 'waiting_header_url', topBar: 'top_bar_image_url' };
    const key = keyMap[pickerTarget];
    await saveSetting(key, pickerValue.trim());
    if (pickerTarget === 'waitingImage') setWaitingImageUrl(pickerValue.trim());
    if (pickerTarget === 'waitingHeader') setWaitingHeaderUrl(pickerValue.trim());
    if (pickerTarget === 'topBar') setTopBarImageUrl(pickerValue.trim());
    setPickerVisible(false);
    Alert.alert('✅ تم', 'تم الحفظ');
  };

  const renderRow = (label, iconName, target, value, color) => (
    <View style={styles.card} key={target}>
      <View style={styles.row}>
        <View style={[styles.iconCircle, { backgroundColor: color + '20' }]}>
          <Ionicons name={iconName} size={22} color={color} />
        </View>
        <View style={styles.rowText}>
          <Text style={styles.rowTitle}>{label}</Text>
          <Text style={styles.rowSub} numberOfLines={1}>{value || 'غير محدد'}</Text>
        </View>
      </View>
      {value ? <Image source={{ uri: value }} style={styles.preview} /> : <View style={styles.noPreview}><Ionicons name="image-outline" size={30} color="#D1D5DB" /></View>}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => handlePickImage(target)} disabled={uploading}>
          {uploading && pickerTarget === target ? <ActivityIndicator size="small" color="#4F46E5" /> : <Ionicons name="cloud-upload-outline" size={18} color="#4F46E5" />}
          <Text style={{ color: '#4F46E5', fontSize: 12, marginLeft: 4 }}>رفع</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => openManualEdit(target)}>
          <Ionicons name="create-outline" size={18} color="#4F46E5" />
          <Text style={{ color: '#4F46E5', fontSize: 12, marginLeft: 4 }}>تعديل الرابط</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>⏳ شاشة انتظار الطلب</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {renderRow('الشريط العلوي', 'image-outline', 'topBar', topBarImageUrl, '#8B5CF6')}
        {renderRow('صورة الانتظار', 'time-outline', 'waitingImage', waitingImageUrl, '#F59E0B')}
        {renderRow('Header الانتظار', 'image-outline', 'waitingHeader', waitingHeaderUrl, '#3B82F6')}
      </ScrollView>

      <Modal visible={pickerVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>تعديل الرابط</Text>
            <TextInput style={styles.modalInput} placeholder="https://..." value={pickerValue} onChangeText={setPickerValue} autoCapitalize="none" keyboardType="url" />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => setPickerVisible(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.saveBtn]} onPress={saveManualValue}><Text style={styles.saveText}>حفظ</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  backBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F3F4F6' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  content: { padding: 16, gap: 12, paddingBottom: 40 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  iconCircle: { width: 42, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  rowText: { flex: 1 },
  rowTitle: { fontSize: 14, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  rowSub: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  preview: { width: '100%', height: 120, borderRadius: 10, marginBottom: 10, resizeMode: 'cover' },
  noPreview: { width: '100%', height: 80, borderRadius: 10, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginBottom: 10 },
  actions: { flexDirection: 'row', justifyContent: 'space-around', borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingTop: 10 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8, backgroundColor: '#F9FAFB' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  modalInput: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, padding: 14, fontSize: 16, color: '#1F2937', marginBottom: 16, backgroundColor: '#F9FAFB' },
  modalBtns: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  btn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#F3F4F6' },
  cancelText: { color: '#374151', fontSize: 15, fontWeight: '600' },
  saveBtn: { backgroundColor: '#4F46E5' },
  saveText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});
