import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput, Alert,
  ActivityIndicator, Modal, ScrollView, KeyboardAvoidingView,
  Platform, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { supabase } from '../../lib/supabaseClient';
import { fontFamily } from '../../utils/fonts';

export default function ManageRegionsScreen({ navigation }) {
  const [regions, setRegions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingRegion, setEditingRegion] = useState(null);
  const [regionName, setRegionName] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleteConfirmVisible, setDeleteConfirmVisible] = useState(false);
  const [regionToDelete, setRegionToDelete] = useState(null);
  const [globalIcon, setGlobalIcon] = useState('');

  const fetchRegions = async () => {
    setLoading(true);
    try { const { data, error } = await supabase.from('regions').select('*').order('name'); if (error) throw error; setRegions(data || []); }
    catch (error) { Alert.alert('خطأ', 'فشل تحميل المناطق'); } finally { setLoading(false); }
  };

  const fetchSettings = async () => {
    const { data } = await supabase.from('app_settings').select('key, value').in('key', ['regions_icon']);
    if (data) {
      data.forEach(item => {
        if (item.key === 'regions_icon') setGlobalIcon(item.value || '');
      });
    }
  };

  useFocusEffect(useCallback(() => { fetchRegions(); fetchSettings(); }, []));

  const openAddModal = () => { setEditingRegion(null); setRegionName(''); setModalVisible(true); };
  const openEditModal = (region) => { setEditingRegion(region); setRegionName(region.name); setModalVisible(true); };

  const handleSave = async () => {
    const trimmed = regionName.trim();
    if (!trimmed) { Alert.alert('تنبيه', 'أدخل اسم المنطقة'); return; }
    setSaving(true);
    try {
      if (editingRegion) {
        await supabase.from('regions').update({ name: trimmed, updated_at: new Date().toISOString() }).eq('id', editingRegion.id);
      } else {
        await supabase.from('regions').insert({ name: trimmed, is_active: true });
      }
      setModalVisible(false);
      fetchRegions();
    } catch (e) { Alert.alert('خطأ', e.message); } finally { setSaving(false); }
  };

  const confirmDelete = (region) => { setRegionToDelete(region); setDeleteConfirmVisible(true); };

  const handleDelete = async () => {
    if (!regionToDelete) return;
    try {
      const { count } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('region_id', regionToDelete.id);
      if (count > 0) { Alert.alert('تنبيه', `يوجد ${count} مستخدم مرتبط`); return; }
      await supabase.from('regions').delete().eq('id', regionToDelete.id);
      fetchRegions();
    } catch (e) { Alert.alert('خطأ', e.message); } finally { setDeleteConfirmVisible(false); setRegionToDelete(null); }
  };

  const toggleActive = async (region) => {
    await supabase.from('regions').update({ is_active: !region.is_active, updated_at: new Date().toISOString() }).eq('id', region.id);
    fetchRegions();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>📍 إدارة المناطق</Text>
        <TouchableOpacity onPress={openAddModal} style={styles.addBtn}>
          <Ionicons name="add" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      {/* شريط إحصائيات */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{regions.filter(r => r.is_active).length}</Text>
          <Text style={styles.statLabel}>نشطة</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{regions.filter(r => !r.is_active).length}</Text>
          <Text style={styles.statLabel}>غير نشطة</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{regions.length}</Text>
          <Text style={styles.statLabel}>المجموع</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {loading ? (
          <ActivityIndicator size="large" color="#4F46E5" style={{ marginTop: 40 }} />
        ) : regions.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="location-outline" size={80} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد مناطق</Text>
            <Text style={styles.emptySubText}>اضغط على + لإضافة منطقة جديدة</Text>
          </View>
        ) : (
          regions.map(item => (
            <View key={item.id} style={[styles.regionCard, !item.is_active && styles.inactiveCard]}>
              <View style={styles.regionInfo}>
                <View style={styles.regionNameRow}>
                  {globalIcon ? (
                    <Image source={{ uri: globalIcon }} style={styles.globalIconSmall} />
                  ) : (
                    <Ionicons name="location-outline" size={22} color={item.is_active ? '#4F46E5' : '#9CA3AF'} />
                  )}
                  <Text style={[styles.regionName, !item.is_active && styles.inactiveText]}>{item.name}</Text>
                  {!item.is_active && (
                    <View style={styles.inactiveBadge}>
                      <Text style={styles.inactiveBadgeText}>غير نشط</Text>
                    </View>
                  )}
                </View>
              </View>
              <View style={styles.regionActions}>
                <TouchableOpacity style={[styles.actionBtn, styles.toggleBtn]} onPress={() => toggleActive(item)}>
                  <Ionicons name={item.is_active ? 'eye-off-outline' : 'eye-outline'} size={20} color={item.is_active ? '#F59E0B' : '#10B981'} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionBtn, styles.editBtn]} onPress={() => openEditModal(item)}>
                  <Ionicons name="create-outline" size={20} color="#4F46E5" />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionBtn, styles.deleteBtn]} onPress={() => confirmDelete(item)}>
                  <Ionicons name="trash-outline" size={20} color="#EF4444" />
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* مودال إضافة/تعديل منطقة */}
      <Modal visible={modalVisible} transparent animationType="fade">
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{editingRegion ? 'تعديل منطقة' : 'إضافة منطقة جديدة'}</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="اسم المنطقة"
              placeholderTextColor="#9CA3AF"
              value={regionName}
              onChangeText={setRegionName}
              textAlign="right"
              autoFocus
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.saveBtn]} onPress={handleSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{editingRegion ? 'تحديث' : 'إضافة'}</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* مودال تأكيد الحذف */}
      <Modal visible={deleteConfirmVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, styles.confirmModal]}>
            <Ionicons name="warning" size={50} color="#EF4444" />
            <Text style={styles.confirmTitle}>تأكيد الحذف</Text>
            <Text style={styles.confirmText}>حذف "{regionToDelete?.name}"؟</Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, styles.cancelBtn]} onPress={() => { setDeleteConfirmVisible(false); setRegionToDelete(null); }}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.deleteConfirmBtn]} onPress={handleDelete}>
                <Text style={styles.saveBtnText}>حذف</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  backBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F3F4F6' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  addBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#4F46E5', justifyContent: 'center', alignItems: 'center' },
  statsBar: { flexDirection: 'row', backgroundColor: '#FFF', marginHorizontal: 16, marginTop: 12, borderRadius: 16, padding: 16, marginBottom: 8, elevation: 1 },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 22, fontWeight: 'bold', color: '#4F46E5' },
  statLabel: { fontSize: 12, color: '#6B7280', fontFamily: fontFamily.arabic, marginTop: 2 },
  statDivider: { width: 1, backgroundColor: '#E5E7EB' },
  scrollContent: { padding: 16, paddingBottom: 40 },
  emptyContainer: { justifyContent: 'center', alignItems: 'center', paddingTop: 40 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 12 },
  emptySubText: { fontSize: 12, color: '#D1D5DB', marginTop: 4 },
  regionCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  inactiveCard: { opacity: 0.5 },
  regionInfo: { flex: 1 },
  regionNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  regionName: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  inactiveText: { color: '#9CA3AF' },
  inactiveBadge: { backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginLeft: 8 },
  inactiveBadgeText: { fontSize: 10, color: '#D97706' },
  regionActions: { flexDirection: 'row', gap: 8 },
  actionBtn: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  toggleBtn: { backgroundColor: '#FEF3C7' },
  editBtn: { backgroundColor: '#EEF2FF' },
  deleteBtn: { backgroundColor: '#FEE2E2' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 16, textAlign: 'center', fontFamily: fontFamily.arabic },
  modalInput: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, padding: 14, fontSize: 16, color: '#1F2937', marginBottom: 16, backgroundColor: '#F9FAFB', fontFamily: fontFamily.arabic },
  modalBtns: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  btn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#F3F4F6' },
  cancelBtnText: { color: '#374151', fontSize: 15, fontWeight: '600' },
  saveBtn: { backgroundColor: '#4F46E5' },
  saveBtnText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
  confirmModal: { alignItems: 'center' },
  confirmTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginTop: 12 },
  confirmText: { fontSize: 15, color: '#6B7280', marginTop: 8, textAlign: 'center' },
  deleteConfirmBtn: { backgroundColor: '#EF4444' },
  globalIconSmall: { width: 22, height: 22, borderRadius: 6, marginRight: 8 },
});
