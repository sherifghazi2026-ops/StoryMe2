import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator, Image, Switch, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import * as ImagePicker from 'expo-image-picker';
import { uploadServiceImage } from '../../services/uploadService';

const COLORS = ['#8B5CF6', '#4F46E5', '#10B981', '#F59E0B', '#EF4444', '#EC4899', '#6B7280'];
const SERVICE_TYPES = [
  { label: 'خدمة عادية', value: 'regular' },
  { label: 'خدمة بأصناف', value: 'items_service' },
  { label: 'خدمة بمنتجات', value: 'items' },
  { label: 'خدمة شاملة', value: 'full_service' },
];

export default function AddServiceScreen({ navigation, route }) {
  const [loading, setLoading] = useState(false);
  const [serviceId, setServiceId] = useState('');
  const [serviceName, setServiceName] = useState('');
  const [serviceType, setServiceType] = useState('regular');
  const [serviceIcon, setServiceIcon] = useState('apps-outline');
  const [serviceColor, setServiceColor] = useState('#6B7280');
  const [serviceImage, setServiceImage] = useState(null);
  const [serviceHeaderImage, setServiceHeaderImage] = useState(null);
  const [trackingImage, setTrackingImage] = useState(null);
  const [isActive, setIsActive] = useState(true);
  const [isVisible, setIsVisible] = useState(true);
  const [category, setCategory] = useState('other');
  const [categories, setCategories] = useState([]);
  const [selectedFullService, setSelectedFullService] = useState(null);
  const [fullServicesList, setFullServicesList] = useState([]);
  const [showFullServicePicker, setShowFullServicePicker] = useState(false);

  // للخدمات بأصناف
  const [subServices, setSubServices] = useState([]);
  const [currentSubService, setCurrentSubService] = useState('');

  useEffect(() => {
    const editService = route.params?.editService;
    if (editService) {
      setServiceId(editService.id);
      setServiceName(editService.name);
      setServiceType(editService.type);
      setServiceIcon(editService.icon);
      setServiceColor(editService.color);
      setServiceImage(editService.image_url);
      setServiceHeaderImage(editService.header_image);
      setTrackingImage(editService.tracking_icon_url);
      setIsActive(editService.is_active);
      setIsVisible(editService.is_visible);
      setCategory(editService.category);
      if (editService.type === 'full_service' && editService.full_service_id) {
        setSelectedFullService({ id: editService.full_service_id, name: 'مرتبطة', full_id: editService.full_service_id });
      } else if (editService.type === 'full_service') {
        setServiceType('full_service');
        setSelectedFullService({ id: editService.id, name: editService.name, full_id: null });
      }
      if (editService.sub_services) setSubServices(editService.sub_services);
    }
  }, [route.params]);

  useEffect(() => { loadFullServices(); loadCategories(); }, []);

  const loadFullServices = async () => {
    const { data } = await supabase.from('services').select('id, name, color, icon, image_url').eq('type', 'full_service').eq('is_active', true);
    setFullServicesList(data || []);
  };

  const loadCategories = async () => {
    const { data } = await supabase.from('service_categories').select('*').eq('is_active', true).order('sort_order');
    if (data) setCategories(data);
  };

  const addSubService = () => {
    if (!currentSubService.trim()) { Alert.alert('تنبيه', 'أدخل اسم الخدمة الفرعية'); return; }
    setSubServices([...subServices, currentSubService.trim()]);
    setCurrentSubService('');
  };

  const removeSubService = (index) => {
    setSubServices(subServices.filter((_, i) => i !== index));
  };

  const pickImage = async (type) => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setLoading(true);
      const res = await uploadServiceImage(result.assets[0].uri);
      setLoading(false);
      if (res.success) {
        if (type === 'icon') setServiceImage(res.fileUrl);
        else if (type === 'header') setServiceHeaderImage(res.fileUrl);
        else if (type === 'tracking') setTrackingImage(res.fileUrl);
      }
    }
  };

  const handleSave = async () => {
    if (!serviceId.trim()) { Alert.alert('تنبيه', 'معرف الخدمة مطلوب'); return; }
    if (!serviceName.trim()) { Alert.alert('تنبيه', 'اسم الخدمة مطلوب'); return; }
    if (serviceType === 'items_service' && subServices.length === 0) {
      Alert.alert('تنبيه', 'يجب إضافة خدمة فرعية واحدة على الأقل'); return;
    }
    setLoading(true);
    let finalServiceId = serviceId.trim().toLowerCase().replace(/\s+/g, '_');
    if (serviceType === 'full_service' && selectedFullService) { finalServiceId = selectedFullService.id; }
    const serviceData = {
      id: finalServiceId, name: serviceName.trim(), type: serviceType,
      icon: serviceIcon, color: serviceColor, category: category,
      is_active: isActive, is_visible: isVisible,
      image_url: serviceImage, header_image: serviceHeaderImage,
      tracking_icon_url: trackingImage,
      full_service_id: selectedFullService?.full_id || null,
      sub_services: serviceType === 'items_service' ? subServices : null,
      has_items: serviceType === 'items_service' || serviceType === 'items',
      items_collection: serviceType === 'items_service' ? `${finalServiceId}_items` : null,
    };
    const { error } = await supabase.from('services').upsert(serviceData, { onConflict: 'id' });
    if (error) { Alert.alert('خطأ', error.message); }
    else { Alert.alert('✅ تم', 'تم حفظ الخدمة بنجاح', [{ text: 'حسناً', onPress: () => navigation.goBack() }]); }
    setLoading(false);
  };

  const selectFullService = async (service) => {
    const { data } = await supabase.from('full_services').select('id').eq('service_id', service.id).single();
    setSelectedFullService({ ...service, full_id: data?.id });
    setServiceType('full_service'); setServiceId(service.id); setServiceName(service.name);
    setServiceColor(service.color || '#8B5CF6'); setServiceIcon(service.icon || 'briefcase');
    setServiceImage(service.image_url || null);
    setShowFullServicePicker(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إضافة خدمة جديدة</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.label}>معرف الخدمة</Text>
          <TextInput style={styles.input} placeholder="مثال: travel" value={serviceId} onChangeText={setServiceId} editable={serviceType !== 'full_service' || !selectedFullService} />
        </View>
        <View style={styles.card}>
          <Text style={styles.label}>اسم الخدمة</Text>
          <TextInput style={styles.input} placeholder="مثال: سياحة وسفر" value={serviceName} onChangeText={setServiceName} />
        </View>

        {/* نوع الخدمة */}
        <View style={styles.card}>
          <Text style={styles.label}>نوع الخدمة</Text>
          <View style={styles.typeRow}>
            {SERVICE_TYPES.map((type) => (
              <TouchableOpacity
                key={type.value}
                style={[styles.typeBtn, serviceType === type.value && !selectedFullService && styles.typeBtnActive]}
                onPress={() => { setServiceType(type.value); setSelectedFullService(null); }}
              >
                <Text style={[styles.typeText, serviceType === type.value && !selectedFullService && styles.typeTextActive]}>{type.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* الخدمات الفرعية - تظهر فقط مع "خدمة بأصناف" */}
        {serviceType === 'items_service' && (
          <View style={styles.card}>
            <Text style={styles.label}>الأصناف الفرعية *</Text>
            {subServices.length > 0 && (
              <View style={styles.subServicesList}>
                {subServices.map((sub, index) => (
                  <View key={index} style={styles.subServiceItem}>
                    <Text style={styles.subServiceName}>{sub}</Text>
                    <TouchableOpacity onPress={() => removeSubService(index)}>
                      <Ionicons name="close-circle" size={20} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
            <View style={styles.addSubServiceRow}>
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                placeholder="أضف صنف فرعي (مثلاً: كي فقط)"
                value={currentSubService}
                onChangeText={setCurrentSubService}
              />
              <TouchableOpacity style={styles.addSubServiceButton} onPress={addSubService}>
                <Ionicons name="add" size={24} color="#FFF" />
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ربط خدمة شاملة - يظهر فقط مع "خدمة شاملة" */}
        {serviceType === 'full_service' && (
          <View style={styles.card}>
            <Text style={styles.label}>ربط خدمة شاملة</Text>
            <View style={styles.fullServiceRow}>
              <TouchableOpacity style={styles.fullServiceButton} onPress={() => setShowFullServicePicker(true)}>
                <Text style={styles.fullServiceButtonText}>{selectedFullService ? selectedFullService.name : 'اختر خدمة شاملة'}</Text>
                <Ionicons name="chevron-down" size={20} color="#FFF" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.settingsButton} onPress={() => navigation.navigate('FullServiceManager')}>
                <Ionicons name="settings-outline" size={24} color="#8B5CF6" />
              </TouchableOpacity>
            </View>
            {selectedFullService && (
              <View style={styles.selectedCard}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.selectedText}>مرتبطة بـ: {selectedFullService.name}</Text>
                <TouchableOpacity onPress={() => { setSelectedFullService(null); setServiceType('regular'); }}>
                  <Ionicons name="close-circle" size={20} color="#EF4444" />
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        <Modal visible={showFullServicePicker} transparent animationType="slide">
          <View style={styles.modalOverlay}><View style={styles.modalContent}>
            <View style={styles.modalHeader}><Text style={styles.modalTitle}>اختر خدمة شاملة</Text><TouchableOpacity onPress={() => setShowFullServicePicker(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
            <ScrollView>{fullServicesList.map(service => (
              <TouchableOpacity key={service.id} style={styles.serviceOption} onPress={() => selectFullService(service)}>
                <View style={[styles.serviceOptionImg, { backgroundColor: (service.color || '#8B5CF6') + '20', justifyContent: 'center', alignItems: 'center' }]}><Ionicons name={service.icon || 'briefcase'} size={24} color={service.color || '#8B5CF6'} /></View>
                <View style={{ flex: 1 }}><Text style={styles.serviceOptionName}>{service.name}</Text><Text style={styles.serviceOptionId}>{service.id}</Text></View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            ))}</ScrollView>
            <TouchableOpacity style={styles.modalCancelBtn} onPress={() => setShowFullServicePicker(false)}><Text style={styles.modalCancelText}>إلغاء</Text></TouchableOpacity>
          </View></View>
        </Modal>

        {/* الفئة */}
        <View style={styles.card}>
          <Text style={styles.label}>الفئة</Text>
          <View style={styles.categoryRow}>
            {categories.map(cat => (
              <TouchableOpacity key={cat.id} style={[styles.categoryBtn, category === cat.id && styles.categoryBtnActive]} onPress={() => setCategory(cat.id)}>
                <Text style={[styles.categoryText, category === cat.id && styles.categoryTextActive]}>{cat.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>أيقونة الخدمة</Text>
          <TextInput style={styles.input} placeholder="briefcase" value={serviceIcon} onChangeText={setServiceIcon} />
        </View>
        <View style={styles.card}>
          <Text style={styles.label}>لون الخدمة</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {COLORS.map(color => (
              <TouchableOpacity key={color} style={[styles.colorDot, { backgroundColor: color }, serviceColor === color && styles.colorDotSelected]} onPress={() => setServiceColor(color)} />
            ))}
          </ScrollView>
        </View>
        <View style={styles.card}>
          <Text style={styles.label}>صورة الخدمة</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('icon')}>
            {serviceImage ? <Image source={{ uri: serviceImage }} style={styles.previewImg} /> : <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={styles.imgPlaceholderText}>اختر صورة</Text></View>}
          </TouchableOpacity>
        </View>
        <View style={styles.card}>
          <Text style={styles.label}>صورة الهيدر</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('header')}>
            {serviceHeaderImage ? <Image source={{ uri: serviceHeaderImage }} style={styles.previewImg} /> : <View style={styles.imgPlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text style={styles.imgPlaceholderText}>اختر صورة</Text></View>}
          </TouchableOpacity>
        </View>
        <View style={styles.card}>
          <Text style={styles.label}>صورة تتبع الطلب</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('tracking')}>
            {trackingImage ? <Image source={{ uri: trackingImage }} style={styles.previewImg} /> : <View style={styles.imgPlaceholder}><Ionicons name="image-outline" size={40} color="#9CA3AF" /><Text style={styles.imgPlaceholderText}>اختر صورة التتبع</Text></View>}
          </TouchableOpacity>
        </View>
        <View style={styles.card}>
          <View style={styles.switchRow}><Text style={styles.label}>مفعلة</Text><Switch value={isActive} onValueChange={setIsActive} /></View>
          <View style={styles.switchRow}><Text style={styles.label}>ظاهرة في الرئيسية</Text><Switch value={isVisible} onValueChange={setIsVisible} /></View>
        </View>
        <TouchableOpacity style={[styles.saveBtn, loading && { opacity: 0.6 }]} onPress={handleSave} disabled={loading}>
          {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveText}>حفظ الخدمة</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 8 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, fontSize: 14 },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  typeBtn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, backgroundColor: '#F3F4F6', alignItems: 'center' },
  typeBtnActive: { backgroundColor: '#8B5CF6' },
  typeText: { fontSize: 13, color: '#4B5563' },
  typeTextActive: { color: '#FFF', fontWeight: '600' },
  // خدمات فرعية
  subServicesList: { marginBottom: 10 },
  subServiceItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F9FAFB', padding: 10, borderRadius: 8, marginBottom: 6 },
  subServiceName: { fontSize: 14, color: '#1F2937' },
  addSubServiceRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  addSubServiceButton: { backgroundColor: '#4F46E5', width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  // خدمة شاملة
  fullServiceRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  fullServiceButton: { flex: 1, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#8B5CF6', padding: 12, borderRadius: 8 },
  fullServiceButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  settingsButton: { padding: 10, backgroundColor: '#F3F4F6', borderRadius: 8 },
  selectedCard: { flexDirection: 'row', alignItems: 'center', marginTop: 12, padding: 10, backgroundColor: '#F0FDF4', borderRadius: 8, gap: 8 },
  selectedText: { flex: 1, fontSize: 14, color: '#10B981' },
  categoryRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  categoryBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6' },
  categoryBtnActive: { backgroundColor: '#8B5CF6' },
  categoryText: { fontSize: 12, color: '#4B5563' },
  categoryTextActive: { color: '#FFF', fontWeight: '600' },
  colorDot: { width: 40, height: 40, borderRadius: 20, marginRight: 12 },
  colorDotSelected: { borderWidth: 3, borderColor: '#1F2937' },
  imagePicker: { height: 120, backgroundColor: '#F3F4F6', borderRadius: 8, overflow: 'hidden' },
  previewImg: { width: '100%', height: '100%', resizeMode: 'cover' },
  imgPlaceholder: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  imgPlaceholderText: { marginTop: 8, color: '#9CA3AF' },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  saveBtn: { backgroundColor: '#8B5CF6', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
  saveText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold' },
  serviceOption: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 8, marginBottom: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  serviceOptionImg: { width: 40, height: 40, borderRadius: 20, marginRight: 12 },
  serviceOptionName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  serviceOptionId: { fontSize: 12, color: '#9CA3AF' },
  modalCancelBtn: { marginTop: 16, padding: 12, borderRadius: 8, backgroundColor: '#E5E7EB', alignItems: 'center' },
  modalCancelText: { fontSize: 16, color: '#4B5563' },
});
