import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView,
  ActivityIndicator, Alert, Modal, TextInput, ScrollView, Switch,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { getAllAssistants, createAssistant, updateAssistant, deleteAssistant, toggleAssistantStatus, AVAILABLE_MODELS } from '../../services/assistantService';
import { getAllServices } from '../../services/servicesService';

const COLORS = ['#F59E0B', '#3B82F6', '#10B981', '#EF4444', '#8B5CF6', '#EC4899', '#6B7280', '#4F46E5'];

const MAIN_SCREENS = [
  { id: 'home', label: 'الرئيسية', icon: 'home-outline' },
  { id: 'offers', label: 'العروض', icon: 'pricetag-outline' },
  { id: 'eshop', label: 'المتجر', icon: 'storefront-outline' },
  { id: 'profile', label: 'الملف الشخصي', icon: 'person-outline' },
  { id: 'orders', label: 'طلباتي', icon: 'cart-outline' },
  { id: 'service', label: 'خدمة', icon: 'apps-outline' },
  { id: 'products_service', label: 'منتجات', icon: 'cube-outline' },
];

export default function AdminAssistantsScreen({ navigation }) {
  const [assistants, setAssistants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingAssistant, setEditingAssistant] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [services, setServices] = useState([]);
  const [loadingServices, setLoadingServices] = useState(false);
  const [merchants, setMerchants] = useState([]);
  const [loadingMerchants, setLoadingMerchants] = useState(false);
  const [filterType, setFilterType] = useState('service'); // 'service' or 'merchant'

  const [name, setName] = useState('');
  const [mainScreen, setMainScreen] = useState('home');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [selectedServiceName, setSelectedServiceName] = useState('');
  const [selectedMerchantId, setSelectedMerchantId] = useState('');
  const [selectedMerchantName, setSelectedMerchantName] = useState('');
  const [icon, setIcon] = useState('chatbubble');
  const [color, setColor] = useState('#4F46E5');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [welcomeMessage, setWelcomeMessage] = useState('');
  const [position, setPosition] = useState('bottom-right');
  const [isActive, setIsActive] = useState(true);
  const [order, setOrder] = useState('0');
  const [model, setModel] = useState('llama-3.3-70b-versatile');
  const [customModel, setCustomModel] = useState('');
  const [showCustomModelInput, setShowCustomModelInput] = useState(false);

  const [dataTable, setDataTable] = useState('all_merchant_products');
  const [dataColumns, setDataColumns] = useState('name, price, description, image_url');
  const [dataFilter, setDataFilter] = useState('');
  const [dataLimit, setDataLimit] = useState('100');
  const [serviceDisplayName, setServiceDisplayName] = useState('');
  const [serviceTypeName, setServiceTypeName] = useState('');
  const [serviceDescription, setServiceDescription] = useState('');

  useEffect(() => {
    loadAssistants();
    loadServices();
    loadMerchants();
  }, []);

  const loadMerchants = async () => {
    setLoadingMerchants(true);
    try {
      const { data, error } = await supabase
        .from('merchants')
        .select('id, name, service_type')
        .eq('is_active', true);
      if (!error && data) setMerchants(data);
    } catch (e) {}
    setLoadingMerchants(false);
  };

  // جلب بيانات الخدمة تلقائياً عند اختيار service_id
  useEffect(() => {
    const fetchServiceData = async () => {
      if (!selectedServiceId) {
        setServiceDisplayName('');
        setServiceTypeName('');
        setServiceDescription('');
        setDataTable('all_merchant_products');
        setDataColumns('name, price, description, image_url');
        setDataFilter('');
        return;
      }
      
      try {
        const { data, error } = await supabase
          .from('services')
          .select('name, type, description, data_table, data_columns, data_filter')
          .eq('id', selectedServiceId)
          .single();

        if (data && !error) {
          setServiceDisplayName(data.name || '');
          setServiceTypeName(data.type || '');
          setServiceDescription(data.description || '');
          setDataTable(data.data_table || 'all_merchant_products');
          setDataColumns(data.data_columns || 'name, price, description, image_url');
          // بناء الفلتر تلقائياً بناءً على service_id
          setDataFilter(`service_id::eq::${selectedServiceId}`);
          console.log('✅ تم ملء الحقول تلقائياً من الخدمة:', data.name);
        }
      } catch (error) {
        console.log('خطأ في جلب بيانات الخدمة:', error);
      }
    };
    
    fetchServiceData();
  }, [selectedServiceId]);

  // عند اختيار تاجر (للمساعد الخاص بتاجر معين)
  useEffect(() => {
    if (filterType === 'merchant' && selectedMerchantId) {
      setDataFilter(`merchant_id::eq::${selectedMerchantId}`);
      setServiceDisplayName(`منتجات ${selectedMerchantName}`);
    }
  }, [filterType, selectedMerchantId, selectedMerchantName]);

  const loadAssistants = async () => {
    setLoading(true);
    const result = await getAllAssistants();
    if (result.success) setAssistants(result.data);
    setLoading(false);
  };

  const loadServices = async () => {
    setLoadingServices(true);
    const result = await getAllServices();
    if (result.success) setServices(result.data.filter(s => s.is_active));
    setLoadingServices(false);
  };

  const resetForm = () => {
    setEditingAssistant(null);
    setName('');
    setMainScreen('home');
    setSelectedServiceId('');
    setSelectedServiceName('');
    setSelectedMerchantId('');
    setSelectedMerchantName('');
    setFilterType('service');
    setIcon('chatbubble');
    setColor('#4F46E5');
    setSystemPrompt('');
    setWelcomeMessage('');
    setPosition('bottom-right');
    setIsActive(true);
    setOrder('0');
    setModel('llama-3.3-70b-versatile');
    setCustomModel('');
    setShowCustomModelInput(false);
    setDataTable('all_merchant_products');
    setDataColumns('name, price, description, image_url');
    setDataFilter('');
    setDataLimit('100');
    setServiceDisplayName('');
    setServiceTypeName('');
    setServiceDescription('');
  };

  const openAddModal = () => {
    resetForm();
    setModalVisible(true);
  };

  const openEditModal = (assistant) => {
    setEditingAssistant(assistant);
    setName(assistant.name || '');
    setMainScreen(assistant.screen === 'service' && assistant.service_id ? 'service' : (assistant.screen || 'home'));
    setSelectedServiceId(assistant.service_id || '');
    setSelectedServiceName(assistant.service_name || '');
    setIcon(assistant.icon || 'chatbubble');
    setColor(assistant.color || '#4F46E5');
    setSystemPrompt(assistant.system_prompt || '');
    setWelcomeMessage(assistant.welcome_message || '');
    setPosition(assistant.position || 'bottom-right');
    setIsActive(assistant.is_active !== false);
    setOrder(String(assistant.order || '0'));
    setDataTable(assistant.data_table || 'all_merchant_products');
    setDataColumns(assistant.data_columns || 'name, price, description, image_url');
    setDataFilter(assistant.data_filter || '');
    setDataLimit(String(assistant.data_limit || '100'));
    setServiceDisplayName(assistant.service_display_name || '');
    setServiceTypeName(assistant.service_type_name || '');
    setServiceDescription(assistant.service_description || '');

    const currentModel = assistant.model || 'llama-3.3-70b-versatile';
    const isCustom = !AVAILABLE_MODELS.some(m => m.value === currentModel);
    if (isCustom && currentModel) {
      setShowCustomModelInput(true);
      setCustomModel(currentModel);
      setModel('custom');
    } else {
      setShowCustomModelInput(false);
      setCustomModel('');
      setModel(currentModel);
    }
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('تنبيه', 'اسم المساعد مطلوب');
      return;
    }

    let finalScreen = mainScreen;
    let finalServiceId = null;
    let finalServiceName = null;

    if ((mainScreen === 'service' || mainScreen === 'products_service') && selectedServiceId) {
      finalScreen = mainScreen;
      finalServiceId = selectedServiceId;
      finalServiceName = selectedServiceName;
    }

    let finalModel = model;
    if (model === 'custom' && customModel.trim()) {
      finalModel = customModel.trim();
    } else if (model === 'custom' && !customModel.trim()) {
      Alert.alert('تنبيه', 'الرجاء إدخال اسم النموذج المخصص');
      return;
    }

    setSubmitting(true);
    try {
      const assistantData = {
        name: name.trim(),
        screen: finalScreen,
        icon,
        color,
        systemPrompt: systemPrompt.trim(),
        welcomeMessage: welcomeMessage.trim(),
        position,
        is_active: isActive,
        order: parseInt(order) || 0,
        serviceId: finalServiceId,
        serviceName: finalServiceName,
        model: finalModel,
        data_table: dataTable.trim() || 'all_merchant_products',
        data_columns: dataColumns.trim() || 'name, price, description, image_url',
        data_filter: dataFilter.trim() || null,
        data_limit: parseInt(dataLimit) || 100,
        service_display_name: serviceDisplayName.trim() || null,
        service_type_name: serviceTypeName.trim() || null,
        service_description: serviceDescription.trim() || null,
      };

      let result;
      if (editingAssistant) {
        result = await updateAssistant(editingAssistant.$id || editingAssistant.id, assistantData);
      } else {
        result = await createAssistant(assistantData);
      }

      if (result.success) {
        Alert.alert('✅ تم', editingAssistant ? 'تم تحديث المساعد' : 'تم إضافة المساعد');
        setModalVisible(false);
        resetForm();
        loadAssistants();
      } else {
        Alert.alert('خطأ', result.error);
      }
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = (assistant) => {
    Alert.alert('حذف المساعد', `حذف "${assistant.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
        const result = await deleteAssistant(assistant.$id || assistant.id);
        if (result.success) { loadAssistants(); Alert.alert('✅ تم', 'تم حذف المساعد'); }
        else Alert.alert('خطأ', result.error);
      }}
    ]);
  };

  const handleToggleStatus = async (assistant) => {
    const result = await toggleAssistantStatus(assistant.$id || assistant.id, !assistant.is_active);
    if (result.success) loadAssistants();
    else Alert.alert('خطأ', result.error);
  };

  const renderAssistant = ({ item }) => (
    <View style={[styles.assistantCard, !item.is_active && styles.assistantCardDisabled]}>
      <View style={styles.assistantHeader}>
        <View style={[styles.assistantIcon, { backgroundColor: item.color + '20' }]}>
          <Ionicons name={item.icon || 'chatbubble'} size={24} color={item.color} />
        </View>
        <View style={styles.assistantInfo}>
          <Text style={styles.assistantName}>{item.name}</Text>
          <Text style={styles.assistantScreen}>{item.screen}</Text>
          {item.service_name && <Text style={styles.assistantModel}>خدمة: {item.service_name}</Text>}
          {item.data_table && <Text style={styles.assistantModel}>📊 {item.data_table}</Text>}
          {item.data_filter && <Text style={styles.assistantModel}>🔍 {item.data_filter}</Text>}
        </View>
        <View style={styles.assistantActions}>
          <TouchableOpacity style={[styles.actionButton, styles.editButton]} onPress={() => openEditModal(item)}>
            <Ionicons name="create-outline" size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.toggleButton]} onPress={() => handleToggleStatus(item)}>
            <Ionicons name={item.is_active ? 'close-outline' : 'checkmark-outline'} size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={() => handleDelete(item)}>
            <Ionicons name="trash-outline" size={18} color="#FFF" />
          </TouchableOpacity>
        </View>
      </View>
      <Text style={styles.welcomeMessage} numberOfLines={2}>{item.welcome_message}</Text>
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة المساعدين</Text>
        <TouchableOpacity onPress={openAddModal}><Ionicons name="add-circle" size={24} color="#4F46E5" /></TouchableOpacity>
      </View>

      <FlatList data={assistants} renderItem={renderAssistant} keyExtractor={(item) => item.$id || item.id} contentContainerStyle={styles.list}
        ListEmptyComponent={<View style={styles.emptyContainer}><Ionicons name="chatbubbles-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد مساعدين</Text><TouchableOpacity style={styles.addButton} onPress={openAddModal}><Text style={styles.addButtonText}>إضافة مساعد جديد</Text></TouchableOpacity></View>}
      />

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <ScrollView contentContainerStyle={styles.modalScrollContent}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{editingAssistant ? 'تعديل المساعد' : 'إضافة مساعد جديد'}</Text>
                <TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity>
              </View>

              <Text style={styles.label}>اسم المساعد *</Text>
              <TextInput style={styles.input} placeholder="مثال: منجز" value={name} onChangeText={setName} />

              <Text style={styles.label}>الشاشة الرئيسية *</Text>
              <View style={styles.screenContainer}>
                {MAIN_SCREENS.map((s) => (
                  <TouchableOpacity key={s.id} style={[styles.screenButton, mainScreen === s.id && styles.screenButtonActive]} onPress={() => setMainScreen(s.id)}>
                    <Ionicons name={s.icon} size={16} color={mainScreen === s.id ? '#FFF' : '#4B5563'} />
                    <Text style={[styles.screenButtonText, mainScreen === s.id && styles.screenButtonTextActive]}>{s.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* اختيار نوع الفلتر */}
              {(mainScreen === 'service' || mainScreen === 'products_service') && (
                <>
                  <Text style={styles.label}>نوع المصدر</Text>
                  <View style={{ flexDirection: 'row', gap: 12, marginBottom: 15 }}>
                    <TouchableOpacity 
                      style={[styles.filterTypeButton, filterType === 'service' && styles.filterTypeActive]}
                      onPress={() => setFilterType('service')}>
                      <Text style={[styles.filterTypeText, filterType === 'service' && styles.filterTypeTextActive]}>حسب الخدمة</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.filterTypeButton, filterType === 'merchant' && styles.filterTypeActive]}
                      onPress={() => setFilterType('merchant')}>
                      <Text style={[styles.filterTypeText, filterType === 'merchant' && styles.filterTypeTextActive]}>حسب التاجر</Text>
                    </TouchableOpacity>
                  </View>

                  {filterType === 'service' ? (
                    <>
                      <Text style={styles.label}>اختر الخدمة *</Text>
                      <Text style={[styles.label, { color: '#10B981', fontSize: 12, marginTop: 0 }]}>📌 سيتم ملء جميع الحقول تلقائياً من الخدمة</Text>
                      {loadingServices ? <ActivityIndicator size="small" color="#4F46E5" /> : (
                        <View style={styles.serviceContainer}>
                          {services.map((s) => (
                            <TouchableOpacity key={s.id} style={[styles.serviceButton, selectedServiceId === s.id && styles.serviceButtonActive]} onPress={() => { setSelectedServiceId(s.id); setSelectedServiceName(s.name); }}>
                              <Text style={[styles.serviceButtonText, selectedServiceId === s.id && styles.serviceButtonTextActive]}>{s.name}</Text>
                            </TouchableOpacity>
                          ))}
                        </View>
                      )}
                    </>
                  ) : (
                    <>
                      <Text style={styles.label}>اختر التاجر *</Text>
                      {loadingMerchants ? <ActivityIndicator size="small" color="#4F46E5" /> : (
                        <View style={styles.serviceContainer}>
                          {merchants.map((m) => (
                            <TouchableOpacity key={m.id} style={[styles.serviceButton, selectedMerchantId === m.id && styles.serviceButtonActive]} onPress={() => { setSelectedMerchantId(m.id); setSelectedMerchantName(m.name); }}>
                              <Text style={[styles.serviceButtonText, selectedMerchantId === m.id && styles.serviceButtonTextActive]}>{m.name}</Text>
                            </TouchableOpacity>
                          ))}
                        </View>
                      )}
                    </>
                  )}

                  {(selectedServiceId || selectedMerchantId) && (
                    <Text style={{ fontSize: 12, color: '#10B981', marginBottom: 10, textAlign: 'center' }}>✅ تم بناء الفلتر تلقائياً: {dataFilter}</Text>
                  )}
                </>
              )}

              <Text style={styles.label}>نموذج الذكاء الاصطناعي</Text>
              <View style={styles.modelContainer}>
                {AVAILABLE_MODELS.map((m) => (
                  <TouchableOpacity key={m.value} style={[styles.modelButton, model === m.value && styles.modelButtonActive]} onPress={() => { setModel(m.value); setShowCustomModelInput(false); setCustomModel(''); }}>
                    <Text style={[styles.modelButtonText, model === m.value && styles.modelButtonTextActive]}>{m.label}</Text>
                  </TouchableOpacity>
                ))}
                <TouchableOpacity style={[styles.modelButton, model === 'custom' && styles.modelButtonActive]} onPress={() => { setModel('custom'); setShowCustomModelInput(true); }}>
                  <Text style={[styles.modelButtonText, model === 'custom' && styles.modelButtonTextActive]}>مخصص</Text>
                </TouchableOpacity>
              </View>
              {showCustomModelInput && <TextInput style={styles.input} placeholder="أدخل اسم النموذج" value={customModel} onChangeText={setCustomModel} />}

              <Text style={styles.label}>رسالة الترحيب</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="أهلاً! أنا مُنجز..." value={welcomeMessage} onChangeText={setWelcomeMessage} multiline numberOfLines={3} />

              <Text style={styles.label}>التعليمات (System Prompt)</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="أنت مساعد ذكي..." value={systemPrompt} onChangeText={setSystemPrompt} multiline numberOfLines={4} />

              <Text style={styles.label}>اللون</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.colorsScroll}>
                {COLORS.map((c) => <TouchableOpacity key={c} style={[styles.colorOption, { backgroundColor: c }, color === c && styles.colorOptionActive]} onPress={() => setColor(c)} />)}
              </ScrollView>

              <View style={styles.switchContainer}>
                <Text style={styles.label}>المساعد نشط</Text>
                <Switch value={isActive} onValueChange={setIsActive} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} />
              </View>

              <Text style={styles.label}>الترتيب</Text>
              <TextInput style={styles.input} placeholder="0" value={order} onChangeText={setOrder} keyboardType="numeric" />

              {/* معلومات الخدمة */}
              <Text style={[styles.label, { marginTop: 20, color: '#10B981' }]}>━━━━━ معلومات الخدمة ━━━━━</Text>
              <Text style={styles.label}>اسم الخدمة الظاهر</Text>
              <TextInput style={styles.input} placeholder="اسم الخدمة" value={serviceDisplayName} onChangeText={setServiceDisplayName} />
              <Text style={styles.label}>نوع الخدمة</Text>
              <TextInput style={styles.input} placeholder="نوع الخدمة" value={serviceTypeName} onChangeText={setServiceTypeName} />
              <Text style={styles.label}>وصف الخدمة</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="وصف الخدمة" value={serviceDescription} onChangeText={setServiceDescription} multiline />

              {/* مصدر البيانات */}
              <Text style={[styles.label, { marginTop: 20, color: '#8B5CF6' }]}>━━━━━ مصدر البيانات ━━━━━</Text>
              <Text style={styles.label}>جدول البيانات</Text>
              <TextInput style={styles.input} placeholder="all_merchant_products" value={dataTable} onChangeText={setDataTable} />
              <Text style={styles.label}>الأعمدة المطلوبة</Text>
              <TextInput style={styles.input} placeholder="name, price, description, image_url" value={dataColumns} onChangeText={setDataColumns} />
              <Text style={styles.label}>فلتر البيانات</Text>
              <TextInput style={styles.input} placeholder="service_id::eq::home_chef" value={dataFilter} onChangeText={setDataFilter} />
              <Text style={styles.label}>الحد الأقصى</Text>
              <TextInput style={styles.input} placeholder="100" value={dataLimit} onChangeText={setDataLimit} keyboardType="numeric" />

              <TouchableOpacity style={[styles.saveButton, submitting && styles.disabled]} onPress={handleSave} disabled={submitting}>
                {submitting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>{editingAssistant ? 'حفظ التغييرات' : 'إضافة المساعد'}</Text>}
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#6B7280', marginBottom: 20 },
  addButton: { backgroundColor: '#4F46E5', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 8 },
  addButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  assistantCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  assistantCardDisabled: { opacity: 0.6, backgroundColor: '#F9FAFB' },
  assistantHeader: { flexDirection: 'row', marginBottom: 8 },
  assistantIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  assistantInfo: { flex: 1 },
  assistantName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  assistantScreen: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  assistantModel: { fontSize: 10, color: '#8B5CF6', marginTop: 2 },
  assistantActions: { flexDirection: 'row', gap: 8 },
  actionButton: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  editButton: { backgroundColor: '#F59E0B' },
  toggleButton: { backgroundColor: '#EF4444' },
  deleteButton: { backgroundColor: '#6B7280' },
  welcomeMessage: { fontSize: 12, color: '#4B5563', marginTop: 4 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalScrollContent: { paddingBottom: 20, paddingTop: 60 },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  textArea: { minHeight: 80, textAlignVertical: 'top' },
  screenContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  screenButton: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  screenButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  screenButtonText: { fontSize: 12, color: '#4B5563' },
  screenButtonTextActive: { color: '#FFF', fontWeight: '600' },
  filterTypeButton: { flex: 1, paddingVertical: 10, borderRadius: 8, backgroundColor: '#F3F4F6', alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  filterTypeActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  filterTypeText: { fontSize: 14, color: '#4B5563', fontWeight: '600' },
  filterTypeTextActive: { color: '#FFF' },
  serviceContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  serviceButton: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  serviceButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  serviceButtonText: { fontSize: 12, color: '#4B5563' },
  serviceButtonTextActive: { color: '#FFF', fontWeight: '600' },
  modelContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  modelButton: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  modelButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  modelButtonText: { fontSize: 12, color: '#4B5563' },
  modelButtonTextActive: { color: '#FFF', fontWeight: '600' },
  colorsScroll: { flexDirection: 'row', marginBottom: 15 },
  colorOption: { width: 40, height: 40, borderRadius: 20, marginRight: 8, borderWidth: 2, borderColor: 'transparent' },
  colorOptionActive: { borderColor: '#1F2937' },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  disabled: { opacity: 0.6 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
