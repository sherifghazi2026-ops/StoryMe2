import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  ActivityIndicator, Image, Modal, TextInput, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { getShopSettings, updateShopSettings, getShopProducts, createShopProduct } from '../../services/shopService';
import { supabase } from '../../lib/supabaseClient';
import { uploadToImageKit } from '../../services/uploadService';
import { getOrders, updateOrderStatus, ORDER_STATUS } from '../../services/orderService';
import { fontFamily } from '../../utils/fonts';

const DEFAULT_CATEGORIES = ['عام', 'عروض', 'رجال', 'نساء', 'أطفال', 'منزل', 'إلكترونيات', 'رياضة', 'مطبخ'];

export default function ShopManagementScreen({ navigation }) {
  const [settings, setSettings] = useState({});
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('products');
  const [pendingReviews, setPendingReviews] = useState([]);

  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [category, setCategory] = useState('عام');
  const [description, setDescription] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [images, setImages] = useState([]);

  const [showReviews, setShowReviews] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [reviewProductId, setReviewProductId] = useState(null);

  const [shippingCost, setShippingCost] = useState('30');
  const [freeShippingMin, setFreeShippingMin] = useState('200');

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [settingsRes, productsRes] = await Promise.all([getShopSettings(), getShopProducts()]);
    setSettings(settingsRes);
    setShippingCost(settingsRes?.shipping_cost?.toString() || '30');
    setFreeShippingMin(settingsRes?.free_shipping_min_order?.toString() || '200');
    setProducts(productsRes.data || []);
    const ordersRes = await getOrders();
    if (ordersRes.success) setOrders(ordersRes.data.filter(o => o.service_type === 'eshop'));
    // ✅ جلب التقييمات المعلقة
    const { data: revs } = await supabase.from("shop_reviews").select("*").eq("is_approved", false).order("created_at", { ascending: false });
    if (revs) setPendingReviews(revs);
    setLoading(false);
  };

  const toggleShop = async (val) => { await updateShopSettings({ is_active: val }); setSettings({ ...settings, is_active: val }); };

  const pickBanner = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadToImageKit(result.assets[0].uri, 'banner_' + Date.now() + '.jpg', 'shop');
      setUploading(false);
      if (res.success) { setSettings({ ...settings, banner_image: res.fileUrl }); await updateShopSettings({ banner_image: res.fileUrl }); }
    }
  };

  const handleSaveSettings = async () => {
    const d = { ...settings, shipping_cost: parseInt(shippingCost) || 30, free_shipping_min_order: parseInt(freeShippingMin) || 200, free_shipping: settings.free_shipping !== false };
    setSaving(true); await updateShopSettings(d); setSettings(d); setSaving(false);
    Alert.alert('✅ تم', 'تم حفظ الإعدادات');
  };

  const openAddModal = () => {
    setEditMode(false); setSelectedProduct(null);
    setName(''); setPrice(''); setOriginalPrice(''); setDiscountPercent('');
    setCategory('عام'); setDescription(''); setIsFeatured(false); setImages([]);
    setShowModal(true);
  };

  const openEditModal = (product) => {
    setEditMode(true); setSelectedProduct(product);
    setName(product.name); setPrice(product.price?.toString()); setOriginalPrice(product.original_price?.toString() || '');
    setDiscountPercent(product.discount_percent?.toString() || '');
    setCategory(product.category || 'عام'); setDescription(product.description || '');
    setIsFeatured(product.is_featured || false);
    setImages(product.images && Array.isArray(product.images) ? product.images : product.image_url ? [product.image_url] : []);
    setShowModal(true);
  };

  const pickImages = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true, allowsMultipleSelection: true, selectionLimit: 5 });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const urls = [];
      for (const asset of result.assets) {
        const res = await uploadToImageKit(asset.uri, 'shop_' + Date.now() + '.jpg', 'shop');
        if (res.success) urls.push(res.fileUrl);
      }
      setUploading(false);
      setImages(prev => [...prev, ...urls]);
    }
  };

  const removeImage = (index) => setImages(images.filter((_, i) => i !== index));

  const handleSaveProduct = async () => {
    if (!name.trim() || !price) { Alert.alert('تنبيه', 'الاسم والسعر مطلوبان'); return; }
    setSaving(true);
    try {
      const finalPrice = parseFloat(price);
      const finalOriginalPrice = originalPrice ? parseFloat(originalPrice) : null;
      const finalDiscount = discountPercent ? parseInt(discountPercent) : (finalOriginalPrice ? Math.round((1 - finalPrice / finalOriginalPrice) * 100) : 0);
      const data = { name: name.trim(), price: finalPrice, original_price: finalOriginalPrice, discount_percent: finalDiscount, category, description: description.trim(), image_url: images[0] || '', images: images, is_featured: isFeatured, updated_at: new Date().toISOString() };
      if (editMode && selectedProduct) await supabase.from('shop_products').update(data).eq('id', selectedProduct.id);
      else await createShopProduct(data);
      setShowModal(false); loadAll();
    } catch (e) { Alert.alert('خطأ', e.message); }
    setSaving(false);
  };

  const handleDelete = (id) => {
    Alert.alert('حذف المنتج', 'هل أنت متأكد؟', [{ text: 'إلغاء' }, { text: 'حذف', onPress: async () => { await supabase.from('shop_products').delete().eq('id', id); loadAll(); } }]);
  };

  const loadReviews = async (productId) => {
    setReviewProductId(productId);
    const { data } = await supabase.from('shop_reviews').select('*').eq('product_id', productId).order('created_at', { ascending: false });
    setReviews(data || []);
    setShowReviews(true);
  };

  const approveReview = async (id) => {
    await supabase.from('shop_reviews').update({ is_approved: true }).eq('id', id);
    loadAll();
    if (reviewProductId) loadReviews(reviewProductId);
  };

  const handleUpdateOrderStatus = (orderId, newStatus) => {
    Alert.alert('تغيير الحالة', `تغيير حالة الطلب إلى "${newStatus}"؟`, [{ text: 'إلغاء' }, { text: 'تأكيد', onPress: async () => { await updateOrderStatus(orderId, newStatus); loadAll(); } }]);
  };

  const getStatusColor = (s) => {
    const c = { pending: '#F59E0B', accepted: '#3B82F6', preparing: '#8B5CF6', ready: '#10B981', driver_assigned: '#3B82F6', on_the_way: '#3B82F6', delivered: '#10B981', cancelled: '#EF4444' };
    return c[s] || '#6B7280';
  };

  const getStatusText = (s) => {
    const t = { pending: 'معلق', accepted: 'مقبول', preparing: 'قيد التجهيز', ready: 'جاهز', driver_assigned: 'مندوب معين', on_the_way: 'جاري التوصيل', delivered: 'تم التوصيل', cancelled: 'ملغي' };
    return t[s] || s;
  };

  const totalSales = orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + (o.total_price || 0), 0);
  const totalOrders = orders.length;

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#F59E0B" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>المتجر</Text>
        <TouchableOpacity onPress={openAddModal}><Ionicons name="add-circle" size={28} color="#F59E0B" /></TouchableOpacity>
      </View>

      {/* ✅ Tabs محسنة - الأرقام تحت الاسم */}
      <View style={styles.tabRow}>
        {[
          { key: 'products', icon: '📦', label: 'المنتجات', count: products.length },
          { key: 'orders', icon: '🛒', label: 'الطلبات', count: orders.length },
          { key: 'reviews', icon: '⭐', label: 'التقييمات', count: pendingReviews.length },
          { key: 'analytics', icon: '📊', label: 'التحليلات', count: null },
        ].map(tab => (
          <TouchableOpacity key={tab.key} style={[styles.tab, activeTab === tab.key && styles.tabActive]} onPress={() => setActiveTab(tab.key)}>
            <Text style={styles.tabIcon}>{tab.icon}</Text>
            <Text style={[styles.tabLabel, activeTab === tab.key && styles.tabLabelActive]}>{tab.label}</Text>
            {tab.count !== null && <Text style={[styles.tabCount, activeTab === tab.key && styles.tabCountActive]}>({tab.count})</Text>}
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* ⭐ التقييمات المعلقة */}
        {activeTab === 'reviews' && (
          pendingReviews.length === 0 ? <View style={styles.empty}><Ionicons name="star-outline" size={60} color="#D1D5DB" /><Text style={styles.emptyText}>لا توجد تقييمات معلقة</Text></View> :
          pendingReviews.map(r => (
            <View key={r.id} style={styles.reviewCard}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={styles.reviewName}>{r.customer_name || 'عميل'}</Text>
                <View style={{ flexDirection: 'row' }}>{[1,2,3,4,5].map(s => <Ionicons key={s} name={s <= r.rating ? 'star' : 'star-outline'} size={14} color="#F59E0B" />)}</View>
              </View>
              {r.comment ? <Text style={styles.reviewComment}>{r.comment}</Text> : null}
              <TouchableOpacity style={styles.approveBtn} onPress={() => approveReview(r.id)}>
                <Text style={styles.approveBtnText}>✅ موافقة</Text>
              </TouchableOpacity>
            </View>
          ))
        )}

        {/* 📊 التحليلات */}
        {activeTab === 'analytics' && (
          <View style={styles.analyticsRow}>
            <View style={styles.analyticsCard}><Text style={styles.analyticsValue}>{totalOrders}</Text><Text style={styles.analyticsLabel}>طلب</Text></View>
            <View style={styles.analyticsCard}><Text style={styles.analyticsValue}>{totalSales} ج</Text><Text style={styles.analyticsLabel}>مبيعات</Text></View>
            <View style={styles.analyticsCard}><Text style={styles.analyticsValue}>⭐ --</Text><Text style={styles.analyticsLabel}>تقييم</Text></View>
          </View>
        )}

        {/* 📦 المنتجات */}
        {activeTab === 'products' && (
          <>
            <View style={styles.card}>
              <View style={styles.switchRow}><Text style={styles.cardTitle}>حالة المتجر</Text><Switch value={settings.is_active} onValueChange={toggleShop} trackColor={{ false: '#E5E7EB', true: '#10B981' }} /></View>
              <Text style={styles.statusText}>{settings.is_active ? '🟢 نشط' : '🔴 تحت الصيانة'}</Text>
            </View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>بانر المتجر</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickBanner} disabled={uploading}>
                {settings.banner_image ? <Image source={{ uri: settings.banner_image }} style={styles.bannerPreview} /> : <View style={styles.imagePlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF" /><Text>اختر صورة البانر</Text></View>}
              </TouchableOpacity>
              <Text style={styles.cardTitle}>🚚 إعدادات الشحن</Text>
              <View style={styles.switchRow}><Text>شحن مجاني</Text><Switch value={settings.free_shipping !== false} onValueChange={(v) => setSettings({ ...settings, free_shipping: v })} trackColor={{ false: '#E5E7EB', true: '#10B981' }} /></View>
              {settings.free_shipping !== false && <><Text style={styles.label}>الحد الأدنى للشحن المجاني</Text><TextInput style={styles.input} value={freeShippingMin} onChangeText={setFreeShippingMin} keyboardType="numeric" placeholder="200" /></>}
              <Text style={styles.label}>تكلفة الشحن</Text><TextInput style={styles.input} value={shippingCost} onChangeText={setShippingCost} keyboardType="numeric" placeholder="30" />
              <TouchableOpacity style={styles.saveBtn} onPress={handleSaveSettings} disabled={saving}>{saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>حفظ الإعدادات</Text>}</TouchableOpacity>
            </View>
            <Text style={styles.sectionTitle}>📦 المنتجات</Text>
            {products.map(p => {
              const discount = p.discount_percent || (p.original_price ? Math.round((1 - p.price / p.original_price) * 100) : 0);
              return (
                <View key={p.id} style={styles.productRow}>
                  {p.image_url ? <Image source={{ uri: p.image_url }} style={styles.productThumb} /> : <View style={styles.productThumbPlaceholder}><Ionicons name="image-outline" size={20} color="#D1D5DB" /></View>}
                  <View style={{ flex: 1 }}>
                    <Text style={styles.productName}>{p.name}</Text>
                    <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                      <Text style={styles.productPrice}>{p.price} ج</Text>
                      {p.original_price && <Text style={styles.productOldPrice}>{p.original_price} ج</Text>}
                      {discount > 0 && <View style={styles.discountChip}><Text style={styles.discountChipText}>%{discount}</Text></View>}
                    </View>
                    <Text style={styles.productCat}>{p.category} | {p.is_featured ? '⭐ مميز' : ''} | {p.images?.length || 1} صور</Text>
                  </View>
                  <TouchableOpacity style={styles.actionBtn} onPress={() => loadReviews(p.id)}><Ionicons name="star-outline" size={16} color="#F59E0B" /></TouchableOpacity>
                  <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#3B82F6' }]} onPress={() => openEditModal(p)}><Ionicons name="create-outline" size={16} color="#FFF" /></TouchableOpacity>
                  <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#EF4444' }]} onPress={() => handleDelete(p.id)}><Ionicons name="trash-outline" size={16} color="#FFF" /></TouchableOpacity>
                </View>
              );
            })}
          </>
        )}

        {/* 🛒 الطلبات */}
        {activeTab === 'orders' && (orders.length === 0 ? <View style={styles.empty}><Ionicons name="cart-outline" size={60} color="#D1D5DB" /><Text style={styles.emptyText}>لا توجد طلبات</Text></View> :
          orders.map(order => (
            <View key={order.id} style={styles.orderCard}>
              <View style={styles.orderHeader}><Text style={styles.orderId}>#{order.id?.slice(-6)}</Text><View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) + '20' }]}><Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>{getStatusText(order.status)}</Text></View></View>
              <Text style={styles.orderCustomer}>{order.customer_name} - {order.customer_phone}</Text>
              <Text style={styles.orderAddress}>{order.customer_address}</Text>
              <Text style={styles.orderTotal}>{order.final_total || order.total_price} ج</Text>
              <View style={styles.orderActions}>
                {order.status === 'pending' && <TouchableOpacity style={styles.acceptBtn} onPress={() => handleUpdateOrderStatus(order.id, 'accepted')}><Text style={styles.orderBtnText}>قبول</Text></TouchableOpacity>}
                {order.status === 'accepted' && <TouchableOpacity style={styles.preparingBtn} onPress={() => handleUpdateOrderStatus(order.id, 'preparing')}><Text style={styles.orderBtnText}>جاري التجهيز</Text></TouchableOpacity>}
                {order.status === 'preparing' && <TouchableOpacity style={styles.deliveryBtn} onPress={() => handleUpdateOrderStatus(order.id, 'on_the_way')}><Text style={styles.orderBtnText}>جاري التوصيل</Text></TouchableOpacity>}
                {order.status === 'on_the_way' && <TouchableOpacity style={styles.deliverBtn} onPress={() => handleUpdateOrderStatus(order.id, 'delivered')}><Text style={styles.orderBtnText}>تم التوصيل</Text></TouchableOpacity>}
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* مودال المنتج */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.modalOverlay}><ScrollView contentContainerStyle={styles.modalContent}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>{editMode ? 'تعديل منتج' : 'إضافة منتج جديد'}</Text><TouchableOpacity onPress={() => setShowModal(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          <Text style={styles.label}>اسم المنتج *</Text><TextInput style={styles.input} value={name} onChangeText={setName} />
          <View style={{ flexDirection: 'row', gap: 10 }}><View style={{ flex: 1 }}><Text style={styles.label}>السعر (ج) *</Text><TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="numeric" /></View><View style={{ flex: 1 }}><Text style={styles.label}>السعر قبل الخصم</Text><TextInput style={styles.input} value={originalPrice} onChangeText={setOriginalPrice} keyboardType="numeric" /></View></View>
          <Text style={styles.label}>نسبة الخصم %</Text><TextInput style={styles.input} value={discountPercent} onChangeText={setDiscountPercent} keyboardType="numeric" placeholder="0" />
          <Text style={styles.label}>الفئة</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>{DEFAULT_CATEGORIES.map(cat => (<TouchableOpacity key={cat} style={[styles.catChip, category === cat && styles.catChipActive]} onPress={() => setCategory(cat)}><Text style={[styles.catChipText, category === cat && styles.catChipTextActive]}>{cat}</Text></TouchableOpacity>))}</ScrollView>
          <Text style={styles.label}>الوصف</Text><TextInput style={styles.input} value={description} onChangeText={setDescription} multiline />
          <View style={styles.switchRow}><Text>منتج مميز ⭐</Text><Switch value={isFeatured} onValueChange={setIsFeatured} /></View>
          <Text style={styles.label}>صور المنتج ({images.length})</Text>
          {images.length > 0 && <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>{images.map((img, idx) => (<View key={idx} style={{ marginRight: 8, position: 'relative' }}><Image source={{ uri: img }} style={{ width: 80, height: 80, borderRadius: 10 }} /><TouchableOpacity style={{ position: 'absolute', top: -6, right: -6, backgroundColor: '#FFF', borderRadius: 12 }} onPress={() => removeImage(idx)}><Ionicons name="close-circle" size={22} color="#EF4444" /></TouchableOpacity></View>))}</ScrollView>}
          <TouchableOpacity style={styles.uploadBtn} onPress={pickImages} disabled={uploading}>{uploading ? <ActivityIndicator size="small" color="#F59E0B" /> : <><Ionicons name="add-circle-outline" size={22} color="#F59E0B" /><Text style={styles.uploadBtnText}>إضافة صور</Text></>}</TouchableOpacity>
          <TouchableOpacity style={[styles.saveBtn, saving && { opacity: 0.6 }]} onPress={handleSaveProduct} disabled={saving}>{saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>{editMode ? 'تحديث المنتج' : 'إضافة المنتج'}</Text>}</TouchableOpacity>
        </ScrollView></View>
      </Modal>

      {/* مودال التقييمات */}
      <Modal visible={showReviews} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.reviewModal}>
          <View style={styles.modalHeader}><Text style={styles.modalTitle}>تقييمات المنتج</Text><TouchableOpacity onPress={() => setShowReviews(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity></View>
          {reviews.length === 0 ? <Text style={styles.emptyText}>لا توجد تقييمات بعد</Text> :
            reviews.map(r => (
              <View key={r.id} style={styles.reviewCard}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={styles.reviewName}>{r.customer_name || 'عميل'}</Text><View style={{ flexDirection: 'row' }}>{[1,2,3,4,5].map(s => <Ionicons key={s} name={s <= r.rating ? 'star' : 'star-outline'} size={14} color="#F59E0B" />)}</View></View>
                {r.comment ? <Text style={styles.reviewComment}>{r.comment}</Text> : null}
                {!r.is_approved && <TouchableOpacity style={styles.approveBtn} onPress={() => approveReview(r.id)}><Text style={styles.approveBtnText}>✅ موافقة</Text></TouchableOpacity>}
                <Text style={styles.reviewDate}>{new Date(r.created_at).toLocaleDateString('ar-EG')}</Text>
              </View>
            ))
          }
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily?.arabic },
  // ✅ Tabs محسنة
  tabRow: { flexDirection: 'row', backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB', paddingVertical: 8 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 6 },
  tabActive: { borderBottomWidth: 2, borderBottomColor: '#F59E0B' },
  tabIcon: { fontSize: 16 },
  tabLabel: { fontSize: 11, color: '#6B7280', fontFamily: fontFamily?.arabic, marginTop: 2 },
  tabLabelActive: { color: '#F59E0B', fontWeight: '600' },
  tabCount: { fontSize: 10, color: '#9CA3AF', marginTop: 1 },
  tabCountActive: { color: '#F59E0B' },
  content: { padding: 16 },
  analyticsRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  analyticsCard: { flex: 1, backgroundColor: '#FFF', borderRadius: 16, padding: 16, alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  analyticsValue: { fontSize: 24, fontWeight: '700', color: '#F59E0B' },
  analyticsLabel: { fontSize: 12, color: '#6B7280', marginTop: 4, fontFamily: fontFamily?.arabic },
  card: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  cardTitle: { fontSize: 16, fontWeight: '600', marginBottom: 12, fontFamily: fontFamily?.arabic },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 8 },
  statusText: { fontSize: 14, fontWeight: '500' },
  imagePicker: { height: 120, backgroundColor: '#F3F4F6', borderRadius: 8, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', marginBottom: 10 },
  bannerPreview: { width: '100%', height: '100%' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  input: { backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#E5E7EB', fontSize: 14, fontFamily: fontFamily?.arabic },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginTop: 12, fontFamily: fontFamily?.arabic },
  saveBtn: { backgroundColor: '#F59E0B', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 12 },
  saveBtnText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12, marginTop: 8, fontFamily: fontFamily?.arabic },
  productRow: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#FFF', borderRadius: 8, marginBottom: 6, gap: 8 },
  productThumb: { width: 44, height: 44, borderRadius: 8 },
  productThumbPlaceholder: { width: 44, height: 44, borderRadius: 8, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  productName: { fontSize: 14, fontWeight: '500', fontFamily: fontFamily?.arabic },
  productCat: { fontSize: 11, color: '#6B7280', marginTop: 2 },
  productPrice: { fontSize: 13, fontWeight: '600', color: '#F59E0B' },
  productOldPrice: { fontSize: 11, color: '#9CA3AF', textDecorationLine: 'line-through', marginLeft: 4 },
  discountChip: { backgroundColor: '#FEE2E2', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 },
  discountChipText: { color: '#EF4444', fontSize: 10, fontWeight: '700' },
  actionBtn: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FEF3C7' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 16, padding: 20 },
  reviewModal: { backgroundColor: '#FFF', borderRadius: 16, padding: 20, maxHeight: '70%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', fontFamily: fontFamily?.arabic },
  catChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 16, backgroundColor: '#F3F4F6', marginRight: 8 },
  catChipActive: { backgroundColor: '#EEF2FF', borderWidth: 1, borderColor: '#4F46E5' },
  catChipText: { fontSize: 13, color: '#6B7280' },
  catChipTextActive: { color: '#4F46E5', fontWeight: '600' },
  uploadBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginTop: 8, gap: 6 },
  uploadBtnText: { color: '#F59E0B', fontSize: 14, fontWeight: '600' },
  empty: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 10, fontFamily: fontFamily?.arabic },
  orderCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600' },
  orderCustomer: { fontSize: 14, fontWeight: '500', color: '#1F2937', fontFamily: fontFamily?.arabic },
  orderAddress: { fontSize: 12, color: '#6B7280', marginTop: 4 },
  orderTotal: { fontSize: 14, fontWeight: '700', color: '#F59E0B', marginTop: 6 },
  orderActions: { flexDirection: 'row', gap: 8, marginTop: 10 },
  acceptBtn: { backgroundColor: '#3B82F6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  preparingBtn: { backgroundColor: '#8B5CF6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  deliveryBtn: { backgroundColor: '#F59E0B', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  deliverBtn: { backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  orderBtnText: { color: '#FFF', fontSize: 13, fontWeight: '600' },
  reviewCard: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  reviewName: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  reviewComment: { fontSize: 13, color: '#4B5563', marginTop: 4 },
  reviewDate: { fontSize: 11, color: '#9CA3AF', marginTop: 4 },
  approveBtn: { backgroundColor: '#10B981', padding: 8, borderRadius: 8, alignSelf: 'flex-start', marginTop: 6 },
  approveBtnText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
});
