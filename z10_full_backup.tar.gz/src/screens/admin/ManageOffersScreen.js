import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, ActivityIndicator, Image, RefreshControl, Modal, TextInput, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../lib/supabaseClient';
import { updateOfferStatus, createOffer } from '../../services/offersService';
import { sendPushNotification } from '../../services/pushNotificationService';
import { uploadToImageKit } from '../../services/uploadService';

export default function ManageOffersScreen({ navigation }) {
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [serviceType, setServiceType] = useState('');
  const [merchantId, setMerchantId] = useState('');
  const [merchantName, setMerchantName] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [offerPrice, setOfferPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState([]);
  const [merchants, setMerchants] = useState([]);
  const [showServicePicker, setShowServicePicker] = useState(false);
  const [showMerchantPicker, setShowMerchantPicker] = useState(false);
  const [headerImage, setHeaderImage] = useState(null);
  const [filter, setFilter] = useState('pending');

  useEffect(() => { loadOffers(); loadServices(); loadMerchants(); loadHeaderImage(); }, []);

  const loadServices = async () => { const { data } = await supabase.from('services').select('id, name'); if (data) setServices(data); };
  const loadMerchants = async () => { const { data } = await supabase.from('merchants').select('id, name, service_type').eq('is_active', true); if (data) setMerchants(data); };

  const loadOffers = async () => {
    setLoading(true);
    let query = supabase.from('offers').select('*').order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query;
    setOffers(data || []);
    setLoading(false); setRefreshing(false);
  };

  useEffect(() => { loadOffers(); }, [filter]);

  const loadHeaderImage = async () => {
    try { const { data } = await supabase.from('services').select('image_url').eq('id', 'offers_header').single(); if (data?.image_url) setHeaderImage(data.image_url); } catch (e) {}
  };

  const pickHeaderImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadToImageKit(result.assets[0].uri, 'offers_header_' + Date.now() + '.jpg', 'services');
      setUploading(false);
      if (res.success) {
        setHeaderImage(res.fileUrl);
        await supabase.from('services').upsert({ id: 'offers_header', name: 'عروض Header', type: 'other', is_visible: false, image_url: res.fileUrl }, { onConflict: 'id' });
        Alert.alert('✅ تم', 'تم تحديث صورة Header العروض');
      } else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleApprove = async (offerId) => {
    await updateOfferStatus(offerId, 'approved');
    loadOffers();
  };

  const handleReject = (offerId) => {
    Alert.alert('رفض العرض', 'هل أنت متأكد؟', [
      { text: 'إلغاء' },
      { text: 'رفض', onPress: async () => { await updateOfferStatus(offerId, 'rejected'); loadOffers(); }},
    ]);
  };

  // ✅ إرسال إشعار للعملاء فقط
  const handleNotifyAll = (offer) => {
    Alert.alert('📢 إرسال إشعار', `إرسال إشعار "${offer.title}" لجميع العملاء؟`, [
      { text: 'إلغاء' },
      { text: 'إرسال', onPress: async () => {
        // ✅ الخطوة 1: جلب كل العملاء
        const { data: customers } = await supabase
          .from('profiles')
          .select('id')
          .eq('role', 'customer');

        if (!customers || customers.length === 0) {
          Alert.alert('تنبيه', 'لا يوجد عملاء مسجلين');
          return;
        }

        // ✅ الخطوة 2: جلب توكناتهم
        const customerIds = customers.map(c => c.id);
        const { data: tokens } = await supabase
          .from('user_tokens')
          .select('expo_push_token')
          .in('user_id', customerIds)
          .not('expo_push_token', 'is', null);

        if (!tokens || tokens.length === 0) {
          Alert.alert('تنبيه', 'لا يوجد عملاء لديهم توكن إشعارات');
          return;
        }

        // ✅ الخطوة 3: إرسال الإشعارات
        let sent = 0;
        for (const t of tokens) {
          if (t.expo_push_token) {
            await sendPushNotification(t.expo_push_token,
              `🔥 ${offer.title}`,
              `${offer.description || 'عرض مميز'}\n💰 ${offer.offer_price || (offer.discount_percent ? offer.discount_percent + '% خصم' : '')}`,
              { screen: 'OffersScreen', offerId: offer.id, type: 'new_offer' }
            );
            sent++;
          }
        }
        Alert.alert('✅ تم', `تم إرسال الإشعار لـ ${sent} عميل من أصل ${customers.length} عملاء`);
      }}
    ]);
  };

  const openAddModal = () => {
    setEditMode(false); setTitle(''); setDescription(''); setServiceType(''); setMerchantId(''); setMerchantName('');
    setDiscountPercent(''); setOriginalPrice(''); setOfferPrice(''); setImageUrl(''); setSelectedOffer(null); setShowModal(true);
  };

  const openEditModal = (offer) => {
    setEditMode(true); setSelectedOffer(offer); setTitle(offer.title || ''); setDescription(offer.description || '');
    setServiceType(offer.service_type || ''); setMerchantId(offer.merchant_id || ''); setMerchantName(offer.merchant_name || '');
    setDiscountPercent(offer.discount_percent?.toString() || ''); setOriginalPrice(offer.original_price?.toString() || '');
    setOfferPrice(offer.offer_price?.toString() || ''); setImageUrl(offer.image_url || ''); setShowModal(true);
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const res = await uploadToImageKit(result.assets[0].uri, 'offer_' + Date.now() + '.jpg', 'offers');
      setUploading(false);
      if (res.success) setImageUrl(res.fileUrl);
      else Alert.alert('خطأ', 'فشل رفع الصورة');
    }
  };

  const handleSave = async () => {
    if (!title.trim()) { Alert.alert('تنبيه', 'يرجى إدخال عنوان العرض'); return; }
    setSaving(true);
    const offerData = { title: title.trim(), description: description.trim(), service_type: serviceType, merchant_id: merchantId || null, merchant_name: merchantName || 'إدارة Zid', discount_percent: discountPercent ? parseInt(discountPercent) : null, original_price: originalPrice ? parseFloat(originalPrice) : null, offer_price: offerPrice ? parseFloat(offerPrice) : null, image_url: imageUrl };
    if (editMode && selectedOffer) await supabase.from('offers').update({ ...offerData, updated_at: new Date().toISOString() }).eq('id', selectedOffer.id);
    else await createOffer(offerData);
    setSaving(false); setShowModal(false); loadOffers();
  };

  const selectMerchant = (merchant) => { setMerchantId(merchant.id); setMerchantName(merchant.name); setServiceType(merchant.service_type); setShowMerchantPicker(false); };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'approved': return { bg: '#10B98120', color: '#10B981', text: '✅ مقبول' };
      case 'rejected': return { bg: '#EF444420', color: '#EF4444', text: '❌ مرفوض' };
      default: return { bg: '#F59E0B20', color: '#F59E0B', text: '⏳ معلق' };
    }
  };

  const renderOffer = ({ item }) => {
    const badge = getStatusBadge(item.status);
    return (
    <View style={styles.card}>
      {item.image_url && <Image source={{ uri: item.image_url }} style={styles.image} />}
      <View style={styles.info}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.merchant}>{item.merchant_name || 'إدارة Zid'} - {item.service_type || 'عام'}</Text>
        {item.discount_percent && <Text style={styles.discount}>خصم {item.discount_percent}%</Text>}
        <View style={styles.statusRow}><View style={[styles.badge, { backgroundColor: badge.bg }]}><Text style={[styles.badgeText, { color: badge.color }]}>{badge.text}</Text></View></View>
      </View>
      <View style={styles.actions}>
        {item.status === 'pending' && (<>
          <TouchableOpacity style={styles.approveBtn} onPress={() => handleApprove(item.id)}><Ionicons name="checkmark" size={18} color="#FFF" /></TouchableOpacity>
          <TouchableOpacity style={styles.rejectBtn} onPress={() => handleReject(item.id)}><Ionicons name="close" size={18} color="#FFF" /></TouchableOpacity>
        </>)}
        {item.status === 'approved' && (
          <TouchableOpacity style={styles.notifyBtn} onPress={() => handleNotifyAll(item)}>
            <Ionicons name="notifications-outline" size={18} color="#FFF" />
          </TouchableOpacity>
        )}
        <TouchableOpacity style={styles.editBtn} onPress={() => openEditModal(item)}><Ionicons name="create-outline" size={18} color="#FFF" /></TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={() => { Alert.alert('حذف', 'حذف هذا العرض؟', [{ text: 'إلغاء' }, { text: 'حذف', onPress: async () => { await supabase.from('offers').delete().eq('id', item.id); loadOffers(); }}]); }}><Ionicons name="trash-outline" size={18} color="#FFF" /></TouchableOpacity>
      </View>
    </View>
  );};

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة العروض</Text>
        <TouchableOpacity onPress={openAddModal}><Ionicons name="add-circle" size={24} color="#F59E0B" /></TouchableOpacity>
      </View>
      <View style={styles.filterRow}>
        {[{ key: 'pending', label: 'معلقة' },{ key: 'approved', label: 'مقبولة' },{ key: 'rejected', label: 'مرفوضة' },{ key: 'all', label: 'الكل' }].map(f => (
          <TouchableOpacity key={f.key} style={[styles.filterBtn, filter===f.key&&styles.filterBtnActive]} onPress={()=>setFilter(f.key)}><Text style={[styles.filterBtnText, filter===f.key&&styles.filterBtnTextActive]}>{f.label}</Text></TouchableOpacity>
        ))}
      </View>
      <FlatList data={offers} renderItem={renderOffer} keyExtractor={item=>item.id.toString()} contentContainerStyle={styles.list} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadOffers}/>} ListEmptyComponent={<Text style={styles.empty}>لا توجد عروض</Text>}/>
      <Modal visible={showModal} transparent animationType="slide"><View style={styles.modalOverlay}><ScrollView contentContainerStyle={styles.modalContent}><View style={styles.modalHeader}><Text style={styles.modalTitle}>{editMode?'تعديل عرض':'إضافة عرض جديد'}</Text><TouchableOpacity onPress={()=>setShowModal(false)}><Ionicons name="close" size={24} color="#EF4444"/></TouchableOpacity></View><Text style={styles.label}>عنوان العرض *</Text><TextInput style={styles.input} value={title} onChangeText={setTitle}/><Text style={styles.label}>التاجر</Text><TouchableOpacity style={styles.selector} onPress={()=>setShowMerchantPicker(true)}><Text style={styles.selectorText}>{merchantName||'اختر تاجر'}</Text></TouchableOpacity><Text style={styles.label}>نوع الخدمة</Text><TouchableOpacity style={styles.selector} onPress={()=>setShowServicePicker(true)}><Text style={styles.selectorText}>{services.find(s=>s.id===serviceType)?.name||'اختر الخدمة'}</Text></TouchableOpacity><Text style={styles.label}>الوصف</Text><TextInput style={styles.input} value={description} onChangeText={setDescription} multiline/><View style={styles.row}><View style={styles.half}><Text style={styles.label}>نسبة الخصم %</Text><TextInput style={styles.input} value={discountPercent} onChangeText={setDiscountPercent} keyboardType="numeric"/></View><View style={styles.half}><Text style={styles.label}>السعر الأصلي</Text><TextInput style={styles.input} value={originalPrice} onChangeText={setOriginalPrice} keyboardType="numeric"/></View></View><Text style={styles.label}>سعر العرض</Text><TextInput style={styles.input} value={offerPrice} onChangeText={setOfferPrice} keyboardType="numeric"/><Text style={styles.label}>صورة العرض</Text><TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>{imageUrl?<Image source={{uri:imageUrl}} style={styles.imagePreview}/>:<View style={styles.imagePlaceholder}><Ionicons name="camera" size={40} color="#9CA3AF"/></View>}</TouchableOpacity><TouchableOpacity style={[styles.saveBtn,saving&&styles.disabled]} onPress={handleSave} disabled={saving}>{saving?<ActivityIndicator color="#FFF"/>:<Text style={styles.saveBtnText}>حفظ</Text>}</TouchableOpacity></ScrollView></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#F9FAFB'},center:{flex:1,justifyContent:'center',alignItems:'center'},
  headerRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',padding:16,backgroundColor:'#FFF',borderBottomWidth:1,borderBottomColor:'#E5E7EB'},
  headerTitle:{fontSize:18,fontWeight:'bold',color:'#1F2937'},
  filterRow:{flexDirection:'row',paddingHorizontal:16,paddingVertical:10,backgroundColor:'#FFF',gap:8,borderBottomWidth:1,borderBottomColor:'#E5E7EB'},
  filterBtn:{paddingHorizontal:14,paddingVertical:6,borderRadius:20,backgroundColor:'#F3F4F6'},
  filterBtnActive:{backgroundColor:'#F59E0B'},
  filterBtnText:{fontSize:13,color:'#6B7280',fontWeight:'600'},
  filterBtnTextActive:{color:'#FFF'},
  list:{padding:16},
  card:{backgroundColor:'#FFF',borderRadius:12,padding:12,marginBottom:12,borderWidth:1,borderColor:'#E5E7EB'},
  image:{width:'100%',height:100,borderRadius:8,marginBottom:8},
  info:{flex:1},
  title:{fontSize:16,fontWeight:'600',color:'#1F2937'},
  merchant:{fontSize:12,color:'#6B7280',marginTop:4},
  discount:{fontSize:14,fontWeight:'700',color:'#F59E0B',marginTop:6},
  statusRow:{flexDirection:'row',marginTop:8},
  badge:{paddingHorizontal:8,paddingVertical:4,borderRadius:12},
  badgeText:{fontSize:12,fontWeight:'600'},
  actions:{flexDirection:'row',justifyContent:'flex-end',gap:6,marginTop:10},
  approveBtn:{backgroundColor:'#10B981',width:32,height:32,borderRadius:16,justifyContent:'center',alignItems:'center'},
  rejectBtn:{backgroundColor:'#EF4444',width:32,height:32,borderRadius:16,justifyContent:'center',alignItems:'center'},
  notifyBtn:{backgroundColor:'#8B5CF6',width:32,height:32,borderRadius:16,justifyContent:'center',alignItems:'center'},
  editBtn:{backgroundColor:'#3B82F6',width:32,height:32,borderRadius:16,justifyContent:'center',alignItems:'center'},
  deleteBtn:{backgroundColor:'#6B7280',width:32,height:32,borderRadius:16,justifyContent:'center',alignItems:'center'},
  empty:{textAlign:'center',fontSize:16,color:'#9CA3AF',padding:20},
  modalOverlay:{flex:1,backgroundColor:'rgba(0,0,0,0.5)',justifyContent:'center',padding:20},
  modalContent:{backgroundColor:'#FFF',borderRadius:16,padding:20},
  modalHeader:{flexDirection:'row',justifyContent:'space-between',marginBottom:16},
  modalTitle:{fontSize:18,fontWeight:'bold',color:'#1F2937'},
  label:{fontSize:14,fontWeight:'600',color:'#4B5563',marginTop:12},
  input:{backgroundColor:'#F9FAFB',borderRadius:8,padding:12,marginTop:6,borderWidth:1,borderColor:'#E5E7EB'},
  selector:{flexDirection:'row',justifyContent:'space-between',backgroundColor:'#F9FAFB',borderRadius:8,padding:12,marginTop:6,borderWidth:1,borderColor:'#E5E7EB'},
  selectorText:{fontSize:14,color:'#1F2937'},
  row:{flexDirection:'row',gap:10},half:{flex:1},
  imagePicker:{height:120,backgroundColor:'#F3F4F6',borderRadius:8,marginTop:6,justifyContent:'center',alignItems:'center',overflow:'hidden'},
  imagePreview:{width:'100%',height:'100%'},imagePlaceholder:{justifyContent:'center',alignItems:'center'},
  saveBtn:{backgroundColor:'#F59E0B',padding:16,borderRadius:8,marginTop:20,alignItems:'center'},
  disabled:{opacity:0.6},
  saveBtnText:{color:'#FFF',fontSize:16,fontWeight:'bold'},
});
