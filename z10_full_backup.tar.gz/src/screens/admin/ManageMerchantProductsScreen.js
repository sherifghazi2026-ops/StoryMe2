import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  Image,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  Switch,
} from 'react-native';
import { SafeAreaView as SafeAreaViewContext } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { uploadServiceImage } from '../../services/uploadService';
import * as ImagePicker from 'expo-image-picker';

export default function ManageMerchantProductsScreen({ navigation, route }) {
  const { merchantId, merchantName } = route.params;

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [uploading, setUploading] = useState(false);

  const [productName, setProductName] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productImage, setProductImage] = useState(null);
  const [isAvailable, setIsAvailable] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from(TABLES.PRODUCTS)
        .select('*')
        .eq('merchant_id', merchantId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('❌ خطأ في تحميل المنتجات:', error);
      Alert.alert('خطأ', 'فشل تحميل المنتجات');
    } finally {
      setLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.7,
        allowsEditing: true,
      });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        setUploading(true);
        const uploadResult = await uploadServiceImage(result.assets[0].uri);
        setUploading(false);
        if (uploadResult.success) {
          setProductImage(uploadResult.fileUrl);
        } else {
          Alert.alert('خطأ', 'فشل رفع الصورة');
        }
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل اختيار الصورة');
    }
  };

  const resetForm = () => {
    setEditingProduct(null);
    setProductName('');
    setProductPrice('');
    setProductDescription('');
    setProductImage(null);
    setIsAvailable(true);
  };

  const openEditModal = (product) => {
    setEditingProduct(product);
    setProductName(product.name || '');
    setProductPrice(product.price?.toString() || '');
    setProductDescription(product.description || '');
    setProductImage(product.image_url || null);
    setIsAvailable(product.is_available !== false);
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!productName.trim()) {
      Alert.alert('تنبيه', 'اسم المنتج مطلوب');
      return;
    }
    if (!productPrice || isNaN(parseFloat(productPrice))) {
      Alert.alert('تنبيه', 'السعر مطلوب');
      return;
    }

    setUploading(true);
    try {
      const productData = {
        name: productName.trim(),
        price: parseFloat(productPrice),
        description: productDescription.trim(),
        image_url: productImage,
        is_available: isAvailable,
        updated_at: new Date().toISOString(),
      };

      if (editingProduct) {
        const { error } = await supabase
          .from(TABLES.PRODUCTS)
          .update(productData)
          .eq('id', editingProduct.id);

        if (error) throw error;
        Alert.alert('✅ تم', 'تم تحديث المنتج');
      } else {
        const newProduct = {
          ...productData,
          merchant_id: merchantId,
          merchant_name: merchantName,
          status: 'pending',
          created_at: new Date().toISOString(),
        };
        const { error } = await supabase
          .from(TABLES.PRODUCTS)
          .insert([newProduct]);

        if (error) throw error;
        Alert.alert('✅ تم', 'تم إضافة المنتج');
      }

      setModalVisible(false);
      resetForm();
      loadProducts();
    } catch (error) {
      console.error('❌ خطأ في حفظ المنتج:', error);
      Alert.alert('خطأ', error.message || 'فشل في حفظ المنتج');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = (product) => {
    Alert.alert(
      'حذف المنتج',
      `هل أنت متأكد من حذف "${product.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from(TABLES.PRODUCTS)
                .delete()
                .eq('id', product.id);

              if (error) throw error;
              loadProducts();
              Alert.alert('✅ تم', 'تم حذف المنتج');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في حذف المنتج');
            }
          }
        }
      ]
    );
  };

  const toggleAvailable = async (product) => {
    try {
      const { error } = await supabase
        .from(TABLES.PRODUCTS)
        .update({ is_available: !product.is_available, updated_at: new Date().toISOString() })
        .eq('id', product.id);

      if (error) throw error;
      loadProducts();
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تغيير حالة المنتج');
    }
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'approved': return { text: 'مقبول', color: '#10B981', bg: '#D1FAE5' };
      case 'pending': return { text: 'قيد المراجعة', color: '#F59E0B', bg: '#FEF3C7' };
      case 'rejected': return { text: 'مرفوض', color: '#EF4444', bg: '#FEE2E2' };
      default: return { text: status, color: '#6B7280', bg: '#F3F4F6' };
    }
  };

  const renderProduct = ({ item }) => {
    const badge = getStatusBadge(item.status);
    return (
      <View style={[styles.productCard, !item.is_available && styles.productCardDisabled]}>
        <TouchableOpacity style={styles.productContent} onPress={() => openEditModal(item)}>
          {item.image_url ? (
            <Image source={{ uri: item.image_url }} style={styles.productImage} />
          ) : (
            <View style={[styles.productImage, styles.placeholderImage]}>
              <Ionicons name="image-outline" size={24} color="#9CA3AF" />
            </View>
          )}
          <View style={styles.productInfo}>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>{item.price} ج</Text>
            {item.description && <Text style={styles.productDesc} numberOfLines={2}>{item.description}</Text>}
            <View style={[styles.statusBadge, { backgroundColor: badge.bg }]}>
              <Text style={[styles.statusText, { color: badge.color }]}>{badge.text}</Text>
            </View>
          </View>
        </TouchableOpacity>

        <View style={styles.actionButtons}>
          <TouchableOpacity style={[styles.actionButton, styles.editButton]} onPress={() => openEditModal(item)}>
            <Ionicons name="create-outline" size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.disableButton]} onPress={() => toggleAvailable(item)}>
            <Ionicons name={item.is_available ? 'close-outline' : 'checkmark-outline'} size={18} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={() => handleDelete(item)}>
            <Ionicons name="trash-outline" size={18} color="#FFF" />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaViewContext style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>منتجات {merchantName}</Text>
        <TouchableOpacity onPress={() => { resetForm(); setModalVisible(true); }}>
          <Ionicons name="add-circle" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="cube-outline" size={80} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد منتجات</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => { resetForm(); setModalVisible(true); }}>
              <Text style={styles.addButtonText}>إضافة منتج</Text>
            </TouchableOpacity>
          </View>
        }
      />

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <ScrollView contentContainerStyle={styles.modalScrollContent}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>
                  {editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}
                </Text>
                <TouchableOpacity onPress={() => { setModalVisible(false); resetForm(); }}>
                  <Ionicons name="close" size={24} color="#EF4444" />
                </TouchableOpacity>
              </View>

              <Text style={styles.label}>اسم المنتج *</Text>
              <TextInput style={styles.input} placeholder="مثال: فينو" value={productName} onChangeText={setProductName} />

              <Text style={styles.label}>السعر (ج) *</Text>
              <TextInput style={styles.input} placeholder="مثال: 6" value={productPrice} onChangeText={setProductPrice} keyboardType="numeric" />

              <Text style={styles.label}>الوصف (اختياري)</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="وصف المنتج..." value={productDescription} onChangeText={setProductDescription} multiline numberOfLines={3} />

              <Text style={styles.label}>صورة المنتج (اختياري)</Text>
              <TouchableOpacity style={styles.imagePicker} onPress={pickImage} disabled={uploading}>
                {productImage ? (
                  <Image source={{ uri: productImage }} style={styles.previewImage} />
                ) : (
                  <View style={styles.imagePlaceholder}>
                    {uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : <><Ionicons name="camera-outline" size={40} color="#9CA3AF" /><Text style={styles.imagePlaceholderText}>اختر صورة</Text></>}
                  </View>
                )}
              </TouchableOpacity>

              <View style={styles.switchContainer}>
                <Text style={styles.label}>متاح للبيع</Text>
                <Switch value={isAvailable} onValueChange={setIsAvailable} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} />
              </View>

              <TouchableOpacity style={[styles.saveButton, uploading && styles.disabled]} onPress={handleSave} disabled={uploading}>
                {uploading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>{editingProduct ? 'حفظ التغييرات' : 'إضافة المنتج'}</Text>}
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaViewContext>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#6B7280', marginBottom: 20 },
  addButton: { backgroundColor: '#4F46E5', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 8 },
  addButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  productCard: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  productCardDisabled: { opacity: 0.6, backgroundColor: '#F9FAFB' },
  productContent: { flexDirection: 'row', flex: 1, alignItems: 'center' },
  productImage: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  placeholderImage: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  productInfo: { flex: 1 },
  productName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  productPrice: { fontSize: 14, fontWeight: 'bold', color: '#F59E0B' },
  productDesc: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  statusBadge: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, marginTop: 4 },
  statusText: { fontSize: 10, fontWeight: '600' },
  actionButtons: { flexDirection: 'row', gap: 8 },
  actionButton: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  editButton: { backgroundColor: '#F59E0B' },
  disableButton: { backgroundColor: '#EF4444' },
  deleteButton: { backgroundColor: '#6B7280' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalScrollContent: { paddingBottom: 20, paddingTop: 60 },
  modalContent: { backgroundColor: '#FFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  textArea: { minHeight: 80, textAlignVertical: 'top' },
  imagePicker: { width: '100%', height: 150, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginBottom: 15, overflow: 'hidden' },
  previewImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F9FAFB' },
  imagePlaceholderText: { marginTop: 8, fontSize: 14, color: '#9CA3AF' },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  disabled: { opacity: 0.6 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
