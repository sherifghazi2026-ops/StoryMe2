import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, RefreshControl, Image, Modal, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAllServices, toggleServiceStatus, toggleServiceVisibility, deleteService } from '../../services/servicesService';

const SUPER_ADMIN_PASSWORD = 'Admin135792';

export default function ServicesManagementScreen({ navigation }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [showOptionsModal, setShowOptionsModal] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [serviceToDelete, setServiceToDelete] = useState(null);

  useEffect(() => { loadServices(); checkAdminLevel(); }, []);

  const checkAdminLevel = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setIsSuperAdmin(user.admin_level === 'super' || user.role === 'admin');
    }
  };

  const loadServices = async () => {
    const result = await getAllServices();
    if (result.success) setServices(result.data);
    setLoading(false);
    setRefreshing(false);
  };

  const handleToggleActive = async (service) => {
    const newStatus = !service.is_active;
    const result = await toggleServiceStatus(service.$id, newStatus);
    if (result.success) {
      setServices(services.map(s => s.$id === service.$id ? { ...s, is_active: newStatus } : s));
      Alert.alert('✅ تم', newStatus ? 'تم تفعيل الخدمة' : 'تم تعطيل الخدمة');
    }
  };

  const handleToggleVisible = async (service) => {
    const newVisibility = !service.is_visible;
    const result = await toggleServiceVisibility(service.$id, newVisibility);
    if (result.success) {
      setServices(services.map(s => s.$id === service.$id ? { ...s, is_visible: newVisibility } : s));
      Alert.alert('✅ تم', newVisibility ? 'تم إظهار الخدمة في الرئيسية' : 'تم إخفاء الخدمة من الرئيسية');
    }
  };

  const confirmDelete = (service) => {
    setServiceToDelete(service);
    setDeletePassword('');
    setShowDeleteConfirm(true);
    setShowOptionsModal(false);
  };

  const executeDelete = async () => {
    if (deletePassword !== SUPER_ADMIN_PASSWORD) {
      Alert.alert('❌ خطأ', 'كلمة المرور غير صحيحة');
      return;
    }
    setShowDeleteConfirm(false);
    const result = await deleteService(serviceToDelete.$id);
    if (result.success) {
      Alert.alert('✅ تم', 'تم حذف الخدمة');
      loadServices();
    } else {
      Alert.alert('خطأ', result.error);
    }
  };

  const openOptionsModal = (service) => {
    setSelectedService(service);
    setShowOptionsModal(true);
  };

  const getTypeLabel = (type) => {
    if (type === 'full_service') return 'شاملة';
    if (type === 'items_service') return 'بأصناف';
    if (type === 'items') return 'بمنتجات';
    return 'عادية';
  };

  const getTypeColor = (type) => {
    if (type === 'full_service') return '#8B5CF6';
    if (type === 'items_service') return '#F59E0B';
    if (type === 'items') return '#10B981';
    return '#6B7280';
  };

  const openItemsScreen = (service) => {
    navigation.navigate('ItemsServiceScreen', {
      service_id: service.id,
      collectionName: service.items_collection,
      serviceName: service.name,
      serviceColor: service.color,
      sub_services: service.sub_services || [],
      isAdmin: true
    });
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة الخدمات</Text>
        <TouchableOpacity onPress={() => navigation.navigate('AddService')}><Ionicons name="add-circle" size={24} color={isSuperAdmin ? "#4F46E5" : "#9CA3AF"} /></TouchableOpacity>
      </View>

      <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadServices} />} contentContainerStyle={styles.content}>
        {services.map((service) => {
          const typeColor = getTypeColor(service.type);
          const typeLabel = getTypeLabel(service.type);

          return (
            <View key={service.$id} style={styles.serviceCard}>
              <View style={styles.serviceInfo}>
                {service.image_url ? (
                  <Image source={{ uri: service.image_url }} style={styles.serviceImage} />
                ) : (
                  <View style={[styles.iconContainer, { backgroundColor: typeColor + '20' }]}>
                    <Ionicons name={service.icon || 'apps-outline'} size={24} color={typeColor} />
                  </View>
                )}
                <View style={styles.serviceDetails}>
                  <View style={styles.serviceNameRow}>
                    <Text style={styles.service_name}>{service.name}</Text>
                    <View style={[styles.typeBadge, { backgroundColor: typeColor + '20' }]}>
                      <Text style={[styles.typeBadgeText, { color: typeColor }]}>{typeLabel}</Text>
                    </View>
                  </View>
                  <Text style={styles.service_id}>ID: {service.id}</Text>
                  {service.tracking_icon_url && (
                    <Image source={{ uri: service.tracking_icon_url }} style={styles.trackingIconPreview} />
                  )}
                  <View style={styles.badgesContainer}>
                    <View style={[styles.statusBadge, { backgroundColor: service.is_active ? '#10B98120' : '#EF444420' }]}>
                      <Text style={[styles.statusText, { color: service.is_active ? '#10B981' : '#EF4444' }]}>{service.is_active ? 'نشط' : 'معطل'}</Text>
                    </View>
                    <View style={[styles.statusBadge, { backgroundColor: service.is_visible ? '#10B98120' : '#EF444420' }]}>
                      <Text style={[styles.statusText, { color: service.is_visible ? '#10B981' : '#EF4444' }]}>{service.is_visible ? 'ظاهر' : 'مخفي'}</Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={styles.serviceActions}>
                <TouchableOpacity style={styles.moreButton} onPress={() => openOptionsModal(service)}>
                  <Ionicons name="ellipsis-vertical" size={20} color="#6B7280" />
                </TouchableOpacity>
                {service.type === 'items_service' && (
                  <TouchableOpacity style={styles.itemsButton} onPress={() => openItemsScreen(service)}>
                    <Ionicons name="list-outline" size={16} color="#FFF" />
                    <Text style={styles.itemsButtonText}>إدارة الأصناف</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        })}
      </ScrollView>

      {/* Modal النقاط الثلاث */}
      <Modal visible={showOptionsModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedService?.name}</Text>
              <TouchableOpacity onPress={() => setShowOptionsModal(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.modalOption} onPress={() => {
              setShowOptionsModal(false);
              navigation.navigate('AddService', { editService: selectedService });
            }}>
              <Ionicons name="create-outline" size={22} color="#4F46E5" />
              <View style={styles.modalOptionTextContainer}>
                <Text style={styles.modalOptionText}>تعديل الخدمة</Text>
                <Text style={styles.modalOptionDesc}>تغيير بيانات الخدمة</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.modalOption} onPress={() => {
              setShowOptionsModal(false);
              handleToggleActive(selectedService);
            }}>
              <Ionicons name={selectedService?.is_active ? 'close-circle-outline' : 'checkmark-circle-outline'} size={22} color={selectedService?.is_active ? '#EF4444' : '#10B981'} />
              <View style={styles.modalOptionTextContainer}>
                <Text style={[styles.modalOptionText, { color: selectedService?.is_active ? '#EF4444' : '#10B981' }]}>
                  {selectedService?.is_active ? 'تعطيل الخدمة' : 'تفعيل الخدمة'}
                </Text>
                <Text style={styles.modalOptionDesc}>
                  {selectedService?.is_active ? 'لن تظهر الخدمة للعملاء' : 'ستظهر الخدمة للعملاء'}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.modalOption} onPress={() => {
              setShowOptionsModal(false);
              handleToggleVisible(selectedService);
            }}>
              <Ionicons name={selectedService?.is_visible ? 'eye-off-outline' : 'eye-outline'} size={22} color={selectedService?.is_visible ? '#6B7280' : '#10B981'} />
              <View style={styles.modalOptionTextContainer}>
                <Text style={[styles.modalOptionText, { color: selectedService?.is_visible ? '#6B7280' : '#10B981' }]}>
                  {selectedService?.is_visible ? 'إخفاء من الرئيسية' : 'إظهار في الرئيسية'}
                </Text>
                <Text style={styles.modalOptionDesc}>
                  {selectedService?.is_visible ? 'لن تظهر الخدمة في الشاشة الرئيسية' : 'ستظهر الخدمة في الشاشة الرئيسية'}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={[styles.modalOption, styles.deleteOption]} onPress={() => confirmDelete(selectedService)}>
              <Ionicons name="trash-outline" size={22} color="#EF4444" />
              <View style={styles.modalOptionTextContainer}>
                <Text style={[styles.modalOptionText, { color: '#EF4444' }]}>حذف الخدمة</Text>
                <Text style={styles.modalOptionDesc}>لا يمكن التراجع عن هذا الإجراء</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.cancelOption} onPress={() => setShowOptionsModal(false)}>
              <Text style={styles.cancelOptionText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal تأكيد الحذف */}
      <Modal visible={showDeleteConfirm} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>⚠️ تأكيد الحذف</Text>
            <Text style={styles.deleteWarningText}>أنت على وشك حذف "{serviceToDelete?.name}"{'\n'}هذا الإجراء لا يمكن التراجع عنه!</Text>
            <TextInput
              style={styles.passwordInput}
              placeholder="أدخل كلمة مرور الأدمن الأساسي"
              value={deletePassword}
              onChangeText={setDeletePassword}
              secureTextEntry
              autoFocus
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelDeleteBtn} onPress={() => setShowDeleteConfirm(false)}>
                <Text style={styles.cancelDeleteText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmDeleteBtn} onPress={executeDelete}>
                <Text style={styles.confirmDeleteText}>حذف</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  serviceCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  serviceInfo: { flexDirection: 'row', alignItems: 'center' },
  serviceImage: { width: 48, height: 48, borderRadius: 24, marginRight: 12 },
  iconContainer: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  serviceDetails: { flex: 1 },
  serviceNameRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 2, flexWrap: 'wrap' },
  service_name: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  typeBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10 },
  typeBadgeText: { fontSize: 9, fontWeight: '600' },
  service_id: { fontSize: 12, color: '#9CA3AF' },
  trackingIconPreview: { width: 28, height: 28, borderRadius: 6, marginTop: 4 },
  badgesContainer: { flexDirection: 'row', gap: 4, marginTop: 4 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12 },
  statusText: { fontSize: 10, fontWeight: '600' },
  serviceActions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  moreButton: { padding: 8 },
  itemsButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, gap: 4 },
  itemsButtonText: { color: '#FFF', fontSize: 11, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, width: '90%', maxWidth: 400 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  modalOption: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: '#F9FAFB', marginBottom: 8, gap: 14 },
  modalOptionTextContainer: { flex: 1 },
  modalOptionText: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 2 },
  modalOptionDesc: { fontSize: 12, color: '#6B7280' },
  deleteOption: { backgroundColor: '#FEE2E2' },
  cancelOption: { backgroundColor: '#F3F4F6', alignItems: 'center', padding: 12, borderRadius: 12, marginTop: 8 },
  cancelOptionText: { fontSize: 16, color: '#1F2937', fontWeight: '500' },
  deleteWarningText: { color: '#EF4444', marginBottom: 16, textAlign: 'center', fontSize: 14 },
  passwordInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 14 },
  modalButtons: { flexDirection: 'row', gap: 10 },
  cancelDeleteBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#E5E7EB', alignItems: 'center' },
  cancelDeleteText: { color: '#1F2937', fontWeight: '600' },
  confirmDeleteBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#EF4444', alignItems: 'center' },
  confirmDeleteText: { color: '#FFF', fontWeight: '600' },
});
