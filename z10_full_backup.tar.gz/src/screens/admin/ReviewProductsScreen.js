import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  
  Image,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getPendingProducts, approveProduct, rejectProduct } from '../../services/productService';

export default function ReviewProductsScreen({ navigation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  useEffect(() => { loadPending(); }, []);

  const loadPending = async () => {
    setLoading(true);
    const result = await getPendingProducts();
    if (result.success) {
      console.log('✅ المنتجات المعلقة:', result.data);
      setProducts(result.data);
    } else {
      console.error('❌ فشل جلب المنتجات:', result.error);
    }
    setLoading(false);
    setRefreshing(false);
  };

  const handleApprove = async (product) => {
    Alert.alert(
      'موافقة',
      `الموافقة على المنتج "${product.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'موافقة',
          onPress: async () => {
            console.log('📦 محاولة الموافقة على المنتج:', product.id);
            const res = await approveProduct(product.id);
            if (res.success) {
              Alert.alert('✅ تم', 'تمت الموافقة على المنتج');
              loadPending();
            } else {
              Alert.alert('خطأ', res.error);
              console.error('❌ فشل الموافقة:', res.error);
            }
          }
        }
      ]
    );
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      Alert.alert('تنبيه', 'أدخل سبب الرفض');
      return;
    }
    Alert.alert(
      'رفض',
      `رفض "${selectedProduct?.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'رفض',
          style: 'destructive',
          onPress: async () => {
            const res = await rejectProduct(selectedProduct.id, rejectReason);
            if (res.success) {
              setRejectModal(false);
              setRejectReason('');
              loadPending();
            } else {
              Alert.alert('خطأ', res.error);
            }
          }
        }
      ]
    );
  };

  const renderProduct = ({ item }) => (
    <View style={styles.productCard}>
      <View style={styles.productHeader}>
        {item.image_url ? (
          <Image source={{ uri: item.image_url }} style={styles.productImage} />
        ) : (
          <View style={[styles.productImage, styles.placeholder]}>
            <Ionicons name="image-outline" size={30} color="#9CA3AF" />
          </View>
        )}
        <View style={styles.productInfo}>
          <Text style={styles.productName}>{item.name}</Text>
          <Text style={styles.productPrice}>{item.price} ج</Text>
          <Text style={styles.productMerchant}>تاجر: {item.merchant_name}</Text>
          <View style={[styles.statusBadge, { backgroundColor: '#F59E0B20' }]}>
            <Text style={[styles.statusText, { color: '#F59E0B' }]}>قيد المراجعة</Text>
          </View>
        </View>
      </View>

      {item.description ? (
        <Text style={styles.description} numberOfLines={2}>{item.description}</Text>
      ) : null}

      <View style={styles.actionsContainer}>
        <TouchableOpacity
          style={[styles.actionButton, styles.approveButton]}
          onPress={() => handleApprove(item)}
        >
          <Ionicons name="checkmark-circle" size={20} color="#FFF" />
          <Text style={styles.actionText}>موافقة</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.rejectButton]}
          onPress={() => { setSelectedProduct(item); setRejectModal(true); }}
        >
          <Ionicons name="close-circle" size={20} color="#FFF" />
          <Text style={styles.actionText}>رفض</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>مراجعة المنتجات</Text>
        <TouchableOpacity onPress={loadPending}>
          <Ionicons name="refresh" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadPending} />}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="checkmark-done-circle" size={80} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد منتجات معلقة</Text>
          </View>
        }
      />

      <Modal visible={rejectModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>سبب الرفض</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="اكتب السبب..."
              value={rejectReason}
              onChangeText={setRejectReason}
              multiline
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => { setRejectModal(false); setRejectReason(''); }}
              >
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleReject}
              >
                <Text style={styles.confirmButtonText}>تأكيد الرفض</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  productCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  productHeader: { flexDirection: 'row', marginBottom: 12 },
  productImage: { width: 70, height: 70, borderRadius: 8, marginRight: 12 },
  placeholder: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  productInfo: { flex: 1 },
  productName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  productPrice: { fontSize: 14, fontWeight: 'bold', color: '#F59E0B', marginTop: 2 },
  productMerchant: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  statusBadge: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, marginTop: 4 },
  statusText: { fontSize: 10, fontWeight: '600' },
  description: { fontSize: 13, color: '#4B5563', marginBottom: 12 },
  actionsContainer: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8 },
  actionButton: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 4 },
  approveButton: { backgroundColor: '#10B981' },
  rejectButton: { backgroundColor: '#EF4444' },
  actionText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  emptyContainer: { alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#6B7280' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#FFF', borderRadius: 12, padding: 20, width: '80%', maxWidth: 400 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  modalInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, minHeight: 80, textAlignVertical: 'top' },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-between', gap: 8, marginTop: 16 },
  modalButton: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#F3F4F6' },
  confirmButton: { backgroundColor: '#EF4444' },
  cancelButtonText: { color: '#1F2937', fontSize: 14, fontWeight: '600' },
  confirmButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
});
