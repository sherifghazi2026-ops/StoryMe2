import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  Alert, ActivityIndicator, ScrollView, Switch, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { updateService, getServiceById } from '../../services/servicesService';
import { uploadServiceImage } from '../../services/uploadService';
import { supabase } from '../../lib/supabaseClient';

const COLORS = [
  '#F59E0B', '#3B82F6', '#10B981', '#EF4444', '#8B5CF6', '#EC4899', '#6B7280', '#4F46E5', '#14B8A6', '#F97316'
];

const SERVICE_TYPES = [
  { label: 'خدمة عادية (بدون منتجات)', value: 'regular' },
  { label: 'خدمة بأصناف (مثل مكوجي)', value: 'items_service' },
  { label: 'خدمة بمنتجات (مطاعم - سوبر ماركت)', value: 'items' },
  { label: 'خدمة AI (ذكاء اصطناعي)', value: 'ai' },
];

export default function EditServiceScreen({ route, navigation }) {
  const { serviceId } = route.params;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [service, setService] = useState(null);

  const [name, setName] = useState('');
  const [type, setType] = useState('regular');
  const [color, setColor] = useState('#6B7280');
  const [category, setCategory] = useState('other');
  const [categories, setCategories] = useState([]);
  const [order, setOrder] = useState('0');
  const [image, setImage] = useState(null);
  const [trackingImage, setTrackingImage] = useState(null);
  const [hasPickup, setHasPickup] = useState(false);
  const [subServices, setSubServices] = useState([]);
  const [currentSubService, setCurrentSubService] = useState('');
  const [editingSubIndex, setEditingSubIndex] = useState(null);
  const [merchantType, setMerchantType] = useState('merchant');

  useEffect(() => {
    loadService();
    loadCategories();
  }, []);

  const loadService = async () => {
    const result = await getServiceById(serviceId);
    if (result.success) {
      const svc = result.data;
      setService(svc);
      setName(svc.name || '');
      setType(svc.type || 'regular');
      setColor(svc.color || '#6B7280');
      setCategory(svc.category || 'other');
      setOrder(String(svc.order || '0'));
      setImage(svc.image_url || null);
      setTrackingImage(svc.tracking_image || null);
      setHasPickup(svc.has_pickup || false);
      setSubServices(svc.sub_services || []);
      setMerchantType(svc.merchant_type || 'merchant');
    } else {
      Alert.alert('خطأ', 'فشل تحميل الخدمة');
      navigation.goBack();
    }
    setLoading(false);
  };

  const loadCategories = async () => {
    const { data } = await supabase.from('service_categories').select('*').eq('is_active', true).order('sort_order');
    if (data) setCategories(data);
  };

  const pickImage = async (type = 'service') => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') { Alert.alert('خطأ', 'يجب السماح بالوصول للمعرض'); return; }
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, allowsEditing: true });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        setUploading(true);
        const uploadResult = await uploadServiceImage(result.assets[0].uri);
        setUploading(false);
        if (uploadResult.success) {
          if (type === 'tracking') setTrackingImage(uploadResult.fileUrl);
          else setImage(uploadResult.fileUrl);
        } else Alert.alert('خطأ', 'فشل رفع الصورة');
      }
    } catch (error) { Alert.alert('خطأ', 'فشل في اختيار الصورة'); }
  };

  const addSubService = () => {
    if (!currentSubService.trim()) { Alert.alert('تنبيه', 'الرجاء إدخال اسم الخدمة الفرعية'); return; }
    if (editingSubIndex !== null) {
      const updated = [...subServices];
      updated[editingSubIndex] = currentSubService.trim();
      setSubServices(updated);
      setEditingSubIndex(null);
    } else {
      setSubServices([...subServices, currentSubService.trim()]);
    }
    setCurrentSubService('');
  };

  const editSubService = (index) => {
    setCurrentSubService(subServices[index]);
    setEditingSubIndex(index);
  };

  const removeSubService = (index) => {
    Alert.alert('حذف الخدمة الفرعية', `هل أنت متأكد من حذف "${subServices[index]}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => {
          const filtered = subServices.filter((_, i) => i !== index);
          setSubServices(filtered);
          if (editingSubIndex === index) { setCurrentSubService(''); setEditingSubIndex(null); }
        }
      }
    ]);
  };

  const handleSave = async () => {
    if (!name.trim()) { Alert.alert('تنبيه', 'اسم الخدمة مطلوب'); return; }
    if (type === 'items_service' && subServices.length === 0) { Alert.alert('تنبيه', 'يجب إضافة خدمة فرعية واحدة على الأقل'); return; }
    setSaving(true);
    try {
      const updateData = {
        name: name.trim(), type: type, color: color, category: category,
        order: parseInt(order) || 0, image_url: image,
        tracking_image: trackingImage, has_pickup: hasPickup,
        merchant_type: merchantType,
        sub_services: type === 'items_service' ? subServices : [],
      };
      const result = await updateService(serviceId, updateData);
      if (result.success) { Alert.alert('✅ تم', 'تم تحديث الخدمة بنجاح'); navigation.goBack(); }
      else Alert.alert('خطأ', result.error);
    } catch (error) { Alert.alert('خطأ', error.message); }
    finally { setSaving(false); }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>تعديل الخدمة</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.form}>
          <Text style={styles.label}>معرف الخدمة</Text>
          <Text style={styles.readonlyText}>{service?.id}</Text>

          <Text style={styles.label}>اسم الخدمة *</Text>
          <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="اسم الخدمة" />

          <Text style={styles.label}>نوع الخدمة</Text>
          <View style={styles.typeContainer}>
            {SERVICE_TYPES.map((t) => (
              <TouchableOpacity key={t.value} style={[styles.typeButton, type === t.value && styles.typeButtonActive]} onPress={() => setType(t.value)}>
                <Text style={[styles.typeButtonText, type === t.value && styles.typeButtonTextActive]}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {type === 'items_service' && (
            <View style={styles.subServicesSection}>
              <Text style={styles.label}>الخدمات الفرعية</Text>
              {subServices.length > 0 && (
                <View style={styles.subServicesList}>
                  {subServices.map((sub, index) => (
                    <View key={index} style={styles.subServiceItem}>
                      <Text style={styles.subServiceName}>{sub}</Text>
                      <View style={styles.subServiceActions}>
                        <TouchableOpacity onPress={() => editSubService(index)}><Ionicons name="create-outline" size={18} color="#4F46E5" /></TouchableOpacity>
                        <TouchableOpacity onPress={() => removeSubService(index)}><Ionicons name="close-circle" size={18} color="#EF4444" /></TouchableOpacity>
                      </View>
                    </View>
                  ))}
                </View>
              )}
              <View style={styles.addSubServiceRow}>
                <TextInput style={[styles.input, { flex: 1, marginBottom: 0 }]} placeholder="أضف خدمة فرعية" value={currentSubService} onChangeText={setCurrentSubService} />
                <TouchableOpacity style={styles.addSubServiceButton} onPress={addSubService}><Ionicons name={editingSubIndex !== null ? 'checkmark' : 'add'} size={24} color="#FFF" /></TouchableOpacity>
              </View>
            </View>
          )}

          {/* ✅ Categories ديناميكية */}
          <Text style={styles.label}>الفئة</Text>
          <View style={styles.categoryRow}>
            {categories.map(cat => (
              <TouchableOpacity key={cat.id} style={[styles.categoryBtn, category === cat.id && styles.categoryBtnActive]} onPress={() => setCategory(cat.id)}>
                <Text style={[styles.categoryText, category === cat.id && styles.categoryTextActive]}>{cat.name}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>صورة الخدمة</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('service')} disabled={uploading}>
            {image ? <Image source={{ uri: image }} style={styles.previewImage} /> : <View style={styles.imagePlaceholder}>{uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : <><Ionicons name="camera-outline" size={40} color="#9CA3AF" /><Text style={styles.imagePlaceholderText}>اختر صورة</Text></>}</View>}
          </TouchableOpacity>

          <Text style={styles.label}>صورة تتبع الطلب</Text>
          <TouchableOpacity style={styles.imagePicker} onPress={() => pickImage('tracking')} disabled={uploading}>
            {trackingImage ? <Image source={{ uri: trackingImage }} style={styles.previewImage} /> : <View style={styles.imagePlaceholder}>{uploading ? <ActivityIndicator size="large" color="#4F46E5" /> : <><Ionicons name="image-outline" size={40} color="#9CA3AF" /><Text style={styles.imagePlaceholderText}>اختر صورة التتبع</Text></>}</View>}
          </TouchableOpacity>

          <Text style={styles.label}>اللون</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.colorsScroll}>
            {COLORS.map((c) => (<TouchableOpacity key={c} style={[styles.colorOption, { backgroundColor: c }, color === c && styles.colorOptionActive]} onPress={() => setColor(c)} />))}
          </ScrollView>

          <View style={styles.row}>
            <View style={styles.halfWidth}><Text style={styles.label}>الترتيب</Text><TextInput style={styles.input} placeholder="0" value={order} onChangeText={setOrder} keyboardType="numeric" /></View>
          </View>

          <View style={styles.switchContainer}>
            <Text style={styles.label}>له Pickup (استلام)</Text>
            <Switch value={hasPickup} onValueChange={setHasPickup} trackColor={{ false: '#E5E7EB', true: '#4F46E5' }} />
          </View>

          <TouchableOpacity style={[styles.saveButton, (saving || uploading) && styles.disabled]} onPress={handleSave} disabled={saving || uploading}>
            {saving || uploading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>حفظ التغييرات</Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  form: { backgroundColor: '#FFF', borderRadius: 12, padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 5, marginTop: 10 },
  readonlyText: { backgroundColor: '#F3F4F6', padding: 12, borderRadius: 8, marginBottom: 15, fontSize: 14, color: '#1F2937' },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 14 },
  typeContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  typeButton: { flex: 1, paddingVertical: 10, paddingHorizontal: 8, borderRadius: 8, backgroundColor: '#F3F4F6', alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  typeButtonActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  typeButtonText: { fontSize: 12, color: '#4B5563' },
  typeButtonTextActive: { color: '#FFF', fontWeight: '600' },
  subServicesSection: { marginBottom: 15 },
  subServicesList: { marginBottom: 10 },
  subServiceItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F9FAFB', padding: 10, borderRadius: 8, marginBottom: 6 },
  subServiceName: { fontSize: 14, color: '#1F2937' },
  subServiceActions: { flexDirection: 'row', gap: 8 },
  addSubServiceRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  addSubServiceButton: { backgroundColor: '#4F46E5', width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  categoryRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  categoryBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  categoryBtnActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  categoryText: { fontSize: 12, color: '#4B5563' },
  categoryTextActive: { color: '#FFF', fontWeight: '600' },
  imagePicker: { width: '100%', height: 150, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', marginBottom: 15, overflow: 'hidden' },
  previewImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F9FAFB' },
  imagePlaceholderText: { marginTop: 8, fontSize: 14, color: '#9CA3AF' },
  colorsScroll: { flexDirection: 'row', marginBottom: 15 },
  colorOption: { width: 40, height: 40, borderRadius: 20, marginRight: 8, borderWidth: 2, borderColor: 'transparent' },
  colorOptionActive: { borderColor: '#1F2937' },
  row: { flexDirection: 'row', gap: 10 },
  halfWidth: { flex: 1 },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10, paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  disabled: { opacity: 0.6 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});
