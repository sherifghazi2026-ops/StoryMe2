import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Image, ActivityIndicator, Alert, ScrollView, Modal, RefreshControl, TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import { TABLES } from '../../lib/tables';
import { fontFamily } from '../../utils/fonts';
import { sendPushNotification } from '../../services/pushNotificationService';

export default function ManageMerchantContentScreen({ navigation }) {
  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedMerchant, setSelectedMerchant] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejecting, setRejecting] = useState(false);
  const [activeTab, setActiveTab] = useState('pending');
  const [rejectTarget, setRejectTarget] = useState(null);

  useEffect(() => { loadMerchants(); }, [activeTab]);

  const loadMerchants = async () => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from(TABLES.PROFILES)
        .select('*')
        .eq('role', 'merchant')
        .order('created_at', { ascending: false });

      const filtered = (data || []).filter(m => {
        if (activeTab === 'pending') {
          return (
            (m.image_url && m.image_approved === null) ||
            (m.bio && m.bio_approved === null) ||
            (m.portfolio_images || []).some(p => p.approved === null) ||
            (m.documents || []).some(d => d.approved === null)
          );
        } else {
          return (
            (m.image_url && m.image_approved === true) ||
            (m.bio && m.bio_approved === true) ||
            (m.portfolio_images || []).some(p => p.approved === true) ||
            (m.documents || []).some(d => d.approved === true)
          );
        }
      });

      setMerchants(filtered);
    } catch (error) { Alert.alert('خطأ', 'فشل جلب بيانات التجار'); }
    finally { setLoading(false); setRefreshing(false); }
  };

  const refreshMerchant = async (merchantId) => {
    const { data } = await supabase.from(TABLES.PROFILES).select('*').eq('id', merchantId).single();
    if (data) setSelectedMerchant(data);
  };

  const sendNotification = async (userId, title, body) => {
    try {
      const { data: tokenData } = await supabase.from('user_tokens').select('expo_push_token').eq('user_id', userId).maybeSingle();
      if (tokenData?.expo_push_token) await sendPushNotification(tokenData.expo_push_token, title, body);
    } catch (e) {}
  };

  // ✅ موافقة على عنصر واحد
  const approveItem = async (type, index) => {
    if (!selectedMerchant) return;
    const m = { ...selectedMerchant };
    let updates = {};

    if (type === 'image') {
      updates = { image_approved: true, image_url: m.image_url };
    } else if (type === 'bio') {
      updates = { bio_approved: true };
    } else if (type === 'document') {
      const docs = [...(m.documents || [])];
      if (docs[index]) docs[index].approved = true;
      updates = { documents: docs };
    } else if (type === 'portfolio') {
      const pics = [...(m.portfolio_images || [])];
      if (pics[index]) pics[index].approved = true;
      updates = { portfolio_images: pics };
    }

    await supabase.from(TABLES.PROFILES).update(updates).eq('id', m.id);
    await sendNotification(m.id, '✅ تمت الموافقة على محتوى', `تم قبول ${type === 'image' ? 'الصورة الشخصية' : type === 'bio' ? 'النبذة' : type === 'document' ? 'مستند' : 'صورة نشاط'} الخاص بك.`);
    refreshMerchant(m.id);
  };

  // ✅ رفض عنصر واحد
  const rejectItem = async () => {
    if (!rejectReason.trim()) { Alert.alert('تنبيه', 'يرجى كتابة سبب الرفض'); return; }
    if (!selectedMerchant || !rejectTarget) return;
    setRejecting(true);
    const m = { ...selectedMerchant };
    let updates = {};

    if (rejectTarget.type === 'image') {
      updates = { image_url: null, image_approved: false };
    } else if (rejectTarget.type === 'bio') {
      updates = { bio: null, bio_approved: false };
    } else if (rejectTarget.type === 'document') {
      const docs = [...(m.documents || [])];
      docs.splice(rejectTarget.index, 1);
      updates = { documents: docs };
    } else if (rejectTarget.type === 'portfolio') {
      const pics = [...(m.portfolio_images || [])];
      pics.splice(rejectTarget.index, 1);
      updates = { portfolio_images: pics };
    }

    await supabase.from(TABLES.PROFILES).update(updates).eq('id', m.id);
    await sendNotification(m.id, '❌ تم رفض محتوى', `سبب الرفض: ${rejectReason}`);
    Alert.alert('✅ تم', 'تم الرفض');
    setShowRejectModal(false);
    setRejectReason('');
    setRejectTarget(null);
    setRejecting(false);
    refreshMerchant(m.id);
  };

  const openModal = (merchant) => { setSelectedMerchant(merchant); setModalVisible(true); };

  const renderMerchant = ({ item }) => (
    <TouchableOpacity style={styles.card} onPress={() => openModal(item)}>
      <Text style={styles.merchantName}>{item.full_name || item.name}</Text>
      <View style={styles.badgeRow}>
        {item.image_url && item.image_approved === null && <View style={[styles.badge, { backgroundColor: '#FEF3C7' }]}><Text style={[styles.badgeText, { color: '#F59E0B' }]}>🖼️ صورة</Text></View>}
        {item.bio && item.bio_approved === null && <View style={[styles.badge, { backgroundColor: '#FEF3C7' }]}><Text style={[styles.badgeText, { color: '#F59E0B' }]}>📝 نبذة</Text></View>}
        {(item.documents || []).filter(d => d.approved === null).length > 0 && <View style={[styles.badge, { backgroundColor: '#FEF3C7' }]}><Text style={[styles.badgeText, { color: '#F59E0B' }]}>📄 مستندات</Text></View>}
        {(item.portfolio_images || []).filter(p => p.approved === null).length > 0 && <View style={[styles.badge, { backgroundColor: '#FEF3C7' }]}><Text style={[styles.badgeText, { color: '#F59E0B' }]}>🖼️ صور</Text></View>}
      </View>
    </TouchableOpacity>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>محتويات التجار</Text>
        <TouchableOpacity onPress={loadMerchants}><Ionicons name="refresh" size={24} color="#4F46E5" /></TouchableOpacity>
      </View>

      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab === 'pending' && styles.activeTab]} onPress={() => setActiveTab('pending')}>
          <Text style={[styles.tabText, activeTab === 'pending' && styles.activeTabText]}>📥 جديد</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'approved' && styles.activeTab]} onPress={() => setActiveTab('approved')}>
          <Text style={[styles.tabText, activeTab === 'approved' && styles.activeTabText]}>✅ تمت الموافقة</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={merchants} renderItem={renderMerchant} keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadMerchants} />}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="checkmark-done-circle" size={80} color="#E5E7EB" /><Text>{activeTab === 'pending' ? 'لا توجد محتويات جديدة' : 'لا توجد محتويات معتمدة'}</Text></View>}
      />

      {/* Modal التفاصيل */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedMerchant?.full_name}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}><Ionicons name="close" size={24} color="#EF4444" /></TouchableOpacity>
            </View>
            <ScrollView>
              {/* صورة البروفايل */}
              {selectedMerchant?.image_url && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>🖼️ صورة البروفايل</Text>
                  <Image source={{ uri: selectedMerchant.image_url }} style={styles.profileImg} />
                  {activeTab === 'pending' && selectedMerchant.image_approved === null && (
                    <View style={styles.actionRow}>
                      <TouchableOpacity style={[styles.btn, styles.approveBtn]} onPress={() => approveItem('image')}><Ionicons name="checkmark-circle" size={16} color="#FFF" /><Text style={styles.btnText}>موافقة</Text></TouchableOpacity>
                      <TouchableOpacity style={[styles.btn, styles.rejectBtn]} onPress={() => { setRejectTarget({ type: 'image' }); setRejectReason(''); setShowRejectModal(true); }}><Ionicons name="close-circle" size={16} color="#FFF" /><Text style={styles.btnText}>رفض</Text></TouchableOpacity>
                    </View>
                  )}
                  {selectedMerchant.image_approved === true && <Text style={styles.approvedText}>✅ معتمد</Text>}
                </View>
              )}

              {/* النبذة */}
              {selectedMerchant?.bio && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>📝 نبذة عن النشاط</Text>
                  <Text style={styles.bioText}>{selectedMerchant.bio}</Text>
                  {activeTab === 'pending' && selectedMerchant.bio_approved === null && (
                    <View style={styles.actionRow}>
                      <TouchableOpacity style={[styles.btn, styles.approveBtn]} onPress={() => approveItem('bio')}><Ionicons name="checkmark-circle" size={16} color="#FFF" /><Text style={styles.btnText}>موافقة</Text></TouchableOpacity>
                      <TouchableOpacity style={[styles.btn, styles.rejectBtn]} onPress={() => { setRejectTarget({ type: 'bio' }); setRejectReason(''); setShowRejectModal(true); }}><Ionicons name="close-circle" size={16} color="#FFF" /><Text style={styles.btnText}>رفض</Text></TouchableOpacity>
                    </View>
                  )}
                  {selectedMerchant.bio_approved === true && <Text style={styles.approvedText}>✅ معتمد</Text>}
                </View>
              )}

              {/* مستندات */}
              {(selectedMerchant?.documents || []).length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>📄 ملفات التوثيق</Text>
                  {(selectedMerchant.documents || []).map((doc, i) => (
                    <View key={i} style={styles.itemRow}>
                      <Image source={{ uri: doc.url }} style={styles.itemImg} />
                      {doc.approved === true && <Text style={styles.approvedText}>✅</Text>}
                      {activeTab === 'pending' && doc.approved === null && (
                        <View style={styles.actionRow}>
                          <TouchableOpacity style={[styles.btn, styles.approveBtn]} onPress={() => approveItem('document', i)}><Ionicons name="checkmark-circle" size={16} color="#FFF" /></TouchableOpacity>
                          <TouchableOpacity style={[styles.btn, styles.rejectBtn]} onPress={() => { setRejectTarget({ type: 'document', index: i }); setRejectReason(''); setShowRejectModal(true); }}><Ionicons name="close-circle" size={16} color="#FFF" /></TouchableOpacity>
                        </View>
                      )}
                    </View>
                  ))}
                </View>
              )}

              {/* صور النشاط */}
              {(selectedMerchant?.portfolio_images || []).length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>🖼️ صور النشاط</Text>
                  {(selectedMerchant.portfolio_images || []).map((img, i) => (
                    <View key={i} style={styles.itemRow}>
                      <Image source={{ uri: img.url }} style={styles.itemImg} />
                      {img.approved === true && <Text style={styles.approvedText}>✅</Text>}
                      {activeTab === 'pending' && img.approved === null && (
                        <View style={styles.actionRow}>
                          <TouchableOpacity style={[styles.btn, styles.approveBtn]} onPress={() => approveItem('portfolio', i)}><Ionicons name="checkmark-circle" size={16} color="#FFF" /></TouchableOpacity>
                          <TouchableOpacity style={[styles.btn, styles.rejectBtn]} onPress={() => { setRejectTarget({ type: 'portfolio', index: i }); setRejectReason(''); setShowRejectModal(true); }}><Ionicons name="close-circle" size={16} color="#FFF" /></TouchableOpacity>
                        </View>
                      )}
                    </View>
                  ))}
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Modal الرفض */}
      <Modal visible={showRejectModal} transparent animationType="fade">
        <View style={styles.rejectOverlay}><View style={styles.rejectContent}>
          <Text style={styles.rejectTitle}>سبب الرفض</Text>
          <TextInput style={styles.rejectInput} placeholder="اكتب سبب الرفض..." value={rejectReason} onChangeText={setRejectReason} multiline />
          <View style={styles.rejectActions}>
            <TouchableOpacity style={[styles.rejectBtn, { backgroundColor: '#E5E7EB' }]} onPress={() => setShowRejectModal(false)}><Text>إلغاء</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.rejectBtn, { backgroundColor: '#EF4444' }]} onPress={rejectItem} disabled={rejecting}>
              {rejecting ? <ActivityIndicator color="#FFF" size="small" /> : <Text style={{ color: '#FFF' }}>رفض</Text>}
            </TouchableOpacity>
          </View>
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  tabRow: { flexDirection: 'row', backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  activeTab: { borderBottomWidth: 2, borderBottomColor: '#4F46E5' },
  tabText: { fontSize: 14, color: '#6B7280' },
  activeTabText: { color: '#4F46E5', fontWeight: '600' },
  list: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  merchantName: { fontSize: 16, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  badgeRow: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontSize: 10, fontWeight: '600' },
  empty: { alignItems: 'center', padding: 40 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', paddingBottom: 10 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 8 },
  profileImg: { width: '100%', height: 180, borderRadius: 12, marginBottom: 8, resizeMode: 'cover' },
  bioText: { fontSize: 14, color: '#4B5563', lineHeight: 22 },
  itemRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  itemImg: { width: 60, height: 60, borderRadius: 8 },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  btn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, gap: 4 },
  approveBtn: { backgroundColor: '#10B981' },
  rejectBtn: { backgroundColor: '#EF4444' },
  btnText: { color: '#FFF', fontSize: 12, fontWeight: '600' },
  approvedText: { fontSize: 13, color: '#10B981', fontWeight: '600', marginTop: 4 },
  rejectOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  rejectContent: { backgroundColor: '#FFF', borderRadius: 16, padding: 20 },
  rejectTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: '#1F2937' },
  rejectInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, minHeight: 80, fontSize: 14 },
  rejectActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 16 },
  rejectBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8 },
});
