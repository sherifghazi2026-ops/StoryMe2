import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image, ActivityIndicator, Alert, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { uploadGifFile, uploadVideoFile } from '../../services/uploadService';

const COLORS = [
  '#FFFFFF', '#F87171', '#FBBF24', '#34D399', '#60A5FA', 
  '#A78BFA', '#F472B6', '#9CA3AF', '#1F2937', '#000000'
];

export default function SettingsSplashScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadType, setUploadType] = useState('');
  
  const [splashType, setSplashType] = useState('gif');
  const [splashGifUrl, setSplashGifUrl] = useState('');
  const [splashVideoUrl, setSplashVideoUrl] = useState('');
  const [splashText, setSplashText] = useState('');
  const [appVersion, setAppVersion] = useState('');
  const [splashTextColor, setSplashTextColor] = useState('#FFFFFF');
  const [splashBgColor, setSplashBgColor] = useState('#1a1a2e');
  const [logoUrl, setLogoUrl] = useState('');
  const [durationMode, setDurationMode] = useState('auto');
  const [splashDuration, setSplashDuration] = useState('5000');

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    try {
      const { data } = await supabase
        .from('app_settings')
        .select('*')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (data) {
        setSplashType(data.splash_type || 'gif');
        setSplashGifUrl(data.splash_gif_url || '');
        setSplashVideoUrl(data.splash_video_url || '');
        setSplashText(data.splash_text || 'مرحباً بك في زد');
        setAppVersion(data.app_version || 'ZID V1.0.0');
        setSplashTextColor(data.splash_text_color || '#FFFFFF');
        setSplashBgColor(data.splash_bg_color || '#1a1a2e');
        setLogoUrl(data.app_logo_url || '');
        setDurationMode(data.duration_mode || 'auto');
        setSplashDuration(String(data.splash_duration || 5000));
      }
    } catch (error) { console.log('خطأ:', error); }
    finally { setLoading(false); }
  };

  const pickAndUploadGif = async () => {
    setUploadType('gif');
    setUploading(true);
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 1,
    });
    if (!result.canceled && result.assets[0]) {
      const uploaded = await uploadGifFile(result.assets[0].uri);
      if (uploaded && uploaded.success) {
        setSplashGifUrl(uploaded.fileUrl);
        Alert.alert('✅ تم', 'تم رفع GIF بنجاح');
      } else {
        Alert.alert('خطأ', uploaded?.error || 'فشل رفع الملف');
      }
    }
    setUploading(false);
    setUploadType('');
  };

  const pickAndUploadVideo = async () => {
    setUploadType('video');
    setUploading(true);
    const result = await DocumentPicker.getDocumentAsync({
      type: ['video/mp4', 'video/mpeg'],
    });
    if (!result.canceled && result.assets && result.assets[0]) {
      const uploaded = await uploadVideoFile(result.assets[0].uri);
      if (uploaded && uploaded.success) {
        setSplashVideoUrl(uploaded.fileUrl);
        Alert.alert('✅ تم', 'تم رفع الفيديو بنجاح');
      } else {
        Alert.alert('خطأ', uploaded?.error || 'فشل رفع الفيديو');
      }
    }
    setUploading(false);
    setUploadType('');
  };

  const pickLogo = async () => {
    setUploadType('logo');
    setUploading(true);
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      const uploaded = await uploadGifFile(result.assets[0].uri);
      if (uploaded && uploaded.success) {
        setLogoUrl(uploaded.fileUrl);
        Alert.alert('✅ تم', 'تم رفع الشعار بنجاح');
      } else {
        Alert.alert('خطأ', uploaded?.error || 'فشل رفع الشعار');
      }
    }
    setUploading(false);
    setUploadType('');
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase.from('app_settings').upsert({
        splash_type: splashType,
        splash_gif_url: splashGifUrl || null,
        splash_video_url: splashVideoUrl || null,
        splash_text: splashText || 'مرحباً بك في زد',
        app_version: appVersion || 'ZID V1.0.0',
        splash_text_color: splashTextColor,
        splash_bg_color: splashBgColor,
        app_logo_url: logoUrl || null,
        duration_mode: durationMode,
        splash_duration: parseInt(splashDuration) || 5000
      });
      
      if (error) throw error;
      Alert.alert('✅ تم', 'تم حفظ جميع الإعدادات');
    } catch (error) { Alert.alert('خطأ', error.message); }
    finally { setSaving(false); }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#4F46E5" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.headerTitle}>إعدادات شاشة البداية</Text>
        <View style={{ width: 40 }} />
      </View>
      
      <ScrollView contentContainerStyle={styles.content}>
        
        {/* نوع الوسائط */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🎬 نوع شاشة البداية</Text>
          <View style={styles.typeSelector}>
            <TouchableOpacity 
              style={[styles.typeButton, splashType === 'gif' && styles.typeActive]}
              onPress={() => setSplashType('gif')}>
              <Ionicons name="image-outline" size={24} color={splashType === 'gif' ? '#FFF' : '#4B5563'} />
              <Text style={[styles.typeText, splashType === 'gif' && styles.typeTextActive]}>GIF متحرك</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.typeButton, splashType === 'video' && styles.typeActive]}
              onPress={() => setSplashType('video')}>
              <Ionicons name="videocam-outline" size={24} color={splashType === 'video' ? '#FFF' : '#4B5563'} />
              <Text style={[styles.typeText, splashType === 'video' && styles.typeTextActive]}>فيديو MP4</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* رفع GIF */}
        {splashType === 'gif' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>🖼️ ملف GIF</Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickAndUploadGif} disabled={uploading}>
              {uploading && uploadType === 'gif' ? <ActivityIndicator color="#4F46E5" /> : <><Ionicons name="cloud-upload-outline" size={24} color="#4F46E5" /><Text style={styles.uploadButtonText}>رفع GIF</Text></>}
            </TouchableOpacity>
            <TextInput style={styles.input} placeholder="رابط GIF" value={splashGifUrl} onChangeText={setSplashGifUrl} />
            {splashGifUrl !== '' && <Image source={{ uri: splashGifUrl }} style={styles.previewImage} />}
          </View>
        )}

        {/* رفع فيديو */}
        {splashType === 'video' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>🎥 ملف فيديو MP4</Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickAndUploadVideo} disabled={uploading}>
              {uploading && uploadType === 'video' ? <ActivityIndicator color="#4F46E5" /> : <><Ionicons name="cloud-upload-outline" size={24} color="#4F46E5" /><Text style={styles.uploadButtonText}>رفع فيديو MP4</Text></>}
            </TouchableOpacity>
            <TextInput style={styles.input} placeholder="رابط الفيديو" value={splashVideoUrl} onChangeText={setSplashVideoUrl} />
          </View>
        )}

        {/* الشعار */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🖼️ شعار التطبيق</Text>
          <TouchableOpacity style={styles.uploadButton} onPress={pickLogo} disabled={uploading}>
            {uploading && uploadType === 'logo' ? <ActivityIndicator color="#4F46E5" /> : <><Ionicons name="cloud-upload-outline" size={24} color="#4F46E5" /><Text style={styles.uploadButtonText}>رفع شعار</Text></>}
          </TouchableOpacity>
          <TextInput style={styles.input} placeholder="رابط الشعار" value={logoUrl} onChangeText={setLogoUrl} />
          {logoUrl !== '' && <Image source={{ uri: logoUrl }} style={styles.previewImageSmall} />}
        </View>

        {/* النص والإصدار */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📝 النص والإصدار</Text>
          <TextInput style={styles.input} placeholder="نص شاشة البداية" value={splashText} onChangeText={setSplashText} />
          <TextInput style={styles.input} placeholder="إصدار التطبيق" value={appVersion} onChangeText={setAppVersion} />
        </View>

        {/* ألوان النص والخلفية */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🎨 ألوان الشاشة</Text>
          
          <Text style={styles.label}>لون النص</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.colorsRow}>
            {COLORS.map((color) => (
              <TouchableOpacity
                key={color}
                style={[styles.colorOption, { backgroundColor: color }, splashTextColor === color && styles.colorOptionActive]}
                onPress={() => setSplashTextColor(color)}
              />
            ))}
          </ScrollView>
          <TextInput style={styles.input} placeholder="#FFFFFF" value={splashTextColor} onChangeText={setSplashTextColor} />

          <Text style={styles.label}>لون الخلفية</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.colorsRow}>
            {COLORS.map((color) => (
              <TouchableOpacity
                key={color}
                style={[styles.colorOption, { backgroundColor: color }, splashBgColor === color && styles.colorOptionActive]}
                onPress={() => setSplashBgColor(color)}
              />
            ))}
          </ScrollView>
          <TextInput style={styles.input} placeholder="#1a1a2e" value={splashBgColor} onChangeText={setSplashBgColor} />
        </View>

        {/* مدة العرض */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⏱️ مدة العرض</Text>
          
          <View style={styles.durationSelector}>
            <TouchableOpacity 
              style={[styles.durationButton, durationMode === 'auto' && styles.durationActive]}
              onPress={() => setDurationMode('auto')}>
              <Text style={[styles.durationText, durationMode === 'auto' && styles.durationTextActive]}>تلقائي</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.durationButton, durationMode === 'custom' && styles.durationActive]}
              onPress={() => setDurationMode('custom')}>
              <Text style={[styles.durationText, durationMode === 'custom' && styles.durationTextActive]}>مدة محددة</Text>
            </TouchableOpacity>
          </View>
          
          {durationMode === 'custom' && (
            <TextInput 
              style={styles.input} 
              placeholder="5000 (مللي ثانية)" 
              value={splashDuration} 
              onChangeText={setSplashDuration} 
              keyboardType="numeric"
            />
          )}
        </View>

        <TouchableOpacity style={[styles.saveButton, saving && styles.disabled]} onPress={saveSettings} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>حفظ جميع الإعدادات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16, paddingBottom: 40 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  cardTitle: { fontSize: 18, fontWeight: '600', color: '#1F2937', marginBottom: 16 },
  typeSelector: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  typeButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12, borderRadius: 12, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  typeActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  typeText: { fontSize: 14, color: '#4B5563', fontWeight: '500' },
  typeTextActive: { color: '#FFF' },
  uploadButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#EEF2FF', padding: 14, borderRadius: 12, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  uploadButtonText: { fontSize: 14, color: '#4F46E5', fontWeight: '500' },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, fontSize: 14, marginBottom: 12 },
  previewImage: { width: 150, height: 150, borderRadius: 12, backgroundColor: '#F3F4F6', marginTop: 8, alignSelf: 'center' },
  previewImageSmall: { width: 80, height: 80, borderRadius: 12, backgroundColor: '#F3F4F6', marginTop: 8, alignSelf: 'center' },
  label: { fontSize: 14, fontWeight: '500', color: '#4B5563', marginBottom: 8, marginTop: 8 },
  colorsRow: { flexDirection: 'row', marginBottom: 12 },
  colorOption: { width: 40, height: 40, borderRadius: 20, marginRight: 12, borderWidth: 2, borderColor: '#E5E7EB' },
  colorOptionActive: { borderColor: '#4F46E5', borderWidth: 3 },
  durationSelector: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  durationButton: { flex: 1, alignItems: 'center', padding: 12, borderRadius: 12, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  durationActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  durationText: { fontSize: 14, color: '#4B5563', fontWeight: '500' },
  durationTextActive: { color: '#FFF' },
  saveButton: { backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 16 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});
