import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
  TextInput, Modal, ScrollView, Image, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import * as ImagePicker from 'expo-image-picker';
import { uploadServiceImage } from '../../services/uploadService';

export default function ItemsServiceScreen({ navigation, route }) {
  const { service_id, service_name, sub_services = [] } = route.params || {};
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  
  const [newItemName, setNewItemName] = useState('');
  const [newItemImage, setNewItemImage] = useState(null);
  const [selectedVariants, setSelectedVariants] = useState({});

  useEffect(() => {
    if (service_id) {
      fetchItems();
    }
  }, [service_id]);

  async function fetchItems() {
    try {
      const { data, error } = await supabase
        .from('service_items')
        .select('*')
        .eq('service_id', service_id)
        .order('name', { ascending: true });
      
      if (error) throw error;
      
      const itemsWithVariants = (data || []).map(item => ({
        ...item,
        variant_prices: item.variant_prices || {}
      }));
      
      setItems(itemsWithVariants);
    } catch (error) {
      console.error('خطأ:', error);
    } finally {
      setLoading(false);
    }
  }

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('خطأ', 'مطلوب صلاحية الوصول للمعرض');
      return;
    }
    
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      allowsEditing: true,
    });
    
    if (!result.canceled && result.assets) {
      setUploading(true);
      const uploadResult = await uploadServiceImage(result.assets[0].uri);
      setUploading(false);
      if (uploadResult.success) {
        setNewItemImage(uploadResult.fileUrl);
      } else {
        Alert.alert('خطأ', 'فشل رفع الصورة');
      }
    }
  }

  const toggleVariant = (variant) => {
    if (selectedVariants[variant] !== undefined) {
      const newVariants = { ...selectedVariants };
      delete newVariants[variant];
      setSelectedVariants(newVariants);
    } else {
      setSelectedVariants({ ...selectedVariants, [variant]: 0 });
    }
  };

  const updateVariantPrice = (variant, price) => {
    setSelectedVariants({
      ...selectedVariants,
      [variant]: parseFloat(price) || 0
    });
  };

  async function addOrUpdateItem() {
    if (!newItemName.trim()) {
      Alert.alert('تنبيه', 'اسم المنتج مطلوب');
      return;
    }

    const finalVariants = {};
    Object.keys(selectedVariants).forEach(variant => {
      if (selectedVariants[variant] > 0) {
        finalVariants[variant] = selectedVariants[variant];
      }
    });

    if (Object.keys(finalVariants).length === 0) {
      Alert.alert('تنبيه', 'يجب إضافة صنف واحد على الأقل بسعر أكبر من 0');
      return;
    }

    try {
      const itemData = {
        service_id: service_id,
        name: newItemName.trim(),
        image_url: newItemImage,
        variant_prices: finalVariants
      };

      if (isEditing && editingItem) {
        const { error } = await supabase
          .from('service_items')
          .update(itemData)
          .eq('id', editingItem.id);
        if (error) throw error;
        Alert.alert('نجاح', 'تم تحديث المنتج');
      } else {
        const { error } = await supabase
          .from('service_items')
          .insert([itemData]);
        if (error) throw error;
        Alert.alert('نجاح', 'تم إضافة المنتج');
      }
      
      resetForm();
      fetchItems();
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  }

  async function deleteItem(itemId) {
    Alert.alert('تأكيد', 'هل تريد حذف هذا المنتج؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'حذف',
        style: 'destructive',
        onPress: async () => {
          const { error } = await supabase
            .from('service_items')
            .delete()
            .eq('id', itemId);
          if (!error) fetchItems();
        }
      }
    ]);
  }

  const openEditModal = (item) => {
    setIsEditing(true);
    setEditingItem(item);
    setNewItemName(item.name);
    setNewItemImage(item.image_url);
    setSelectedVariants(item.variant_prices || {});
    setModalVisible(true);
  };

  const resetForm = () => {
    setNewItemName('');
    setNewItemImage(null);
    setSelectedVariants({});
    setIsEditing(false);
    setEditingItem(null);
    setModalVisible(false);
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemCard}>
      <View style={styles.itemRow}>
        {item.image_url ? (
          <Image source={{ uri: item.image_url }} style={styles.itemImage} />
        ) : (
          <View style={[styles.itemImage, styles.imagePlaceholder]}>
            <Ionicons name="image-outline" size={24} color="#9CA3AF" />
          </View>
        )}
        <View style={styles.itemInfo}>
          <Text style={styles.itemName}>{item.name}</Text>
          <View style={styles.variantsPreview}>
            {Object.keys(item.variant_prices || {}).map((variant, idx) => (
              <View key={idx} style={styles.variantChip}>
                <Text style={styles.variantName}>{variant}</Text>
                <Text style={styles.variantPrice}>{item.variant_prices[variant]}ج</Text>
              </View>
            ))}
          </View>
        </View>
        <View style={styles.itemActions}>
          <TouchableOpacity onPress={() => openEditModal(item)} style={styles.editButton}>
            <Ionicons name="create-outline" size={22} color="#4F46E5" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => deleteItem(item.id)}>
            <Ionicons name="trash-outline" size={24} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>منتجات {service_name}</Text>
        <TouchableOpacity onPress={() => {
          resetForm();
          setModalVisible(true);
        }}>
          <Ionicons name="add" size={28} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.emptyText}>لا توجد منتجات</Text>}
      />

      {/* Modal إضافة/تعديل منتج - تصميم محسن */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalWrapper}>
            <ScrollView contentContainerStyle={styles.modalScroll}>
              <View style={styles.modalContent}>
                <Text style={styles.modalTitle}>
                  {isEditing ? 'تعديل المنتج' : 'إضافة منتج جديد'}
                </Text>
                
                {/* صورة المنتج */}
                <TouchableOpacity style={styles.imagePicker} onPress={pickImage}>
                  {newItemImage ? (
                    <Image source={{ uri: newItemImage }} style={styles.pickedImage} />
                  ) : (
                    <View style={styles.imagePlaceholder}>
                      <Ionicons name="camera-outline" size={40} color="#9CA3AF" />
                      <Text style={styles.imagePlaceholderText}>اختر صورة</Text>
                    </View>
                  )}
                </TouchableOpacity>

                {/* اسم المنتج */}
                <Text style={styles.inputLabel}>اسم المنتج</Text>
                <TextInput
                  style={styles.input}
                  placeholder="مثال: قميص, بنطلون, فينو"
                  value={newItemName}
                  onChangeText={setNewItemName}
                />

                {/* الخدمات الفرعية */}
                <Text style={styles.inputLabel}>اختر الخدمات الفرعية لهذا المنتج</Text>
                
                {sub_services.map((sub, idx) => {
                  const isSelected = selectedVariants[sub] !== undefined;
                  return (
                    <View key={idx} style={styles.variantCard}>
                      <TouchableOpacity 
                        style={[styles.checkbox, isSelected && styles.checkboxActive]}
                        onPress={() => toggleVariant(sub)}
                      >
                        {isSelected && <Ionicons name="checkmark" size={16} color="#FFF" />}
                      </TouchableOpacity>
                      <Text style={styles.variantLabel}>{sub}</Text>
                      
                      {isSelected && (
                        <View style={styles.priceRow}>
                          <Text style={styles.priceLabel}>السعر:</Text>
                          <TextInput
                            style={styles.priceInput}
                            placeholder="0"
                            value={selectedVariants[sub] ? String(selectedVariants[sub]) : ''}
                            onChangeText={(text) => updateVariantPrice(sub, text)}
                            keyboardType="numeric"
                          />
                          <Text style={styles.currency}>ج.م</Text>
                        </View>
                      )}
                    </View>
                  );
                })}

                {/* أزرار الحفظ والإلغاء */}
                <View style={styles.modalButtons}>
                  <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={resetForm}>
                    <Text style={styles.cancelButtonText}>إلغاء</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.button, styles.saveButton]} onPress={addOrUpdateItem} disabled={uploading}>
                    {uploading ? <ActivityIndicator size="small" color="#FFF" /> : <Text style={styles.saveButtonText}>حفظ</Text>}
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 50, paddingBottom: 12, paddingHorizontal: 16, backgroundColor: '#FFF', borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { textAlign: 'center', marginTop: 32, color: '#9CA3AF' },

  itemCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 12, marginBottom: 12 },
  itemRow: { flexDirection: 'row', alignItems: 'center' },
  itemImage: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  imagePlaceholder: { backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 6 },
  variantsPreview: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  variantChip: { backgroundColor: '#EEF2FF', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, flexDirection: 'row', gap: 4 },
  variantName: { fontSize: 11, color: '#4F46E5' },
  variantPrice: { fontSize: 10, color: '#4F46E5', fontWeight: '500' },
  itemActions: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  editButton: { padding: 4 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalWrapper: { width: '92%', maxWidth: 500, backgroundColor: '#FFF', borderRadius: 24, overflow: 'hidden', maxHeight: '85%' },
  modalScroll: { paddingVertical: 20, paddingHorizontal: 16 },
  modalContent: { width: '100%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginBottom: 20, color: '#1F2937' },

  imagePicker: { width: '100%', height: 130, borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', marginBottom: 16, overflow: 'hidden', backgroundColor: '#F9FAFB' },
  pickedImage: { width: '100%', height: '100%' },
  imagePlaceholder: { justifyContent: 'center', alignItems: 'center' },
  imagePlaceholderText: { marginTop: 8, fontSize: 14, color: '#9CA3AF' },

  inputLabel: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 6, marginTop: 8 },
  input: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, color: '#1F2937', marginBottom: 16, backgroundColor: '#FFF' },

  variantCard: { backgroundColor: '#F9FAFB', borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#EEF2FF' },
  checkbox: { width: 24, height: 24, borderRadius: 6, borderWidth: 2, borderColor: '#4F46E5', justifyContent: 'center', alignItems: 'center', marginBottom: 10 },
  checkboxActive: { backgroundColor: '#4F46E5' },
  variantLabel: { fontSize: 15, fontWeight: '500', color: '#1F2937', marginBottom: 8 },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  priceLabel: { fontSize: 13, color: '#6B7280', width: 45 },
  priceInput: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 8, width: 100, fontSize: 14, textAlign: 'center', backgroundColor: '#FFF' },
  currency: { fontSize: 14, color: '#6B7280', marginLeft: 6, width: 30 },

  modalButtons: { flexDirection: 'row', gap: 12, marginTop: 24, marginBottom: 8 },
  button: { flex: 1, padding: 14, borderRadius: 10, alignItems: 'center' },
  cancelButton: { backgroundColor: '#F3F4F6' },
  saveButton: { backgroundColor: '#4F46E5' },
  cancelButtonText: { color: '#1F2937', fontSize: 15, fontWeight: '500' },
  saveButtonText: { color: '#FFF', fontSize: 15, fontWeight: 'bold' },
});
