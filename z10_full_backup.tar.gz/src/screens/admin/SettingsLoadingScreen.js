import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  Image, ActivityIndicator, Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabaseClient';
import * as ImagePicker from 'expo-image-picker';

export default function SettingsLoadingScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadingType, setLoadingType] = useState('image');
  const [loadingImageUrl, setLoadingImageUrl] = useState('');
  const [loadingVideoUrl, setLoadingVideoUrl] = useState('');
  const [loadingDuration, setLoadingDuration] = useState('3000');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('*')
        .maybeSingle();
      
      if (data) {
        setLoadingType(data.loading_type || 'image');
        setLoadingImageUrl(data.loading_image_url || '');
        setLoadingVideoUrl(data.loading_video_url || '');
        setLoadingDuration(String(data.loading_duration || 3000));
      }
    } catch (error) {
      console.log('خطأ:', error);
    } finally {
      setLoading(false);
    }
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: 'images',
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setLoadingImageUrl(result.assets[0].uri);
    }
  };

  const pickVideo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: 'videos',
      allowsEditing: false,
    });
    if (!result.canceled && result.assets[0]) {
      setLoadingVideoUrl(result.assets[0].uri);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('app_settings')
        .upsert({
          loading_type: loadingType,
          loading_image_url: loadingImageUrl || null,
          loading_video_url: loadingVideoUrl || null,
          loading_duration: parseInt(loadingDuration) || 3000,
          updated_at: new Date().toISOString()
        });
      
      if (error) throw error;
      Alert.alert('✅ تم', 'تم حفظ إعدادات شاشة التحميل');
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إعدادات شاشة التحميل</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⏳ نوع شاشة التحميل</Text>
          
          <View style={styles.rowButtons}>
            <TouchableOpacity 
              style={[styles.optionButton, loadingType === 'none' && styles.optionActive]}
              onPress={() => setLoadingType('none')}>
              <Ionicons name="close-circle-outline" size={24} color={loadingType === 'none' ? '#FFF' : '#4B5563'} />
              <Text style={[styles.optionText, loadingType === 'none' && styles.optionTextActive]}>لا شيء</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[styles.optionButton, loadingType === 'image' && styles.optionActive]}
              onPress={() => setLoadingType('image')}>
              <Ionicons name="image-outline" size={24} color={loadingType === 'image' ? '#FFF' : '#4B5563'} />
              <Text style={[styles.optionText, loadingType === 'image' && styles.optionTextActive]}>صورة (GIF)</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.optionButton, loadingType === 'video' && styles.optionActive]}
              onPress={() => setLoadingType('video')}>
              <Ionicons name="videocam-outline" size={24} color={loadingType === 'video' ? '#FFF' : '#4B5563'} />
              <Text style={[styles.optionText, loadingType === 'video' && styles.optionTextActive]}>فيديو</Text>
            </TouchableOpacity>
          </View>
        </View>

        {loadingType === 'image' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>🖼️ صورة التحميل</Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickImage}>
              <Ionicons name="cloud-upload-outline" size={24} color="#4F46E5" />
              <Text style={styles.uploadButtonText}>اختر صورة/GIF من المعرض</Text>
            </TouchableOpacity>
            <Text style={styles.label}>أو أدخل رابط الصورة</Text>
            <TextInput style={styles.input} placeholder="https://example.com/loading.gif" value={loadingImageUrl} onChangeText={setLoadingImageUrl} />
            {loadingImageUrl !== '' && (
              <View style={styles.previewContainer}>
                <Text style={styles.previewLabel}>معاينة:</Text>
                <Image source={{ uri: loadingImageUrl }} style={styles.previewImage} />
              </View>
            )}
          </View>
        )}

        {loadingType === 'video' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>🎥 فيديو التحميل</Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickVideo}>
              <Ionicons name="cloud-upload-outline" size={24} color="#4F46E5" />
              <Text style={styles.uploadButtonText}>اختر فيديو من المعرض</Text>
            </TouchableOpacity>
            <Text style={styles.label}>أو أدخل رابط الفيديو</Text>
            <TextInput style={styles.input} placeholder="https://example.com/loading.mp4" value={loadingVideoUrl} onChangeText={setLoadingVideoUrl} />
            <Text style={styles.label}>مدة العرض (مللي ثانية)</Text>
            <TextInput style={styles.input} placeholder="3000" value={loadingDuration} onChangeText={setLoadingDuration} keyboardType="numeric" />
          </View>
        )}

        <TouchableOpacity style={styles.saveButton} onPress={saveSettings} disabled={saving}>
          {saving ? <ActivityIndicator color="#FFF" /> : (
            <>
              <Ionicons name="save-outline" size={20} color="#FFF" />
              <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  cardTitle: { fontSize: 18, fontWeight: '600', color: '#1F2937', marginBottom: 16 },
  rowButtons: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  optionButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12, borderRadius: 12, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  optionActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  optionText: { fontSize: 14, color: '#4B5563', fontWeight: '500' },
  optionTextActive: { color: '#FFF' },
  uploadButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#EEF2FF', padding: 14, borderRadius: 12, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB', borderStyle: 'dashed' },
  uploadButtonText: { fontSize: 14, color: '#4F46E5', fontWeight: '500' },
  label: { fontSize: 14, fontWeight: '500', color: '#4B5563', marginBottom: 8, marginTop: 8 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 12, fontSize: 14, marginBottom: 12 },
  previewContainer: { marginTop: 12, alignItems: 'center' },
  previewLabel: { fontSize: 12, color: '#6B7280', marginBottom: 8 },
  previewImage: { width: 200, height: 200, borderRadius: 12, backgroundColor: '#F3F4F6' },
  saveButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#4F46E5', padding: 16, borderRadius: 12, marginTop: 8 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});
