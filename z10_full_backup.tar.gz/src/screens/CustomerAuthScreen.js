import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, Image, StatusBar,
  KeyboardAvoidingView, Platform, ActivityIndicator, Animated, Dimensions, Alert,
  Modal, ScrollView, Keyboard
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';
import { fontFamily } from '../utils/fonts';
import { registerForPushNotificationsAsync } from "../services/pushNotificationService";
import { useTerms } from '../context/TermsContext';
import Checkbox from 'expo-checkbox';

const { width, height } = Dimensions.get('window');

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export default function CustomerAuthScreen({ navigation, route }) {
  const { prefillName, prefillPhone, fromGuestCheckout, fromFulfillment } = route.params || {};
  const [phone, setPhone] = useState(prefillPhone || '');
  const [name, setName] = useState(prefillName || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [regions, setRegions] = useState([]);
  const [globalIcon, setGlobalIcon] = useState('');
  const [showRegionPicker, setShowRegionPicker] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isLogin, setIsLogin] = useState(!fromGuestCheckout);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [existingUser, setExistingUser] = useState(null);
  const [existingUserRole, setExistingUserRole] = useState(null);
  const [existingUserRegionId, setExistingUserRegionId] = useState(null);
  const [existingUserRegionName, setExistingUserRegionName] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const { acceptTerms } = useTerms();

  const [backgroundImageUrl, setBackgroundImageUrl] = useState(null);
  const [bgOpacity, setBgOpacity] = useState(1);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    loadAppearanceSettings();
    fetchRegions();
    Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }).start();
  }, []);

  const loadAppearanceSettings = async () => {
    try {
      const { data } = await supabase.from('app_settings').select('customer_auth_background_url, customer_auth_opacity, regions_icon').eq('id', 1).single();
      if (data) {
        setBackgroundImageUrl(data.customer_auth_background_url || null);
        const opacity = parseFloat(data.customer_auth_opacity);
        setBgOpacity(isNaN(opacity) ? 1 : opacity);
        if (data.regions_icon) setGlobalIcon(data.regions_icon);
      }
    } catch (error) {
      console.log('خطأ:', error);
    }
  };

  const fetchRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    if (data) setRegions(data);
  };

  useEffect(() => {
    const checkExistingUser = async () => {
      if (!isLogin && phone.length >= 10) {
        const { data } = await supabase.from('profiles').select('id, full_name, phone').eq('phone', phone).limit(1);
        if (data && data.length > 0) setExistingUser(data[0]);
        else setExistingUser(null);
      } else setExistingUser(null);
    };
    checkExistingUser();
  }, [phone, isLogin]);

  useEffect(() => {
    if (isLogin && phone.length >= 10) {
      supabase.from('profiles').select('role, region_id').eq('phone', phone).single().then(async ({ data }) => {
        if (data) {
          setExistingUserRole(data.role); setExistingUserRegionId(data.region_id);
          if (data.region_id) {
            const { data: regionData } = await supabase.from('regions').select('name').eq('id', data.region_id).single();
            setExistingUserRegionName(regionData?.name || ''); setSelectedRegion(data.region_id);
          } else { setExistingUserRegionName(''); setSelectedRegion(null); }
        } else { setExistingUserRole(null); setExistingUserRegionId(null); setExistingUserRegionName(''); setSelectedRegion(null); }
      });
    } else if (isLogin) { setExistingUserRole(null); setExistingUserRegionId(null); setExistingUserRegionName(''); setSelectedRegion(null); }
  }, [phone, isLogin]);

  const handleLogin = async () => {
    if (phone === '' && password === 'Admin135792') { navigation.replace('AdminHome'); return; }
    if (!phone || !password) { Alert.alert('تنبيه', 'أدخل رقم الهاتف وكلمة المرور'); return; }
    setLoading(true);
    try {
      const { data: users, error } = await supabase.from('profiles').select('*').eq('phone', phone).limit(1);
      if (error) throw error;
      if (!users || users.length === 0) { Alert.alert('خطأ', 'رقم الهاتف أو كلمة المرور غير صحيحة'); setLoading(false); return; }
      const user = users[0];
      if (user.password !== password) { Alert.alert('خطأ', 'رقم الهاتف أو كلمة المرور غير صحيحة'); setLoading(false); return; }
      if (!user.active) { Alert.alert('خطأ', 'هذا الحساب غير نشط'); setLoading(false); return; }
      const userDataToStore = { id: user.id, $id: user.id, full_name: user.full_name, name: user.full_name, phone: user.phone, role: user.role, merchantType: user.merchant_type, image_url: user.image_url, region_id: user.region_id };
      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await registerForPushNotificationsAsync().catch(e => console.log("فشل تسجيل التوكن:", e));
      await AsyncStorage.setItem('userRole', user.role);
      await AsyncStorage.setItem('userPhone', phone);
      if (user.full_name) await AsyncStorage.setItem('userName', user.full_name);
      // ✅ لو جاي من Fulfillment، ارجع له
      if (fromFulfillment) { navigation.goBack(); return; }
      if (user.role === 'admin') navigation.replace('AdminHome');
      else if (user.role === 'merchant') navigation.replace('MerchantDashboard');
      else navigation.replace('MainTabs');
    } catch (error) { Alert.alert('خطأ', 'حدث خطأ في الاتصال'); }
    finally { setLoading(false); }
  };

  const handleRegister = async () => {
    if (existingUser) {
      Alert.alert('رقم الهاتف مسجل مسبقاً', 'هذا الرقم مسجل باسم "' + existingUser.full_name + '". هل تريد تسجيل الدخول؟', [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تسجيل الدخول', onPress: () => { setIsLogin(true); setPassword(''); setConfirmPassword(''); } }
      ]);
      return;
    }
    if (!name || !phone || !password || !confirmPassword) { Alert.alert('تنبيه', 'الرجاء إدخال جميع البيانات'); return; }
    if (password !== confirmPassword) { Alert.alert('تنبيه', 'كلمة المرور غير متطابقة'); return; }
    if (password.length < 4) { Alert.alert('تنبيه', 'كلمة المرور يجب أن تكون 4 أحرف على الأقل'); return; }
    if (!selectedRegion) { Alert.alert('تنبيه', 'الرجاء اختيار المنطقة'); return; }
    if (!termsAccepted) { Alert.alert('تنبيه', 'يجب الموافقة على شروط الاستخدام'); return; }
    setLoading(true);
    try {
      const newUserId = generateUUID();
      const newUser = { id: newUserId, full_name: name.trim(), phone: phone.trim(), password, role: 'customer', region_id: selectedRegion, active: true, profile_completed: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      const { data: user, error: insertError } = await supabase.from('profiles').insert([newUser]).select().single();
      if (insertError) { Alert.alert('خطأ', insertError.message || 'فشل في إنشاء الحساب'); setLoading(false); return; }
      await acceptTerms();
      const userDataToStore = { id: user.id, $id: user.id, full_name: user.full_name, name: user.full_name, phone: user.phone, role: 'customer', region_id: selectedRegion };
      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await registerForPushNotificationsAsync().catch(e => console.log("فشل تسجيل التوكن:", e));
      await AsyncStorage.setItem('userRole', 'customer');
      await AsyncStorage.setItem('userName', name.trim());
      await AsyncStorage.setItem('userPhone', phone.trim());
      Alert.alert('مرحباً بك', 'تم إنشاء حسابك بنجاح');
      // ✅ لو جاي من Fulfillment، ارجع له
      if (fromFulfillment) { navigation.goBack(); } else { navigation.replace('MainTabs'); }
    } catch (error) { Alert.alert('خطأ', error.message || 'فشل في إنشاء الحساب'); }
    finally { setLoading(false); }
  };

  const handleTermsPress = () => {
    navigation.navigate('TermsScreen', { onAccept: (value) => { setTermsAccepted(value); acceptTerms(); } });
  };

  const regionDisplayName = isLogin ? (existingUserRegionName || '') : (regions.find(r => r.id === selectedRegion)?.name || 'اختر المنطقة');

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent />

      {backgroundImageUrl && (
        <Image source={{ uri: backgroundImageUrl }} style={[styles.bgImage, { opacity: bgOpacity }]} resizeMode="cover" />
      )}

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Animated.View style={[styles.outerContent, { opacity: fadeAnim }]}>

            {/* فريم زجاجي شفاف */}
            <View style={styles.glassCard}>

              <View style={styles.logoContainer}>
                <Image source={require('../../assets/icons/ZidiconSP.png')} style={styles.logo} resizeMode="contain" />
              </View>

              <Text style={styles.title}>{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</Text>

              {!isLogin && (
                <View style={styles.inputContainer}>
                  <Ionicons name="person-outline" size={20} color="#6B7280" style={styles.inputIcon} />
                  <TextInput style={styles.input} placeholder="الاسم الكامل" placeholderTextColor="#9CA3AF" value={name} onChangeText={setName} editable={!loading} returnKeyType="next" />
                </View>
              )}

              <View style={styles.inputContainer}>
                <Ionicons name="call-outline" size={20} color="#6B7280" style={styles.inputIcon} />
                <TextInput style={styles.input} placeholder="رقم الهاتف" placeholderTextColor="#9CA3AF" value={phone} onChangeText={setPhone} keyboardType="phone-pad" editable={!loading} returnKeyType="next" />
              </View>

              <View style={styles.inputContainer}>
                <Ionicons name="lock-closed-outline" size={20} color="#6B7280" style={styles.inputIcon} />
                <TextInput style={[styles.input, { flex: 1 }]} placeholder="كلمة المرور" placeholderTextColor="#9CA3AF" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} editable={!loading} returnKeyType={isLogin ? 'done' : 'next'} />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                  <Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={20} color="#6B7280" />
                </TouchableOpacity>
              </View>

              {!isLogin && (
                <View style={styles.inputContainer}>
                  <Ionicons name="lock-closed-outline" size={20} color="#6B7280" style={styles.inputIcon} />
                  <TextInput style={[styles.input, { flex: 1 }]} placeholder="تأكيد كلمة المرور" placeholderTextColor="#9CA3AF" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry={!showConfirmPassword} editable={!loading} returnKeyType="done" />
                  <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                    <Ionicons name={showConfirmPassword ? "eye-off-outline" : "eye-outline"} size={20} color="#6B7280" />
                  </TouchableOpacity>
                </View>
              )}

              {!isLogin ? (
                <TouchableOpacity style={styles.regionPickerBtn} onPress={() => { Keyboard.dismiss(); setShowRegionPicker(true); }}>
                  <Text style={styles.regionPickerText}>{regionDisplayName}</Text>
                  <Ionicons name="chevron-down" size={20} color="#6B7280" />
                  {globalIcon ? <Image source={{ uri: globalIcon }} style={styles.regionPickerIcon} /> : <Ionicons name="location-outline" size={20} color="#6B7280" />}
                </TouchableOpacity>
              ) : (
                <View style={styles.regionInfoContainer}>
                  {globalIcon ? <Image source={{ uri: globalIcon }} style={{ width: 18, height: 18, borderRadius: 5 }} /> : <Ionicons name="location" size={16} color="#4F46E5" />}
                  <Text style={styles.regionInfoText}>{regionDisplayName || 'جار التحميل...'}</Text>
                </View>
              )}

              {!isLogin && (
                <TouchableOpacity style={styles.termsRow} onPress={handleTermsPress} activeOpacity={0.7}>
                  <Checkbox value={termsAccepted} onValueChange={setTermsAccepted} color={termsAccepted ? '#4F46E5' : undefined} />
                  <Text style={styles.termsText}>أوافق على <Text style={styles.termsLink}>شروط وأحكام تطبيق Zid</Text></Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={styles.primaryButton} onPress={isLogin ? handleLogin : handleRegister} disabled={loading}>
                {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.primaryButtonText}>{isLogin ? 'دخول' : 'تسجيل'}</Text>}
              </TouchableOpacity>

              <TouchableOpacity onPress={() => setIsLogin(!isLogin)} style={styles.switchButton}>
                <Text style={styles.switchText}>{isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب؟ سجل دخول'}</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.replace('MainTabs')} style={styles.guestButton}>
                <Text style={styles.guestText}>الدخول كزائر</Text>
              </TouchableOpacity>

            </View>

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={showRegionPicker} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowRegionPicker(false)}>
          <View style={styles.modalContent}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>اختر المنطقة</Text>
            <ScrollView style={styles.regionScroll} showsVerticalScrollIndicator={false}>
              {regions.map((region) => (
                <TouchableOpacity
                  key={region.id}
                  style={[styles.regionOption, selectedRegion === region.id && styles.regionOptionActive]}
                  onPress={() => { setSelectedRegion(region.id); setShowRegionPicker(false); }}
                >
                  <Text style={[styles.regionOptionText, selectedRegion === region.id && styles.regionOptionTextActive]}>{region.name}</Text>
                  {selectedRegion === region.id && <Ionicons name="checkmark" size={20} color="#4F46E5" />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  bgImage: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, width, height },
  keyboardView: { flex: 1 },
  scrollContent: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  outerContent: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  glassCard: {
    width: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.65)',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 5,
    alignItems: 'center',
  },

  logoContainer: { width: 100, height: 100, marginBottom: 16, alignItems: 'center', justifyContent: 'center' },
  logo: { width: '100%', height: '100%' },
  title: { fontSize: 22, fontWeight: 'bold', color: '#1F2937', marginBottom: 24, textAlign: 'center', fontFamily: fontFamily.arabic },

  inputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#FFFFFF', borderRadius: 14, paddingHorizontal: 14, marginBottom: 14, height: 52, width: '100%' },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15, color: '#1F2937', textAlign: 'right', fontFamily: fontFamily.arabic },

  regionPickerBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#FFFFFF', borderRadius: 14, paddingHorizontal: 14, marginBottom: 14, height: 52, gap: 8, width: '100%' },
  regionPickerIcon: { width: 22, height: 22, borderRadius: 6, resizeMode: 'cover' },
  regionPickerText: { flex: 1, fontSize: 15, color: '#1F2937', textAlign: 'right', fontFamily: fontFamily.arabic },
  regionInfoContainer: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', padding: 14, marginBottom: 14, gap: 8, width: '100%' },
  regionInfoText: { fontSize: 14, color: '#4B5563', fontFamily: fontFamily.arabic },

  termsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14, gap: 8, paddingVertical: 4, width: '100%' },
  termsText: { fontSize: 13, color: '#4B5563', fontFamily: fontFamily.arabic },
  termsLink: { color: '#4F46E5', textDecorationLine: 'underline', fontWeight: '600' },

  primaryButton: { backgroundColor: '#4F46E5', padding: 15, borderRadius: 14, alignItems: 'center', marginBottom: 10, width: '100%' },
  primaryButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600', fontFamily: fontFamily.arabic },
  switchButton: { alignItems: 'center', marginVertical: 8 },
  switchText: { color: '#4F46E5', fontSize: 14, fontWeight: '500', fontFamily: fontFamily.arabic },
  guestButton: { alignItems: 'center', paddingVertical: 4 },
  guestText: { color: '#DC2626', fontSize: 14, fontWeight: '600', fontFamily: fontFamily.arabic },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingHorizontal: 20, paddingTop: 12, paddingBottom: 30, maxHeight: '50%' },
  modalHandle: { width: 36, height: 4, backgroundColor: '#E5E7EB', borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 17, fontWeight: '700', color: '#1F2937', marginBottom: 12, textAlign: 'center', fontFamily: fontFamily.arabic },
  regionScroll: { maxHeight: 300 },
  regionOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, paddingHorizontal: 12, borderRadius: 10, marginBottom: 2 },
  regionOptionActive: { backgroundColor: '#EEF2FF' },
  regionOptionText: { fontSize: 15, color: '#374151', fontFamily: fontFamily.arabic },
  regionOptionTextActive: { color: '#4F46E5', fontWeight: '600' },
});
