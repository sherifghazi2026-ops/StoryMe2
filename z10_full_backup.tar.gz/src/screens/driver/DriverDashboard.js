import React, { useState, useEffect, useRef } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, RefreshControl, Linking, Modal, StatusBar, AppState, BackHandler } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getOrders, startDelivery, completeDelivery, assignDriver, ORDER_STATUS } from '../../services/orderService';
import { playNotificationSound, stopNotificationSound } from '../../utils/SoundHelper';
import CustomDrawer from '../../components/CustomDrawer';
import { useNavigation } from '@react-navigation/native';

export default function DriverDashboard({ navigation: propsNavigation }) {
  const rootNavigation = useNavigation();
  const [availableOrders, setAvailableOrders] = useState([]);
  const [myOrders, setMyOrders] = useState([]);
  const [completedOrders, setCompletedOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [driverData, setDriverData] = useState(null);
  const [activeTab, setActiveTab] = useState('available');
  const [drawerVisible, setDrawerVisible] = useState(false);
  const pollingInterval = useRef(null);
  const isFirstLoad = useRef(true);
  const lastAvailableOrderIds = useRef(new Set());
  const appState = useRef(AppState.currentState);

  useEffect(() => {
    loadDriverData();
    const subscription = AppState.addEventListener('change', handleAppStateChange);
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true);
    return () => {
      stopNotificationSound();
      if (pollingInterval.current) clearInterval(pollingInterval.current);
      subscription.remove();
      backHandler.remove();
    };
  }, []);

  const handleAppStateChange = (nextAppState) => {
    if (appState.current.match(/inactive|background/) && nextAppState === 'active') loadOrders();
    appState.current = nextAppState;
  };

  useEffect(() => {
    if (driverData) {
      loadOrders();
      if (pollingInterval.current) clearInterval(pollingInterval.current);
      pollingInterval.current = setInterval(() => { loadOrders(); }, 5000);
      setTimeout(() => { isFirstLoad.current = false; }, 3000);
    }
    return () => { if (pollingInterval.current) clearInterval(pollingInterval.current); };
  }, [driverData]);

  const loadDriverData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) { setDriverData(JSON.parse(data)); }
    setLoading(false);
  };

  const loadOrders = async () => {
    if (!driverData) return;
    try {
      if (activeTab === 'available') {
        const result = await getOrders({ status: [ORDER_STATUS.READY, ORDER_STATUS.ACCEPTED] });
        if (result.success) {
          const available = result.data.filter(order => !order.driver_id && order.id);
          const newOrderIds = new Set(available.map(o => o.id));
          const hasNewOrder = available.length > 0 && [...newOrderIds].some(id => !lastAvailableOrderIds.current.has(id));
          if (hasNewOrder && !isFirstLoad.current) { playNotificationSound(); setTimeout(() => stopNotificationSound(), 30000); }
          lastAvailableOrderIds.current = newOrderIds;
          setAvailableOrders(available);
        }
      } else if (activeTab === 'my') {
        const result = await getOrders({ driverId: driverData?.id, status: [ORDER_STATUS.DRIVER_ASSIGNED, ORDER_STATUS.ON_THE_WAY, 'delivery'] });
        if (result.success) setMyOrders(result.data.filter(o => o.id));
      } else {
        const result = await getOrders({ driverId: driverData?.id, status: [ORDER_STATUS.DELIVERED, 'complete'] });
        if (result.success) setCompletedOrders(result.data.filter(o => o.id));
      }
    } catch (error) {}
    setLoading(false); setRefreshing(false);
  };

  const handleAcceptOrder = (order) => {
    Alert.alert('قبول التوصيل', 'هل تريد توصيل هذا الطلب؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'قبول', onPress: async () => {
        stopNotificationSound();
        const result = await assignDriver(order.id, driverData.id, driverData.name || driverData.full_name, driverData.phone);
        if (result.success) { setAvailableOrders(prev => prev.filter(o => o.id !== order.id)); loadOrders(); }
        else Alert.alert('خطأ', result.error);
      }}
    ]);
  };

  const handleStartDelivery = async (orderId) => {
    Alert.alert('بدء التوصيل', 'هل أنت في طريقك لتوصيل الطلب؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'بدء', onPress: async () => { const result = await startDelivery(orderId); if (result.success) loadOrders(); else Alert.alert('خطأ', result.error); }}
    ]);
  };

  const handleCompleteDelivery = async (orderId) => {
    Alert.alert('تأكيد التسليم', 'هل تم تسليم الطلب للعميل؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'نعم، تم', onPress: async () => { const result = await completeDelivery(orderId); if (result.success) { Alert.alert('✅ تم', 'تم تسليم الطلب'); loadOrders(); } else Alert.alert('خطأ', result.error); }}
    ]);
  };

  const makePhoneCall = (phone) => phone && Linking.openURL(`tel:${phone}`);
  const formatAddress = (address) => address?.length > 30 ? address.substring(0, 30) + '...' : address || '';
  const onRefresh = () => { setRefreshing(true); loadOrders(); };
  const getOrderDisplayId = (order) => order?.id ? String(order.id).slice(-6) : '......';

  // تحديد إذا كان الطلب من تاجر ولا عميل عادي
  const getContactLabel = (order) => {
    if (order.merchant_name && order.merchant_id) return 'التاجر';
    if (order.merchant_name) return 'المحل';
    return 'العميل';
  };

  const getContactPhone = (order) => {
    if (order.merchant_phone || order.merchant_place) return order.merchant_phone || order.merchant_place;
    return order.customer_phone;
  };

  const getContactName = (order) => {
    if (order.merchant_name && order.merchant_id) return order.merchant_name;
    return order.customer_name;
  };

  const getItemsList = (order) => {
    if (order.items && Array.isArray(order.items) && order.items.length > 0) {
      return order.items.slice(0, 3).join(', ') + (order.items.length > 3 ? ` +${order.items.length - 3}` : '');
    }
    return order.description || order.service_name || '';
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#3B82F6" /></View>;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuButton}><Ionicons name="menu" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={styles.welcome}>مرحباً، {driverData?.name || driverData?.full_name || 'مندوب'}</Text>
        <TouchableOpacity onPress={() => propsNavigation.navigate('Profile')}><Ionicons name="person-circle" size={40} color="#4F46E5" /></TouchableOpacity>
      </View>
      <View style={styles.tabContainer}>
        <TouchableOpacity style={[styles.tab, activeTab === 'available' && styles.activeTab]} onPress={() => setActiveTab('available')}><Text style={[styles.tabText, activeTab === 'available' && styles.activeTabText]}>متاحة ({availableOrders.length})</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'my' && styles.activeTab]} onPress={() => setActiveTab('my')}><Text style={[styles.tabText, activeTab === 'my' && styles.activeTabText]}>طلباتي ({myOrders.length})</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'completed' && styles.activeTab]} onPress={() => setActiveTab('completed')}><Text style={[styles.tabText, activeTab === 'completed' && styles.activeTabText]}>منتهية ({completedOrders.length})</Text></TouchableOpacity>
      </View>
      <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />} contentContainerStyle={styles.ordersContainer}>
        {activeTab === 'available' && (availableOrders.length === 0 ? <View style={styles.emptyContainer}><Ionicons name="bicycle-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد طلبات متاحة</Text></View> : availableOrders.map((order) => (
          <View key={order.id} style={styles.orderCard}>
            <View style={styles.orderHeader}><Text style={styles.orderId}>طلب #{getOrderDisplayId(order)}</Text><View style={[styles.statusBadge, { backgroundColor: '#10B98120' }]}><Text style={[styles.statusText, { color: '#10B981' }]}>{order.service_name}</Text></View></View>
            <View style={styles.orderDetails}>
              <View style={styles.detailRow}><Ionicons name={order.merchant_id ? "business-outline" : "person-outline"} size={16} color="#3B82F6" /><Text style={styles.detailText}>{getContactLabel(order)}: {getContactName(order)}</Text></View>
              <TouchableOpacity style={styles.detailRow} onPress={() => makePhoneCall(getContactPhone(order))}><Ionicons name="call-outline" size={16} color="#3B82F6" /><Text style={styles.detailText}>{getContactPhone(order)}</Text></TouchableOpacity>
              <View style={styles.detailRow}><Ionicons name="location-outline" size={16} color="#6B7280" /><Text style={styles.detailText}>{formatAddress(order.customer_address)}</Text></View>
              <View style={styles.detailRow}><Ionicons name="list-outline" size={16} color="#8B5CF6" /><Text style={styles.detailText}>{getItemsList(order)}</Text></View>
              {order.final_total > 0 && <View style={styles.priceContainer}><Text style={styles.priceLabel}>الإجمالي:</Text><Text style={styles.priceValue}>{order.final_total} ج</Text></View>}
            </View>
            <TouchableOpacity style={[styles.actionButton, { backgroundColor: '#10B981' }]} onPress={() => handleAcceptOrder(order)}><Ionicons name="checkmark-circle" size={18} color="#FFF" /><Text style={styles.actionButtonText}>قبول التوصيل</Text></TouchableOpacity>
          </View>
        )))}
        {activeTab === 'my' && (myOrders.length === 0 ? <View style={styles.emptyContainer}><Ionicons name="time-outline" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد طلبات حالية</Text></View> : myOrders.map((order) => (
          <View key={order.id} style={styles.orderCard}>
            <View style={styles.orderHeader}><Text style={styles.orderId}>طلب #{getOrderDisplayId(order)}</Text><View style={[styles.statusBadge, { backgroundColor: order.status === ORDER_STATUS.ON_THE_WAY || order.status === 'delivery' ? '#3B82F620' : '#10B98120' }]}><Text style={[styles.statusText, { color: order.status === ORDER_STATUS.ON_THE_WAY || order.status === 'delivery' ? '#3B82F6' : '#F59E0B' }]}>{order.status === ORDER_STATUS.ON_THE_WAY || order.status === 'delivery' ? 'جاري التوصيل' : 'قيد التجهيز'}</Text></View></View>
            <View style={styles.orderDetails}>
              <View style={styles.detailRow}><Ionicons name={order.merchant_id ? "business-outline" : "person-outline"} size={16} color="#3B82F6" /><Text style={styles.detailText}>{getContactLabel(order)}: {getContactName(order)}</Text></View>
              <TouchableOpacity style={styles.detailRow} onPress={() => makePhoneCall(getContactPhone(order))}><Ionicons name="call-outline" size={16} color="#3B82F6" /><Text style={styles.detailText}>{getContactPhone(order)}</Text></TouchableOpacity>
              <View style={styles.detailRow}><Ionicons name="location-outline" size={16} color="#6B7280" /><Text style={styles.detailText}>{formatAddress(order.customer_address)}</Text></View>
              <View style={styles.detailRow}><Ionicons name="list-outline" size={16} color="#8B5CF6" /><Text style={styles.detailText}>{getItemsList(order)}</Text></View>
              {order.final_total > 0 && <View style={styles.priceContainer}><Text style={styles.priceLabel}>الإجمالي:</Text><Text style={styles.priceValue}>{order.final_total} ج</Text></View>}
            </View>
            {order.status === ORDER_STATUS.DRIVER_ASSIGNED && <TouchableOpacity style={[styles.actionButton, { backgroundColor: '#3B82F6' }]} onPress={() => handleStartDelivery(order.id)}><Ionicons name="bicycle" size={18} color="#FFF" /><Text style={styles.actionButtonText}>بدء التوصيل</Text></TouchableOpacity>}
            {(order.status === ORDER_STATUS.ON_THE_WAY || order.status === 'delivery') && <TouchableOpacity style={[styles.actionButton, { backgroundColor: '#10B981' }]} onPress={() => handleCompleteDelivery(order.id)}><Ionicons name="checkmark-done" size={18} color="#FFF" /><Text style={styles.actionButtonText}>تم التوصيل</Text></TouchableOpacity>}
          </View>
        )))}
        {activeTab === 'completed' && (completedOrders.length === 0 ? <View style={styles.emptyContainer}><Ionicons name="checkmark-done-circle" size={80} color="#E5E7EB" /><Text style={styles.emptyText}>لا توجد طلبات سابقة</Text></View> : completedOrders.map((order) => (
          <View key={order.id} style={styles.completedCard}>
            <View style={styles.orderHeader}><Text style={styles.orderId}>طلب #{getOrderDisplayId(order)}</Text><View style={[styles.statusBadge, { backgroundColor: '#10B98120' }]}><Text style={[styles.statusText, { color: '#10B981' }]}>تم التوصيل</Text></View></View>
            <View style={styles.orderDetails}><Text style={styles.completedAddress}>{order.customer_address}</Text><Text style={styles.completedDate}>{new Date(order.delivered_at || order.created_at).toLocaleDateString('ar-EG')}</Text>{order.final_total > 0 && <Text style={styles.completedPrice}>الإجمالي: {order.final_total} ج</Text>}</View>
          </View>
        )))}
      </ScrollView>
      <Modal visible={drawerVisible} transparent animationType="slide"><View style={styles.drawerOverlay}><View style={styles.drawerContent}><CustomDrawer isLoggedIn={true} userData={driverData} onClose={() => setDrawerVisible(false)} navigation={propsNavigation} onOpenAdminModal={() => {}} /></View></View></Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  menuButton: { padding: 8 },
  welcome: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', flex: 1, textAlign: 'center' },
  tabContainer: { flexDirection: 'row', backgroundColor: '#FFF', paddingHorizontal: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 20, marginHorizontal: 2 },
  activeTab: { backgroundColor: '#3B82F6' },
  tabText: { fontSize: 12, color: '#6B7280' },
  activeTabText: { color: '#FFF', fontWeight: '600' },
  ordersContainer: { padding: 16 },
  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
  orderCard: { backgroundColor: '#FFF', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB', elevation: 2 },
  completedCard: { backgroundColor: '#F9FAFB', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600' },
  orderDetails: { marginBottom: 12 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6, gap: 8 },
  detailText: { fontSize: 14, color: '#4B5563', flex: 1 },
  priceContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#F3F4F6', gap: 8 },
  priceLabel: { fontSize: 14, color: '#4B5563' },
  priceValue: { fontSize: 16, fontWeight: 'bold', color: '#F59E0B' },
  actionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, borderRadius: 8, gap: 6 },
  actionButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  completedAddress: { fontSize: 14, color: '#4B5563', marginBottom: 4 },
  completedDate: { fontSize: 12, color: '#9CA3AF', marginBottom: 4 },
  completedPrice: { fontSize: 14, fontWeight: '600', color: '#10B981', marginTop: 4 },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  drawerContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 25, borderTopRightRadius: 25, height: '80%', overflow: 'hidden' },
});
