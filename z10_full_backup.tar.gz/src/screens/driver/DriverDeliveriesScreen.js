import React, { useState, useEffect } from 'react';
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  
  ActivityIndicator,
  RefreshControl,
  Linking,
  StatusBar,
  Modal,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getOrders, ORDER_STATUS } from '../../services/orderService';
import CustomDrawer from '../../components/CustomDrawer';
import { useNavigation } from '@react-navigation/native';

export default function DriverDeliveriesScreen({ navigation: propsNavigation }) {
  const rootNavigation = useNavigation();
  
  const [deliveries, setDeliveries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [driverData, setDriverData] = useState(null);
  const [activeTab, setActiveTab] = useState('active');
  const [drawerVisible, setDrawerVisible] = useState(false);

  const ACTIVE_STATUSES = [
    ORDER_STATUS.PENDING,
    ORDER_STATUS.ACCEPTED,
    ORDER_STATUS.PREPARING,
    ORDER_STATUS.READY,
    ORDER_STATUS.DRIVER_ASSIGNED,
    ORDER_STATUS.ON_THE_WAY
  ];

  useEffect(() => {
    loadDriverData();
  }, []);

  useEffect(() => {
    if (driverData) {
      loadDeliveries();
    }
  }, [driverData, activeTab]);

  const loadDriverData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      setDriverData(JSON.parse(data));
    }
  };

  const loadDeliveries = async () => {
    try {
      let statusFilter;
      if (activeTab === 'active') {
        statusFilter = [ORDER_STATUS.DRIVER_ASSIGNED, ORDER_STATUS.ON_THE_WAY, 'delivery'];
      } else {
        statusFilter = ORDER_STATUS.DELIVERED;
      }

      const result = await getOrders({
        driverId: driverData?.$id || driverData?.id,
        status: statusFilter
      });

      if (result.success) {
        const validDeliveries = result.data.filter(order => {
          const orderId = order?.id || order?.$id;
          return orderId && orderId !== undefined && orderId !== null;
        });
        setDeliveries(validDeliveries);
      }
    } catch (error) {
      console.error('Error loading deliveries:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const makePhoneCall = (phone) => {
    if (phone) Linking.openURL(`tel:${phone}`);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadDeliveries();
  };

  const getOrderDisplayId = (order) => {
    const id = order?.id || order?.$id;
    if (!id) return '......';
    return String(id).slice(-6);
  };

  const handleOrderPress = (order) => {
    const orderId = order?.id || order?.$id;
    if (!orderId) {
      Alert.alert('تنبيه', 'الطلب غير موجود أو تم حذفه');
      return;
    }
    const isActive = ACTIVE_STATUSES.includes(order.status);
    if (!isActive) {
      console.log('⏭️ طلب منتهي - لا تنقل:', order.status);
      return;
    }
    console.log('🔍 التنقل إلى OrderTrackingScreen مع ID:', orderId);
    try {
      rootNavigation.navigate('OrderTrackingScreen', { orderId });
    } catch (error) {
      console.error('❌ خطأ في التنقل:', error);
      Alert.alert('تنبيه', 'حدث خطأ أثناء فتح الطلب');
    }
  };

  const isOrderActive = (order) => ACTIVE_STATUSES.includes(order.status);
  const isOrderCompleted = (order) => order.status === ORDER_STATUS.DELIVERED;
  const isOrderCancelled = (order) => order.status === ORDER_STATUS.CANCELLED;

  const renderDelivery = ({ item }) => {
    const orderId = item.id || item.$id;
    if (!orderId) return null;
    
    const active = isOrderActive(item);
    const completed = isOrderCompleted(item);
    const cancelled = isOrderCancelled(item);
    
    const Container = active ? TouchableOpacity : View;
    const containerProps = active ? { 
      onPress: () => handleOrderPress(item),
      activeOpacity: 0.7
    } : {};
    
    return (
      <Container
        key={orderId}
        style={[styles.deliveryCard, (cancelled || completed) && styles.disabledCard]}
        {...containerProps}
      >
        <View style={styles.deliveryHeader}>
          <Text style={styles.deliveryId}>طلب #{getOrderDisplayId(item)}</Text>
          <View style={[styles.statusBadge, { backgroundColor:
            completed ? '#10B98120' : 
            cancelled ? '#EF444420' : '#3B82F620'
          }]}>
            <Text style={[styles.statusText, { color:
              completed ? '#10B981' : 
              cancelled ? '#EF4444' : '#3B82F6'
            }]}>
              {completed ? 'تم التسليم' : 
               cancelled ? 'ملغي' : 'جاري'}
            </Text>
          </View>
        </View>

        {/* ✅ للطلبات المنتهية أو الملغاة: لا نعرض بيانات العميل */}
        {active ? (
          <View style={styles.customerInfo}>
            <TouchableOpacity style={styles.infoRow} onPress={() => makePhoneCall(item.customer_phone)}>
              <Ionicons name="call-outline" size={16} color="#3B82F6" />
              <Text style={styles.infoText}>{item.customer_phone || 'غير متوفر'}</Text>
            </TouchableOpacity>
            <View style={styles.infoRow}>
              <Ionicons name="location-outline" size={16} color="#6B7280" />
              <Text style={styles.infoText} numberOfLines={2}>{item.customer_address || 'عنوان غير متوفر'}</Text>
            </View>
          </View>
        ) : (
          // ✅ للطلبات المنتهية: عرض ملخص فقط بدون بيانات العميل
          <View style={styles.summaryContainer}>
            {item.items && item.items.length > 0 && (
              <Text style={styles.summaryText} numberOfLines={2}>
                المنتجات: {item.items.slice(0, 2).join(', ')}
                {item.items.length > 2 ? ` +${item.items.length - 2}` : ''}
              </Text>
            )}
            {(item.total_price > 0 || item.delivery_fee > 0) && (
              <Text style={styles.summaryPrice}>الإجمالي: {(item.total_price || 0) + (item.delivery_fee || 0)} ج</Text>
            )}
          </View>
        )}

        <View style={styles.deliveryFooter}>
          <Text style={styles.deliveryDate}>
            {formatDate(item.created_at)}
          </Text>
        </View>
        
        {(cancelled || completed) && (
          <View style={styles.invalidBadge}>
            <Text style={styles.invalidText}>{cancelled ? 'ملغي' : 'تم التسليم'}</Text>
          </View>
        )}
      </Container>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3B82F6" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setDrawerVisible(true)} style={styles.menuButton}>
          <Ionicons name="menu" size={28} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>توصيلاتي</Text>
        <TouchableOpacity onPress={onRefresh}>
          <Ionicons name="refresh-outline" size={24} color="#3B82F6" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'active' && styles.activeTab]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}>
            الحالية ({deliveries.filter(d => d.status !== ORDER_STATUS.DELIVERED && d.status !== ORDER_STATUS.CANCELLED).length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'completed' && styles.activeTab]}
          onPress={() => setActiveTab('completed')}
        >
          <Text style={[styles.tabText, activeTab === 'completed' && styles.activeTabText]}>
            السابقة ({deliveries.filter(d => d.status === ORDER_STATUS.DELIVERED).length})
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        contentContainerStyle={styles.list}
      >
        {deliveries.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="bicycle-outline" size={60} color="#E5E7EB" />
            <Text style={styles.emptyText}>لا توجد توصيلات</Text>
          </View>
        ) : (
          deliveries.map((delivery) => renderDelivery({ item: delivery }))
        )}
      </ScrollView>

      <Modal visible={drawerVisible} transparent animationType="slide">
        <View style={styles.drawerOverlay}>
          <View style={styles.drawerContent}>
            <CustomDrawer
              isLoggedIn={true}
              userData={driverData}
              onClose={() => setDrawerVisible(false)}
              navigation={propsNavigation}
              onOpenAdminModal={() => {}}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  menuButton: { padding: 8 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', flex: 1, textAlign: 'center' },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 20,
    marginHorizontal: 4,
  },
  activeTab: { backgroundColor: '#3B82F6' },
  tabText: { fontSize: 14, color: '#6B7280' },
  activeTabText: { color: '#FFF', fontWeight: '600' },
  list: { padding: 16 },
  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  emptyText: { marginTop: 12, fontSize: 14, color: '#6B7280' },
  deliveryCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    position: 'relative',
  },
  disabledCard: {
    opacity: 0.7,
    backgroundColor: '#F9FAFB',
  },
  deliveryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  deliveryId: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600' },
  customerInfo: { marginBottom: 12 },
  summaryContainer: { marginBottom: 12, padding: 8, backgroundColor: '#F3F4F6', borderRadius: 8 },
  summaryText: { fontSize: 13, color: '#4B5563', marginBottom: 4 },
  summaryPrice: { fontSize: 13, fontWeight: '600', color: '#F59E0B' },
  infoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6, gap: 8 },
  infoText: { fontSize: 14, color: '#4B5563', flex: 1 },
  deliveryFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  deliveryDate: { fontSize: 12, color: '#9CA3AF' },
  invalidBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#10B981', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12 },
  invalidText: { color: '#FFF', fontSize: 10, fontWeight: '600' },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  drawerContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 25, borderTopRightRadius: 25, height: '80%', overflow: 'hidden' },
});
