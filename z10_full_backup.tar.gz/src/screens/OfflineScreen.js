import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Easing, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { fontFamily } from '../utils/fonts';

export default function OfflineScreen({ navigation }) {
  const [isChecking, setIsChecking] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(-30)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ])
    ).start();

    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]).start();
  }, []);

  const checkConnection = async () => {
    setIsChecking(true);
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const response = await fetch('https://www.google.com', { 
        method: 'HEAD', 
        signal: controller.signal 
      });
      clearTimeout(timeout);
      if (response.ok) {
        navigation.replace('Splash');
      } else {
        setIsChecking(false);
      }
    } catch (error) {
      setIsChecking(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <Animated.View style={[styles.content, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        <Animated.View style={[styles.iconContainer, { transform: [{ scale: pulseAnim }] }]}>
          <View style={styles.wifiIconWrapper}>
            <Ionicons name="wifi-outline" size={60} color="#9CA3AF" />
            <View style={styles.crossLine} />
          </View>
        </Animated.View>

        <Text style={styles.title}>لا يوجد اتصال</Text>
        <Text style={styles.subtitle}>
          يبدو أنك غير متصل بالإنترنت.{'\n'}يرجى التحقق من اتصالك والمحاولة مرة أخرى.
        </Text>

        <TouchableOpacity 
          style={styles.retryButton} 
          onPress={checkConnection} 
          disabled={isChecking}
          activeOpacity={0.8}
        >
          <Ionicons name="refresh" size={20} color="#FFF" style={{ marginRight: 8 }} />
          <Text style={styles.retryButtonText}>
            {isChecking ? 'جاري التحقق...' : 'أعد المحاولة'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.offlineButton} onPress={() => navigation.replace('MainTabs')}>
          <Text style={styles.offlineButtonText}>المتابعة بدون إنترنت</Text>
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center' },
  content: { alignItems: 'center', paddingHorizontal: 40 },
  iconContainer: { width: 110, height: 110, borderRadius: 55, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginBottom: 30 },
  wifiIconWrapper: { position: 'relative' },
  crossLine: { position: 'absolute', width: 70, height: 3, backgroundColor: '#EF4444', transform: [{ rotate: '-45deg' }], top: 28, left: -5, borderRadius: 2 },
  title: { fontSize: 22, fontWeight: '700', color: '#1F2937', marginBottom: 12, fontFamily: fontFamily.arabic },
  subtitle: { fontSize: 15, color: '#6B7280', textAlign: 'center', lineHeight: 24, marginBottom: 36, fontFamily: fontFamily.arabic },
  retryButton: { flexDirection: 'row', backgroundColor: '#4F46E5', paddingVertical: 14, paddingHorizontal: 32, borderRadius: 14, alignItems: 'center', marginBottom: 16, elevation: 2, shadowColor: '#4F46E5', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
  retryButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600', fontFamily: fontFamily.arabic },
  offlineButton: { paddingVertical: 8, paddingHorizontal: 16 },
  offlineButtonText: { color: '#9CA3AF', fontSize: 14, fontFamily: fontFamily.arabic },
});
