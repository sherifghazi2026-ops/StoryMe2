import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getMerchantsByType } from '../services/merchantService';
import { getProviderAverageRating } from '../services/reviewService';
import DynamicMongez from '../components/DynamicMongez';
import { fontFamily } from '../utils/fonts';

export default function MerchantsListScreen({ navigation, route }) {
  const { serviceType, serviceName, serviceHeaderImage, isFullService, subServices, regionId } = route.params;
  const [merchants, setMerchants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [ratings, setRatings] = useState({});

  useEffect(() => { loadMerchants(); }, []);

  const loadMerchants = async () => {
    const result = await getMerchantsByType(serviceType, regionId);
    if (result.success) {
      setMerchants(result.data);
      result.data.forEach(async (m) => {
        const avg = await getProviderAverageRating(m.id);
        if (avg.success) {
          setRatings(prev => ({ ...prev, [m.id]: avg }));
        }
      });
    }
    setLoading(false);
    setRefreshing(false);
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Ionicons
          key={i}
          name={i <= Math.round(rating) ? 'star' : 'star-outline'}
          size={12}
          color={i <= Math.round(rating) ? '#F59E0B' : '#D1D5DB'}
        />
      );
    }
    return stars;
  };

  const renderMerchant = ({ item }) => {
    const rating = ratings[item.id] || { average: 0, count: 0 };

    return (
      <TouchableOpacity
        style={styles.merchantCard}
        onPress={() => {
          if (isFullService && subServices) {
            navigation.navigate('FullServiceFlow', {
              fullServiceId: serviceType,
              merchantId: item.id,
              merchantName: item.name,
              merchantImage: item.image_url,
              serviceType: serviceType,
              subServices: subServices,
              serviceName: serviceName,
              serviceHeaderImage: serviceHeaderImage,
              regionId: regionId
            });
          } else {
            navigation.navigate('MerchantProductsScreen', {
              merchantId: item.id,
              merchantName: item.name,
              merchantImage: item.image_url,
              serviceType: serviceType,
              serviceName: serviceName,
              serviceHeaderImage: serviceHeaderImage
            });
          }
        }}
        activeOpacity={0.9}
      >
        <View style={styles.merchantImageContainer}>
          {item.image_url ? (
            <Image source={{ uri: item.image_url }} style={styles.merchantImage} />
          ) : (
            <View style={styles.merchantPlaceholder}>
              <Ionicons name="storefront-outline" size={40} color="#9CA3AF" />
            </View>
          )}
        </View>

        <View style={styles.merchantInfo}>
          <Text style={styles.merchantName} numberOfLines={1}>{item.name}</Text>
          {item.place_name && (
            <View style={styles.placeRow}>
              <Ionicons name="location-outline" size={12} color="#6B7280" />
              <Text style={styles.placeText}>{item.place_name}</Text>
            </View>
          )}
          <View style={styles.ratingRow}>
            {renderStars(rating.average)}
            <Text style={styles.ratingText}>{rating.average.toFixed(1)}</Text>
            <Text style={styles.ratingCount}>({rating.count})</Text>
          </View>
        </View>

        <Ionicons name="chevron-forward" size={20} color="#D1D5DB" style={styles.chevron} />
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color="#1F2937" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{serviceName}</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#4F46E5" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{serviceName}</Text>
        <View style={{ width: 40 }} />
      </View>

      {serviceHeaderImage && (
        <View style={styles.headerImageContainer}>
          <Image source={{ uri: serviceHeaderImage }} style={styles.headerImage} />
        </View>
      )}

      {merchants.length === 0 ? (
        <View style={styles.center}>
          <Ionicons name="storefront-outline" size={60} color="#E5E7EB" />
          <Text style={styles.emptyText}>لا يوجد تجار في هذه الخدمة</Text>
        </View>
      ) : (
        <FlatList
          data={merchants}
          keyExtractor={(item) => item.id}
          renderItem={renderMerchant}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadMerchants(); }} />
          }
        />
      )}

      <DynamicMongez screen="merchants_list" navigation={navigation} contextData={{ serviceType, serviceName }} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#FFF',
    borderBottomWidth: 1, borderBottomColor: '#F0F0F0',
  },
  backBtn: { padding: 8, borderRadius: 8, backgroundColor: '#F3F4F6' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', fontFamily: fontFamily.arabic },
  headerImageContainer: { width: '100%', height: 120 },
  headerImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 12, fontFamily: fontFamily.arabic },
  listContent: { padding: 16 },
  merchantCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF',
    borderRadius: 12, padding: 12, marginBottom: 10, borderWidth: 1,
    borderColor: '#E5E7EB', elevation: 1,
  },
  merchantImageContainer: { marginRight: 12 },
  merchantImage: { width: 56, height: 56, borderRadius: 12 },
  merchantPlaceholder: {
    width: 56, height: 56, borderRadius: 12, backgroundColor: '#F3F4F6',
    justifyContent: 'center', alignItems: 'center',
  },
  merchantInfo: { flex: 1 },
  merchantName: { fontSize: 15, fontWeight: '600', color: '#1F2937', fontFamily: fontFamily.arabic },
  placeRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4, gap: 4 },
  placeText: { fontSize: 12, color: '#6B7280', fontFamily: fontFamily.arabic },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6, gap: 3 },
  ratingText: { fontSize: 12, fontWeight: '600', color: '#F59E0B' },
  ratingCount: { fontSize: 11, color: '#9CA3AF' },
  chevron: { marginLeft: 8 },
});
