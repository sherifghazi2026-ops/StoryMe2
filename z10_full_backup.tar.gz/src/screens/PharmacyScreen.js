import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useAudioPlayer } from 'expo-audio';

export default function PharmacyScreen() {
  const [orderStatus, setOrderStatus] = useState('pending');
  
  // استخدام expo-audio لتشغيل الصوت
  const notificationPlayer = useAudioPlayer(require('../../assets/sounds/notification.mp3'));
  const successPlayer = useAudioPlayer(require('../../assets/sounds/success.mp3'));
  
  const placeOrder = async () => {
    try {
      // تشغيل صوت الإشعار عند تقديم الطلب
      await notificationPlayer.play();
      
      // محاكاة تقديم الطلب
      setTimeout(async () => {
        setOrderStatus('completed');
        // تشغيل صوت النجاح عند اكتمال الطلب
        await successPlayer.play();
      }, 2000);
      
    } catch (error) {
      console.error('خطأ في تقديم الطلب:', error);
    }
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>صيدلية زيد</Text>
      <TouchableOpacity style={styles.button} onPress={placeOrder}>
        <Text style={styles.buttonText}>تقديم طلب</Text>
      </TouchableOpacity>
      <Text style={styles.status}>الحالة: {orderStatus}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  status: {
    fontSize: 16,
    color: '#6B7280',
  },
});
