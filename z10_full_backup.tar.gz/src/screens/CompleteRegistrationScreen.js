import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  Alert, ActivityIndicator, ScrollView, StatusBar, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';
import { fontFamily } from '../utils/fonts';

const appIcon = require('../../assets/icons/ZidiconSP.png');

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export default function CompleteRegistrationScreen({ navigation, route }) {
  const { name, phone, pendingOrderId } = route.params;

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [appLogoUrl, setAppLogoUrl] = useState(null);

  useEffect(() => {
    supabase.from('app_settings').select('value').eq('key', 'app_logo_url').single().then(({ data }) => {
      if (data?.value) setAppLogoUrl(data.value);
    });
  }, []);

  const handleComplete = async () => {
    if (!password) { Alert.alert('تنبيه', 'الرجاء إدخال كلمة المرور'); return; }
    if (password !== confirmPassword) { Alert.alert('تنبيه', 'كلمة المرور غير متطابقة'); return; }
    if (password.length < 4) { Alert.alert('تنبيه', 'كلمة المرور يجب أن تكون 4 أحرف على الأقل'); return; }

    setLoading(true);
    try {
      const { data: existing, error: checkError } = await supabase.from(TABLES.PROFILES).select('id').eq('phone', phone).limit(1);
      if (checkError) throw checkError;
      if (existing && existing.length > 0) { Alert.alert('خطأ', 'رقم الهاتف مسجل مسبقاً'); setLoading(false); return; }

      const newUserId = generateUUID();
      const newUser = {
        id: newUserId, full_name: name, phone: phone, password: password,
        role: 'customer', active: true, profile_completed: true,
        created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
      };

      const { data: user, error: insertError } = await supabase.from(TABLES.PROFILES).insert([newUser]).select().single();
      if (insertError) throw insertError;

      const userDataToStore = { id: user.id, $id: user.id, full_name: user.full_name, name: user.full_name, phone: user.phone, role: 'customer' };
      await AsyncStorage.setItem('userData', JSON.stringify(userDataToStore));
      await AsyncStorage.setItem('userRole', 'customer');
      await AsyncStorage.setItem('userName', name);
      await AsyncStorage.setItem('userPhone', phone);

      Alert.alert('مرحباً بك', 'تم إنشاء حسابك بنجاح وتسجيل الدخول تلقائياً');
      navigation.replace('MainTabs');
    } catch (error) { Alert.alert('خطأ', 'فشل في إنشاء الحساب'); }
    finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-forward" size={28} color="#1F2937" /></TouchableOpacity>
        <Text style={[styles.headerTitle, { fontFamily: fontFamily.arabic }]}>إكمال التسجيل</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.logoContainer}>
          {appLogoUrl ? <Image source={{ uri: appLogoUrl }} style={styles.logo} resizeMode="contain" onError={() => setAppLogoUrl(null)} /> : <Image source={appIcon} style={styles.logo} resizeMode="contain" />}
        </View>

        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Ionicons name="person-outline" size={20} color="#6B7280" />
            <Text style={[styles.infoLabel, { fontFamily: fontFamily.arabic }]}>الاسم</Text>
            <Text style={[styles.infoValue, { fontFamily: fontFamily.arabic }]}>{name}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Ionicons name="call-outline" size={20} color="#6B7280" />
            <Text style={[styles.infoLabel, { fontFamily: fontFamily.arabic }]}>رقم الهاتف</Text>
            <Text style={[styles.infoValue, { fontFamily: fontFamily.arabic }]}>{phone}</Text>
          </View>
        </View>

        <View style={styles.passwordSection}>
          <Text style={[styles.passwordLabel, { fontFamily: fontFamily.arabic }]}>كلمة المرور *</Text>
          <View style={styles.passwordContainer}>
            <TextInput style={[styles.passwordInput, { fontFamily: fontFamily.arabic }]} placeholder="أدخل كلمة المرور" placeholderTextColor="#9CA3AF" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} editable={!loading} />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}><Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={22} color="#9CA3AF" /></TouchableOpacity>
          </View>

          <Text style={[styles.passwordLabel, { fontFamily: fontFamily.arabic }]}>تأكيد كلمة المرور *</Text>
          <View style={styles.passwordContainer}>
            <TextInput style={[styles.passwordInput, { fontFamily: fontFamily.arabic }]} placeholder="أعد إدخال كلمة المرور" placeholderTextColor="#9CA3AF" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry={!showConfirmPassword} editable={!loading} />
            <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.eyeIcon}><Ionicons name={showConfirmPassword ? "eye-off-outline" : "eye-outline"} size={22} color="#9CA3AF" /></TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={[styles.completeButton, loading && styles.disabled]} onPress={handleComplete} disabled={loading}>
          {loading ? <ActivityIndicator color="#FFF" /> : <Text style={[styles.completeButtonText, { fontFamily: fontFamily.arabic }]}>إكمال التسجيل</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  content: { paddingHorizontal: 24, paddingBottom: 40 },
  logoContainer: { alignItems: 'center', marginTop: 20, marginBottom: 32 },
  logo: { width: 200, height: 100 },
  infoCard: { backgroundColor: '#F9FAFB', borderRadius: 16, paddingVertical: 16, paddingHorizontal: 20, marginBottom: 32, borderWidth: 1, borderColor: '#F0F0F0' },
  infoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  infoLabel: { fontSize: 14, color: '#6B7280', width: 70, marginLeft: 12 },
  infoValue: { fontSize: 14, fontWeight: '500', color: '#1F2937', flex: 1 },
  divider: { height: 1, backgroundColor: '#F0F0F0', marginVertical: 4 },
  passwordSection: { marginBottom: 32 },
  passwordLabel: { fontSize: 14, fontWeight: '600', color: '#4B5563', marginBottom: 8 },
  passwordContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, marginBottom: 20, height: 52, paddingHorizontal: 16 },
  passwordInput: { flex: 1, fontSize: 15, color: '#1F2937' },
  eyeIcon: { padding: 8 },
  completeButton: { backgroundColor: '#4F46E5', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  disabled: { opacity: 0.6 },
  completeButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },
});
