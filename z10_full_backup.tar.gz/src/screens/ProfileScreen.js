import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert,
  ActivityIndicator, Image, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabaseClient';
import { TABLES } from '../lib/tables';
import * as Location from 'expo-location';
import { uploadProfileImage, uploadToImageKit } from '../services/uploadService';
import { fontFamily } from '../utils/fonts';

const appIcon = require('../../assets/icons/ZidiconSP.png');

export default function ProfileScreen({ navigation }) {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [serviceArea, setServiceArea] = useState('');
  const [maxRadius, setMaxRadius] = useState('');
  const [deliveryFee, setDeliveryFee] = useState('');
  const [image, setImage] = useState(null);
  const [imageApproved, setImageApproved] = useState(null);
  const [bio, setBio] = useState('');
  const [bioApproved, setBioApproved] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [isServiceMerchant, setIsServiceMerchant] = useState(false);
  const [editBioModalVisible, setEditBioModalVisible] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [regions, setRegions] = useState([]);
  const [showRegionPicker, setShowRegionPicker] = useState(false);
  const [newBio, setNewBio] = useState('');
  const [hasDriver, setHasDriver] = useState(false); // ✅ تفعيل المندوب

  useFocusEffect(useCallback(() => { loadUserDataFromSupabase(); loadRegions(); }, []));

  const loadUserDataFromSupabase = async () => {
    setLoading(true);
    try {
      const localData = await AsyncStorage.getItem('userData');
      if (!localData) { setLoading(false); return; }
      const localUser = JSON.parse(localData);
      const userId = localUser.id || localUser.$id;
      const { data: profile } = await supabase.from(TABLES.PROFILES).select('*').eq('id', userId).single();
      if (!profile) { setLoading(false); return; }
      setUserData(profile);
      setName(profile.full_name || profile.name || '');
      setPhone(profile.phone || '');
      setAddress(profile.address || '');
      setServiceArea(profile.service_area || '');
      setMaxRadius(profile.max_delivery_radius?.toString() || '');
      setDeliveryFee(profile.delivery_fee?.toString() || '');
      setImage(profile.image_url || null);
      setImageApproved(profile.image_approved);
      setBio(profile.bio || '');
      setBioApproved(profile.bio_approved);
      const rawDocs = profile.documents;
      const parsedDocs = typeof rawDocs === 'string' ? JSON.parse(rawDocs) : (rawDocs || []);
      setDocuments(parsedDocs);
      setIsServiceMerchant(profile.role === 'merchant');
      if (profile.region_id) setSelectedRegion(profile.region_id);
      
      // ✅ تحميل has_driver من جدول merchants
      if (profile.role === 'merchant') {
        const { data: merchant } = await supabase.from('merchants').select('has_driver').eq('user_id', userId).single();
        if (merchant) setHasDriver(merchant.has_driver || false);
      }
      
      await AsyncStorage.setItem('userData', JSON.stringify(profile));
    } catch (error) { console.error(error); }
    finally { setLoading(false); }
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const uploadResult = await uploadProfileImage(result.assets[0].uri, name || 'user');
      setUploading(false);
      if (uploadResult.success) { setImage(uploadResult.fileUrl); setImageApproved(null); }
    }
  };

  const removeImage = () => {
    Alert.alert('حذف الصورة', 'هل تريد حذف صورتك الشخصية؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => { setImage(null); setImageApproved(null); } },
    ]);
  };

  const pickDocument = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.8 });
    if (!result.canceled && result.assets?.length > 0) {
      setUploading(true);
      const uploadResult = await uploadToImageKit(result.assets[0].uri, `doc_${Date.now()}.jpg`, 'documents', userData?.name || 'merchant');
      setUploading(false);
      if (uploadResult.success) setDocuments(prev => [...(prev || []), { url: uploadResult.fileUrl, approved: null }]);
    }
  };

  const removeItem = (arr, setArr, index) => setArr(arr.filter((_, i) => i !== index));

  const handleSave = async () => {
    if (!name.trim()) return Alert.alert('تنبيه', 'الاسم مطلوب');
    setSaving(true);
    try {
      const updateData = {
        full_name: name.trim(),
        address: address.trim(),
        service_area: serviceArea.trim(),
        max_delivery_radius: maxRadius ? parseFloat(maxRadius) : null,
        delivery_fee: deliveryFee ? parseFloat(deliveryFee) : null,
        region_id: selectedRegion,
        image_url: image,
        image_approved: imageApproved,
        bio: bio,
        bio_approved: bioApproved,
        documents: documents,
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase.from(TABLES.PROFILES).update(updateData).eq('id', userData.id);
      if (error) throw error;
      
      // ✅ حفظ has_driver في جدول merchants
      if (userData?.role === 'merchant') {
        await supabase.from('merchants').update({ has_driver: hasDriver }).eq('user_id', userData.id);
      }
      
      await loadUserDataFromSupabase();
      navigation.goBack();
    } catch (error) { Alert.alert('خطأ', error.message); }
    finally { setSaving(false); }
  };

  const getCurrentLocation = async () => {};

  const loadRegions = async () => {
    const { data } = await supabase.from('regions').select('*').eq('is_active', true).order('name');
    if (data) setRegions(data);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#2563EB" /></View>;

  const isMerchant = userData?.role === 'merchant';

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.content}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={28} color="#1F2937" /></TouchableOpacity>
            <Text style={styles.headerTitle}>الملف الشخصي</Text>
            <View style={{ width: 28 }} />
          </View>

          <View style={styles.avatarSection}>
            <TouchableOpacity onPress={pickImage} disabled={uploading} style={styles.avatarWrapper}>
              {image ? <Image source={{ uri: image }} style={styles.avatar} /> : <View style={styles.avatar}><Image source={appIcon} style={styles.avatarImage} /></View>}
              <View style={styles.cameraIcon}>{uploading ? <ActivityIndicator color="#FFF" size="small" /> : <Ionicons name="camera" size={22} color="#FFF" />}</View>
            </TouchableOpacity>
            {image && (
              <TouchableOpacity onPress={removeImage} style={styles.removeImageBtn}>
                <Ionicons name="trash-outline" size={18} color="#EF4444" />
                <Text style={styles.removeImageText}>حذف الصورة</Text>
              </TouchableOpacity>
            )}
            <Text style={styles.userName}>{name || 'اسم المستخدم'}</Text>
          </View>

          {isMerchant && (
            <>
              <View style={styles.sectionCard}>
                <View style={styles.rowHeader}>
                  <Ionicons name="document-text-outline" size={22} color="#2563EB" />
                  <Text style={styles.sectionTitle}>نبذة عن النشاط</Text>
                  <TouchableOpacity onPress={() => { setNewBio(bio); setEditBioModalVisible(true); }}><Ionicons name="create-outline" size={20} color="#2563EB" /></TouchableOpacity>
                </View>
                <Text style={styles.bioText}>{bio || 'أضف نبذة تعريفية عن نشاطك...'}</Text>
              </View>
              <View style={styles.sectionCard}>
                <View style={styles.rowHeader}>
                  <Ionicons name="folder-open-outline" size={22} color="#2563EB" />
                  <Text style={styles.sectionTitle}>ملفات التوثيق</Text>
                  <TouchableOpacity onPress={pickDocument} disabled={uploading}>
                    <Ionicons name="add-circle" size={26} color="#2563EB" />
                  </TouchableOpacity>
                </View>
                {documents.length > 0 ? (
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {documents.map((doc, i) => (
                      <View key={i} style={styles.thumbItem}>
                        <Image source={{ uri: doc.url }} style={styles.thumbImage} />
                        {doc.approved !== true && (
                          <TouchableOpacity style={styles.removeBtn} onPress={() => removeItem(documents, setDocuments, i)}>
                            <Ionicons name="close-circle" size={22} color="#EF4444" />
                          </TouchableOpacity>
                        )}
                        {doc.approved === true && (
                          <View style={styles.approvedCheck}>
                            <Ionicons name="checkmark-circle" size={22} color="#10B981" />
                          </View>
                        )}
                      </View>
                    ))}
                  </ScrollView>
                ) : (
                  <Text style={styles.emptyText}>ارفع صور المستندات المطلوبة (سجل تجاري، بطاقة ضريبية، شهادة صحية)</Text>
                )}
              </View>
            </>
          )}

          <View style={styles.formCard}>
            <Text style={[styles.sectionTitle, { marginBottom: 20 }]}>معلوماتي</Text>
            <Text style={styles.label}>الاسم الكامل</Text>
            <TextInput style={[styles.input, { backgroundColor: '#F1F5F9', color: '#64748B' }]} value={name} editable={false} />
            <View style={styles.phoneContainer}><Text style={styles.phoneText}>{phone || 'غير متوفر'}</Text></View>
            <TouchableOpacity style={styles.locationButton} onPress={getCurrentLocation} disabled={gettingLocation}>
              {gettingLocation ? <ActivityIndicator color="#2563EB" /> : <><Ionicons name="location" size={22} color="#2563EB" /><Text style={styles.locationButtonText}>تحديد موقعي الحالي</Text></>}
            </TouchableOpacity>
            <TextInput style={styles.input} value={address} onChangeText={setAddress} placeholder="العنوان بالتفصيل" multiline />
            {isMerchant ? (
              <>
                <Text style={styles.label}>منطقة الخدمة</Text>
                <TextInput style={styles.input} value={serviceArea} onChangeText={setServiceArea} placeholder="منطقة الخدمة" />
                <Text style={styles.label}>أقصى مسافة توصيل (كم)</Text>
                <TextInput style={styles.input} value={maxRadius} onChangeText={setMaxRadius} keyboardType="numeric" placeholder="المسافة" />
                <Text style={styles.label}>رسوم التوصيل (ج)</Text>
                <TextInput style={styles.input} value={deliveryFee} onChangeText={setDeliveryFee} keyboardType="numeric" placeholder="الرسوم" />
                
                {/* ✅ Toggle تفعيل المندوب */}
                <View style={styles.switchRow}>
                  <View>
                    <Text style={styles.label}>تفعيل المندوب</Text>
                    <Text style={styles.hintText}>اختيار مندوب أو توصيل بنفسي</Text>
                  </View>
                  <TouchableOpacity 
                    style={[styles.toggleSwitch, hasDriver && styles.toggleSwitchActive]} 
                    onPress={() => setHasDriver(!hasDriver)}
                  >
                    <View style={[styles.toggleKnob, hasDriver && styles.toggleKnobActive]} />
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <>
                <Text style={styles.label}>المنطقة</Text>
                <TouchableOpacity style={styles.regionPickerBtn} onPress={() => setShowRegionPicker(true)}>
                  <Text style={styles.regionPickerText}>{regions.find(r => r.id === selectedRegion)?.name || 'اختر المنطقة'}</Text>
                  <Ionicons name="chevron-down" size={20} color="#2563EB" />
                </TouchableOpacity>
              </>
            )}
            <TouchableOpacity style={[styles.saveButton, saving && styles.disabled]} onPress={handleSave} disabled={saving}>
              {saving ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveButtonText}>حفظ التغييرات</Text>}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={showRegionPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <Text style={styles.modalTitle}>اختر المنطقة</Text>
          {regions.map((region) => (
            <TouchableOpacity
              key={region.id}
              style={[styles.regionOption, selectedRegion === region.id && styles.regionOptionActive]}
              onPress={() => { setSelectedRegion(region.id); setShowRegionPicker(false); }}
            >
              <Text style={[styles.regionOptionText, selectedRegion === region.id && styles.regionOptionTextActive]}>{region.name}</Text>
              {selectedRegion === region.id && <Ionicons name="checkmark" size={20} color="#2563EB" />}
            </TouchableOpacity>
          ))}
          <TouchableOpacity onPress={() => setShowRegionPicker(false)} style={{ marginTop: 16, alignItems: 'center' }}>
            <Text style={{ color: '#EF4444', fontSize: 15 }}>إلغاء</Text>
          </TouchableOpacity>
        </View></View>
      </Modal>

      <Modal visible={editBioModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.modalContent}>
          <Text style={styles.modalTitle}>نبذة عن النشاط</Text>
          <TextInput style={styles.bioInput} value={newBio} onChangeText={setNewBio} placeholder="اكتب نبذة عن نشاطك التجاري..." multiline numberOfLines={6} />
          <View style={styles.modalButtons}>
            <TouchableOpacity style={styles.modalCancel} onPress={() => setEditBioModalVisible(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity>
            <TouchableOpacity style={styles.modalSave} onPress={() => { setBio(newBio); setBioApproved(null); setEditBioModalVisible(false); }}><Text style={styles.saveBtnText}>حفظ</Text></TouchableOpacity>
          </View>
        </View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, marginBottom: 10 },
  headerTitle: { fontSize: 21, fontWeight: '700', color: '#1F2937' },
  avatarSection: { alignItems: 'center', marginBottom: 30 },
  avatarWrapper: { position: 'relative' },
  avatar: { width: 130, height: 130, borderRadius: 65, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', borderWidth: 4, borderColor: '#EFF6FF' },
  avatarImage: { width: 90, height: 90, resizeMode: 'contain' },
  cameraIcon: { position: 'absolute', bottom: 8, right: 8, backgroundColor: '#2563EB', borderRadius: 22, width: 44, height: 44, justifyContent: 'center', alignItems: 'center', borderWidth: 3, borderColor: '#FFF' },
  removeImageBtn: { flexDirection: 'row', alignItems: 'center', marginTop: 10, padding: 8, gap: 6 },
  removeImageText: { fontSize: 13, color: '#EF4444', fontWeight: '500' },
  userName: { fontSize: 24, fontWeight: '700', color: '#1F2937', marginTop: 16 },
  sectionCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 20, marginBottom: 16, elevation: 3 },
  rowHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1F2937', flex: 1 },
  bioText: { fontSize: 15, color: '#475569', lineHeight: 22 },
  emptyText: { fontSize: 13, color: '#94A3B8', textAlign: 'center', padding: 10 },
  thumbItem: { marginRight: 12, position: 'relative' },
  thumbImage: { width: 90, height: 90, borderRadius: 12 },
  removeBtn: { position: 'absolute', top: -6, right: -6, backgroundColor: '#FFF', borderRadius: 12 },
  approvedCheck: { position: 'absolute', top: -6, right: -6, backgroundColor: '#FFF', borderRadius: 12, padding: 1 },
  formCard: { backgroundColor: '#FFF', borderRadius: 24, padding: 24, elevation: 3, marginBottom: 20 },
  label: { fontSize: 14, color: "#64748B", marginBottom: 8, marginTop: 12, fontWeight: "500" },
  input: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 16, fontSize: 16 },
  phoneContainer: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 16, marginBottom: 12 },
  phoneText: { fontSize: 16, color: '#1F2937' },
  locationButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EFF6FF', padding: 16, borderRadius: 16, marginVertical: 12, gap: 10 },
  locationButtonText: { color: '#2563EB', fontSize: 16, fontWeight: '600' },
  saveButton: { backgroundColor: '#2563EB', padding: 18, borderRadius: 18, alignItems: 'center', marginTop: 24 },
  saveButtonText: { color: '#FFF', fontSize: 17, fontWeight: '700' },
  disabled: { opacity: 0.7 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FFF', borderRadius: 24, padding: 24, width: '100%', maxWidth: 420 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: '#1F2937', textAlign: 'center', marginBottom: 20 },
  bioInput: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 16, minHeight: 140, fontSize: 16, textAlignVertical: 'top' },
  modalButtons: { flexDirection: 'row', gap: 12, marginTop: 24 },
  modalCancel: { flex: 1, backgroundColor: '#F1F5F9', padding: 16, borderRadius: 16, alignItems: 'center' },
  modalSave: { flex: 1, backgroundColor: '#2563EB', padding: 16, borderRadius: 16, alignItems: 'center' },
  cancelText: { color: '#1F2937', fontSize: 16, fontWeight: '600' },
  saveBtnText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  regionPickerBtn: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 16 },
  regionPickerText: { fontSize: 16, color: '#1F2937' },
  regionOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  regionOptionActive: { backgroundColor: '#EFF6FF' },
  regionOptionText: { fontSize: 16, color: '#1F2937' },
  regionOptionTextActive: { color: '#2563EB', fontWeight: '600' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  // ✅ Toggle Styles
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, marginBottom: 4 },
  hintText: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  toggleSwitch: { width: 50, height: 28, borderRadius: 14, backgroundColor: '#D1D5DB', padding: 2, justifyContent: 'center' },
  toggleSwitchActive: { backgroundColor: '#10B981' },
  toggleKnob: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFF' },
  toggleKnobActive: { marginLeft: 'auto' },
});
