import React, { useState, useEffect } from 'react';
import {
  View, StyleSheet, TouchableOpacity, Text, TextInput, ScrollView,
  Image, Alert, ActivityIndicator, Modal, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createOrder } from '../services/orderService';
import { playSendSound } from '../utils/SoundHelper';
import { supabase } from '../lib/supabaseClient';
import { getServiceFields, getServiceFieldsByServiceId } from '../services/fullServiceService';

const { width } = Dimensions.get('window');
const COL_WIDTH = (width - 80) / 7;
const MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const WEEKDAYS = ['سبت','أحد','إثنين','ثلاثاء','أربعاء','خميس','جمعة'];

export default function FullServiceFieldScreen({ navigation, route }) {
  const { serviceType, subServiceName, merchantId, merchantName, serviceHeaderImage, subServiceImage } = route.params;
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [sending, setSending] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [allFields, setAllFields] = useState([]);
  const [formData, setFormData] = useState({});
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [currentDateField, setCurrentDateField] = useState(null);
  const [selectedDay, setSelectedDay] = useState(1);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const headerImg = subServiceImage || serviceHeaderImage;

  useEffect(() => { loadUserData(); loadFields(); }, []);

  const loadUserData = async () => {
    const data = await AsyncStorage.getItem('userData');
    if (data) {
      const user = JSON.parse(data);
      setUserData(user); setIsLoggedIn(true);
      setName(user.full_name || user.name || '');
      setPhone(user.phone || '');
    }
  };

  const loadFields = async () => {
    try {
      let fields = await getServiceFieldsByServiceId(subServiceName);
      if (!fields || fields.length === 0) {
        const { data: fs } = await supabase.from('full_services').select('id').eq('service_id', serviceType).single();
        if (fs) {
          const { data: subs } = await supabase.from('sub_services').select('*').eq('full_service_id', fs.id).eq('name', subServiceName);
          if (subs?.length) { fields = await getServiceFields(subs[0].id); }
        }
      }
      setAllFields(fields || []);
      const initial = {}; (fields || []).forEach(f => { initial[f.field_name] = ''; });
      setFormData(initial);
    } catch (error) { console.error('خطأ في تحميل الحقول:', error); }
    finally { setLoading(false); }
  };

  const updateField = (f, v) => {
    setFormData(p => {
      const updated = { ...p, [f]: v };
      allFields.forEach(field => { if (field.show_when_field === f) updated[field.field_name] = ''; });
      return updated;
    });
  };

  const visibleFields = allFields.filter(field => {
    if (!field.show_when_field) return true;
    const pv = formData[field.show_when_field];
    const vals = (field.show_when_value || '').split(',').map(v => v.trim());
    return vals.includes(pv);
  });

  const openDatePicker = (fieldName) => {
    setCurrentDateField(fieldName);
    const val = formData[fieldName];
    if (val) { const d = new Date(val); if (!isNaN(d.getTime())) { setSelectedDay(d.getDate()); setSelectedMonth(d.getMonth()); setSelectedYear(d.getFullYear()); } }
    setShowDatePicker(true);
  };

  const confirmDate = () => {
    const d = new Date(selectedYear, selectedMonth, selectedDay);
    updateField(currentDateField, `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
    setShowDatePicker(false);
  };

  const jsDay = new Date(selectedYear, selectedMonth, 1).getDay();
  const firstDay = (jsDay + 1) % 7;
  const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
  const blanks = Array(firstDay).fill(null);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const validate = () => {
    if (!name.trim()) { Alert.alert('تنبيه', 'الاسم مطلوب'); return false; }
    if (!phone.trim() || phone.length < 10) { Alert.alert('تنبيه', 'رقم هاتف صحيح مطلوب'); return false; }
    for (const f of visibleFields) { if (f.is_required && !formData[f.field_name]?.trim()) { Alert.alert('تنبيه', `حقل "${f.field_label}" مطلوب`); return false; } }
    return true;
  };

  const sendOrder = async () => {
    if (!validate()) return;
    setSending(true);
    try {
      const items = visibleFields.map(f => formData[f.field_name] ? `${f.field_label}: ${formData[f.field_name]}` : null).filter(Boolean);
      const r = await createOrder({ customer_name: name.trim(), customer_phone: phone.trim(), customer_address: address.trim(), service_type: serviceType, service_name: subServiceName, merchant_id: merchantId, merchant_name: merchantName, items, description: items.join('\n'), notes: notes.trim(), is_guest: !isLoggedIn });
      if (r.success) {
        await playSendSound();
        if (!isLoggedIn) {
          setLastOrderId(r.data.id);
          setShowSuccessModal(true);
        } else {
          Alert.alert('✅ تم', 'تم إرسال الطلب بنجاح', [{ text: 'حسناً', onPress: () => navigation.popToTop() }]);
        }
      } else { Alert.alert('خطأ', r.error); }
    } catch (e) { Alert.alert('خطأ', 'فشل في إرسال الطلب'); }
    finally { setSending(false); }
  };

  const handleRegister = () => {
    setShowSuccessModal(false);
    navigation.navigate('CustomerAuth', {
      prefillName: name,
      prefillPhone: phone,
      fromGuestCheckout: true,
      pendingOrderId: lastOrderId,
    });
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#8B5CF6" /></View>;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {headerImg ? (
        <View style={styles.headerImageContainer}>
          <Image source={{ uri: headerImg }} style={styles.headerImage} />
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <Text style={styles.headerImageTitle}>{subServiceName}</Text>
        </View>
      ) : (
        <View style={[styles.header, { backgroundColor: '#8B5CF6' }]}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <View style={styles.backButtonCircle}><Ionicons name="arrow-back" size={22} color="#FFF" /></View>
          </TouchableOpacity>
          <View style={styles.headerCenter}><Text style={styles.headerTitle}>{subServiceName}</Text><Text style={styles.headerSubtitle}>املأ البيانات المطلوبة</Text></View>
          <View style={{ width: 40 }} />
        </View>
      )}

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}><Text style={styles.cardTitle}>👤 معلومات التواصل</Text><TextInput style={styles.input} value={name} onChangeText={setName} placeholder="الاسم الكامل" placeholderTextColor="#9CA3AF" /><TextInput style={styles.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="01xxxxxxxxx" placeholderTextColor="#9CA3AF" /><TextInput style={styles.input} value={address} onChangeText={setAddress} placeholder="العنوان التفصيلي" placeholderTextColor="#9CA3AF" /></View>
        {visibleFields.filter(f => f.is_visible !== false).map(field => (
          <View key={field.id} style={styles.card}>
            <View style={styles.fieldHeader}><Text style={styles.cardTitle}>{field.field_label}</Text>{field.is_required && <Text style={styles.required}>*</Text>}</View>
            {field.field_type === 'date' ? (
              <TouchableOpacity style={styles.dateField} onPress={() => openDatePicker(field.field_name)}><Ionicons name="calendar-outline" size={20} color="#8B5CF6" /><Text style={[styles.dateText, !formData[field.field_name] && { color: '#9CA3AF' }]}>{formData[field.field_name] || 'اختر التاريخ'}</Text></TouchableOpacity>
            ) : field.field_type === 'number' ? (
              <View style={styles.numberField}><TouchableOpacity style={styles.numBtn} onPress={() => updateField(field.field_name, String(Math.max(0, (parseInt(formData[field.field_name] || '0') || 0) - 1)))}><Ionicons name="remove" size={22} color="#8B5CF6" /></TouchableOpacity><View style={styles.numDisplay}><Text style={styles.numValue}>{formData[field.field_name] || '0'}</Text></View><TouchableOpacity style={styles.numBtn} onPress={() => updateField(field.field_name, String((parseInt(formData[field.field_name] || '0') || 0) + 1))}><Ionicons name="add" size={22} color="#8B5CF6" /></TouchableOpacity></View>
            ) : field.field_type === 'select' ? (
              <View style={styles.radioContainer}>{(field.field_options || []).map(opt => { const isSelected = formData[field.field_name] === opt; return (<TouchableOpacity key={opt} style={[styles.radioCard, isSelected && styles.radioCardActive]} onPress={() => updateField(field.field_name, opt)}><View style={[styles.radioCircle, isSelected && styles.radioCircleActive]}>{isSelected && <View style={styles.radioDot} />}</View><Text style={[styles.radioLabel, isSelected && styles.radioLabelActive]}>{opt}</Text></TouchableOpacity>); })}</View>
            ) : (
              <TextInput style={[styles.input, field.field_type === 'textarea' && styles.textarea]} value={formData[field.field_name]} onChangeText={(v) => updateField(field.field_name, v)} placeholder={field.placeholder || field.field_label} placeholderTextColor="#9CA3AF" multiline={field.field_type === 'textarea'} textAlignVertical={field.field_type === 'textarea' ? 'top' : 'auto'} />
            )}
          </View>
        ))}
        <View style={styles.card}><Text style={styles.cardTitle}>📝 ملاحظات</Text><TextInput style={[styles.input, styles.textarea]} value={notes} onChangeText={setNotes} placeholder="ملاحظات إضافية..." placeholderTextColor="#9CA3AF" multiline textAlignVertical="top" /></View>
        <TouchableOpacity style={[styles.sendBtn, sending && { opacity: .6 }]} onPress={sendOrder} disabled={sending}>{sending ? <ActivityIndicator color="#FFF" /> : <View style={styles.sendContent}><Ionicons name="send" size={20} color="#FFF" /><Text style={styles.sendText}>إرسال الطلب</Text></View>}</TouchableOpacity>
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* ✅ مودال النجاح للعملاء غير المسجلين */}
      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.successModal}>
            <View style={styles.successIcon}><Ionicons name="checkmark-circle" size={60} color="#10B981" /></View>
            <Text style={styles.successTitle}>✅ تم استلام طلبك!</Text>
            <View style={styles.successDivider} />
            <Text style={styles.successText}>رقم الطلب: <Text style={styles.successOrderId}>#{lastOrderId?.slice(-6) || '......'}</Text></Text>
            <Text style={styles.successSubtext}>لتتمكن من تتبع طلبك ومعرفة حالته، يرجى استكمال التسجيل.</Text>
            <TouchableOpacity style={styles.registerButton} onPress={handleRegister} activeOpacity={0.8}>
              <Ionicons name="person-add" size={20} color="#FFF" />
              <Text style={styles.registerButtonText}>حفظ بياناتي واستكمال التسجيل</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.laterButton} onPress={() => setShowSuccessModal(false)}>
              <Text style={styles.laterButtonText}>لاحقاً</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showDatePicker} transparent animationType="slide">
        <View style={styles.modalOverlay}><View style={styles.dateModal}><View style={styles.dateModalHeader}><TouchableOpacity onPress={() => setShowDatePicker(false)}><Text style={styles.cancelText}>إلغاء</Text></TouchableOpacity><Text style={styles.dateModalTitle}>اختر التاريخ</Text><TouchableOpacity onPress={confirmDate}><Text style={styles.doneText}>تم</Text></TouchableOpacity></View><View style={styles.mySelector}><TouchableOpacity onPress={() => { if (selectedMonth > 0) setSelectedMonth(selectedMonth - 1); else { setSelectedMonth(11); setSelectedYear(selectedYear - 1); } }}><Ionicons name="chevron-back" size={20} color="#8B5CF6" /></TouchableOpacity><Text style={styles.myText}>{MONTHS[selectedMonth]} {selectedYear}</Text><TouchableOpacity onPress={() => { if (selectedMonth < 11) setSelectedMonth(selectedMonth + 1); else { setSelectedMonth(0); setSelectedYear(selectedYear + 1); } }}><Ionicons name="chevron-forward" size={20} color="#8B5CF6" /></TouchableOpacity></View><View style={styles.weekRow}>{WEEKDAYS.map(d => <View key={d} style={styles.weekCell}><Text style={styles.weekDay}>{d}</Text></View>)}</View><View style={styles.daysGrid}>{blanks.map((_, i) => <View key={`b${i}`} style={styles.dayCell} />)}{days.map(day => (<TouchableOpacity key={day} style={[styles.dayCell, selectedDay === day && styles.dayCellActive]} onPress={() => setSelectedDay(day)}><Text style={[styles.dayText, selectedDay === day && styles.dayTextActive]}>{day}</Text></TouchableOpacity>))}</View></View></View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerImageContainer: { height: 160, position: "relative", justifyContent: "center", alignItems: "center" },
  headerImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  backButton: { position: 'absolute', top: 12, left: 12, zIndex: 10 },
  backButtonCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  headerImageTitle: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, textAlign: "center", textAlignVertical: "center", fontSize: 28, fontWeight: "900", color: "#FFF", textShadowColor: "#000", textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2, paddingTop: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, elevation: 2 },
  headerCenter: { alignItems: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#FFF' },
  headerSubtitle: { fontSize: 12, color: 'rgba(255,255,255,0.9)', marginTop: 4, textAlign: 'center' },
  content: { padding: 16 },
  card: { backgroundColor: '#FFF', borderRadius: 14, padding: 16, marginBottom: 14, borderWidth: 1, borderColor: '#E8ECF0' },
  cardTitle: { fontSize: 16, fontWeight: '700', color: '#1F2937', marginBottom: 10 },
  fieldHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 4 },
  required: { color: '#EF4444', fontSize: 16, fontWeight: '700' },
  input: { backgroundColor: '#F9FAFB', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1F2937', borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 10 },
  textarea: { minHeight: 80, textAlignVertical: 'top' },
  dateField: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 14, borderWidth: 1, borderColor: '#E5E7EB', gap: 10 },
  dateText: { fontSize: 14, color: '#1F2937', flex: 1 },
  numberField: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#F9FAFB', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 14, borderWidth: 1, borderColor: '#E5E7EB' },
  numBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#F0F0FF', justifyContent: 'center', alignItems: 'center' },
  numDisplay: { flex: 1, alignItems: 'center' },
  numValue: { fontSize: 22, fontWeight: '700', color: '#8B5CF6' },
  radioContainer: { gap: 8 },
  radioCard: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1.5, borderColor: '#E5E7EB', backgroundColor: '#F9FAFB', gap: 12 },
  radioCardActive: { borderColor: '#8B5CF6', backgroundColor: '#F0F0FF' },
  radioCircle: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: '#D1D5DB', justifyContent: 'center', alignItems: 'center' },
  radioCircleActive: { borderColor: '#8B5CF6' },
  radioDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#8B5CF6' },
  radioLabel: { fontSize: 15, color: '#4B5563', flex: 1 },
  radioLabelActive: { color: '#8B5CF6', fontWeight: '600' },
  sendBtn: { backgroundColor: '#8B5CF6', padding: 16, borderRadius: 14, alignItems: 'center', marginTop: 10 },
  sendContent: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sendText: { color: '#FFF', fontSize: 17, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  successModal: { backgroundColor: '#FFF', borderRadius: 24, padding: 28, alignItems: 'center', width: '88%', elevation: 10 },
  successIcon: { marginBottom: 12 },
  successTitle: { fontSize: 20, fontWeight: '800', color: '#1F2937', marginTop: 8 },
  successDivider: { height: 1, width: 40, backgroundColor: '#E5E7EB', marginVertical: 14 },
  successText: { fontSize: 14, color: '#4B5563' },
  successOrderId: { fontWeight: '700', color: '#4F46E5', fontSize: 16 },
  successSubtext: { fontSize: 13, color: '#6B7280', marginTop: 14, textAlign: 'center', lineHeight: 20 },
  registerButton: { flexDirection: 'row', backgroundColor: '#4F46E5', padding: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 20, gap: 8 },
  registerButtonText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  laterButton: { marginTop: 12, padding: 8 },
  laterButtonText: { color: '#9CA3AF', fontSize: 14 },
  dateModal: { backgroundColor: '#FFF', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 30 },
  dateModalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  dateModalTitle: { fontSize: 18, fontWeight: '700', color: '#1F2937' },
  cancelText: { fontSize: 15, color: '#EF4444' },
  doneText: { fontSize: 15, color: '#8B5CF6', fontWeight: '600' },
  mySelector: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', marginBottom: 12 },
  myText: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  weekRow: { flexDirection: 'row', marginBottom: 8 },
  weekCell: { width: COL_WIDTH, alignItems: 'center', paddingVertical: 4 },
  weekDay: { fontSize: 12, color: '#9CA3AF', fontWeight: '600' },
  daysGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: { width: COL_WIDTH, height: 42, justifyContent: 'center', alignItems: 'center', borderRadius: 21, marginBottom: 2 },
  dayCellActive: { backgroundColor: '#8B5CF6' },
  dayText: { fontSize: 15, color: '#1F2937', textAlign: 'center' },
  dayTextActive: { color: '#FFF', fontWeight: '700' },
});
