import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { Alert, Platform } from 'react-native';

// دوال الصوت - مع expo-audio الأذونات تدار تلقائياً
export const requestAudioPermission = async (showAlert = true) => {
  try {
    // expo-audio يدير الأذونات تلقائياً عند استخدام التسجيل
    console.log('✅ Audio permissions handled automatically by expo-audio');
    return true;
  } catch (error) { 
    console.error('Error checking audio permission:', error);
    if (showAlert) Alert.alert('تنبيه', 'التسجيل الصوتي غير متاح');
    return false;
  }
};

export const checkAudioPermission = async () => {
  try {
    // مع expo-audio، نفترض أن الأذونات متاحة
    return true;
  } catch (error) { 
    console.error('Error checking audio permission:', error);
    return false;
  }
};

export const requestCameraPermission = async (showAlert = true) => {
  try {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted' && showAlert) Alert.alert('تنبيه', 'التطبيق يحتاج إلى إذن الكاميرا');
    return status === 'granted';
  } catch (error) { 
    console.error('Error requesting camera permission:', error);
    return false;
  }
};

export const requestLocationPermission = async (showAlert = true) => {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted' && showAlert) Alert.alert('تنبيه', 'التطبيق يحتاج إلى إذن الموقع');
    return status === 'granted';
  } catch (error) { 
    console.error('Error requesting location permission:', error);
    return false;
  }
};

export const getCurrentLocation = async () => {
  try {
    const hasPermission = await requestLocationPermission(false);
    if (!hasPermission) return null;
    const location = await Location.getCurrentPositionAsync({});
    return { latitude: location.coords.latitude, longitude: location.coords.longitude };
  } catch (error) { 
    console.error('Error getting current location:', error);
    return null;
  }
};
