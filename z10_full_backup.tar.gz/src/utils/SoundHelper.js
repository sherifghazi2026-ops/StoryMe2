import { createAudioPlayer } from 'expo-audio';
import { supabase } from '../lib/supabaseClient';

let sendPlayer = null;
let notificationPlayer = null;
let soundTimeout = null;
let isPlaying = false;
let repeatCount = 0;
const MAX_REPEAT = 11; // 11 مرات × 5 ثواني = 55 ثانية

// ✅ إيقاف كل الأصوات
const stopAllSounds = async () => {
  try {
    if (notificationPlayer) {
      await notificationPlayer.pause();
      await notificationPlayer.seekTo(0);
    }
    if (sendPlayer) {
      await sendPlayer.pause();
      await sendPlayer.seekTo(0);
    }
  } catch (e) {}
};

// ✅ تحميل روابط الصوت
const fetchSoundUrls = async () => {
  try {
    const { data } = await supabase.from('app_settings').select('key, value').in('key', ['send_sound_url', 'notification_sound_url']);
    const urls = {};
    if (data) {
      data.forEach(item => { urls[item.key] = item.value; });
    }
    return urls;
  } catch (error) { return {}; }
};

export const loadSounds = async () => {
  const soundUrls = await fetchSoundUrls();

  // صوت الإرسال
  try {
    if (soundUrls.send_sound_url) {
      sendPlayer = createAudioPlayer({ uri: soundUrls.send_sound_url });
    } else {
      sendPlayer = createAudioPlayer(require('../../assets/sounds/send.mp3'));
    }
    console.log('✅ تم تحميل صوت الإرسال');
  } catch (e) {
    console.log('⚠️ فشل تحميل صوت الإرسال');
  }

  // صوت الإشعار - دايمًا من assets
  try {
    notificationPlayer = createAudioPlayer(require('../../assets/sounds/notification.mp3'));
    console.log('✅ تم تحميل صوت الإشعار المحلي');
  } catch (e) {
    console.log('⚠️ فشل تحميل صوت الإشعار');
  }
};

export const cleanup = () => {
  stopNotificationSound();
  if (sendPlayer) sendPlayer.remove();
  if (notificationPlayer) notificationPlayer.remove();
};

export const playSendSound = async () => {
  await stopAllSounds();
  if (sendPlayer) {
    sendPlayer.seekTo(0);
    await sendPlayer.play();
    console.log('🔊 صوت الإرسال');
  }
};

// ✅ تشغيل صوت الإشعار - مرة واحدة للعميل، تكرار للتاجر
export const startNotificationSound = (role = 'customer') => {
  stopAllSounds();
  
  if (role === 'customer') {
    // مرة واحدة فقط
    playOnce();
  } else {
    // تكرار للتاجر - كل 5 ثواني، 11 مرة = 55 ثانية
    repeatCount = 0;
    isPlaying = true;
    playRepeat();
  }
};

const playOnce = async () => {
  try {
    const player = notificationPlayer || createAudioPlayer(require('../../assets/sounds/notification.mp3'));
    player.seekTo(0);
    await player.play();
    console.log('🔔 صوت العميل - مرة واحدة');
  } catch (e) {
    console.log('⚠️ فشل تشغيل الصوت');
  }
};

const playRepeat = () => {
  if (!isPlaying || repeatCount >= MAX_REPEAT) {
    stopNotificationSound();
    return;
  }
  
  playOnce();
  repeatCount++;
  soundTimeout = setTimeout(playRepeat, 5000); // كل 5 ثواني
};

export const stopNotificationSound = () => {
  if (soundTimeout) clearTimeout(soundTimeout);
  stopAllSounds();
  isPlaying = false;
  repeatCount = 0;
  console.log('🔇 تم إيقاف صوت الإشعار');
};

export const playNotificationSound = startNotificationSound;
export const stopNotificationLoop = stopNotificationSound;
export const startNotificationLoop = startNotificationSound;
export const playSendSoundOnce = playSendSound;

export const useSoundEffect = () => ({
  playSendSound,
  playNotificationSound: startNotificationSound,
  startNotificationLoop,
  stopNotificationLoop,
  startNotificationSound,
  stopNotificationSound,
  playSendSoundOnce
});
