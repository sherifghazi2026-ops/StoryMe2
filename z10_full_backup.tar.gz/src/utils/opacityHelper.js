// دالة لحساب لون الخلفية مع الشفافية
// كلما زادت النسبة (90%) = خلفية أفتح (شفافية أكثر)
// كلما قلت النسبة (10%) = خلفية أغمق (شفافية أقل)
export const getBackgroundStyle = (bgOpacity, baseColor = '#000000') => {
  // bgOpacity تأتي كقيمة من 0 إلى 1 (0.3 = 30%)
  // نريد: كلما زادت النسبة، زادت الشفافية (خففت)
  // كلما قلت النسبة، قلت الشفافية (أغمق)
  const alpha = 1 - bgOpacity;
  return {
    backgroundColor: `rgba(0, 0, 0, ${alpha})`,
  };
};

// دالة لتطبيق الشفافية على الصورة الخلفية
export const getImageOverlayStyle = (bgOpacity) => {
  const alpha = 1 - bgOpacity;
  return {
    backgroundColor: `rgba(0, 0, 0, ${alpha})`,
  };
};

// دالة لتوليد لون متدرج مع شفافية
export const getGradientColors = (bgOpacity, colors) => {
  const alpha = 1 - bgOpacity;
  return colors.map(color => {
    if (color.startsWith('#')) {
      const r = parseInt(color.slice(1, 3), 16);
      const g = parseInt(color.slice(3, 5), 16);
      const b = parseInt(color.slice(5, 7), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    return color;
  });
};
