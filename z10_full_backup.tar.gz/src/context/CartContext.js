import React, { createContext, useContext, useState, useCallback } from 'react';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = useCallback((product) => {
    setCartItems(prev => {
      const existingIndex = prev.findIndex(item => item.id === product.id);
      
      if (existingIndex >= 0) {
        const newItems = [...prev];
        newItems[existingIndex] = {
          ...newItems[existingIndex],
          quantity: (newItems[existingIndex].quantity || 1) + (product.quantity || 1),
          isUnified: newItems[existingIndex].isUnified || product.isUnified,
        };
        return newItems;
      } else {
        return [...prev, { ...product, cartItemId: product.cartItemId || product.id, quantity: product.quantity || 1 }];
      }
    });
  }, []);

  const updateQuantity = useCallback((itemId, delta) => {
    setCartItems(prev => {
      return prev.map(item => {
        if (item.id === itemId || item.cartItemId === itemId) {
          const newQty = (item.quantity || 1) + delta;
          return newQty <= 0 ? null : { ...item, quantity: newQty };
        }
        return item;
      }).filter(Boolean);
    });
  }, []);

  const removeFromCart = useCallback((itemId) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId && item.cartItemId !== itemId));
  }, []);

  const clearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  const getTotalPrice = useCallback(() => {
    return cartItems.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 1)), 0);
  }, [cartItems]);

  const currentMerchant = cartItems.length > 0 ? {
    id: cartItems[0].merchantId,
    name: cartItems[0].merchantName,
  } : null;

  const itemCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);

  return (
    <CartContext.Provider value={{
      cartItems,
      currentMerchant,
      itemCount,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
      getTotalPrice,
    }}>
      {children}
    </CartContext.Provider>
  );
};

export default CartContext;
