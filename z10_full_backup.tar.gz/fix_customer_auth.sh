# نشوف الـ params اللي بتستقبلها CustomerAuthScreen
grep -n "fromGuestCheckout\|route.params" ~/Z1/src/screens/CustomerAuthScreen.js | head -20
