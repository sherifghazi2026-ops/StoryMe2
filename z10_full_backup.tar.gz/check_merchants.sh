#!/bin/bash
echo "🔍 فحص جدول merchants..."
echo "SELECT id, name, service_type, is_active FROM merchants;" | supabase db query
echo ""
echo "🔍 فحص جدول services..."
echo "SELECT id, name, is_active FROM services;" | supabase db query
echo ""
echo "🔍 فحص جدول user_tokens..."
echo "SELECT user_id, platform FROM user_tokens;" | supabase db query
