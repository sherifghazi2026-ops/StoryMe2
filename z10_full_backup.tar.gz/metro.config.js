const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// دعم الملفات الصوتية
config.resolver.assetExts.push('mp3', 'wav', 'ogg');

module.exports = config;
